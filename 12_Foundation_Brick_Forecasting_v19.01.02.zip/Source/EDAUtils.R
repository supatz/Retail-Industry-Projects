
# packages <- c("png","grid","ggplot2","gridExtra","htmlTable","moments","xtable","knitr","rmarkdown","igraph","corrgram","qgraph","pander","dplyr","tseries","GGally","corrr","corrplot","nFactors","data.table","lsr","spaa","car","forecast","reshape2","reshape","qpcR","sp","dummies","GPArotation","cluster","ggfortify","stats","DandEFA","deldir","viridis","lattice", "shinyjs", "stringi", "dendextend","colourpicker")

#Importing all packages
# lapply(packages, FUN = function(p){ loadPackage(p) })

# Numeric descriptive statistics
numericStats <- function(data){
  num_desc_list <- lapply(data, function(x) {
    
    ## calculating different statistics for numerical continuous variables
    min_val <-  min(x, na.rm = T) %>% round(3)
    max_val <-  max(x, na.rm = T) %>% round(3)
    mean_val <- mean(x, na.rm = T) %>% round(3)
    median_val <- stats::median(x, na.rm = T) %>% round(3)
    sd_val <- stats::sd(x, na.rm = T) %>% round(3)
    unique_val <- unique(x) %>% length()
    no_of_na <- is.na(x) %>% sum()
    no_of_lines <- x %>% length()
    data_skewness <-timeDate::skewness(x, na.rm = TRUE) %>% round(3)
    data_kurtosis <- timeDate::kurtosis(x, na.rm = TRUE) %>% round(3)
    
    data.frame(
      "N" = no_of_lines,
      "Unique" = unique_val,
      "Missing" = no_of_na,
      "Min" = min_val,
      "Max" = max_val,
      "Mean" = mean_val,
      "Median" = median_val,
      "SD" = sd_val,
      "Skewness" = data_skewness,
      "Kurtosis" = data_kurtosis
    )
  })
  
  data_sum <- do.call(rbind, num_desc_list)
  data_sum <- cbind(data.frame(ColumnName = rownames(data_sum)), data_sum)
  rownames(data_sum) <- NULL
  return(data_sum)
}

# Categorical Stats
categoricStats <- function(data){
  cat_desc_list <- lapply(data, function(x) {
    
    mat_cat <- table(x)
    mode <- names(mat_cat)[mat_cat == max(mat_cat)]
    mode <- ifelse(length(mode) > 1, "No mode", mode)
    uniq_val <- length(unique(x))
    total_rows <- length(x)
    missing_perc <- round((sum(is.na(x))*100/total_rows), 3)
    data.frame('N' = total_rows,
               'Unique' = uniq_val,
               'Missing' = missing_perc,
               'Mode' = mode)
  })
  
  data_sum <- do.call(rbind, cat_desc_list)
  data_sum <- cbind(data.frame(ColumnName = rownames(data_sum)), data_sum)
  rownames(data_sum) <- NULL
  return(data_sum)
}

# Observe Categoric Levels
observeCatLevels <- function(data){
  cat_col_desc_list <- lapply(colnames(data), function(i) {
    
    count_lvl <- data %>% 
      group_by_(i) %>% 
     dplyr::summarise(freq = n())
    j <- sapply(count_lvl, is.factor)
    count_lvl[j] <- lapply(count_lvl[j], as.character)
    count_lvl <- count_lvl %>% 
      plotly::mutate(freq_perc = round((freq / length(data[,i]))*100, 3))
    count_lvl <- cbind(i, count_lvl)
    colnames(count_lvl) <- c("Column Name", "Level", "Frequency", "Frequency %")
    count_lvl <- count_lvl[order(-count_lvl[,4]),]
    count_lvl
  })
  
  cat_col_sum <- do.call(rbind, cat_col_desc_list)
  return(cat_col_sum)
}

# Missing Value Detection Function 
missingValue <- function(data,lower = 0,upper = 100){
  missingVal <- sapply(data,function(x){
    (sum(is.na(x))*100)/length(x)
  },USE.NAMES = F)
  missingVal <- round(missingVal,2)
  missingVal <- as.data.frame(missingVal)
  missingVal <- cbind(colnames(data),missingVal)
  missingVal <- missingVal %>% filter(missingVal >= lower,
                                      missingVal < upper)
  colnames(missingVal) <- c("Column Name","% of Missing Values")
  return(missingVal)
}

# Univariate Numeric Distribution function
univarNumDistPlots <- function(data, uniCol, priColor, secColor){
  distHistogram <- ggplot2::ggplot(data, 
                                   ggplot2::aes(x = data[,uniCol])) +
    ggplot2::geom_histogram(
      ggplot2::aes(y = ..density..),
      color = "black",
      fill = priColor,
      size = 0.2
    ) +
    ggplot2::stat_density(aes(color = "Density"), geom = "line", linetype = "dashed") +
    ggplot2::stat_function(aes(color = "Normal"), fun = dnorm, 
                  args = list(
                   mean = mean(data[, uniCol]),
                   sd = stats::sd(data[, uniCol])
                  )
    ) +
    ggplot2::xlab(uniCol) +
    ggplot2::ylab('Frequency') +
    ggplot2::theme(legend.position = c(0.8, 0.8)) +
    ggplot2::scale_colour_manual("Plot type", values = c(secColor, "#EE7600")) +
    ggplot2::scale_linetype_manual("Plot type", values = c("Normal" = 2, "Density" = 1)) +
    ggplot2::guides(
      fill = ggplot2::guide_legend(keywidth = 1, keyheight = 1),
      linetype = ggplot2::guide_legend(keywidth = 3, keyheight = 1),
      colour = ggplot2::guide_legend(keywidth = 3, keyheight = 1)
    )
  
  distBox <- ggplot2::ggplot(data, 
                             ggplot2::aes(x = 1, y = data[, uniCol])) +
    ggplot2::geom_boxplot(fill=priColor) +
    ggplot2::xlab(' ') +
    ggplot2::ylab(uniCol) +
    ggplot2::theme(
      axis.title.x = ggplot2::element_blank(),
      axis.text.x = ggplot2::element_blank(),
      axis.ticks.x = ggplot2::element_blank()
    )
  return(list(distHistogram, distBox))
}


# Univariate Categoric Distribution function
univarCatDistPlots <- function(data, uniCol, priColor){
  levels(data[[uniCol]]) <- c(levels(data[[uniCol]]), "NA")
  data[[uniCol]][is.na(data[[uniCol]])] <- "NA"
  data <- data %>% group_by_(.dots = c(uniCol)) %>%dplyr::summarise(count = n())
  
  catPlot <- ggplot2::ggplot(data, 
                             ggplot2::aes(x = reorder(data[[uniCol]], count), y=count)) +
    ggplot2::geom_bar(stat = "identity", color = priColor, fill = priColor) + 
    ggplot2::xlab(uniCol) +
    ggplot2::ylab('Frequency') +
    ggplot2::theme(
      axis.title = ggplot2::element_text(size = 16)
    ) +
    ggplot2::coord_flip()
  
  return(catPlot)
}


# Univariate Outlier Statistic Function
outlierStatistic <- function(data,method){
  if(method == "percentile"){
    summaryTable <- sapply(data,function(x){
      stats::quantile(x,c(0.0,.01,.05,.10,.25,.50,.75,.90,.95,.99,1),na.rm = T)
    })
    summaryTable <- round(summaryTable,3)
    summaryTable <- t(summaryTable)
    rownames(summaryTable) <- NULL
    summaryTable <- cbind(colnames(data),summaryTable)
    colnames(summaryTable) <- c("Column Name","P_00","P_01","P_05","P_10",
                                "P_25","P_50","P_75","P_90","P_95","P_99",
                                "P_100")
    summaryTable <- as.data.frame(summaryTable)
    return(summaryTable)
  }
  if(method == "iqr"){
    quantile13 <- sapply(data,function(x){
      quantile(x,c(0.25,0.75),na.rm = T)
    })
    quantile13 <- t(quantile13)
    IQR <- sapply(data,function(x){
      IQR(x,na.rm = T)
    })
    summaryTable <- cbind(round(quantile13,3),round(IQR,3))
    summaryTable <- data.frame(summaryTable)
    colnames(summaryTable) <- c("first","third","iqr")
    summaryTable <- summaryTable %>% plotly::mutate(first1 = round((first - 1.5*iqr),3))
    summaryTable <- summaryTable %>% plotly::mutate(third1 = round((third + 1.5*iqr),3))
    summaryTable <- summaryTable %>% plotly::mutate(first3 = round((first - 3*iqr),3))
    summaryTable <- summaryTable %>% plotly::mutate(third3 = round((third + 3*iqr),3))
    summaryTable <- cbind(colnames(data),summaryTable)
    colnames(summaryTable) <- c("Column Name","25%","75%","IQR",
                                "-1.5*IQR","+1.5*IQR","-3*IQR","+3*IQR")
    return(summaryTable)
  }
  if(method == "z_score"){
    meanData <- sapply(data,function(x){
      mean(x,na.rm =T)
    })
    stdDev <- sapply(data,function(x){
      stats::sd(x, na.rm = T)
    })
    summaryTable <- cbind(round(meanData,3),round(stdDev,3))
    summaryTable <- data.frame(summaryTable)
    summaryTable <- cbind(colnames(data),summaryTable)
    colnames(summaryTable) <- c("colname","Mean","SD")
    summaryTable <- summaryTable %>% plotly::mutate(zp1 = round((Mean + SD),3),
                                            zp2 = round((Mean + (SD*2)),3),
                                            zp3 = round((Mean + (SD*3)),3),
                                            zn1 = round((Mean - SD),3),
                                            zn2 = round((Mean - (SD*2)),3),
                                            zn3 = round((Mean - (SD*3)),3))
    colnames(summaryTable) <- c("Column Name","Mean","SD","+1 SD","+2 SD",
                                "+3 SD","-1 SD","-2 SD","-3 SD")
    return(summaryTable)
  }
}


# Outlier Detection Function
outlierDetection <- function(data,method,columnName,cutoffValue){
  if(TRUE %in% unique(is.na(data[,columnName])))
  {
    data <- data[-which(is.na(data[,columnName])== T),]
  }
  if(method == "iqr"){
    lower <- stats::quantile(data[,columnName],.25,na.rm = T) - 1.5*(IQR(data[,columnName],na.rm = T))
    upper <- stats::quantile(data[,columnName],.75,na.rm = T) + 1.5*(IQR(data[,columnName],na.rm = T))
    data$Outlier <- data[,columnName] > upper | data[,columnName] < lower
    return(data)
  }
  if(method == "percentile"){
    lower <- stats::quantile(data[,columnName],cutoffValue,na.rm = T)
    upper <- stats::quantile(data[,columnName],(1-cutoffValue),na.rm = T)
    data$Outlier <- data[,columnName] > upper | data[,columnName] < lower
    return(data)
  }
  if(method == "z_score"){
    lower <- mean(data[,columnName],na.rm = T) - (cutoffValue*(stats::sd(data[,columnName],na.rm = T)))
    upper <- mean(data[,columnName],na.rm = T) + (cutoffValue*(stats::sd(data[,columnName],na.rm = T)))
    data$Outlier <- data[,columnName] > upper | data[,columnName] < lower
    return(data)
  }
} 


#Outlier Plot Function 
outlierPlot<- function(data,method,columnName,cutoffValue, priColor){
  if(method == "iqr"){
    
    outlierPlot <- ggplot2::ggplot(data, ggplot2::aes(x="", y = data[,columnName,drop = F])) +
      ggplot2::geom_boxplot() + ggplot2::ylab(columnName) + ggplot2::xlab("")
    return(outlierPlot)
  }
  if(method == "percentile"){
    
    outlierPlot <- ggplot2::ggplot(data) + 
      ggplot2::geom_histogram(ggplot2::aes(x = data[,columnName], fill = data$Outlier),bins=30) +
      ggplot2::scale_fill_manual(values = c(priColor, "red"),breaks=c("FALSE", "TRUE"),
                        labels=c("Normal", "Outlier"),name = "Status") +
      ggplot2::xlab(columnName)
    return(outlierPlot)
  }
  if(method == "z_score"){
    data$zScore <- scale(data[,columnName,drop = F],center = T, scale = T)
    outlierPlot <- 
      ggplot2::ggplot(data, ggplot2::aes(x = data$zScore, y = data[,columnName,drop = F])) +
      ggplot2::geom_point(aes(color = Outlier))+     
      ggplot2::scale_color_manual("Status", values = c("TRUE" = "red","FALSE" ="grey50"))+
      ggplot2::ylab(columnName)+
      ggplot2::xlab("Z-score")+
      ggplot2::geom_vline(xintercept = (cutoffValue),linetype = "dashed")+
      ggplot2::geom_vline(xintercept = -(cutoffValue), linetype = "dashed") 
    return(outlierPlot)
  }
}


#Multivariate Outlier Detection
multiVarOutlier <- function(data,depCol,indepCol,cutoffValue){
  
  if(TRUE %in% unique(is.na(data[,depCol])))
  {
    data <- data[-which(is.na(data[,depCol])== T),]
  }
  
  indep_form <- paste(indepCol, collapse = "+")
  form <- paste(depCol, indep_form, sep = "~")
  form <- stats::formula(form)
  
  lmObject <- stats::lm(form,data)
  limit <- nrow(data)
  outlierDetect <- outlierTest(lmObject,cutoffValue,n.max = limit)
  outlierDetect <- data.frame(outlierDetect[c(1,2,3)])
  outlierDetect <- round(outlierDetect, 4)
  colnames(outlierDetect) <- c("Studentized Residuals","P-Value",
                               "P-Value(Bonferroni Correction)")
  data$Outlier <- ifelse(rownames(data) %in% rownames(outlierDetect),"Outlier","Normal")
  outlierTable <- data %>% filter(Outlier == "Outlier")
  outlierTable <- cbind(outlierDetect,outlierTable)
  return(list(data,outlierTable))
}


#Mutlivariate Outlier Plot Function
multiVarOutlierPlot <- function(data,depCol,indepCol,sizeCol, priColor){
  
  outlierPlot <- ggplot2::ggplot(data,ggplot2::aes(x = data[,indepCol],y = data[,depCol]))+
    ggplot2::geom_point(ggplot2::aes(color = Outlier, size = data[,sizeCol]))+
    ggplot2::scale_color_manual("Status",values = c("TRUE" = "red", "FALSE" = priColor))+
    ggplot2::labs(title = paste(depCol,"vs",indepCol)) +
    ggplot2::ylab(depCol) +
    ggplot2::xlab(indepCol)+
    ggplot2::labs(size = sizeCol)
  return(outlierPlot)
}


# Creates dummy variables for string categorical columns of a dataset
DummyVarCreation <- function(columnToConvert, outPath = getwd(), fileName = paste("DummyVariableLog_", deparse(substitute(columnToConvert)), sep = ""), 
                             referenceLevel = NA, cutoffValue = 20) {
  
  levelDropVec <- c()
  
  # Checking data Quality
  
  if (length(columnToConvert) > 0 && nrow(columnToConvert) > 0){
    #Creating dummy columns to remove
    dummyColsToRemove <- c()
    
    if(is.na(referenceLevel) || is.null(referenceLevel) || referenceLevel == ""){
      freqDf <- data.frame(table(columnToConvert))
      minFreqVal <- freqDf[which.min(freqDf[, 2]), 1 ]
      minFreqVal <- as.character(minFreqVal)
      referenceLevel <- minFreqVal
    }
    columnName <- names(columnToConvert)
    columnToConvert[[1]] <- as.character(columnToConvert[[1]])
    names(columnToConvert) <- columnName
    dummyColsToRemove <- c(dummyColsToRemove, referenceLevel)
    levelDropVec <- c(levelDropVec, paste(colnames(columnToConvert), sep = "_", referenceLevel))
    
    #creation of dummy variables 
    if(length(unique(columnToConvert[[1]]))>2){
      dummys <- dummy.data.frame(columnToConvert, sep = "_")
      #Removal of columns
      dummys <- dummys[, !colnames(dummys) %in% levelDropVec]
    }else{
      # If its a binary column
      dummys <- as.data.frame(as.numeric(columnToConvert != referenceLevel))
      colnames(dummys) <- paste(colnames(columnToConvert),
                                unique(columnToConvert)[unique(columnToConvert) != referenceLevel],sep='_')
    }
  }
  return(list(dummys, referenceLevel))
}


# Return the column type 
CheckColumnType <- function(dataVector) {
  
  #Check if the column type is "numeric" or "character" & decide type accordingly
  if (class(dataVector) == "integer" || class(dataVector) == "numeric") {
    #Extract number of unique levels in the dataVector
    numUnique <- length(unique(dataVector))
    #Check for cut-off condition
    columnType <- "numeric"
  } else { columnType <- "character" }
  #Return the result
  return(columnType)
  
}

getCorrMat <- function(dataset, methodused = "everything"){
  print(dataset)
  cormat <-base::round(cor(dataset, use = methodused),3)
  return(cormat)
}





inDataType_func <- function(conList, dbName){
  # ref <- dataRefresh$refresh
  #conList <- inDataReactive$inData
  
  if(is.null(conList$con)){ # CSV --------
    dat <- conList$table
  }
  else { # DB  ---------
    fn <- function(){tryCatch(dbFetchTop(conList, dbName),warning=function(w){message(w[1]);dbFetchTop(conList, dbName)},error=function(e){message(e[1])})}
    dat <- fn()
    #inDataHead <<- dat
  }
  
  if(is.null(dat)) return(NULL)
  dat <- collect(utils::head(dat,n=10))
  
  dtypes <-unlist(lapply(lapply(dat,class),function(x){return(x[1])}))
  data.frame(col=colnames(dat),dataType=dtypes,stringsAsFactors = F)
}


clearResults <- function(con){
  if(class(con)=='SQLiteConnection') return()
  if(dbResultLen(con)){
    DBI::dbClearResult(DBI::dbListResults(con)[[1]])
  }
}

dbResultLen <- function(con){
  return(length(DBI::dbListResults(con)))
} 





## Download Report

downloadReport <- function(reactData, input, downloadData, fileName){
  require(rmarkdown)
  print(input$format)
  rmarkdown::render('Source/report.Rmd',
                    params = list(reactData = reactData,
                                  downloadData = downloadData,
                                  input = input),
                    switch(input$format,
                           PDF = pdf_document(),
                           PrettyHTML = prettydoc::html_pretty(css = paste0(reactData$working_dir ,
                                                                            "/Styles/pretty_styles.css")),
                           HTML = html_document(css = paste0(reactData$working_dir,"/Styles/styles.css") ,toc= T,toc_float= T),
                           
                           MSWord = word_document(toc = T)),
                    output_dir = paste0(reactData$working_dir,"/Downloads/") , 
                    output_file = paste(fileName,switch( input$format, 
                                                         PDF = '.pdf', 
                                                         HTML = '.html',
                                                         PrettyHTML = '_pretty.html', 
                                                         MSWord = ".doc"),sep='')
  )
}