parseBrickName <- function()
{
  x <- rjson::fromJSON(file = "Source/Description.json")$filename
  return(x)
}

postUsageMetric <- function()
{
  brickName <- parseBrickName()
  ts <- Sys.time()
  ts <- as.character(as.POSIXct(ts, tz="Asia/Kolkata")) # converting to IST
  
  # Step 1: Check if log file exists; create if not
  usage <- base::list.files("Source/", pattern = "usage.RDS")
  if(base::length(usage)==0)
  {
    usage <- base::list(ts)
    base::saveRDS(usage, "Source/usage.RDS")
  }else
  {
    usage <- base::readRDS("Source/usage.RDS")
    usage <- base::append(usage, ts)
    base::saveRDS(usage, "Source/usage.RDS")
  }
  
  # Step 2: Finding user details
  info <- base::as.list(Sys.info())
  os <- info$sysname
  node <- info$nodename
  login <- info$login
  username <- info$user
  effective_uname <- info$effective_user
  count <- base::unlist(usage)
  serviceName <- "prefabs"
  
  payload <- list()
  base::lapply(count, function(x){
    body <- base::paste0('{"os":"', os,'", "serviceName":"prefabs", "brickName":"', brickName, '", "node":"', node,'", "login":"', login, '", "username":"', username,'", "effective_uname":"', effective_uname,'", "timestamp":"', x, '"}')   
    payload <<- base::append(payload, body)
  })
  payload <- base::unlist(payload)
  payload <- base::paste0("[", paste0(payload, collapse = ","), "]")
  
  val <- httr::POST("https://eoc.mu-sigma.com/phoenix/logging-service/logs",
                    httr::add_headers('Content-Type'= 'application/json', 'Authorization' = "Basic aW5jZW5kaW86YWd1YW1lbnRp"),
                    body = payload, timeout(20))
  if(val$status_code == 200)
    base::unlink("Source/usage.RDS")
}
