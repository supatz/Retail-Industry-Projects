reportIssue <- function(projectID, input, output, session)
{
  # packages <- c("httr", "rjson")
  # loadPackage <- function(pkgName){
  #   if (!do.call(require, list(pkgName))) {
  #     install.packages(pkgName, dependencies = T, repos = "http://cran.us.r-project.org")
  #     do.call(library, list(pkgName))
  #   }
  # }
  # lapply(packages, FUN = function(p){ loadPackage(p) })
  user_token<-""
  git_url <- "https://mugitlab.mu-sigma.com/api/v4"
  
  # UI end
  output$file_upload<-shiny::renderUI({shiny::tagList(shiny::fileInput('attachment','Add attachment'))})
  stored<-F
  shiny::observe({
    if(stored==F){
      output$userpass<-shiny::renderUI({shiny::inputPanel(shiny::tags$p("Please enter your Windows credentials:",style="width:1000px;font-weight: bold;"),shiny::tags$br(),shiny::tags$br(),shiny::textInput("usrnme", "Username", value = "",width = NULL, placeholder = NULL),shiny::passwordInput("passw", "Password", value = "",width = NULL, placeholder = NULL),shiny::tags$br(),shiny::actionButton("logn", "Login"))})
    }
  })
  
  
  
  shiny::observeEvent(input$logn,{
    progress <- shiny::Progress$new()
    on.exit(progress$close())
    progress$set(message = "Logging In")
    
    login = input$usrnme
    password = input$passw
    current_user<-strsplit(input$usrnme,".",fixed=T)
    current_user<-lapply(current_user,function(x){paste0(toupper(substr(x,1,1)),substr(x,2,nchar(x)))})
    if(length(current_user[[1]])>1){
      current_user<-paste0(current_user[[1]][1],".",current_user[[1]][2])}
    else{
      current_user<-current_user[[1]][1]}
    
    tryCatch({
      session_info <- httr::POST('https://mugitlab.mu-sigma.com/oauth/token',
                           httr::add_headers('Content-Type'= 'application/json'),
                           body=paste0('{"grant_type":"password", "username":"',login,'", "password":"',password,'"}'))
      user_token <<- rjson::fromJSON(rawToChar(session_info$content))$access_token
      if (session_info[[2]]==200)
      {
        stored<-T
        output$mssge<-shiny::renderUI({shiny::tags$p("")})
        output$userpass<-shiny::renderUI({})
        #--------------------------checking user access status----------------------#
        current_members <- c()
        for(i in 1:100)
        {
          current_members_temp <- httr::GET(paste0(git_url,"/groups/214/members?page=",i,"&per_page=100"),
                                      httr::accept_json(),
                                      httr::add_headers("Authorization" = paste0("Bearer ",user_token)),httr::timeout(6)
          )
          current_members_temp <-  rjson::fromJSON(rawToChar(current_members_temp$content))
          if(length(current_members_temp) == 0)
            break
          current_members <- c(current_members,current_members_temp)
        }
        current_user_id = NULL
        for(i in current_members)
        {
          
          if(tolower(current_user) == tolower(i$username))
          {
            current_user_id = i$id
            
            break
          }
        }
        current_user_id
        
        if(is.null(current_user_id))
        {
          #trigger flow
          url = "http://qa.ird.mu-sigma.com/exposerestwebservice/muflow/runFlow/runWithReturn"
          payload = paste0('{"flowId": "/eoc/add_member_to_git", "type": "Deployment","variableBean": [{ "name": "current_user_id", "value": "', current_user_id,'","direction": "in"}]}')
          tryCatch({
            val=httr::POST(paste0(url),
                     httr::add_headers('Content-Type'= 'application/json'),
                     body = payload,httr::timeout(20))
            if(rawToChar(val$content)!=201)
            {
              user_token<<-"hxpbK1dzcrva_yoSZHir"
              output$mssge<-shiny::renderUI({ shiny::tags$p("We are unable to add you to the brick's repository, but you can still post issues.",style="color:red")  })
            }  
          },error = function(e) {
            user_token<<-"hxpbK1dzcrva_yoSZHir"
            output$mssge<-shiny::renderUI({ shiny::tags$p("We are unable to add you to the brick's repository, but you can still post issues.",style="color:red")  })
          }) 
        }
        output$userpass<-shiny::renderUI({shiny::inputPanel(shiny::textAreaInput("Issue", "Issue", value = "",width = 700,height=40, placeholder = NULL),shiny::tags$br(),shiny::tags$br(),shiny::textAreaInput("Description", "Description", value = "",width=700,height=100, placeholder = NULL),shiny::tags$br(),shiny::tags$br(), shiny::uiOutput("file_upload"),shiny::tags$br(),shiny::selectInput("label","Label",c("Bug", "Feature Enhancement","Feature Request","Formatting Changes","Help"),selected = NULL,multiple=T),shiny::actionButton("submit", "Submit Issue"))})
      }else
      {
        output$mssge<-shiny::renderUI({shiny::tagList( shiny::tags$p("Wrong username or password",style="color:red")  ,shiny::tags$p("If are using this feature for the first time please login",shiny::tags$a(href="https://mugitlab.mu-sigma.com/","here once"),style="color:red") )  })
        shiny::updateTextInput(session, "usrnme", value="")
        shiny::updateTextInput(session, "passw", value="")
      }
    },error = function(e) {output$mssge<-shiny::renderUI({shiny::tags$p("unable to access gitlab from your network",style="color:red")})}
    
    )}
  ) # end of input$logn shiny::observeEvent
  
  shiny::observeEvent(input$attachment,{
    progress <- shiny::Progress$new()
    on.exit(progress$close())
    progress$set(message = "Reporting Issue")
    tryCatch({
      file_path <- httr::POST(paste0(git_url,"/projects/", projectID, "/uploads"),
                        httr::accept_json(),
                        httr::add_headers("Content-Type" = "multipart/form-data","Authorization" = paste0("Bearer ",user_token)),
                        body = list("file" = httr::upload_file(input$attachment$datapath)),httr::timeout(6))
      fm <- rjson::fromJSON(rawToChar(file_path$content))$markdown
      fm_update <- paste0("!",fm)
      shiny::updateTextInput(session, "Description", value=paste0(input$Description,"\n",fm_update))
      output$file_upload<-shiny::renderUI({shiny::tagList(shiny::fileInput('attachment','Add attachment'))})
    },error = function(e) {output$mssge<-shiny::renderUI({shiny::tags$p("Can't upload attachment, unable to access gitlab from your network. Please try again",style="color:red")})}
    
    
    )}
  ) # end of input$attachment shiny::observeEvent
   
  shiny::observeEvent(input$submit,{
    progress <- shiny::Progress$new()
    on.exit(progress$close())
    progress$set(message = "Reporting Issue")
    tryCatch({
      issueList <- list("title"=input$Issue,
                        "description"=paste(input$Description),
                        "labels"=paste(input$label,collapse=","))
      issue_posted<-httr::POST(paste0(git_url,"/projects/", projectID, "/issues"),
                         httr::accept_json(),
                         httr::add_headers("Content-Type" = "application/json","Authorization" = paste0("Bearer ",user_token)),
                         body = rjson::toJSON(issueList),httr::timeout(6))
      stored<-T
      output$mssge<-shiny::renderUI({shiny::tags$p(paste0("Your issue with issue id ",rjson::fromJSON(rawToChar(issue_posted$content))['iid']," has been posted on mugitlab"),style="color:green")} )
      shiny::updateTextInput(session, "Issue", value="")
      shiny::updateTextInput(session, "Description", value="")
      shiny::updateTextInput(session, "label", value="")
    },error = function(e) {output$mssge<-shiny::renderUI({shiny::tags$p("Can't post issues, unable to access gitlab from your network. Please try again",style="color:red")})}
    
    )}
  ) # end of input$submit shiny::observeEvent
} # end of reportIssue function
