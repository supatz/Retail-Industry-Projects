library(testthat)

library(futile.logger)
set.seed(145)

flog.threshold(INFO)
# flog.appender(appender.file("./testCaseSummary.log"))
flog.appender(appender.file("./testCases.log"))

testResults <- as.data.frame(testthat::test_file("testCases.R"))

summary <- list()
summary[['Number of tests run']] <- nrow(testResults)#196
summary[['Numeber of tests failed']] <- sum(testResults$failed)

flog.info( knitr::kable(testResults))
flog.info("*************************************************************************************************************")
flog.info("Summary of test cases for this build")
flog.info(knitr::kable(as.data.frame(summary)))


if(sum(testResults$failed) > 0){
  stop()
}else{
  print("All tests passed. Pushing build...")
  flog.info("All tests passed. Pushing build...")
}


#

################################################

library("devtools")

testPackageName<-"testcovr"

# set value according to brick 
# EDA
# Data Wrangling
# Regression
# Classification
# Panel Regression
# Text Mining
# Segmentation
# Quality Check
# SQL

brickName<-"Text Mining"

#Delete old testing package if exists
if(dir.exists(testPackageName)){
  unlink(testPackageName,recursive = T)
}
library("covr")
total_coverage <- file_coverage('TextMiningUtils.R','testCases.R')


unit_test_coverage_percentage<-"0%"

unit_test_coverage_percentage<-paste0(as.character(round(percent_coverage(total_coverage),2)),"%")


#### Deleting the test package
unlink(testPackageName,recursive = T)

number_of_unit_test<-0
number_of_unit_test<-nrow(testResults)

#### Read Number of lines ####


openedFile <- file("TextMiningUtils.R",open="r")
readsizeof <- 20000
lines_of_code<-0
(while((linesread <- length(readLines(openedFile,readsizeof))) > 0 )
  lines_of_code <- lines_of_code+linesread )
close(openedFile)
lines_of_code = as.character(lines_of_code)

##### upload results to DB ######


unit_coverage<-unit_test_coverage_percentage
issues<-"0"
number_of_int_tests<-"0"
## lint function is masked by devtools
detach("package:devtools", unload=TRUE)
library("lintr")
warnings_lint<-lintr::lint("TextMiningUtils.R")
warnings_data_frame <- as.data.frame(warnings_lint)
warnings_list <- as.list(table(warnings_data_frame$type))
issues<-as.character(warnings_list$warning[1])

# Use RPostgreSQL package to connect into database directly and import tables into dataframes.
library("RPostgreSQL")
# loads the PostgreSQL driver
drv <- dbDriver("PostgreSQL")
## Open connection
con <- dbConnect(drv, host='172.25.1.30', port='5432', dbname="metric", user='postgres', password='postgres')


## Submits a statement
dbSendQuery(con, paste0("INSERT INTO eoc_brick_metrics VALUES (\'",brickName,"\',\'",lines_of_code,"\',\'",number_of_unit_test,"\',\'",issues,"\',\'",number_of_int_tests,"\',\'",unit_test_coverage_percentage,"\');"))

## Closes the connection
dbDisconnect(con)
## Frees all resources in the driver
dbUnloadDriver(drv)

#############################################################################################################
#####                               METRIC COVERAGE REPORTING ENDS                                      #####
#############################################################################################################

