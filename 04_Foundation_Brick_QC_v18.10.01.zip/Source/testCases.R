
list.of.packages <- list(
  'devtools'
  ,'shiny'
  ,'shinyjs'
  ,'shinyBS'
  ,'knitr'
  ,'DT'
  ,'dplyr'
  ,'ggplot2'
  ,'rJava'
  ,'RPostgreSQL'
  ,'RMySQL'
  ,'RSQLite'
  ,'lubridate'
  #,'RODBC'
  #,'xlsx'
  #,'dbplyr'
  ,'data.table'
  ,'DBI'
  ,'RJDBC'
  ,'httr'
  ,'rjson'
  ,'data.table'
  #,'RODBCDBI'
  #,'ROracle'
)

pkgTest <- function(x)
{
  if (!require(x,character.only = TRUE))
  {
    # if(x=='dbplyr'){
    #   devtools::install_github("hadley/dbplyr")
    #   return()
    # }
    install.packages(x,dep=TRUE,repos='https://cran.rstudio.com/')
    if(!require(x,character.only = TRUE)) stop(paste0("Package not found : ",x))
  }
}
lapply(list.of.packages,pkgTest)

source("utils.R")
# source('buildPush.R')

library(testthat)
library(futile.logger)
set.seed(7)

options(warn = -1)

flog.threshold(INFO)
flog.appender(appender.file("./testCases.log"))

allTestResults <- list()
allTestResultsConnect = list()
allTestResultsInDataType_func = list()
allTestResultsInDatCols_func = list()
allTestResultsGetRuleListTableNames = list()
allTestResultsGetMetafileNames = list()
allTestResultsMetaFileLoad = list()
allTestResultsUseMetaFile = list()
allTestResultsPcquery = list()
allTestResultsDbResultLen = list()
allTestResultsClearResults = list()
allTestResultsJoinTables = list()
allTestResultsFilterTransform = list()
allTestResultsParaTransform  = list()
alltestResultsInputTreatment = list()
allTestResultsEvalQuery = list()
allTestResultsEvaluateQuery = list()
allTestResultsEvaluateQuery_db = list()
allTestResultsCreateQuery1 = list()
allTestResultsCreateQuery = list()
allTestResultsExecSqlQuery = list()
allTestResultsColExpr = list()
allTestResultsFilterExpr = list()
allTestResultsOperationExpr1 = list()
allTestResultsOperationExpr = list()
allTestResultsGroupbycolsexpr = list()
allTestResultsEvaluateQuery_local = list()
allTestResultsHasUnique = list()
allTestResultsFplyr = list()
allTestResultsCompare = list()
allTestResultsDataType  = list()
alltestResultsEvalStr = list()
allTestResultsDbCreateNewCol = list()
allTestResultsDbCalculatedCol = list()
allTestResultsDbDropColumns = list()
allTestResultsDbKeepColumns = list()
allTestResultsDbTableTopQuery = list()
allTestResultsDbTableTop = list()
allTestResultsDbFetchTopWrapper = list()
allTestResultsConvertToDate = list()
allTestResultsTemplateLocalInfo = list()
allTestResultsTemplateDBInfo = list()
allTestResultsTemplateCheckSubmit_func_main = list()
allTestResultsNullCheckSubmit_func_main = list()
allTestResultsDuplicationCheck = list()
allTestResultsHierarchyCheck = list()
allTestResultsUploadedQueries_func = list()


###################################################################################
inDataReactive <- list(
  inData=NULL,
  mainData=NULL,
  dataType=NULL,
  cols=NULL,
  dim=NULL
)
testVariables <- readRDS("../JenkinsTestData/testVariables.RDS")


#dbButton <- input$dbButton
print('Reading inputs')
inTables <- list()
fileCounter <- 2
tableCounter <-2
dbButton <- 'csv'
file1 <- list(
  name = 'hotel_panel_time_data.csv',
  datapath = '../Sample_Datasets/hotel_panel_time_data.csv'
)
file2 <- list(
  name = 'hotel_panel_time_data_1.csv',
  datapath = '../Sample_Datasets/hotel_panel_time_data_1.csv'
)
counter <- ifelse(dbButton =='csv',fileCounter,tableCounter)

if(dbButton=='csv'){
  print('Reading local input datasets')
  if(is.null(file1)) return()
  connObj <<- NULL
  connDb <<- NULL
  
  for(i in 1:counter){
    name <- get(paste0('file',i))$name
    if(is.null(name)) return()
    alias <- LETTERS[i]
    path <- get(paste0('file',i))$datapath
    # data <- read.csv(path,stringsAsFactors = F)
    data <- as.data.frame(fread(path,stringsAsFactors = F,header = T),stringsAsFactors = F)
    colnames(data)<-make.names(colnames(data))
    cols <- colnames(data)
    dim <- dim(data)
    dataTypes <- inDataType_func(list(con=NULL,table=data,db=connDb))
    head <- head(data,n=10)
    keyCols <- ''
    
    inTables$tables[[i]] <- list(name=name,alias=alias,path=path,data=data,cols=cols,dim=dim,dataTypes=dataTypes,keyCols=keyCols,head=head)
    
  }
} else {
  print('Reading DB inputs')
  if(input$tableName1=='') return()
  connObj <<- connectionObj
  connDb <<- connectionParams$dbButton1
  
  if(counter>0){
    if(!tableExistsCheck(counter)) return()
  }
  
  for(i in 1:counter){
    name <- get(paste0('file',i))$name
    if(name=='') return()
    alias <- LETTERS[i]
    conList <- list(con=connectionObj,table=name,db=connDb)
    path <- NULL
    data <- name
    head <- dbFetchTopWrapper(conList) # Head here will only have top 10 rows of the table
    cols <- colnames(head)
    dim <- c('',length(cols))
    dataTypes <- inDataType_func(conList)
    keyCols <- ''
    
    inTables$tables[[i]] <- list(name=name,alias=alias,path=path,data=data,cols=cols,dim=dim,dataTypes=dataTypes,keyCols=keyCols,head=head)
    reactData$reportTableData[[i]] <- list(name=name,data=head,dim=dim,dataTypes=dataTypes)
    
  }
}

inTables$tableNames <- unlist(lapply(inTables$tables,function(x) x$name))
names(inTables$tableNames) <- LETTERS[1:counter]

names(inTables$tables) <- LETTERS[1:counter]
dat <- inTables$tables[[1]]$data
conList <- list(con=NULL,table=dat,db=connDb)
if(is.null(conList$table)) {
  print('No Table Uploaded!',type='error')
  
}
inDataReactive$inData <- conList
inDataReactive$dataType <- inDataType_func(inDataReactive$inData)
# testVariables$inDataType_funcResults<-inDataReactive$dataType
inDataReactive$cols <- inDataReactive$dataType$col

#-----------------------------test inDataType_func------------------
failedTestsInDataType_func <- list()
error <- tryCatch({
  test_that("inDataType_func calculation is correct", {
    expect_equal(inDataReactive$dataType,testVariables$inDataType_funcResults)
  })
},error = function(e){return(e)})
if(!isTRUE(error)){
  failedTestsInDataType_func[length(failedTestsInDataType_func)+1] <- as.character(error)
}

if(length(failedTestsInDataType_func) == 0){
  print("inDataType_func test passed")
}else{
  allTestResultsInDataType_func[1] = "inDataType_func Test"
  allTestResultsInDataType_func[[2]] = failedTestsInDataType_func
  allTestResults[[length(allTestResults)+1]] <- allTestResultsInDataType_func
}

#-------------------------------------------------------------------


#########################uploadedQueries_func###########################################

reactData <- list(
  inDataHead = data.frame()
  ,inDataType = data.frame()
  ,tableAlias=data.frame()
  ,calColsTable = data.frame()
  ,queryTable = data.frame()
  ,panelDataHead = data.frame()
  ,panelCompTable = data.frame()
  ,working_dir = getwd()
  ,donutChart = NULL
  ,summaryTable = NULL
  ,reportTableData=list()
  ,levelText = ''
  ,colCheckTable = data.frame(DataTable=character())
  ,missingValueTable = data.frame(DataTable=character())
  ,hierarchyCheckTable = data.frame(DataTable=character())
  ,hierarchyFailsTable = data.frame(DataTable=character())
  ,dupsTable = data.frame(DataTable=character())
)


path <- '../JenkinsTestData/SingleDatasetChecks.csv'
queryData <- data.frame(Filters=character(),
                        GroupBy=character(),
                        Column=character(),
                        Function=character(),
                        Operation=character(),
                        Argument=character(),
                        Result=character(),
                        Value=character(),
                        Run=character(),
                        Command=character(),
                        Comparison=character(),
                        TableName=character(),
                        JoinKeys=character(),
                        caseSensitive = character(), 
                        Remarks = character(),
                        stringsAsFactors = F)
out <- uploadedQueries_func(path,queryData)

# testVariables$uploadedQueries_funcResults <- out$data

#-----------------------------test uploadedQueries_func------------------
failedTestsUploadedQueries_func <- list()
error <- tryCatch({
  test_that("uploadedQueries_func is correct", {
    expect_equal(out$data,testVariables$uploadedQueries_funcResults)
  })
},error = function(e){return(e)})
if(!isTRUE(error)){
  failedTestsUploadedQueries_func[length(failedTestsUploadedQueries_func)+1] <- as.character(error)
}

if(length(failedTestsUploadedQueries_func) == 0){
  print("uploadedQueries_func test passed")
}else{
  allTestResultsUploadedQueries_func[1] = "uploadedQueries_func Test"
  allTestResultsUploadedQueries_func[[2]] = failedTestsUploadedQueries_func
  allTestResults[[length(allTestResults)+1]] <- allTestResultsUploadedQueries_func
}
#-------------------------------------------------------------------
if(is.null(out$data)){
  
  print(paste0(out$error,'error'))
  return()
} else {
  queryData <- out$data
  print(out$data)
  
}
if(sum(as.numeric(queryData$Comparison))>0){ #If TRUE  => Rule list contains Multiple Dataset Comparison
  print("Check Point 6")
  if(!'TableName' %in% colnames(queryData)) return()
  queryData1 <- queryData %>% filter(Comparison=='1')
  tableNameColFlag <- 1
  colBreak <- getRuleListTableNames(queryData1)
  #testVariables$getRuleListTableNamesResults <- colBreak
  #-----------------------------test getRuleListTableNames------------------
  failedTestsGetRuleListTableNames <- list()
  error <- tryCatch({
    test_that("uploadedQueries_func is correct", {
      expect_equal(colBreak,testVariables$getRuleListTableNamesResults)
    })
  },error = function(e){return(e)})
  if(!isTRUE(error)){
    failedTestsGetRuleListTableNames[length(failedTestsGetRuleListTableNames)+1] <- as.character(error)
  }
  
  if(length(failedTestsGetRuleListTableNames) == 0){
    print("uploadedQueries_func test passed")
  }else{
    allTestResultsGetRuleListTableNames[1] = "uploadedQueries_func Test"
    allTestResultsGetRuleListTableNames[[2]] = failedTestsGetRuleListTableNames
    allTestResults[[length(allTestResults)+1]] <- allTestResultsGetRuleListTableNames
  }
  #-------------------------------------------------------------------
  workflowTables <<- colBreak
  
}

########################## 31th Oct ####################################
##-----------------------initialization---------------------------
queryQ <- list()
queryQ$calCols <- c()
queryQ$filterString <- ''
queryQ$filterString2 <- ''
##-----------------------------------------------------------------

if(is.na(queryData[1,'Column'])){
  print('No queries in queryTable')
}
if(is.null(inDataReactive$inData)){  ##-- Return if no data input
  print('No data')
}

print('Executing queries in the table')

# runOption <- isolate('Run All')


queryQ$correct <- 0
queryQ$incorrect <- 0


runOption <- 'Run All'
qData <- queryData
print(qData)

qData[,'Run'] <- '0'
print("===================================================================================")
if(is.null(qData)){
  print('no data')
}else{
  
  for(i in 1:nrow(qData)){
    query <- qData[i,c('Filters','GroupBy','Column','Function','Operation','Argument','Run','Comparison','JoinKeys','caseSensitive')]
    
    #print(query)
    row <- unlist(query)
    nRun <- trimws(row['Run'])
    print(row)
    if(nRun=='0' | nRun==''){
      evalRun <- function(){
        tryCatch(# Call function that evaluates the QC check
          {
            bin <- evalQuery(inDataReactive$inData,inTables,as.character(row['Filters']),
                             as.character(row['GroupBy']),as.character(row['Column']),
                             as.character(row['Function']),as.character(row['Operation']),
                             as.character(row['Argument']),as.character(row['Comparison']),row['JoinKeys'],
                             row['caseSensitive'])
            
            
            
          }
          #,warning=function(w){showNotification(paste0('Warning in Rule',i,':',w[1]),type='warning');NULL}
          ,error=function(e){print(e)}
        )
      }
      bin <- evalRun()
      print(bin)
      #if(!is.null(bin)){
      if(bin[[1]]!='error'){
        queryData[i,'Result'] <- ifelse(bin[[1]],'Passed','Failed')
        queryData[i,'Value'] <- bin[[2]]
        queryData[i,'Command'] <- bin[[3]]
      }
      else {
        queryData[i,'Result'] <- 'Error'
        queryData[i,'Value'] <- bin[[2]]  ## bin[[2]] contains the error string returned by the error handler
        queryData[i,'Command'] <- 'Error'
      }
      queryData[i,'Run'] <- '1'
      
    }
    
  }
  # testVariables$evalQueryResults <- rep('Passed',nrow(queryData))
  #------------------------------test evalQuery-------------------------------------
  failedTestsEvalQuery <- list()
  error <- tryCatch({
    test_that("evalQuery for query is correct", {
      expect_equal(queryData$Result,testVariables$evalQueryResults)
    })
  },error = function(e){return(e)})
  if(!isTRUE(error)){
    failedTestsEvalQuery[length(failedTestsEvalQuery)+1] <- as.character(error)
  }
  if(length(failedTestsEvalQuery) == 0){
    print("uploadedQueries_func test passed")
  }else{
    allTestResultsEvalQuery[1] = "uploadedQueries_func Test"
    allTestResultsEvalQuery[[2]] = failedTestsEvalQuery
    allTestResults[[length(allTestResults)+1]] <- allTestResultsEvalQuery
  }
  #-------------------------------------------------------------------
}

queryQ$correct <- sum(queryData$Result=='Passed',na.rm=T)
queryQ$incorrect <- sum(queryData$Result=='Failed',na.rm=T)


#####################################33 mutliple csv comparison checks

out <- uploadedQueries_func('../JenkinsTestData/MultipleDatasetCheckTrue.csv',queryData)
testVariables$uploadedQueries_funcResults <- out$data

#-----------------------------test uploadedQueries_func------------------
failedTestsUploadedQueries_func <- list()
error <- tryCatch({
  test_that("uploadedQueries_func is correct", {
    expect_equal(out$data,testVariables$uploadedQueries_funcResults)
  })
},error = function(e){return(e)})
if(!isTRUE(error)){
  failedTestsUploadedQueries_func[length(failedTestsUploadedQueries_func)+1] <- as.character(error)
}
if(length(failedTestsUploadedQueries_func) == 0){
  print("uploadedQueries_func test passed")
}else{
  allTestResultsUploadedQueries_func[1] = "uploadedQueries_func Test"
  allTestResultsUploadedQueries_func[[2]] = failedTestsUploadedQueries_func
  allTestResults[[length(allTestResults)+1]] <- allTestResultsUploadedQueries_func
}
#-------------------------------------------------------------------
if(is.null(out$data)){
  
  print(paste0(out$error,'error'))
  return()
} else {
  queryData <- out$data
  print(out$data)
  
}
if(sum(as.numeric(queryData$Comparison))>0){ #If TRUE  => Rule list contains Multiple Dataset Comparison
  print("Check Point 6")
  if(!'TableName' %in% colnames(queryData)) return()
  queryData1 <- queryData %>% filter(Comparison=='1')
  tableNameColFlag <- 1
  colBreak <- getRuleListTableNames(queryData1)
  #testVariables$getRuleListTableNamesResults <- colBreak
  #-----------------------------test getRuleListTableNames------------------
  failedTestsGetRuleListTableNames <- list()
  error <- tryCatch({
    test_that("uploadedQueries_func is correct", {
      expect_equal(colBreak,testVariables$getRuleListTableNamesResults)
    })
  },error = function(e){return(e)})
  if(!isTRUE(error)){
    failedTestsGetRuleListTableNames[length(failedTestsGetRuleListTableNames)+1] <- as.character(error)
  }
  
  if(length(failedTestsGetRuleListTableNames) == 0){
    print("uploadedQueries_func test passed")
  }else{
    allTestResultsGetRuleListTableNames[1] = "uploadedQueries_func Test"
    allTestResultsGetRuleListTableNames[[2]] = failedTestsGetRuleListTableNames
    allTestResults[[length(allTestResults)+1]] <- allTestResultsGetRuleListTableNames
  }
  #-------------------------------------------------------------------
  workflowTables <<- colBreak
  
}

########################## 31th Oct ####################################
##-----------------------initialization---------------------------
queryQ <- list()
queryQ$calCols <- c()
queryQ$filterString <- ''
queryQ$filterString2 <- ''
##-----------------------------------------------------------------

if(is.na(queryData[1,'Column'])){
  print('No queries in queryTable')
}
if(is.null(inDataReactive$inData)){  ##-- Return if no data input
  print('No data')
}

print('Executing queries in the table')

# runOption <- isolate('Run All')


queryQ$correct <- 0
queryQ$incorrect <- 0


runOption <- 'Run All'
qData <- queryData
print(qData)

qData[,'Run'] <- '0'
print("===================================================================================")
if(is.null(qData)){
  print('no data')
}else{
  
  for(i in 1:nrow(qData)){
    query <- qData[i,c('Filters','GroupBy','Column','Function','Operation','Argument','Run','Comparison','JoinKeys','caseSensitive')]
    
    #print(query)
    row <- unlist(query)
    nRun <- trimws(row['Run'])
    print(row)
    if(nRun=='0' | nRun==''){
      evalRun <- function(){
        tryCatch(# Call function that evaluates the QC check
          {
            bin <- evalQuery(inDataReactive$inData,inTables,as.character(row['Filters']),
                             as.character(row['GroupBy']),as.character(row['Column']),
                             as.character(row['Function']),as.character(row['Operation']),
                             as.character(row['Argument']),as.character(row['Comparison']),row['JoinKeys'],row['caseSensitive'])
            
            
            
          }
          #,warning=function(w){showNotification(paste0('Warning in Rule',i,':',w[1]),type='warning');NULL}
          ,error=function(e){print(e)}
        )
      }
      bin <- evalRun()
      print(bin)
      #if(!is.null(bin)){
      if(bin[[1]]!='error'){
        queryData[i,'Result'] <- ifelse(bin[[1]],'Passed','Failed')
        queryData[i,'Value'] <- bin[[2]]
        queryData[i,'Command'] <- bin[[3]]
      }
      else {
        queryData[i,'Result'] <- 'Error'
        queryData[i,'Value'] <- bin[[2]]  ## bin[[2]] contains the error string returned by the error handler
        queryData[i,'Command'] <- 'Error'
      }
      queryData[i,'Run'] <- '1'
      
    }
    
  }
  # testVariables$evalQueryResults <- rep('Passed',nrow(queryData))
  #------------------------------test evalQuery-------------------------------------
  failedTestsEvalQuery_comp <- list()
  allTestResultsEvalQuery_comp <- list()
  #testVariables$evalQueryResults_comp <- queryData$Result 
  error <- tryCatch({
    test_that("evalQuery for query is correct", {
      expect_equal(queryData$Result,testVariables$evalQueryResults_comp)
    })
  },error = function(e){return(e)})
  if(!isTRUE(error)){
    failedTestsEvalQuery_comp[length(failedTestsEvalQuery_comp)+1] <- as.character(error)
  }
  if(length(failedTestsEvalQuery_comp) == 0){
    print("uploadedQueries_func test passed")
  }else{
    allTestResultsEvalQuery_comp[1] = "uploadedQueries_func Test"
    allTestResultsEvalQuery_comp[[2]] = failedTestsEvalQuery_comp
    allTestResults[[length(allTestResults)+1]] <- allTestResultsEvalQuery_comp
  }
  #-------------------------------------------------------------------
}

queryQ$correct <- sum(queryData$Result=='Passed',na.rm=T)
queryQ$incorrect <- sum(queryData$Result=='Failed',na.rm=T)



##################################################################################
### PANEL COMPARISON CHECK

#allTestResultsPcquery = list()
connObj <- NULL
connDb <- NULL
panelComp <- list()
panelComp$Data <- data.frame(Comparison_Nbr=character(),Time_1_Value=character(),Time_2_Value=character(),stringsAsFactors = F)
new <- data.frame(Comparison_Nbr=1,Time_1_Value='2016',Time_2_Value='2017',stringsAsFactors = F)
panelComp$Data <- rbind(panelComp$Data,new)
keyCols <- 'FAC_ID'
panelCols <- 'YEAR'
diffCols <- 'RMS_AVAIL_QTY'
dbTempTable <- ''
panelCompR <- panelComp


compData <- 
  pcquery(inTable1=inTables$tables[[1]],list(con=connObj,db=connDb),connDb=connDb,compData=panelCompR$Data,keyCols,panelCols,diffCols,dbTempTable)
testVariables$compData <- compData
#saveRDS(compData,'compData.RDS')
#------------------------------test pcquery-------------------------------------
failedTestsPcquery <- list()
testCompData <- readRDS('../JenkinsTestData/compData.RDS')

error <- tryCatch({
  test_that("Panel Comparison is correct", {
    expect_equal(compData$data,testCompData$data)
  })
},error = function(e){return(e)})

if(!isTRUE(error)){
  failedTestsPcquery[length(failedTestsPcquery)+1] <- as.character(error)
}
if(length(failedTestsPcquery) == 0){
  print("pcquery function test passed")
}else{
  failedTestsPcquery[1] = "pcquery function Test"
  failedTestsPcquery[[2]] = failedTestsPcquery
  allTestResults[[length(allTestResults)+1]] <- allTestResultsPcquery
}
#-------------------------------------------------------------------


###########################_- quick checks tests


## Test for templateCheckSubmit_func_main
colData <- readRDS("../JenkinsTestData/colData.RDS")
templateTable <- read.csv("../Sample_Datasets/hotel_panel_time_data.csv",stringsAsFactors = FALSE)
templateFile <- head(templateTable,10)
inDataHead <- head(templateTable,10)
checkTable <- readRDS("../JenkinsTestData/templateCheckResult.RDS")
test_that('Test templateCheckSubmit_func_main',{
  
  expect_equal( checkTable ,
                templateCheckSubmit_func_main(colData,templateType="CSV",templateFile,inDataHead,
                                              conList=list(con=NULL,table=templateTable,db=NULL)))
}
)
## Test for hierarchyCheck


hierarchyTableResult <- readRDS("../JenkinsTestData/hierarchyTableResult.RDS")

test_that('Test templateCheckSubmit_func_main',{
  
  expect_equal( hierarchyTableResult ,
                hierarchyCheck(c("YEAR","MONTH"),conList = list(con=NULL,table=templateTable,db=NULL))                  )
}
)

## Test for nullCheckSubmit_func_main
test_that('Test nullCheckSubmit_func_main',{
  expect_true(all(nullCheckSubmit_func_main(conList =list(con=NULL,table=templateTable,db=NULL),
                                            cols = colnames(templateTable)$NA_Count ==0)$NA_Count ==0))
  
  
}
)

duplicationCheckResult <- readRDS("../JenkinsTestData/duplicationCheckResult.RDS")

## Test for duplicationCheck
test_that('Test duplicationCheck',{
  expect_equal(duplicationCheckResult,duplicationCheck("FAC_ID",list(con=NULL,table=templateTable,db=NULL)))
  
  
}
)

###################################################################################

########################################  DB testing ##############################

inDataReactive <- list(
  inData=NULL,
  mainData=NULL,
  dataType=NULL,
  cols=NULL,
  dim=NULL
)
# testVariables <- readRDS("testVariables.RDS")

#  cParams <- list()
#   cParams$dbButton1 <- 'postgres'
#   cParams$dbName <- 'mydatabase'
#  cParams$dbName1 <- ''
#  cParams$dbHost <- 'localhost'
# cParams$dbPort <- 5432
# cParams$dbUsername <- 'myuser'
#   cParams$dbPassword <- 'password'
#  cParams$dbTable <- 'hotel4'
#   cParams$dbDriverLocation <- ''
#   cParams$dbDriverClass <- ''
#   cParams$driverOptions <- 0
#  cParams$connectionString <- ''
#  connectionParams <- cParams
# 
#  con <- connect(cParams)[[1]]
#  connectionObj <- con
# 
#  #dbButton <- input$dbButton
#  print('Reading inputs')
#  inTables <- list()
#  fileCounter <- 2
#  tableCounter <-2
#  dbButton <- 'db'
#  file1 <- list(
#    name = 'hotel4',
#    datapath = 'hotel4'
#  )
#  file2 <- list(
#    name = 'hotel2',
#    datapath = 'hotel2'
#  )
#  


cParams <- list()
cParams$dbButton1 <- 'postgres'
cParams$dbName <- 'test'
cParams$dbName1 <- ''
cParams$dbHost <- '172.25.1.30'
cParams$dbPort <- 5432
cParams$dbUsername <- 'postgres'
cParams$dbPassword <- 'postgres'
cParams$dbTable <- 'qc_brick_test_hotel'
cParams$dbDriverLocation <- ''
cParams$dbDriverClass <- ''
cParams$driverOptions <- 0
cParams$connectionString <- ''
cParams$connectionMethod <- 'jdbc'
connectionParams <- cParams

con <- connect(cParams)[[1]]
connectionObj <- con

#dbButton <- input$dbButton
print('Reading inputs')
inTables <- list()
fileCounter <- 2
tableCounter <-2
dbButton <- 'db'
file1 <- list(
  name = 'qc_brick_test_hotel',
  datapath = 'qc_brick_test_hotel'
)
file2 <- list(
  name = 'qc_brick_test_hotel',
  datapath = 'qc_brick_test_hotel'
)
counter <- ifelse(dbButton =='csv',fileCounter,tableCounter)

tableExistsCheck <- function(counter){
  for(i in 1:counter){
    name <- trimws(get(paste0('file',i))$name)
    flag <- dbExistsTable(connObj,name)
    if(!flag){
      showNotification(paste0('Table Does Not Exist : ',name),type='error')
      return(FALSE)
    }
  }
  return(TRUE)
}

if(dbButton=='csv'){
  print('Reading local input datasets')
  if(is.null(file1)) return()
  connObj <<- NULL
  connDb <<- NULL
  
  for(i in 1:counter){
    name <- get(paste0('file',i))$name
    if(is.null(name)) return()
    alias <- LETTERS[i]
    path <- get(paste0('file',i))$datapath
    # data <- read.csv(path,stringsAsFactors = F)
    data <- as.data.frame(fread(path,stringsAsFactors = F,header = T),stringsAsFactors = F)
    colnames(data)<-make.names(colnames(data))
    cols <- colnames(data)
    dim <- dim(data)
    dataTypes <- inDataType_func(list(con=NULL,table=data,db=connDb))
    head <- head(data,n=10)
    keyCols <- ''
    
    inTables$tables[[i]] <- list(name=name,alias=alias,path=path,data=data,cols=cols,dim=dim,dataTypes=dataTypes,keyCols=keyCols,head=head)
    
  }
} else {
  print('Reading DB inputs')
  if(get(paste0('file',1))$name=='') return()
  connObj <- connectionObj
  connDb <- connectionParams$dbButton1
  
  if(counter>0){
    if(!tableExistsCheck(counter)) return()
  }
  
  for(i in 1:counter){
    name <- get(paste0('file',i))$name
    if(name=='') return()
    alias <- LETTERS[i]
    conList <- list(con=connectionObj,table=name,db=connDb)
    path <- NULL
    data <- name
    head <- dbFetchTopWrapper(conList) # Head here will only have top 10 rows of the table
    cols <- colnames(head)
    dim <- c('',length(cols))
    dataTypes <- inDataType_func(conList)
    keyCols <- ''
    
    inTables$tables[[i]] <- list(name=name,alias=alias,path=path,data=data,cols=cols,dim=dim,dataTypes=dataTypes,keyCols=keyCols,head=head)
    reactData$reportTableData[[i]] <- list(name=name,data=head,dim=dim,dataTypes=dataTypes)
    
  }
}

inTables$tableNames <- unlist(lapply(inTables$tables,function(x) x$name))
names(inTables$tableNames) <- LETTERS[1:counter]

names(inTables$tables) <- LETTERS[1:counter]
dat <- inTables$tables[[1]]$data

conList <- list(con=connObj,table=dat,db=connDb)

if(is.null(conList$table)) {
  print('No Table Uploaded!',type='error')
  
}

inDataReactive$inData <- conList
inDataReactive$dataType <- inDataType_func(inDataReactive$inData)
# testVariables$inDataType_funcResults<-inDataReactive$dataType
inDataReactive$cols <- inDataReactive$dataType$col




queryData <- data.frame(Filters=character(),
                        GroupBy=character(),
                        Column=character(),
                        Function=character(),
                        Operation=character(),
                        Argument=character(),
                        Result=character(),
                        Value=character(),
                        Run=character(),
                        Command=character(),
                        Comparison=character(),
                        TableName=character(),
                        JoinKeys=character(),
                        caseSensitive = character(), 
                        Remarks = character(),
                        stringsAsFactors = F)








out <- uploadedQueries_func('../JenkinsTestData/MultipleDatasetCheckTrue.csv',queryData)
queryData <- out$data
########################## 31th Oct ####################################
##-----------------------initialization---------------------------
queryQ <- list()
queryQ$calCols <- c()
queryQ$filterString <- ''
queryQ$filterString2 <- ''
##-----------------------------------------------------------------

if(is.na(queryData[1,'Column'])){
  print('No queries in queryTable')
}
if(is.null(inDataReactive$inData)){  ##-- Return if no data input
  print('No data')
}

print('Executing queries in the table')

# runOption <- isolate('Run All')


queryQ$correct <- 0
queryQ$incorrect <- 0


runOption <- 'Run All'
qData <- queryData
print(qData)

qData[,'Run'] <- '0'
print("===================================================================================")
if(is.null(qData)){
  print('no data')
}else{
  
  for(i in 1:nrow(qData)){
    print(i)
    query <- qData[i,c('Filters','GroupBy','Column','Function','Operation','Argument','Run','Comparison','JoinKeys','caseSensitive')]
    print(query)
    #print(query)
    row <- unlist(query)
    nRun <- trimws(row['Run'])
    print(row)
    if(nRun=='0' | nRun==''){
      evalRun <- function(){
        tryCatch(# Call function that evaluates the QC check
          {
            bin <- evalQuery(inDataReactive$inData,inTables,as.character(row['Filters']),
                             as.character(row['GroupBy']),as.character(row['Column']),
                             as.character(row['Function']),as.character(row['Operation']),
                             as.character(row['Argument']),as.character(row['Comparison']),row['JoinKeys'],row['caseSensitive'])
            
            
            
          }
          #,warning=function(w){showNotification(paste0('Warning in Rule',i,':',w[1]),type='warning');NULL}
          ,error=function(e){print(e)}
        )
      }
      bin <- evalRun()
      print(bin)
      #if(!is.null(bin)){
      if(bin[[1]]!='error'){
        queryData[i,'Result'] <- ifelse(bin[[1]],'Passed','Failed')
        queryData[i,'Value'] <- bin[[2]]
        queryData[i,'Command'] <- bin[[3]]
      }
      else {
        queryData[i,'Result'] <- 'Error'
        queryData[i,'Value'] <- bin[[2]]  ## bin[[2]] contains the error string returned by the error handler
        queryData[i,'Command'] <- 'Error'
      }
      queryData[i,'Run'] <- '1'
      
    }
    
  }
  #testVariables1 <- testVariables
  #testVariables1$evalQueryDBResults <- queryData$Result
  #------------------------------test evalQuery-------------------------------------
  allTestResultsEvaluateQuery_comp_db <- list()
  failedTestsEvalQuery_comp_db <- list()
  error <- tryCatch({
    test_that("evalQuery for comparison queryies on DB is correct", {
      expect_equal(queryData$Result,testVariables$evalQueryDBResults)
    })
  },error = function(e){return(e)})
  if(!isTRUE(error)){
    failedTestsEvalQuery_comp_db[length(failedTestsEvalQuery_comp_db)+1] <- as.character(error)
  }
  if(length(failedTestsEvalQuery_comp_db) == 0){
    print("evalQuery test for comparison on DB passed")
  }else{
    allTestResultsEvaluateQuery_comp_db[1] = "evalQuery DB Test"
    allTestResultsEvaluateQuery_comp_db[[2]] = failedTestsEvalQuery_comp_db
    allTestResults[[length(allTestResults)+1]] <- allTestResultsEvaluateQuery_comp_db
  }
  #-------------------------------------------------------------------
}

queryQ$correct <- sum(queryData$Result=='Passed',na.rm=T)
queryQ$incorrect <- sum(queryData$Result=='Failed',na.rm=T)












#-------------------------- single table checks db

out <- uploadedQueries_func('../JenkinsTestData/SingleDatasetChecksFalse_db.csv',queryData)
queryData <- out$data
########################## 31th Oct ####################################
##-----------------------initialization---------------------------
queryQ <- list()
queryQ$calCols <- c()
queryQ$filterString <- ''
queryQ$filterString2 <- ''
##-----------------------------------------------------------------

if(is.na(queryData[1,'Column'])){
  print('No queries in queryTable')
}
if(is.null(inDataReactive$inData)){  ##-- Return if no data input
  print('No data')
}

print('Executing queries in the table')

# runOption <- isolate('Run All')


queryQ$correct <- 0
queryQ$incorrect <- 0


runOption <- 'Run All'
qData <- queryData
print(qData)

qData[,'Run'] <- '0'
print("===================================================================================")
if(is.null(qData)){
  print('no data')
}else{
  
  for(i in 1:nrow(qData)){
    print(i)
    query <- qData[i,c('Filters','GroupBy','Column','Function','Operation','Argument','Run','Comparison','JoinKeys','caseSensitive')]
    print(query)
    #print(query)
    row <- unlist(query)
    nRun <- trimws(row['Run'])
    print(row)
    if(nRun=='0' | nRun==''){
      evalRun <- function(){
        tryCatch(# Call function that evaluates the QC check
          {
            bin <- evalQuery(inDataReactive$inData,inTables,as.character(row['Filters']),
                             as.character(row['GroupBy']),as.character(row['Column']),
                             as.character(row['Function']),as.character(row['Operation']),
                             as.character(row['Argument']),as.character(row['Comparison']),row['JoinKeys'],row['caseSensitive'])
            
            
            
          }
          #,warning=function(w){showNotification(paste0('Warning in Rule',i,':',w[1]),type='warning');NULL}
          ,error=function(e){print(e)}
        )
      }
      bin <- evalRun()
      print(bin)
      #if(!is.null(bin)){
      if(bin[[1]]!='error'){
        queryData[i,'Result'] <- ifelse(bin[[1]],'Passed','Failed')
        queryData[i,'Value'] <- bin[[2]]
        queryData[i,'Command'] <- bin[[3]]
      }
      else {
        queryData[i,'Result'] <- 'Error'
        queryData[i,'Value'] <- bin[[2]]  ## bin[[2]] contains the error string returned by the error handler
        queryData[i,'Command'] <- 'Error'
      }
      queryData[i,'Run'] <- '1'
      
    }
    
  }
  #testVariables$evalQueryDBResults_single <- queryData$Result
  #------------------------------test evalQuery-------------------------------------
  allTestResultsEvaluateQuery_db <- list()
  failedTestsEvalQuery_db <- list()
  error <- tryCatch({
    test_that("evalQuery on DB is correct", {
      expect_equal(queryData$Result,testVariables$evalQueryDBResults_single)
    })
  },error = function(e){return(e)})
  if(!isTRUE(error)){
    failedTestsEvalQuery_db[length(failedTestsEvalQuery_db)+1] <- as.character(error)
  }
  if(length(failedTestsEvalQuery_db) == 0){
    print("evalQuery test for comparison on DB passed")
  }else{
    allTestResultsEvaluateQuery_db[1] = "evalQuery DB Test"
    allTestResultsEvaluateQuery_db[[2]] = failedTestsEvalQuery_db
    allTestResults[[length(allTestResults)+1]] <- allTestResultsEvaluateQuery_db
  }
  #-------------------------------------------------------------------
}

queryQ$correct <- sum(queryData$Result=='Passed',na.rm=T)
queryQ$incorrect <- sum(queryData$Result=='Failed',na.rm=T)






##################################################################################
### PANEL COMPARISON CHECK DB DB

#allTestResultsPcquery = list()
panelComp <- list()
panelComp$Data <- data.frame(Comparison_Nbr=character(),Time_1_Value=character(),Time_2_Value=character(),stringsAsFactors = F)
new <- data.frame(Comparison_Nbr=1,Time_1_Value='2016',Time_2_Value='2017',stringsAsFactors = F)
panelComp$Data <- rbind(panelComp$Data,new)
keyCols <- 'fac_id'
panelCols <- 'year'
diffCols <- 'rms_avail_qty'
dbTempTable <- ''
panelCompR <- panelComp

dbExecute(connObj, paste0('DROP TABLE IF EXISTS qcTempTable_',gsub('-','',as.Date(Sys.time()))))
compDataDB <- 
  pcquery(inTable1=inTables$tables[[1]],list(con=connObj,db=connDb),connDb=connDb,compData=panelCompR$Data,keyCols,panelCols,diffCols,dbTempTable)

#testVariables$compDataDB <- compDataDB
#saveRDS(compData,'compData.RDS')
#------------------------------test pcquery-------------------------------------
failedTestsPcquery_db <- list()
allTestResultsPcquery_db <- list()
#testCompData <- readRDS('compData.RDS')

error <- tryCatch({
  test_that("Panel Comparison on DB is correct", {
    expect_equal(compDataDB$data,paste0('qcTempTable_',gsub('-','',as.Date(Sys.time()))))
  })
},error = function(e){return(e)})

if(!isTRUE(error)){
  failedTestsPcquery_db[length(failedTestsPcquery_db)+1] <- as.character(error)
}
if(length(failedTestsPcquery_db) == 0){
  print("pcquery db function test passed")
}else{
  allTestResultsPcquery_db[1] = "pcquery function Test"
  allTestResultsPcquery_db[[2]] = failedTestsPcquery_db
  allTestResults[[length(allTestResults)+1]] <- allTestResultsPcquery_db
}
#-------------------------------------------------------------------


dbDisconnect(con)