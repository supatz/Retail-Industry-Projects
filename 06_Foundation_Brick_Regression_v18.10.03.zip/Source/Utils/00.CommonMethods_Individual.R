#================================================================================================================================
# Delivery Engine: Code Repository (R)
#================================================================================================================================
#	Section - 0       : Common Methods
#   
#================================================================================================================================
#	Functions         : checkColumnMissing
#                     checkColumnType
#                     findZeroVar
#                     findMaxVariance
#                   
#================================================================================================================================
#	  Details:          The file consists of functions used to identify missing values, variable type, zero and maximum variance in
#                     vector or column of a data frame
#================================================================================================================================

#--------------------------------------------------------------------------------------------------------------------------------                                                                                   -----------------------                                                                                                                                                                                         --#
#' 
#' CheckColumnMissing()
#' @description                      Function to check which columns of the data have missing values
#'
#' @param dataVector                 Data frame to be tested for missing values
#'
#' @return columnType                Returns a bool indicating if given column has missing values
#' 
#--------------------------------------------------------------------------------------------------------------------------------

CheckColumnMissing <- function(data) {
  
  missingMessageVec <- NULL
  numCols <- ncol(data)
  for (i in 1:numCols) {
    #Extract the required statistics
    colNumMiss <- sum(is.na(data[,i]))
    colPercMiss <- paste(round(colNumMiss / nrow(data) * 100, 2), "% ", sep = "")
    if (colNumMiss > 0) {
      missingMessage <- paste("The column ", colnames(data)[i], " contains ",colNumMiss, " values, which is ",colPercMiss,
                               "missing values in the column", sep = "")
      missingMessageVec <- c(missingMessageVec, missingMessage)
    }
  }
  data <- mtcars
  #Returns message in the console, percentage of missing values in each column of a data frame
  return(missingMessageVec)
  
}



#--------------------------------------------------------------------------------------------------------------------------------
#' 
#' CheckColumnType()
#' @description                      Function to check if a column is numerical continuous, numerical categorical or categorical
#'
#' @param dataVector                 Data Vector to be tested for variable type
#' @param cutoffValue                Maximum uniqe values a numeric categorical variable can have, above which
#'                                   the variable is considered to be a continuous variable
#'
#' @return columnType                Returns a string indicating type of the column
#' 
#--------------------------------------------------------------------------------------------------------------------------------

CheckColumnType <- function(dataVector, cutoffValue = 0) {
  
  #Check if the column type is "numeric" or "character" & decide type accordingly
  if (class(dataVector) == "integer" || class(dataVector) == "numeric") {
    #Extract number of unique levels in the dataVector
    numUnique <- length(unique(dataVector))
    #Check for cut-off condition
    if (numUnique > cutoffValue){
      columnType <- "numeric" 
    } else { columnType <- "factor" }
  } else { columnType <- "character" }
  
  #Return the result
  return(columnType)
  
}



#--------------------------------------------------------------------------------------------------------------------------------
#' 
#' FindZeroVar()
#' @description               Function to return the indices of columns which have no variance
#'
#' @param data                Name of the desired data frame that needs to be tested
#'
#' @return zeroList           Returns indices of the columns with no variance as a vector
#' 
#--------------------------------------------------------------------------------------------------------------------------------

FindZeroVar <- function(data) {
  
  #Create list for collecting results
  zeroList <- NULL
  
  #Iterate through the data frame, one column at a time
  for(i in 1:ncol(data)) {
    variance <- var(data[,i])
    if (variance == 0) {
      zeroList <- c(zeroList, i) 
    }
  }
  
  #Return the list
  return(zeroList)
  
}



#--------------------------------------------------------------------------------------------------------------------------------                                                                                        -----------------------                                                                                                                                                                                         --#
#' 
#' FindMaxVariance()
#' @description                    Sub-Function to extract variable with maximum variance in a given data frame
#'
#' @param ignoreList               Vector of column names indicating the data columns that should not be considered
#' @param data                     Data frame to be tested
#'
#' @return maxPos                  Returns the name of the variable with maximum variance
#' 
#--------------------------------------------------------------------------------------------------------------------------------

FindMaxVariance <- function(data, ignoreList = c()) {
  
  #Subset data to remove elements that have already been considered
  if (length(ignoreList) == 0) { 
    data <- data 
  } else {
    colsToConsider <- colnames(data)
    colsToConsider <- colsToConsider[!colsToConsider %in% ignoreList]
    data <- data[, colsToConsider]
  }
  
  #Use "sapply" to extract variance across every column in the dataSet
  varVector <- sapply(data, var)
  
  #Identify position of columns with MAX variance
  maxPos <- which.max(varVector)  
  maxColName <- colnames(data)[maxPos]
  return (maxColName)
  
}