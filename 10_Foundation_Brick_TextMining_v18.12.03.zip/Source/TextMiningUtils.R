packages <- NULL
git_url <- NULL
project_issue_url <- NULL
session_url <- NULL
projectID <- NULL

loadGlobals <- function() {
  # options(java.parameters = c("-Xmx2g", "-Xss2560k"))
  packages <<- c("tm","qdapRegex", "ggplot2", "RColorBrewer", "wordcloud", "textstem", "quanteda",
                "openNLP", "openNLPdata", "phrasemachine", "tokenizers", "NLP",
                "tidytext", "tidyr", "topicmodels", "treemap", "dplyr", "caret","data.table",
                "text2vec","tsne","Cairo","devtools","httr", "pander", "gridExtra", "REEMtree", "rpart.plot","DT", "igraph",
                "shiny", "knitr", "rmarkdown", "shinyBS", "shinyjs", "colourpicker", "plyr", "reshape2", "png", "rjson", "coreNLP","zoom")
  dbPackages <<- c("rJava", "RPostgreSQL", "RMySQL", "RSQLite", "DBI","RJDBC", "odbc")
  packageList <<-   if(file.exists("Source/packageList.csv")){
    packageList <<- read.csv("Source/packageList.csv")
  } else if(file.exists("packageList.csv")){
    packageList <<- read.csv("packageList.csv")
  } else {
    packageList <<- NULL
  }
  
  git_url <<- "http://mugitlab.mu-sigma.com/api/v3"
  project_issue_url <<- "http://mugitlab.mu-sigma.com/api/v3/projects/126/issues"
  session_url <<- "http://mugitlab.mu-sigma.com/api/v3/session"
  projectID <<- 126
  uiPkgMissMsgWithoutJava <<- "<div style='color:red;margin-left:20vw;'>NOTE: Some of the required packages failed to install and few functionalities in the brick may not work. Please refer to the file 'InstallationFailedPackages.txt' in the folder of the brick to get the list of the required packages. Also some of the bricks' feautures have been disabled as"
  uiPkgMissMsgWithJava <<- "<div style='color:red;margin-left:20vw;'>NOTE: Some of the required packages failed to install and few functionalities in the brick may not work. Please refer to the file 'InstallationFailedPackages.txt' in the folder of the brick to get the list of the required packages</div>"
  uiReferToReadmeMsg <<- ". Please refer to file Foundation_Brick_README.html for steps to install and setting up Java.</div>"
  uiJavaMissMsg <<- "<div style='color:red;margin-left:20vw;'>Some of the features have been disabled as"
  generalMsgWarningHdr <<- "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:"
  warningHdrRDRPOSTagger <<- "\r\n\r\ninstall.packages('RDRPOSTagger', repos ='http://www.datatailor.be/rcube', type = 'source',INSTALL_opts = '--no-multiarch')"
  warningHdrOpenNLPModelsEn <<- "\r\n\r\ninstall.packages('openNLPmodels.en', repos = 'http://datacube.wu.ac.at/' , type = 'source')"
  warningHdrWordVec <<-"\r\n\r\ndevtools::install_github('bmschmidt/wordVectors')"
  warningHdrLineSep <<- "\r\n\r\n ===============Run following command after running previous command==============="
  ### Packages to be used and are not available in CRAN 
  # if(!require("openNLPmodels.en")) {
  #   utils::install.packages("openNLPmodels.en", repos = "http://datacube.wu.ac.at/" , type = "source")
  #   library("openNLPmodels.en")
  # }
  # if(!require("RDRPOSTagger")) {
  #   utils::install.packages("RDRPOSTagger", repos = "http://www.datatailor.be/rcube" , type = "source",INSTALL_opts = '--no-multiarch')
  #   library("RDRPOSTagger")
  # }
  
}

findRAMSize <- function (osType) {
  if (osType  ==  "Windows") {
    maxRAM <- as.numeric(memory.limit()) * 1024 ^ 2
  } else if (osType  ==  "Linux") {
    maxRAM <- floor(as.numeric(system("awk '/MemTotal/ {print $2}' /proc/meminfo", intern = TRUE)) / 1024) * 1024 ^ 2
  } else if (osType  ==  "Darwin") {
    cmdOutput <- system("sysctl hw.memsize", intern = TRUE)
    maxRAM <- substr(cmdOutput, 13, nchar(cmdOutput))
    maxRAM <- (as.numeric(maxRAM) / (1024 * 1024)) * 1024 ^ 2
  } else {
    maxRAM <- 102400 * 1024 ^ 2
  }
  return(maxRAM)
}

#Removed this from utils and added the same in Rmd. 

#if(! 'wordVectors' %in% rownames(installed.packages())){
#  devtools::install_github("bmschmidt/wordVectors")
#}
#library("wordVectors")

parseInputs <- function(inputs) {
  entries <- names(inputs)[grep("_", names(inputs))]
  new_inputs <- list()
  lapply(entries, function(n)
  {
    i <- gregexpr("_", n)[[1]][1]
    op <- substr(n,1,i-1)
    s <- substr(n,i+1,nchar(n))
    if(!(op %in% names(new_inputs)))
    {
      new_inputs[[op]] <<- list()
    }
    new_inputs[[op]][[paste(c(op, s), collapse="_")]] <<- inputs[[n]]
  })
  return(new_inputs)
}

#### Data Preparation ####


# Removing Special Char
removeSpecialChar <- function(corpus){
  
  corpus <- tm::tm_map(corpus,tm::removePunctuation) 
  
  return(corpus)
}

# Removing URLs
removeURLs <- function(corpus){
  
  corpus <- tm::tm_map(corpus,function(x) gsub(" ?(f|ht)(tp)s?(://)(\\S*)[./](\\S*)" , " ", x))
  return(corpus)
}

# Removing Stop words
removeStopWords <- function(corpus){
  
  corpus <- convertIntoLowerCase(corpus)
  corpus <- tm::tm_map(corpus, tm::removeWords, tm::stopwords("english"))
  return(corpus)
}

# Removing Custom Stop words
removeCustomStopWords <- function(corpus, stopWordsList){
  
  stopWordsList <- tolower(stopWordsList)
  corpus <- convertIntoLowerCase(corpus)
  corpus <- tm::tm_map(corpus, tm::removeWords, stopWordsList)
  return(corpus)
}

# Removing Html tags
removeHtmlTags <- function(corpus){
  
  corpus <- tm::tm_map(corpus, FUN = function(x) gsub("<.*?>" , " ", x)) 
  return(corpus)
}

# Removing Email address
removeEmailAddress <- function(corpus){
  
  corpus <- tm::tm_map(corpus,function(x) gsub("\\S+@\\S+" , " ", x))
  return(corpus)
}

# Replace Author Names to AUTHORNAME placeholder
replaceAuthorName <- function(corpus){
  
  corpus <- tm::tm_map(corpus, function(x) gsub("\\B@\\w+" , "AUTHORNAME", x, perl = TRUE)) 
  return(corpus)
}

# Remove Author Names
removeAuthorName <- function(corpus){
  
  corpus <- tm::tm_map(corpus, function(x) gsub("\\B@\\w+" , " ", x, perl = TRUE))
  return(corpus)
}

# Replace Hash tags to HASHTAG placeholder
replaceHashTags <- function(corpus){
  
  corpus <- tm::tm_map(corpus, function(x) gsub("#[[:alnum:]]+" , " HASHTAG", x))
  return(corpus)
}

# Remove Hash tags 
removeHashTags <- function(corpus){
  
  corpus <- tm::tm_map(corpus, function(x) gsub("#[[:alnum:]]+" , " ", x))
  return(corpus)
}

# Removing None words
removeNoneWords <- function(corpus){
  
  corpus <- tm::tm_map(corpus, function(x) gsub("[^\x20-\x7F]+" , " ", x)) 
  
  return(corpus)
}

# Removing Solo numbers
removeSoloNumbers <- function(corpus){
  
  corpus <- tm::tm_map(corpus, function(x) gsub("\\b\\d+\\b" , " ", x))
  return(corpus)
}

# Removing Multi space unicodes
removeMultiSpaceUnicode <- function(corpus){
  
  corpus <- tm::tm_map(corpus, function(x) gsub("[^\x20-\x7F]+" , " ", x))
  return(corpus)
}

# Removing Repetitive words
removeRepetitiveWords <- function(corpus){
  
  corpus <- tm::tm_map(corpus, function(x) gsub("\\b(\\w+)( \\1\\b)+","\\1", x))
  return(corpus)
}

# Removing one or two char words
removeSmallWords <- function(corpus){
  
  corpus <- tm::tm_map(corpus, function(x) gsub(" *\\b[[:alpha:]]{1,2}\\b *"," ", x))
  return(corpus)
}

# Strip white spaces
removeExtraWhiteSpaces <- function(corpus){
  
  corpus <- tm::tm_map(corpus, tm::stripWhitespace)
  return(corpus)
}

# Remove user provided regex
removeCustomRegEx <- function(corpus, pattern) {
  
  corpus <- tm::tm_map(corpus, function(x) gsub(pattern," ", x, perl = TRUE))
  return(corpus)
}

# Converting to lowercase
convertIntoLowerCase <- function(corpus){
  
  corpus <- tm::tm_map(corpus, tm::content_transformer(tolower))   
  return(corpus)
}

# Converting to uppercase
convertIntoUpperCase <- function(corpus){
  
  corpus <- tm::tm_map(corpus, tm::content_transformer(toupper))   
  return(corpus)
}

### Clean data corpus forAdvanced Data Prepration
basicDataCleaning <- function(corpus, lower = TRUE, specialChar = TRUE, stopWords = FALSE){
  
  if(lower) {
    corpus <- convertIntoLowerCase(corpus)
  }
  corpus <- removeURLs(corpus)
  corpus <- removeHtmlTags(corpus)
  corpus <- removeSoloNumbers(corpus)
  corpus <- removeMultiSpaceUnicode(corpus)
  if(stopWords) {
    corpus <- removeStopWords(corpus)
  }
  if(specialChar) {
    corpus <- removeSpecialChar(corpus)
  }
  corpus <- removeExtraWhiteSpaces(corpus)
  
  # Removing empty documents from the cleaned dataset
  corpus <- tm::Corpus(tm::VectorSource(unlist(lapply(corpus, function(x) if(nchar(trimws(x)) > 0) x else NULL ))))
  
  return(corpus)
}


### Stemming
performStemming <- function(corpus){
  
  stemmedData <- tm::tm_map(corpus, tm::stemDocument)
  return(stemmedData)
}


### Lemmatization
performLemmatization <- function(strings, lemma_enigne = "Lexicon (Default)"){
 
  if(lemma_enigne == "Lexicon (Default)")
  {
    lemmatizedData <- textstem::lemmatize_strings(strings, engine ='lexicon')
   }
  
  
  if(lemma_enigne == "Hunspell")
  {
    lemma_dict_hs <- textstem::make_lemma_dictionary(strings,'hunspell')
    lemmatizedData <- textstem::lemmatize_strings(strings, dictionary = lemma_dict_hs)
  }
  
  
  if(lemma_enigne == "Treetagger")
  {
    lemma_dict_tt <- textstem::make_lemma_dictionary(strings,'treetagger')
    lemmatizedData <- textstem::lemmatize_strings(strings, dictionary = lemma_dict_tt)
  }
  
  return(lemmatizedData)
}



### SentenceTokenizer
SentenceTokenizer <- function(string, simplify = TRUE){
# browser()  
  sentences <- tokenizers::tokenize_sentences(string, simplify = simplify)
  return(sentences)
}

#### Feature Generation & Exploratory Analysis ####

### Generate NP & VP
generatePhrases <- function(corpus, minNgramLength = 2, maxNgramLength = 5, returnPhraseVector = TRUE){
  
  phrases <- phrasemachine::phrasemachine(corpus,
                           minimum_ngram_length = minNgramLength,
                           maximum_ngram_length = maxNgramLength,
                           return_phrase_vectors = returnPhraseVector,
                           return_tag_sequences = FALSE)
  
  names(phrases) <- 1:length(phrases)
  phrases <- plyr::ldply(phrases, rbind, .id = 'doc')
  phrases <- reshape::melt(phrases, id.vars = 'doc', variable_name = 'order', na.rm = TRUE)
  phrases <- phrases[with(phrases, order(doc, order)), ]
  
  return(phrases)
}


# ### N - Grams
# generateNGrams <- function(corpus, n = 3 , cleandNGrams = TRUE){
# 
#   if (cleandNGrams == TRUE) {
#     corpus <- basicDataCleaning(corpus, lower = TRUE, specialChar = TRUE, stopWords = TRUE)
#   }
# 
#   cleanedCorpus <- as.character(corpus)[1]
#   cleanedCorpus <- gsub("[^[:alnum:]]", " ", cleanedCorpus)
#   cleanedCorpus <- gsub("^c", "", cleanedCorpus)
#   cleanedCorpus <- gsub("\\s+", " ", cleanedCorpus)
#   corpusWords <- strsplit(cleanedCorpus, " ", fixed = T)[[1]]
#   corpusNgrams <- vapply(NLP::ngrams(corpusWords, n), paste, "", collapse = " ")
#   corpusNgrams <- data.frame('n.grams' = corpusNgrams)
#   return(corpusNgrams)
# }
# 
# 
# ### N - Grams with frequency
# generateNGramsFrequency <- function(corpus, n = 2, cleandNGrams = TRUE){
# 
#   if (cleandNGrams == TRUE) {
#     corpus <- basicDataCleaning(corpus, lower = TRUE, specialChar = TRUE, stopWords = TRUE)
#   }
# 
#   cleanedCorpus <- as.character(corpus)[1]
#   cleanedCorpus <- gsub("[^[:alnum:]]", " ", cleanedCorpus)
#   cleanedCorpus <- gsub("^c", "", cleanedCorpus)
#   cleanedCorpus <- gsub("\\s+", " ", cleanedCorpus)
#   corpusWords <- strsplit(cleanedCorpus, " ", fixed = T)[[1]]
#   corpusNgrams <- vapply(NLP::ngrams(corpusWords, n), paste, "", collapse = " ")
#   corpusNgramCounts <- as.data.frame(xtabs(~corpusNgrams))
#   colnames(corpusNgramCounts) <- c('n.grams', 'Frequency')
#   corpusNgramCounts$n.grams <- as.character(corpusNgramCounts$n.grams)
#   return(corpusNgramCounts)
# }

### Generate N-Grams
generateNGrams <- function(corpus, n = 2, cleanNgrams = TRUE) {
  
  cleanedCorpus <- data.frame(text = sapply(corpus, identity), stringsAsFactors = FALSE)
  
  ngrams <- tidytext::unnest_tokens(cleanedCorpus, output = ngrams, input = text, token = 'ngrams', n = n)
  
  if(cleanNgrams) {
    newngrams <- ngrams %>% tidyr::separate(ngrams, paste0('word', c(1:n)), sep = ' ')
    for(i in 1:n) {
      newngrams <- newngrams %>% dplyr::filter_(paste0('!word', i, ' %in% tm::stopwords("en")'))
    }
    ngrams <- newngrams %>% tidyr::unite(ngrams, paste0('word', c(1:n)), sep = ' ')
  }
  return(ngrams)
}


### Generate TFIDF Matrix
generateTFIDFM <- function(corpus, threshold = .95, clean = TRUE){

  if(clean) {
    corpus <- basicDataCleaning(corpus, lower = TRUE, specialChar = TRUE, stopWords = TRUE)
  }
  dtm_tfidf <- tm::DocumentTermMatrix(corpus, control = list(weighting = tm::weightTfIdf,removePunctuation = TRUE, tolower = TRUE,
                                                             stopwords = TRUE, wordLengths=c(4, 20)))
  dtm_tfidf <- tm::removeSparseTerms(dtm_tfidf, threshold)
  return(dtm_tfidf)
}


### Generate DocumentTermMatrix
generateDTM <- function(corpus, controlList = list()){
  
  dtm <- tm::DocumentTermMatrix(corpus, control = controlList)
  
  # clearing empty documents
  rowTotals <- apply(dtm, 1, sum)
  dtm <- dtm[rowTotals > 0, ]
  
  return(dtm)
}


### Generate TermDocumentMatrix
generateTDM <- function(corpus, controlList = list()){
  
  tdm <-TermDocumentMatrix(corpus, control = controlList)
  
  # clearing empty documents
  rowTotals <- apply(tdm, 2, sum)
  tdm <- tdm[, rowTotals > 0]
  
  return(tdm)
}

### Preprocess and generate inputs for DTM/TDM
getDTM_TDM <- function(corpus, dtm_tdm = FALSE ,weighting) {
#browser()
  # estimate weighting function
  if(weighting == 'Term Frequency') {
    weightingFunction <- tm::weightTf
  } else if(weighting == 'TF-IDF') {
    weightingFunction <- tm::weightTfIdf
  } else if(weighting == 'Binary') {
    weightingFunction <- tm::weightBin
  } else if(weighting == 'SMART') {
    weightingFunction <- tm::weightSMART
  } else {
    stop('Weighting not recognizable')
  }
  
  # If TRUE, generate TDM. If FALSE, generate DTM
  if(dtm_tdm) {
    tdm <- generateTDM(corpus, controlList = list(weighting = weightingFunction, 
                                                  removePunctuation = TRUE, tolower = TRUE,
                                                  stopwords = TRUE, wordLengths=c(4, 20)))
    
    return(tdm)
    
  } else {
    dtm <- generateDTM(corpus, controlList = list(weighting = weightingFunction, 
                                                  removePunctuation = TRUE, tolower = TRUE,
                                                  stopwords = TRUE, wordLengths=c(4, 20)))
    #dtm <- tm::removeSparseTerms(dtm, threshold)
    return(dtm)
  }
}

getDTM_TDM1 <- function(corpus, dtm_tdm = FALSE, threshold = 0.95,weighting) {
  tdm_dtm <- getDTM_TDM(corpus, dtm_tdm ,weighting)
  tdm_dtm <- tm::removeSparseTerms(tdm_dtm, threshold)
  return(tdm_dtm)
}


### Generate word frequency table
generateWordFrequency <- function(corpus){
  
  dtm = getDTM_TDM(corpus, dtm_tdm = FALSE, weighting = 'Term Frequency')
  wordFrequency <- sort(colSums(as.matrix(dtm)), decreasing=TRUE)
  return(wordFrequency)
}


### Generate Word cloud based on word frequency
generateWordCloudFrequency <- function(corpus, priColor, secColor, minFreq = 50, maxWords = 100){
  
  #setting the same seed each time ensures consistent look across clouds
  set.seed(142)
  paletteColors <- grDevices::colorRampPalette(c(secColor, priColor))(5)
  wordFrequency <- generateWordFrequency(corpus)
  wordcloud::wordcloud(names(wordFrequency), wordFrequency, min.freq = minFreq, max.words = maxWords,
            colors = paletteColors, scale = c(5, 0.6), random.order = FALSE)
}


### Generate Word cloud based on word TFIDF
generateWordCloudTFIDF <- function(corpus, priColor, secColor, minFreq = 50, maxWords = 100){
  
  #setting the same seed each time ensures consistent look across clouds
  set.seed(142)
  paletteColors <- grDevices::colorRampPalette(c(priColor, secColor))(5)
  review_dtm_tfidf <- generateTFIDFM(corpus)
  wordFrequency <- sort(colSums(as.matrix(review_dtm_tfidf)), decreasing=TRUE)
  wordcloud::wordcloud(names(wordFrequency), wordFrequency, min.freq = minFreq, max.words = maxWords,
            colors= paletteColors, scale = c(5, 0.6))
}


### Generate Word Co-Occurrence Matrix
generateWordCoOccurrenceMatrix <- function(corpus, context = 'window', window = 3, count = 'frequency', cleandNGrams = TRUE){
#browser()  
  if(cleandNGrams == TRUE) {
    corpus <- basicDataCleaning(corpus, lower = TRUE, specialChar = TRUE, stopWords = TRUE)
  }
  
  cleanedCorpus <- sapply(corpus, identity)
  
  if(context == 'window') {
    cleanedCorpus <- paste(cleanedCorpus, collapse = ' ')
    toks <- quanteda::tokens(cleanedCorpus, remove_punct = TRUE)
    wcoMatrix <- quanteda::fcm(toks, context = context, window = window, count = count)
    
  } else if(context == 'document') {
    wcoMatrix <- quanteda::fcm(cleanedCorpus, context = context, count = count)
  }
  return(wcoMatrix)
}


### Get Associate words
getAssociateWords <- function(corpus, word, corlimit = 0.30){
  
  dtm <- getDTM_TDM(corpus, dtm_tdm = FALSE, weighting = 'Term Frequency')
  associateWords <- tm::findAssocs(dtm, word, corlimit)
  return(associateWords)
}


## Make a graph from Tree_parse result
## Taken from StackOverflow
parse2graph <- function(ptext, leaf.color='chartreuse4', label.color='blue4',
                        cex.main=.9, ...) {
  #stopifnot(require(NLP) && require(igraph))
  
  
  ## Replace words with unique versions
  ms <- gregexpr("[^() ]+", ptext)                                      # just ignoring spaces and brackets?
  words <- regmatches(ptext, ms)[[1]]                                   # just words
  regmatches(ptext, ms) <- list(paste0(words, seq.int(length(words))))  # add id to words
  
  ## Going to construct an edgelist and pass that to igraph
  ## allocate here since we know the size (number of nodes - 1) and -1 more to exclude 'TOP'
  edgelist <- matrix('', nrow=length(words)-2, ncol=2)
  
  ## Function to fill in edgelist in place
  edgemaker <- (function() {
    i <- 0                                       # row counter
    g <- function(node) {                        # the recursive function
      if (inherits(node, "Tree")) {            # only recurse subtrees
        if ((val <- node$value) != 'TOP1') { # skip 'TOP' node (added '1' above)
          for (child in node$children) {
            childval <- if(inherits(child, "Tree")) child$value else child
            i <<- i+1
            edgelist[i,1:2] <<- c(val, childval)
          }
        }
        invisible(lapply(node$children, g))
      }
    }
  })()
  
  ## Create the edgelist from the parse tree
  edgemaker(NLP::Tree_parse(ptext))
  
  ## Make the graph, add options for coloring leaves separately
  g <- igraph::graph_from_edgelist(edgelist)
  igraph::vertex_attr(g, 'label.color') <- label.color  # non-leaf colors
  igraph::vertex_attr(g, 'label.color', igraph::V(g)[!igraph::degree(g, mode='out')]) <- leaf.color
  igraph::V(g)$label <- sub("\\d+", '', igraph::V(g)$name)      # remove the numbers for labels
  # plot(g, layout=layout.reingold.tilford, ...)
  return(g)
}


# Create anotators before running the parsing to save computation time.
# anonParse - TRUE if parse anotator
# anonPos - TRUE if pos anotator
createAnnotators <- function(anonParse = FALSE, anonPos = FALSE) {
  sent_token_annotator <- openNLP::Maxent_Sent_Token_Annotator()
  word_token_annotator <- openNLP::Maxent_Word_Token_Annotator()
  
  # generate parse anotator
  if(anonParse) {
    parse_annotator <- openNLP::Parse_Annotator()
    return(
      list(sent = sent_token_annotator, word = word_token_annotator, parse = parse_annotator)
    )
    
  }
  
  # generate pos anotator
  if(anonPos) {
    pos_annotator <- openNLP::Maxent_POS_Tag_Annotator()
    return(
      list(sent = sent_token_annotator, word = word_token_annotator, pos = pos_annotator)
    )
  }
  
  return(
    list(sent = sent_token_annotator, word = word_token_annotator)
  )
}

createParseTree <- function(text, anonList){
  
  s <- NLP::as.String(text)
  
  parseTreeAnnotator <- NLP::annotate(s, list(anonList$sent, anonList$word))
  textAnnotator <- anonList$parse(s, parseTreeAnnotator)
  parsetext <- sapply(textAnnotator$features, `[[`, "parse")
  
  # generating the graph
  g <- parse2graph(parsetext)
  gc()
  return(g)
}

### Extract POS Tags
extractPOSTags <- function(text, anonList) {
  
  s <- NLP::as.String(text)
  
  tokenAnnotators <- NLP::annotate(s, list(anonList$sent, anonList$word))
  posAnnotators <- NLP::annotate(s, anonList$pos, tokenAnnotators)
  annotatorWords <- subset(posAnnotators, type == "word")
  POStags <- unlist(lapply(annotatorWords$features, `[[`, "POS"))
  
  gc()
  return(sprintf("%s-%s", s[annotatorWords], POStags))
}

#### Prediction of Classification Techniques:
pred_classifcation <- function(text_data_classify, pred_obj, Model_type){
  # browser()
  a<- load(pred_obj)
  corpus <- tm::Corpus(tm::VectorSource(text_data_classify$Text_data))
  corpus_clean <- basicDataCleaning(corpus, lower = TRUE, specialChar = TRUE, stopWords = TRUE)
  dtm<- tm::DocumentTermMatrix(corpus_clean)
  dtm <- tm::removeSparseTerms(dtm, 0.99) 
  data_input <- as.data.frame(as.matrix(dtm))
  
  # Identify the additional terms in the model object:
  if(Model_type == "Random Forest"){
    model_obj_terms <- matrix(unlist(attributes(get(a)$forest$xlevels)), ncol = 1)
    pred_data_terms <- matrix(colnames(data_input))
    Additional_column<- setdiff(model_obj_terms, pred_data_terms)
    data_input[Additional_column] <- 0
  }
  
  if(Model_type == "Naive Bayes"){
    model_obj_terms <- matrix(names(get(a)$tables))
    pred_data_terms <- matrix(colnames(data_input))
    Additional_column<- setdiff(model_obj_terms, pred_data_terms)
    data_input[Additional_column] <- 0
  }
  library(randomForest)
  library(e1071)
  # apply(summarise_if(data_input[,(1:1464)], is.numeric, funs(sum(is.na(.)))),1, sum)
  y_pred <-  stats::predict(get(a), data_input)
  # write.csv(y_pred,'/home/shruti/10_FoundationBrick_TextMining/JenkinsTestData/Predicted_RM_data.csv', row.names = FALSE)
  return(y_pred)
}


#### Classification Techniques ####
### Random Forest ###
rf_train_model <- function(input_data, split=0.7, Trees = 500){
  # browser()
  colnames(input_data)
  corpus <- tm::Corpus(tm::VectorSource(input_data$Content))
  corpus_clean <- basicDataCleaning(corpus, lower = TRUE, specialChar = TRUE, stopWords = TRUE)
  dtm<- tm::DocumentTermMatrix(corpus_clean)
  dtm <- tm::removeSparseTerms(dtm, 0.99) 
  data_input <- as.data.frame(as.matrix(dtm))
  data_input$Intent <- input_data$Intent
  Unique_level_Intent <- unique(data_input$Intent)
  data_input$Intent <- factor(data_input$Intent, levels = Unique_level_Intent)
  
  # Splitting the data into training and test;
  
  library(caTools)
  set.seed(123)
  split = sample.split(data_input$Intent, SplitRatio =split)
  training_set = subset(data_input, split == TRUE)
  test_set = subset(data_input, split == FALSE)
  
  # Applying the random forest model on the data set:
  # install.packages('randomForest')
  library(randomForest)
  classifier = randomForest(x = subset(training_set, select=-c(Intent)),
                            y = training_set$Intent,
                            ntree = Trees)

  
  # Predicting the values of the dataset:
  y_pred = predict(classifier, newdata = subset(test_set, select=-c(Intent)))
  y_pred <- factor(y_pred, levels = Unique_level_Intent)
  
  # Analyse the accuracy of the model:
  analytics <- caret::confusionMatrix(data = y_pred, reference = test_set$Intent)
  filename = ""
  return(list(filename, analytics, classifier))
  
}


### KNN_model ###
KNN_model<- function(input_data, split=0.7, K_Value = 4){
  # browser()
  colnames(input_data)
  corpus <- tm::Corpus(tm::VectorSource(input_data$Content))
  corpus_clean <- basicDataCleaning(corpus, lower = TRUE, specialChar = TRUE, stopWords = TRUE)
  dtm<- tm::DocumentTermMatrix(corpus_clean)
  dtm <- tm::removeSparseTerms(dtm, 0.99) 
  data_input <- as.data.frame(as.matrix(dtm))
  data_input$Intent <- input_data$Intent
  Unique_level_Intent <- unique(data_input$Intent)
  # data_input$Intent[data_input$Intent == "positive"] <- 1
  # data_input$Intent[data_input$Intent == "negative"] <- 0
  data_input$Intent <- factor(data_input$Intent, levels = Unique_level_Intent)
  
  # Splitting the data into training and test;
  library(caTools)
  set.seed(123)
  split = sample.split(data_input$Intent, SplitRatio =split)
  training_set = subset(data_input, split == TRUE)
  test_set = subset(data_input, split == FALSE)
  training_set[,c("Intent")]
  
  # Building the Model:
  # install.packages("class")
  library(class)
  y_pred = knn(train = subset(training_set, select=-c(Intent)),
               test = subset(test_set, select=-c(Intent)),
               cl = training_set$Intent,
               k = K_Value,
               prob = TRUE)
  
  # Analyse the accuracy of the model:
  analytics <- caret::confusionMatrix(data = y_pred, reference = test_set$Intent)
  
  return(analytics)
}

### Naive bayes ###
nb_train_model <- function(input_data, split=0.7){
  # browser()
  colnames(input_data)
  corpus <- tm::Corpus(tm::VectorSource(input_data$Content))
  corpus_clean <- basicDataCleaning(corpus, lower = TRUE, specialChar = TRUE, stopWords = TRUE)
  dtm<- tm::DocumentTermMatrix(corpus_clean)
  dtm <- tm::removeSparseTerms(dtm, 0.99) 
  data_input <- as.data.frame(as.matrix(dtm))
  data_input$Intent <- input_data$Intent
  Unique_level_Intent <- unique(data_input$Intent)
  data_input$Intent <- factor(data_input$Intent, levels = Unique_level_Intent)

  set.seed(123)
  split = caTools::sample.split(data_input$Intent, SplitRatio =split)
  training_set = subset(data_input, split == TRUE)
  test_set = subset(data_input, split == FALSE)
  
  # Applying the random forest model on the data set:
  # install.packages('e1071')
  # library(e1071)
  classifier = e1071::naiveBayes(x = subset(training_set, select=-c(Intent)),
                            y = training_set$Intent)
  
  # Predicting the values of the dataset:
  y_pred = predict(classifier, newdata = subset(test_set, select=-c(Intent)))
  set.seed(123)
  y_pred <- factor(y_pred, levels = Unique_level_Intent) 
  
  # Analyse the accuracy of the model:
  analytics <- caret::confusionMatrix(data = y_pred, reference = test_set$Intent)
  filename = ""
  return(list(filename, analytics, classifier))
  
}


# #### Classification techniques ####
# rf_train_model <- function(train_file, modelfile='randomForest',split){
#   browser()
#   input_data <- train_file
# 
# 
#   # Create train test split
#   intrain<-caret::createDataPartition(y=input_data$Intent,p=split,list=FALSE)
#   data<-input_data[intrain,]
#   test_df<-input_data[-intrain,]
# 
#   # Prepare Corpus for vocabulary
#   data <- data.frame(doc_id=row.names(data), text=data$Content, Intent = data$Intent)
#   test_df <- data.frame(doc_id=row.names(test_df), text=test_df$Content, Intent = test_df$Intent)
# 
#   data <- data[!duplicated(rbind(test_df, data))[-seq_len(nrow(test_df))], ]
#   data_content <- subset(data, select = c("doc_id", "text"))
#   test_content_df <- subset(test_df, select = c("doc_id", "text"))
# 
#   corpus <- tm::Corpus(tm::DataframeSource(data_content))
#   # Create a document term matrix.
#   TriTok<- function(x) tokenizers::NGramTokenizer(x, Weka_control(min = 1, max = 2))
#   tdm <- tm::DocumentTermMatrix(corpus, list(stopwords = TRUE, weighting = function(x) tm::weightTfIdf(x, normalize = TRUE), tokenize = TriTok))
#   #tdm <- removeSparseTerms(tdm, 0.99)
#   train <- as.matrix(tdm)
# 
#   save(tdm, file = "./Downloads/tdm.rda")
#   #dim(train)
# 
#   # Convert to a data.frame for training and assign a classification (factor) to each document.
#   train <- cbind(train, data$Intent)
#   colnames(train)[ncol(train)] <- 'y'
#   train <- as.data.frame(train)
#   train$y <- as.factor(train$y)
# 
# 
#   ##Process test data
#   corpus <- tm::Corpus(tm::DataframeSource(test_content_df))
#   tdm <- tm::DocumentTermMatrix(corpus, control = list(dictionary = tm::Terms(tdm), stopwords = TRUE, weighting = function(x) tm::weightTfIdf(x, normalize = TRUE),tokenize = TriTok))
# 
#   test <- as.matrix(tdm)
#   test <- cbind(test, test_df$Intent)
#   colnames(test)[ncol(test)] <- 'y'
#   test <- as.data.frame(test)
#   test$y <- as.factor(test$y)
#   names(test) <- make.names(names(test))
#   test <- test[, !duplicated(colnames(test))]
#   names(train) <- make.names(names(train))
#   train <- train[, !duplicated(colnames(train))]
#   test <- test[, intersect(colnames(train), colnames(test))]
#   train <- train[, intersect(colnames(train), colnames(test))]
# 
#   fit <- randomForest::randomForest(y ~ ., data = train)
#   summary(fit)
#   modelname =  paste('./Downloads/',modelfile,'.rda', sep = "")
#   save(fit, file=modelname)
#   print(paste0("Model saved in ", modelname))
# 
#   predictions <- stats::predict(fit, newdata = test)
# 
#   x <- as.data.frame(cbind(test$y, predictions))
#   colnames(x) <- c("actual_intent", "predicted_intent")
#   x$actual_intent <- factor(x$actual_intent)
#   x$predicted_intent <- factor(x$predicted_intent)
#   analytics <- caret::confusionMatrix(data = x$predicted_intent, reference = x$actual_intent)
#   stats <- analytics$byClass
#   print(stats)
# }

rf_prediction <- function(modelfile, content){
  load("./Downloads/tdm.rda")
  train <- as.data.frame(as.matrix(tdm))
  
  corpus <- tm::Corpus(tm::VectorSource(c(content)))
  TriTok<- function(x) tokenizers::NGramTokenizer(x, Weka_control(min = 1, max = 2))
  tdm <- tm::DocumentTermMatrix(corpus, control = list(dictionary = Terms(tdm), stopwords = TRUE, weighting = function(x) tm::weightTfIdf(x, normalize = TRUE),tokenize = TriTok))
  #tdm <- removeSparseTerms(tdm, 0.99)
  test <- as.matrix(tdm)
  test <- as.data.frame(test)
  names(test) <- make.names(names(test))
  test <- test[, !duplicated(colnames(test))]
  load(paste("./Downloads/", modelfile, '.rda', sep=""))
  
  test[, attributes(fit$terms)$term.labels] <- 0
  predictions <- predict(fit, newdata = test)
  print(as.integer(predictions))
  return(as.integer(predictions))
}
#### Topic Model ####

# To calculate the perplexity for the given number of topics and estimate the ideal number of topics for the given corpus
findNumTopics <- function(corpus, maxSample, topics, progIndicator = FALSE, progressObj = NA) {
#browser()  
  set.seed(142)
  
  # Generating samples
  nSamples <- min(maxSample, length(corpus))
  trainSamples <- sample(1:nSamples, round(nSamples*0.8), replace = FALSE)
  testSamples <- setdiff(1:nSamples, trainSamples)
  
  train <- corpus[trainSamples]
  test <- corpus[testSamples]
  
  dtm_train <- getDTM_TDM(train, dtm_tdm = FALSE, weighting = 'Term Frequency')
  dtm_test <- getDTM_TDM(test, dtm_tdm = FALSE,  weighting = 'Term Frequency')
  # dtm_test <- tm::removeSparseTerms(dtm_test, 0.5)
  # dtm_train <- tm::removeSparseTerms(dtm_train, 0.9)
  # Setting default control parameters
  perplexityDf <- data.frame(train=numeric(), test=numeric())
  
  for(i in topics){
    
    if(progIndicator) {
      progressObj$inc(1/length(topics))
    }
    cat(paste("Calculating for", i, "topics \n"))
    
    # build model and calculate perplexity
    fitted <- topicmodels::LDA(dtm_train, k = i, method = "Gibbs",
                  control = list(burnin = 100, iter = 1000, keep = 50))
    
    perplexityDf[i,1] <- topicmodels::perplexity(fitted, newdata = dtm_train)
    perplexityDf[i,2] <- topicmodels::perplexity(fitted, newdata = dtm_test) 
  }
  
  perplexityDf <- na.omit(perplexityDf)
  
  # hold out perplexity plot
  perplexityDf2 <- reshape::melt(perplexityDf)
  perplexityDf2$topics <- topics
  
  perplexityPlot <- ggplot2::ggplot(data=perplexityDf2, ggplot2::aes(y = value, x = topics, color = variable)) + 
    ggplot2::labs(y = "Perplexity", x = "Number of topics", color = 'Dataset') + 
    ggplot2::ggtitle("Perplexity of hold out and training data") + 
    ggplot2::geom_line()
  
  return(list(df = perplexityDf, plot = perplexityPlot))
}


# Build LDA model and return the model along with the top words in each topic
buildLDA <- function(dtm, nTopics, method, nterms, ndocs) {
  
  if(class(dtm)[1] != 'DocumentTermMatrix') {
    stop('The generated matrix should be a Document Term Matrix weighted using Word Frequency')
  }
  if(attr(dtm, 'weighting')[1] != 'term frequency') {
    stop('The generated matrix should be a Document Term Matrix weighted using Word Frequency')
  }
  dtm <- tm::removeSparseTerms(dtm, 0.95)
  set.seed(142)
  
  # Build LDA model
  ldaModel <- topicmodels::LDA(dtm, k = nTopics, method = 'VEM', control = list(keep = 2))
  
  print("built model...")
  
  # tidy model and get the per-topic per-word probabilities
  probTableBeta <- tidytext::tidy(ldaModel, matrix = "beta")
  
  # Filtering top 'nterms' to return for the plot
  topwords <- probTableBeta %>% 
    dplyr::group_by(topic) %>%
    dplyr::top_n(nterms, beta) %>% 
    # top_n(8, beta) %>% 
    dplyr::ungroup() %>% 
    dplyr::arrange(topic, -beta) %>% 
    dplyr::mutate(term = reorder(term, beta))
  
  # generating plot
  wordPlot <- ggplot2::ggplot(topwords, ggplot2::aes(term, beta, fill = factor(topic))) +
    ggplot2::geom_bar(stat = 'identity', show.legend = FALSE, color = 'grey90') +
    ggplot2::facet_wrap(~ topic, scales = "free") +
    ggplot2::coord_flip() +
    ggplot2::xlab('Terms') +
    ggplot2::ylab('Probabilities') +
    ggplot2::ggtitle('Most probable words per topic')
  
  # tidy model and get per-document per-topic probabilities
  probTableGamma <- tidytext::tidy(ldaModel, matrix = "gamma")
  
  # Filtering top 'ndocs' to return for the plot
  probTableGamma <- probTableGamma %>% dplyr::arrange(document, topic)
  plotdocs <- probTableGamma %>% dplyr::group_by(topic) %>% dplyr::top_n(ndocs, gamma) %>% dplyr::ungroup() %>% 
    dplyr::arrange(topic, -gamma)
  plotdocs <- as.numeric(plotdocs$document)
  
  rows <- unlist(lapply(match(plotdocs, probTableGamma$document), function(x) x:(x+nTopics-1)))
  
  topdocs <- probTableGamma[rows,]
  topdocs$document <- factor(topdocs$document, levels = unique(topdocs$document))
  
  # generating plots
  docPlot <- ggplot2::ggplot(topdocs, ggplot2::aes(x = document, y = gamma, fill = factor(topic))) +
    ggplot2::geom_bar(stat = 'identity', width = 0.8, show.legend = FALSE) +
    ggplot2::coord_flip() +
    ggplot2::xlab('Document') +
    ggplot2::ylab('Probabilities') +
    ggplot2::ggtitle("Document topic probabilities")
  
  return(list(model = ldaModel, topwords = topwords, wordPlot = wordPlot, topdocs = topdocs, docPlot = docPlot))
}

#### Sentiment Analysis ####

# Basic sentiment analysis using dictonary provided with tidytext package
runBasicSentiment <- function(dataset, lexicon, positiveClass, priColor, labelPresent) {
  #browser()
  if(lexicon == 'Bing et al.') {
    sentimentTable <- tidytext::get_sentiments('bing')
  } else if(lexicon == 'NRC') {
    sentimentTable <- tidytext::get_sentiments('nrc') %>% dplyr::filter(sentiment %in% c('positive', 'negative'))
  } else if(lexicon != 'AFINN') {
    stop('Wrong sentiment dictionary.')
  }
  
  unigrams <- tidytext::unnest_tokens(dataset, output = word, input = text)
  
  # Since AFINN gives scores directly, we calculate sentiments differently for that dataset
  if(lexicon == 'AFINN') {
    predicted <- unigrams %>% dplyr::inner_join(tidytext::get_sentiments("afinn"), by = 'word') %>% 
      dplyr::group_by(doc) %>% dplyr::summarise(sent.score = sum(score)) %>%
      dplyr::mutate(sentiment.pred = ifelse(sent.score > 0, 'positive', 'negative'))
    
  } else {
    predicted <- unigrams %>% dplyr::inner_join(sentimentTable, by = 'word') %>%  # Merge sentiment words and unigrams
      dplyr::count(doc, sentiment) %>% tidyr::spread(sentiment, n, fill = 0) %>% # split sentiment col into positive & negative sentiment cols
      dplyr::mutate(sent.score = positive - negative) %>% # calculate total sentiment scores
      dplyr::mutate(sentiment.pred = ifelse(sent.score > 0, 'positive', 'negative'))
  }
  # Generating plot
  scorePlot <- ggplot2::ggplot(predicted, ggplot2::aes(x = doc, y = sent.score)) +
    ggplot2::geom_col(color = priColor) +
    ggplot2::xlab('Document') +
    ggplot2::ylab('Sentiment Score') +
    ggplot2::ggtitle(paste0('Sentiment scores from ',lexicon))
 scorePlot <- plotly::ggplotly(scorePlot) 
  # combining with actual to fill documents that went missing
  ## NOTE: Filled 0s will be replaced as negative class
  if(labelPresent==TRUE){
    predicted <- predicted %>% dplyr::right_join(dataset[, c('sentiment.true', 'doc')], by = 'doc')
  }
  else{
    predicted <- predicted %>% dplyr::right_join(dataset['doc'],by='doc')
  }
  predicted <- predicted %>% dplyr::mutate(sentiment.pred = ifelse(is.na(sentiment.pred), 'negative', sentiment.pred))
  predicted[is.na(predicted)] <- 0

  print("predicted computed successfully")
  
  
  # getting confusion matrix
  if(labelPresent==TRUE){
    
    #Replacing 'positive's and 'negative's with positiveClass and negativeClass names
    
    index_positive <- which(predicted$sentiment.pred=="positive")
    index_negative <- which(predicted$sentiment.pred=="negative")
    availableSentiment <- unique(predicted$sentiment.true)
    negativeClass <- availableSentiment[availableSentiment!=positiveClass]
    predicted$sentiment.pred[index_positive] <- positiveClass
    predicted$sentiment.pred[index_negative] <- negativeClass
    
    cm <- caret::confusionMatrix(table(predicted$sentiment.true,predicted$sentiment.pred), positive = positiveClass)
  }
  
  return(list(pred = predicted, plot = scorePlot, cm = cm))
}

#To run CoreNLP model to get sentiment for every tokenized sentence
getSentiment_sentence <- function(sentence){
  single_sentence <- gsub('[.]','',sentence)
  annotated_sentence <- coreNLP::annotateString(single_sentence)
  sentiment_pred <- coreNLP::getSentiment(annotated_sentence)$sentiment
  return(sentiment_pred)
}

getDataFrameFromTm <- function(tmObject){
  return (data.frame(text=sapply(tmObject, identity), stringsAsFactors=F)   )
}

## Download Report
downloadReport <- function(reactData, input, fileName){

  rmarkdown::render('Source/TextMiningReport.Rmd',
                    switch(input$report_format,
                           PrettyHTML = prettydoc::html_pretty(css = paste0(reactData$working_dir, "/Styles/pretty_styles.css")),
                           HTML = rmarkdown::html_document(css = paste0(reactData$working_dir,"/Styles/styles.css") ,toc=TRUE, toc_float=TRUE)
                    ), 
                    output_dir = paste0(reactData$working_dir,"/Downloads/"), 
                    output_file = fileName,
                    params = list(
                      workingDir = reactData$working_dir,
                      reactData = reactData,
                      input = input
                    )
  )
}