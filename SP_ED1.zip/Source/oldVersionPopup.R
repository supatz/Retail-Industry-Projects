oldVersionPopup <- function(input, output)
{
  tryCatch({
    getContent<-function(id){
      url = paste0('https://eoc.mu-sigma.com/alfresco/api/-default-/public/alfresco/versions/1/nodes/',id,'/children')
      r <- httr::GET(url, httr::authenticate(user = "foundation.bricks", password = "Musigma@2018"),httr::timeout(5))
      url_content<- rjson::fromJSON(rawToChar(r$content))
      return(url_content)
    }
    
  rooms<-getContent('12bea98f-a72d-4c59-831b-719a4c9f1d82')$list$entries
  
  rooms_id <- lapply(rooms, FUN = function(x){x$entry$id})
  bricks_id<- lapply(rooms_id, FUN = function(x){getContent(x)$list$entries[[1]]$entry$id})
  bricks_names<- lapply(bricks_id, FUN = function(x){getContent(x)$list$entries[[1]]$entry$name})
  
  filename <- rjson::fromJSON(file = 'Source/Description.json')['filename']
  latestbrick <-  bricks_names[grep(filename, bricks_names)]
  w <- strsplit(latestbrick[[1]],"_")[[1]]
  latest_version <- strsplit(w[length(w)],".zip")
  version <- rjson::fromJSON(file = 'Source/Description.json')['version']

  if(latest_version > paste0("v",version))
    # if(1)
  {
    output$popStart_2<-shiny::renderUI({shiny::tags$div(class="whiteBox_2","")})
    
    output$popStart<-shiny::renderUI({shiny::tagList(shiny::tags$div(class="whiteBox",shiny::tags$p(id="headPopup","Older Version Detected",style="color:red;"),shiny::tags$hr(),
                                                                     shiny::tags$p(id="bodyPopup","Hey! Looks like you are using an older version of this brick. We recommend you to download the latest version",style="color:red;font-size=18px"),shiny::tags$hr(),
                                                                     shiny::actionButton("closePopup","Close")))
    })
    
    
    
    shiny::observeEvent(input$closePopup,
                 {
                   output$popStart<-shiny::renderUI({})
                   output$popStart_2<-shiny::renderUI({})
                 }
    )
    
  }
  }, error = function(e) {print(e)})
}
