
#Test cases for the text mining brick
library(testthat)
source('TextMiningUtils.R')
loadGlobals()
loadPackage <- function(pkgName){
  if (!do.call(require, list(pkgName))) {
    install.packages(pkgName, dependencies = T, repos = "http://cran.us.r-project.org")
    do.call(library, list(pkgName))
  }
}
lapply(packages, FUN = function(p){ loadPackage(p) })


### Input for the benchmarking and outputs

basicCleaningInput <- readRDS('../JenkinsTestData/basicCleaningInput.RDS')
basicCleaningOutput <- readRDS('../JenkinsTestData/basicCleaningOutput.RDS')
numTopicList <- readRDS("../JenkinsTestData/numTopicList.RDS")
dtm <- readRDS("../JenkinsTestData/dtm.RDS")
LDAObject <- readRDS("../JenkinsTestData/LDAObject.RDS")
gPhrases <- readRDS("../JenkinsTestData/gPhrases.RDS")
basicSentimentText <- readRDS("../JenkinsTestData/basicSentimentText.RDS")
basicSentimentResult <- readRDS("../JenkinsTestData/basicSentimentResult.RDS")
textCorpus <- readRDS('../JenkinsTestData/textCorpus.RDS')
dtmResult <- readRDS('../JenkinsTestData/dtmResult.RDS')
wcm_result <- as.matrix(readRDS("../JenkinsTestData/wordCooccurenceMatrix.RDS"))
NGrams <- readRDS('../JenkinsTestData/NGrams.RDS')
pfStemming <- readRDS("../JenkinsTestData/performStemming.RDS")
pfLemmatization <- readRDS('../JenkinsTestData/performLemmatization.RDS')
rmSpChar <- readRDS("../JenkinsTestData/rmSpChar.RDS")
rmURL <- readRDS("../JenkinsTestData/rmURL.RDS")
rmStopwords <- readRDS("../JenkinsTestData/rmStopwords.RDS")
rmCuswords <- readRDS("../JenkinsTestData/rmCuswords.RDS")
rmemail <- readRDS("../JenkinsTestData/rmemail.RDS")
rmhtml <- readRDS("../JenkinsTestData/rmhtml.RDS")
rmauthor <- readRDS("../JenkinsTestData/rmauthor.RDS")
rmAuthorName <- readRDS("../JenkinsTestData/removeAuthorName.RDS")
rpHashTags <- readRDS("../JenkinsTestData/replaceHashTags.RDS")
rmHashTags <- readRDS("../JenkinsTestData/removeHashTags.RDS")
rmNoneWords <- readRDS("../JenkinsTestData/removeNoneWords.RDS")
rmSoloNumbers <- readRDS("../JenkinsTestData/removeSoloNumbers.RDS")
rmMultiSpaceUnicode <- readRDS("../JenkinsTestData/removeMultiSpaceUnicode.RDS")
rmRepetitiveWords <-readRDS("../JenkinsTestData/removeRepetitiveWords.RDS")
rmSmallWords <- readRDS("../JenkinsTestData/removeSmallWords.RDS")
rmExtraWhiteSpaces <- readRDS("../JenkinsTestData/removeExtraWhiteSpaces.RDS")
IntoLowerCase <- readRDS("../JenkinsTestData/convertIntoLowerCase.RDS")
IntoUpperCase <- readRDS("../JenkinsTestData/convertIntoUpperCase.RDS")
gDTM <- readRDS("../JenkinsTestData/gDTM.RDS") 
gTDM <- readRDS("../JenkinsTestData/gTDM.RDS")
gWordFrequency <- readRDS("../JenkinsTestData/gWordFrequency.RDS")
gAWords <- readRDS("../JenkinsTestData/gAWords.RDS")
gWCTFIDF <- readRDS("../JenkinsTestData/gWCTFIDF.RDS")
sen <- readRDS("../JenkinsTestData/string.RDS")
gGFFT <- readRDS("../JenkinsTestData/gGFFT.RDS")
getSenTok <- readRDS("../JenkinsTestData/getSenTok.RDS")
textPtree<- readRDS("../JenkinsTestData/textPtree.RDS")
anlist <- readRDS("../JenkinsTestData/anlist.RDS")
partext <- readRDS("../JenkinsTestData/partext.RDS")
resPartext <-readRDS("../JenkinsTestData/resPartext.RDS")
parsetree <- readRDS("../JenkinsTestData/parseTree.RDS") 
TFIDFM <- readRDS("../JenkinsTestData/TFIDFM.RDS")
text_data <- read.csv("../JenkinsTestData/Text_data.csv")
Random_Forest <- readRDS("../JenkinsTestData/Random_Forest.RDS")
Naive_Bayes <- readRDS("../JenkinsTestData/Naive_Bayes.RDS")
failedTestResults <- list()

allTestResults <- list()


### Testing of Random Forest Function:

Testrandomforest <- function(text_data, results)
{ 
  failedTests <- list()
  set.seed(89)
  colnames(text_data) <- c("X","Content","Intent")
  obj <- rf_train_model(text_data, split=0.7)
  obj <- obj[[3]]
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test randomForest' ,{
        expect_equal(
          class(obj), class(results)
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}

result <- Testrandomforest(text_data,Random_Forest)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n rf_train_model() test starts \n", 
                                                                x, "rf_train_model() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n rf_train_model() test starts\n", x, "\n rf_train_model() test ends\n\n")))
  }
})


### Testing of Naive Bayes Function:

TestNaiveBayes <- function(text_data, results)
{
  failedTests <- list()
  set.seed(89)
  colnames(text_data) <- c("X","Content","Intent")
  obj <- nb_train_model(text_data, split=0.7)
  obj <- obj[[3]]
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test NaiveBayes' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}

result <- TestNaiveBayes(text_data,Naive_Bayes)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n nb_train_model() test starts \n", 
                                                                x, "nb_train_model() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n nb_train_model() test starts\n", x, "\n nb_train_model() test ends\n\n")))
  }
})


### Testing of removeSpecialChar() 

TestremoveSpecialChar <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeSpecialChar(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeSpecialChar' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- TestremoveSpecialChar(textCorpus,rmSpChar)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeSpecialChar() test starts \n", 
                                                                x, "removeSpecialChar() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeSpecialChar() test starts\n", x, "\n removeSpecialChar() test ends\n\n")))
  }
})

### end of removeSpecialChar() test


### Testing of removeURLs() 

TestremoveURLs <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeURLs(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeURLs' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestremoveURLs(textCorpus,rmURL)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeURLs() test starts \n", 
                                                                x, "removeURLs() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeURLs() test starts\n", x, "\n removeURLs() test ends\n\n")))
  }
})

### end of removeURLs() test

### Testing of removeStopWords() 

TestremoveStopWords <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeStopWords(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeStopWords' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestremoveStopWords(textCorpus,rmStopwords)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeStopWords() test starts \n", 
                                                                x, "removeStopWords() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeStopWords() test starts\n", x, "\n removeStopWords() test ends\n\n")))
  }
})

### end of removeStopWords() test

### Testing of removeCustomStopWords() 

TestremoveCustomStopWords <- function(corpus,stopWordsList,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeCustomStopWords(corpus,stopWordsList)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeCustomStopWords' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestremoveCustomStopWords(textCorpus,"film",rmCuswords)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeCustomStopWords() test starts \n", 
                                                                x, "removeCustomStopWords() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeCustomStopWords() test starts\n", x, "\n removeCustomStopWords() test ends\n\n")))
  }
})

### end of removeCustomStopWords() test


### Testing of removeHtmlTags() 

TestremoveHtmlTags <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeHtmlTags(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeHtmlTags' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestremoveHtmlTags(textCorpus,rmhtml)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeHtmlTags() test starts \n", 
                                                                x, "removeHtmlTags() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeHtmlTags() test starts\n", x, "\n removeHtmlTags() test ends\n\n")))
  }
})

### end of removeHtmlTags() test

### Testing of removeEmailAddress() 

TestremoveEmailAddress <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeEmailAddress(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeEmailAddress' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestremoveEmailAddress(textCorpus,rmemail)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeEmailAddress() test starts \n", 
                                                                x, "removeEmailAddress() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeEmailAddress() test starts\n", x, "\n removeEmailAddress() test ends\n\n")))
  }
})

### end of removeEmailAddress() test


### Testing of replaceAuthorName() 

TestreplaceAuthorName <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- replaceAuthorName(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test replaceAuthorName' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- TestreplaceAuthorName(textCorpus,rmauthor)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n replaceAuthorName() test starts \n", 
                                                                x, "replaceAuthorName() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n replaceAuthorName() test starts\n", x, "\n replaceAuthorName() test ends\n\n")))
  }
})

### end of replaceAuthorName() test



### Testing of removeAuthorName() 

TestremoveAuthorName <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeAuthorName(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeAuthorName' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestremoveAuthorName(textCorpus,rmAuthorName)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeAuthorName() test starts \n", 
                                                                x, "removeAuthorName() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeAuthorName() test starts\n", x, "\n removeAuthorName() test ends\n\n")))
  }
})

### end of removeAuthorName() test

### Testing of replaceHashTags() 

TestreplaceHashTags <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- replaceHashTags(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test replaceHashTags' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestreplaceHashTags(textCorpus,rpHashTags)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n replaceHashTags() test starts \n", 
                                                                x, "replaceHashTags() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n replaceHashTags() test starts\n", x, "\n replaceHashTags() test ends\n\n")))
  }
})

### end of replaceHashTags() test

### Testing of removeHashTags() 

TestremoveHashTags <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeHashTags(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeHashTags' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestremoveHashTags(textCorpus,rmHashTags)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeHashTags() test starts \n", 
                                                                x, "removeHashTags() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeHashTags() test starts\n", x, "\n removeHashTags() test ends\n\n")))
  }
})

### end of removeHashTags() test


### Testing of removeNoneWords() 

TestremoveNoneWords <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeNoneWords(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeNoneWords' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- TestremoveNoneWords(textCorpus,rmNoneWords)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeNoneWords() test starts \n", 
                                                                x, "removeNoneWords() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeNoneWords() test starts\n", x, "\n removeNoneWords() test ends\n\n")))
  }
})

### end of removeNoneWords() test


### Testing of removeSoloNumbers() 

TestremoveSoloNumbers <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeSoloNumbers(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeSoloNumbers' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- TestremoveSoloNumbers(textCorpus,rmSoloNumbers)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeSoloNumbers() test starts \n", 
                                                                x, "removeSoloNumbers() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeSoloNumbers() test starts\n", x, "\n removeSoloNumbers() test ends\n\n")))
  }
})

### end of removeSoloNumbers() test

### Testing of removeMultiSpaceUnicode() 

TestremoveMultiSpaceUnicode <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeMultiSpaceUnicode(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeMultiSpaceUnicode' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestremoveMultiSpaceUnicode(textCorpus,rmMultiSpaceUnicode)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeMultiSpaceUnicode() test starts \n", 
                                                                x, "removeMultiSpaceUnicode() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeMultiSpaceUnicode() test starts\n", x, "\n removeMultiSpaceUnicode() test ends\n\n")))
  }
})

### end of removeMultiSpaceUnicode() test

### Testing of removeRepetitiveWords() 

TestremoveRepetitiveWords <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeRepetitiveWords(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeRepetitiveWords' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestremoveRepetitiveWords(textCorpus,rmRepetitiveWords)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeRepetitiveWords() test starts \n", 
                                                                x, "removeRepetitiveWords() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeRepetitiveWords() test starts\n", x, "\n removeRepetitiveWords() test ends\n\n")))
  }
})

### end of removeRepetitiveWords() test

### Testing of removeSmallWords() 

TestremoveSmallWords <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeSmallWords(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeSmallWords' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestremoveSmallWords(textCorpus,rmSmallWords)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeSmallWords() test starts \n", 
                                                                x, "removeSmallWords() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeSmallWords() test starts\n", x, "\n removeSmallWords() test ends\n\n")))
  }
})

### end of removeSmallWords() test

### Testing of removeExtraWhiteSpaces() 

TestremoveExtraWhiteSpaces <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- removeExtraWhiteSpaces(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test removeExtraWhiteSpaces' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestremoveExtraWhiteSpaces(textCorpus,rmExtraWhiteSpaces)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n removeExtraWhiteSpaces() test starts \n", 
                                                                x, "removeExtraWhiteSpaces() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n removeExtraWhiteSpaces() test starts\n", x, "\n removeExtraWhiteSpaces() test ends\n\n")))
  }
})

### end of removeExtraWhiteSpaces() test

### Testing of convertIntoLowerCase() 

TestconvertIntoLowerCase <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- convertIntoLowerCase(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test convertIntoLowerCase' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestconvertIntoLowerCase(textCorpus,IntoLowerCase)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n convertIntoLowerCase() test starts \n", 
                                                                x, "convertIntoLowerCase() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n convertIntoLowerCase() test starts\n", x, "\n convertIntoLowerCase() test ends\n\n")))
  }
})

### end of convertIntoLowerCase() test

### Testing of convertIntoUpperCase() 

TestconvertIntoUpperCase <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- convertIntoUpperCase(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test convertIntoUpperCase' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestconvertIntoUpperCase(textCorpus,IntoUpperCase)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n convertIntoUpperCase() test starts \n", 
                                                                x, "convertIntoUpperCase() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n convertIntoUpperCase() test starts\n", x, "\n convertIntoUpperCase() test ends\n\n")))
  }
})



### Testing of performStemming() 

TestperformStemming <- function(corpus,results)
{
  failedTests <- list()
  set.seed(89)
  obj <- performStemming(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test performStemming' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestperformStemming(textCorpus,pfStemming)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n performStemming() test starts \n", 
                                                                x, "performStemming() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n performStemming() test starts\n", x, "\n performStemming() test ends\n\n")))
  }
})

### end of performStemming() test


TestperformLemmatization <- function(corpus,results)
{ 
  failedTests <- list()
  set.seed(89)
  obj <- performLemmatization(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test performLemmatization' ,{
        expect_equal(
          class(obj), class(results)
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestperformLemmatization(textCorpus,pfLemmatization)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n performLemmatization() test starts \n", 
                                                                x, "performLemmatization() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n performLemmatization() test starts\n", x, "\n performLemmatization() test ends\n\n")))
  }
})

### end of performLemmatisation() test




### Testing basicDataCleaning()

TestbasicDataCleaning <- function(corpus, lower = TRUE, specialChar = TRUE, stopWords = FALSE, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- basicDataCleaning(corpus, lower = TRUE, specialChar = TRUE, stopWords = FALSE)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(length(obj),length(results))
                  expect_equal(names(obj),names(results))
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestbasicDataCleaning(basicCleaningInput, lower = TRUE, specialChar = FALSE, stopWords = FALSE,basicCleaningOutput)




lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n basicDataCleaning() test starts \n", 
                                                                x, "basicDataCleaning() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nbasicDataCleaning() test starts\n", x, "\nbasicDataCleaning() test ends\n\n")))
  }
})

### end of basicDataCleaning() test
### Testing findNumTopics()

TestfindNumTopics <- function(corpus, maxSample, topics, progIndicator = FALSE, progressObj = NA, results)
{
  failedTests <- list()
  set.seed(142)
  obj <- findNumTopics(corpus, maxSample, topics, progIndicator = FALSE, progressObj = NA)$df
  # Test 1
  error <- tryCatch(
    {
      test_that('Test findNumTopics',{
        
        expect_equal(obj,
                     results)
      }
      )
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestfindNumTopics(basicCleaningOutput, maxSample=50,topics = 2:10,F,NA,numTopicList$df)


lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n findNumTopics() test starts \n", 
                                                                x, "findNumTopics() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nfindNumTopics() test starts\n", x, "\nfindNumTopics() test ends\n\n")))
  }
})

### end of findNumTopics() test

### Testing buildLDA()

TestbuildLDA <- function(dtm, nTopics, method, nterms, ndocs , results)
{
  failedTests <- list()
  set.seed(142)
  obj <- buildLDA(dtm, nTopics, method, nterms, ndocs)
  # Test 1
  error <- tryCatch(
    {
      test_that('Test buildLDA',{
        
        expect_true( any(as.character(buildLDA(dtm,nTopics = 3,method = "VEM",7,7)$topwords$term[1]) == c("movie","film"))
        )
      }
      )
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestbuildLDA(dtm,nTopics = 3,method = "VEM",7,7,c("movie","film"))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n buildLDA() test starts \n", 
                                                                x, "buildLDA() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nbuildLDA() test starts\n", x, "\nbuildLDA() test ends\n\n")))
  }
})

### end of buildLDA() test

### Testing generatePhrases()

TestgeneratePhrases <- function(corpus, minNgramLength = 2, maxNgramLength = 5, returnPhraseVector = TRUE,results)
{
  failedTests <- list()
  set.seed(12)
  # corpus <- basicDataCleaning(Corpus, lower = TRUE, specialChar = TRUE, stopWords = FALSE)
  obj <- generatePhrases(corpus, minNgramLength = 2, maxNgramLength = 5, returnPhraseVector = TRUE)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test generatePhrases' ,{
        expect_equal(length(obj),length(results))
         expect_equal( dim(obj),dim(results)
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- TestgeneratePhrases(basicCleaningOutput, 2, 5, TRUE, gPhrases)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n generatePhrases() test starts \n", 
                                                                x, "generatePhrases() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n generatePhrases() test starts\n", x, "\n generatePhrases() test ends\n\n")))
  }
})

### end of generatePhrases() test

### Testing runBasicSentiment()

TestrunBasicSentiment <- function(dataset, lexicon, positiveClass, priColor, labelPresent,results) 
{
  failedTests <- list()
  set.seed(12)
  obj <- runBasicSentiment(dataset, lexicon, positiveClass, priColor, labelPresent) 
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test runBasicSentiment' ,{
        expect_equal(
          obj$pred, results$pred
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestrunBasicSentiment(basicSentimentText, lexicon="AFINN", positiveClass="positive", priColor="#1E90FF",labelPresent = T,basicSentimentResult)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n runBasicSentiment() test starts \n", 
                                                                x, "runBasicSentiment() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n runBasicSentiment() test starts\n", x, "\n runBasicSentiment() test ends\n\n")))
  }
})

### end of runBasicSentiment() test

### Testing getDTM_TDM()

TestgetDTM_TDM <- function(corpus, dtm_tdm = FALSE, weighting, results)
{
  failedTests <- list()
  set.seed(12)
  obj <- getDTM_TDM(corpus, dtm_tdm = FALSE, weighting)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test getDTM_TDM' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestgetDTM_TDM(textCorpus,FALSE,"Term Frequency",dtmResult)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n getDTM_TDM() test starts \n", 
                                                                x, "getDTM_TDM() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n getDTM_TDM() test starts\n", x, "\n getDTM_TDM() test ends\n\n")))
  }
})

### end of getDTM_TDM() test

### Testing generateWordCoOccurrenceMatrix()

TestgenerateWordCoOccurrenceMatrix <- function(corpus, context = 'window', window = 3, count = 'frequency', cleandNGrams = TRUE,results)
{
  failedTests <- list()
  set.seed(12)
  obj <- as.matrix(generateWordCoOccurrenceMatrix(corpus, context = 'window', window = 3, count = 'frequency', cleandNGrams = TRUE))
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test generateWordCoOccurrenceMatrix' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestgenerateWordCoOccurrenceMatrix(textCorpus,"window",3,"frequency",FALSE,wcm_result)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n generateWordCoOccurrenceMatrix() test starts \n", 
                                                                x, "generateWordCoOccurrenceMatrix() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n generateWordCoOccurrenceMatrix() test starts\n", x, "\n generateWordCoOccurrenceMatrix() test ends\n\n")))
  }
})

### end of generateWordCoOccurrenceMatrix() test


### Testing generateNGrams()

TestgenerateNGrams <- function(corpus, n = 2, cleanNgrams = TRUE,results)
{
  failedTests <- list()
  set.seed(12)
  obj <- generateNGrams(corpus, n = 2, cleanNgrams = TRUE)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test generateNGrams' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestgenerateNGrams(textCorpus, n = 2, cleanNgrams = TRUE,NGrams)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n generateNGrams() test starts \n", 
                                                                x, "generateNGrams() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n generateNGrams() test starts\n", x, "\n generateNGrams() test ends\n\n")))
  }
})

### end of generateNGrams() test

### Testing generateTFIDFM() test

TestgenerateTFIDFM <- function(corpus, threshold = .95, clean = TRUE,results)
{
 
  failedTests <- list()
  set.seed(15)
  obj <- generateTFIDFM(corpus, threshold = .95, clean = TRUE)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test generateTFIDFM' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestgenerateTFIDFM(textCorpus, .95, clean = TRUE,TFIDFM)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n generateTFIDFM() test starts \n", 
                                                                x, "generateTFIDFM() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n generateTFIDFM() test starts\n", x, "\n generateTFIDFM() test ends\n\n")))
  }
})

### end of generateTFIDFM() test

### Testing generateDTM() test

TestgenerateDTM <- function(corpus,results)
{
  failedTests <- list()
  set.seed(15)
  obj <- generateDTM(corpus,controlList = list())
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test generateDTM' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestgenerateDTM(textCorpus,gDTM)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n generateDTM() test starts \n", 
                                                                x, "generateDTM() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n generateDTM() test starts\n", x, "\n generateDTM() test ends\n\n")))
  }
})

### end of generateDTM() test

### Testing generateTDM() test

TestgenerateTDM <- function(corpus,results)
{
  failedTests <- list()
  set.seed(15)
  obj <- generateTDM(corpus,controlList = list())
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test generateTDM' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestgenerateTDM(textCorpus,gTDM)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n generateTDM() test starts \n", 
                                                                x, "generateTDM() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n generateTDM() test starts\n", x, "\n generateTDM() test ends\n\n")))
  }
})

### end of generateTDM() test

### Testing generateWordFrequency() test

TestgenerateWordFrequency <- function(corpus,results)
{
  failedTests <- list()
  set.seed(15)
  obj <- generateWordFrequency(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test generateWordFrequency' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestgenerateWordFrequency(textCorpus,gWordFrequency)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n generateWordFrequency() test starts \n", 
                                                                x, "generateWordFrequency() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n generateWordFrequency() test starts\n", x, "\n generateWordFrequency() test ends\n\n")))
  }
})

### end of generateWordFrequency() test

### Testing getAssociateWords() test

TestgetAssociateWords <- function(corpus, word, corlimit = 0.30,results)
{
  failedTests <- list()
  set.seed(15)
  obj <- getAssociateWords(corpus, word, corlimit = 0.30)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test getAssociateWords' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestgetAssociateWords(textCorpus,"movie",corlimit = 0.30,gAWords)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n getAssociateWords() test starts \n", 
                                                                x, "getAssociateWords() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n getAssociateWords() test starts\n", x, "\n getAssociateWords() test ends\n\n")))
  }
})

### end of getAssociateWords() test

### Testing generateWordCloudTFIDF() test

TestgenerateWordCloudTFIDF <- function(corpus, priColor, secColor, minFreq = 50, maxWords = 100,results)
{
  failedTests <- list()
  set.seed(15)
  obj <- generateWordCloudTFIDF(corpus, priColor, secColor, minFreq = 50, maxWords = 100)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test generateWordCloudTFIDF' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function



result <- TestgenerateWordCloudTFIDF(textCorpus, "red", "blue", minFreq = 50, maxWords = 100,gWCTFIDF)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n generateWordCloudTFIDF() test starts \n", 
                                                                x, "generateWordCloudTFIDF() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n generateWordCloudTFIDF() test starts\n", x, "\n generateWordCloudTFIDF() test ends\n\n")))
  }
})

### end of generateWordCloudTFIDF() test



  
### Testing SentenceTokenizer() test

TestSentenceTokenizer <- function(string, simplify = TRUE,results)
{
  failedTests <- list()
  set.seed(15)
  obj <- SentenceTokenizer(string,TRUE)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test SentenceTokenizer' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestSentenceTokenizer(sen,T,getSenTok)

lapply(result, function(x){
if(x != "Result: Test passed")
{
  failedTestResults <<- append(failedTestResults, list(paste0("\n \n SentenceTokenizer() test starts \n", 
                                                              x, "SentenceTokenizer() test ends \n \n")))
}else
{
  allTestResults <<- append(allTestResults, list(paste0("\n\n SentenceTokenizer() test starts\n", x, "\n SentenceTokenizer() test ends\n\n")))
}
})

### end of SentenceTokenizer() test

# ### Testing getSentiment_sentence() test
# 
# TestgetSentiment_sentence <- function(sentence,results)
# {
#   failedTests <- list()
#   set.seed(15)
#   obj <- getSentiment_sentence(sentence)
#   # Test 1
#   error <- tryCatch(
#     {
#       test_that( 'Test getSentiment_sentence' ,{
#         expect_equal(
#           obj, results
#         )
#       })
#     },error = function(e)
#     {
#       return(e)
#     }
#   )
#   if(!isTRUE(error))
#   {
#     failedTests[length(failedTests)+1] <- as.character(error)
#   }
#   
#   if(length(failedTests) == 0)
#     return("Result: Test passed")
#   else
#     return(failedTests)
# }# end of function
# 
# getSent <- getSentiment_sentence(getSenTok)
# result <- TestgetSentiment_sentence(getSenTok,getSent)
# 
# lapply(result, function(x){
#   if(x != "Result: Test passed")
#   {
#     failedTestResults <<- append(failedTestResults, list(paste0("\n \n getSentiment_sentence() test starts \n", 
#                                                                 x, "getSentiment_sentence() test ends \n \n")))
#   }else
#   {
#     allTestResults <<- append(allTestResults, list(paste0("\n\n getSentiment_sentence() test starts\n", x, "\n getSentiment_sentence() test ends\n\n")))
#   }
# })
# 
# ### end of getSentiment_sentence() test


### Testing getDataFrameFromTm() test

TestgetDataFrameFromTm <- function(corpus,results)
{
  failedTests <- list()
  set.seed(15)
  obj <- getDataFrameFromTm(corpus)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test getDataFrameFromTm' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestgetDataFrameFromTm(textCorpus,gGFFT)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n getDataFrameFromTm() test starts \n", 
                                                                x, "getDataFrameFromTm() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n getDataFrameFromTm() test starts\n", x, "\n getDataFrameFromTm() test ends\n\n")))
  }
})

### end of getDataFrameFromTm() test

# Testing the function parseInputs()
listWithNamePrefix <- list('select_a'=1,'select_b'=2)
list.with.prefix.structure <- list('select'=list('select_a'=1,'select_b'=2))

TestparseInputs <- function(listWithNamePrefix,list.with.prefix.structure)
{
  failedTests <- list()
  set.seed(89)
  error <- tryCatch(
    {
  test_that('Test parseInputs',{
  expect_equal(list.with.prefix.structure,parseInputs(listWithNamePrefix))
})
},error = function(e)
 
{ return(e)}
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}

result <- TestparseInputs(listWithNamePrefix,list.with.prefix.structure)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n getDataFrameFromTm() test starts \n", 
                                                                x, "getDataFrameFromTm() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n getDataFrameFromTm() test starts\n", x, "\n getDataFrameFromTm() test ends\n\n")))
  }
})

# end of function parseInput()


### Testing parse2graph() test

Testparse2graph <- function(ptext,results)
{
  failedTests <- list()
  set.seed(15)
  obj <- parse2graph(ptext)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test parse2graph' ,{
        expect_equal(
          length(obj), length(results))
        expect_equal(dim(obj),dim(results)
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- Testparse2graph(partext,resPartext)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n parse2graph() test starts \n", 
                                                                x, "parse2graph() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n parse2graph() test starts\n", x, "\n parse2graph() test ends\n\n")))
  }
})

### end of parse2graph() test

# ### Testing createParseTree() test
# 
# TestcreateParseTree <- function(text,anonList,results)
# {
#   failedTests <- list()
#   set.seed(143)
#   obj <- createParseTree(text,anonList)
#   # Test 1
#   error <- tryCatch(
#     {
#       test_that( 'Test createParseTree' ,{
#         expect_equal(
#           obj, results
#         )
#       })
#     },error = function(e)
#     {
#       return(e)
#     }
#   )
#   if(!isTRUE(error))
#   {
#     failedTests[length(failedTests)+1] <- as.character(error)
#   }
#   
#   if(length(failedTests) == 0)
#     return("Result: Test passed")
#   else
#     return(failedTests)
# }# end of function
# 
# 
# result <- TestcreateParseTree(textPtree,anlist,parsetree)
# 
# lapply(result, function(x){
#   if(x != "Result: Test passed")
#   {
#     failedTestResults <<- append(failedTestResults, list(paste0("\n \n createParseTree() test starts \n", 
#                                                                 x, "createParseTree() test ends \n \n")))
#   }else
#   {
#     allTestResults <<- append(allTestResults, list(paste0("\n\n createParseTree() test starts\n", x, "\n createParseTree() test ends\n\n")))
#   }
# })
# 
# ### end of createParseTree() test

### Testing extractPOSTags() test

# TestextractPOSTags <- function(text,anonList,results)
# {
#   failedTests <- list()
#   set.seed(143)
#   obj <- extractPOSTags(text,anonList)
#   # Test 1
#   error <- tryCatch(
#     {
#       test_that( 'Test extractPOSTags' ,{
#         expect_equal(
#           obj, results
#         )
#       })
#     },error = function(e)
#     {
#       return(e)
#     }
#   )
#   if(!isTRUE(error))
#   {
#     failedTests[length(failedTests)+1] <- as.character(error)
#   }
#   
#   if(length(failedTests) == 0)
#     return("Result: Test passed")
#   else
#     return(failedTests)
# }# end of function

# resPOStags <- extractPOSTags(textPtree,anlist)
# 
# result <- TestextractPOSTags(textPtree,anlist,resPOStags)
# 
# lapply(result, function(x){
#   if(x != "Result: Test passed")
#   {
#     failedTestResults <<- append(failedTestResults, list(paste0("\n \n extractPOSTags() test starts \n", 
#                                                                 x, "extractPOSTags() test ends \n \n")))
#   }else
#   {
#     allTestResults <<- append(allTestResults, list(paste0("\n\n extractPOSTags() test starts\n", x, "\n extractPOSTags() test ends\n\n")))
#   }
# })
# 
# ### end of extractPOSTags() test
# downloadReport
# edgemaker
# createAnnotators
# extractPOSTags
