####################################################################################################################################
# Steps to include warning UI
# 1. Copy the warningHeader.R to brick's Source folder
# 
# 2. Add the following section in your main Rmd's css
#
#       .warningButton{
#         background-color:white !important;
#         border:none;
#         padding:0px !important;
#       }
#       .warningButton:hover{
#         background-color:white !important;
#         border:none;
#         padding:0px !important;
#       }
#       .warningButton:focus{
#         background-color:white !important;
#         border:none;
#         padding:0px !important;
#       }
#       .warningButton:active{
#         background-color:white !important;
#         border:none;
#         padding:0px !important;
#       }
# 3. Add this section to your brick's Rmd
# 
#       ```{r warning Header,echo=FALSE, results='asis', warning=FALSE, message=FALSE}
#       shinyjs::useShinyjs(rmd = T)
#       reactive({
#         for(i in 1:nrow(packageList))
#         {
#           packageList_2 <- unlist(strsplit(as.character(packageList[packageList$heading_id=packageList$heading_id[i],"packages"]),","))
#           x <-unlist(lapply(packageList_2,function(x){x %in%  installed.packages()[,1]}))
#           if(FALSE %in% x){
#             shinyjs::show(paste0(packageList$heading_id[i],"warningDivInner"))
#             shinyjs::show(paste0(packageList$heading_id[i],"DownloadButton"))
#           }
#           
#         }
#       })
#       ```
# 4. Add these three lines after every section's header (delete section description and add it after these three lines in tags$p)
#       
#       heading <- "Quick Peek"
#       header<- warningHeader(heading_id,packageList,input,output,session)
#       eval(parse(text=header))
#       
# 5. Make a package list csv with heading_id, packages as columns and save it in source folder
# 
# 6. Add these lines to utils file.
#         if(file.exists("Source/packageList.csv")){
#           packageList <<- read.csv("Source/packageList.csv")
#         } else if(file.exists("packageList.csv")){
#           packageList <<- read.csv("packageList.csv")
#         } else {
#           packageList <<- NULL
#         }
# 7. Add warningHeader file to the file sourcing list in mainUtils
# 8. Copy th warning and download note images from EDA.


######################################################################################################################################


tryCatch({
  warningHeader<-function(heading_id,packageList,input,output,session){
    
    
    # heading_id <- paste(unlist(strsplit(heading," ")),collapse="_")
    packageList_1 <- packageList[packageList$heading_id == heading_id,"packages"]
    packageList_2 <- unlist(strsplit(as.character(packageList_1),","))
    
    
    warningMessage <- "Warning: This section has some missing packages"
    refreshTooltip <- "Click to refresh the missing package list"
    downloadTooltip <- "Download the list of missing packages"
    
    ######################################################  UI String  ###################################################################  
    uiWarning<-paste0(' 
                      shiny::div(
                      
                      
                      shinyjs::hidden(shiny::tags$div(style="display: inline-block;float: right;margin-top: -45px;",id="',heading_id,'warningDivInner",
                      shiny::tags$img(src="Logos/warning.png",title="Package missing",height="21",width="21"),
                      shiny::tags$p("',warningMessage,'",class="warningImage",style="display: inline-block;"),
                      shinyjs::hidden(shiny::actionButton(paste0("',heading_id,'","DownloadButton"),class="warningButton",title="',downloadTooltip,'",label=
                      shiny::tags$img(src="Logos/downloadPackage.png",height="18",width="18" ))),
                      shinyjs::hidden(shiny::actionButton(paste0("',heading_id,'","RefreshButton"),class="warningButton",title="',refreshTooltip,'",label=
                      shiny::tags$img(src="Logos/refresh.png",height="22",width="22" )))
                      
                      )),
                      
                      shinyjs::hidden(shiny::div(id=paste0("',heading_id,'","warningDownloadNote"),shiny::tags$p("The missing package list has been successfully downloaded at Downloads/ as \'',heading_id,'_Missing_Package_List.txt\'",style="color:green"))),
                      
                      shinyjs::hidden(shiny::div(id=paste0("',heading_id,'","warningDownloadNote2"),shiny::tags$p("The missing package list has been successfully updated at Downloads/ as \'',heading_id,'_Missing_Package_List.txt\'",style="color:green")))
                      )
                      
                      ')
    
    
    #########################################################################################################################################
    
    
    shiny::observeEvent(input[[paste0(heading_id,"RefreshButton")]],{
      
      x <-unlist( lapply(packageList_2,function(x){x %in%  installed.packages()[,1]}))
      if(FALSE %in% x){
        shinyjs::hide(paste0(heading_id,"warningDownloadNote"))
        shinyjs::show(paste0(heading_id,"warningDownloadNote2"))
        shinyjs::show(paste0(heading_id,"warningDivInner"))
        missPackages <-unlist( lapply(packageList_2,function(x){if(!(x %in%  installed.packages()[,1])) x}))
        tmp1 <- paste0(missPackages, collapse= "','")
        nonCRANPackages <- c('openNLPmodels.en','RDRPOSTagger')
        openNLPFailed <- FALSE
        RDRPOSTaggerFailed <- FALSE
        wordVectorsFailed <- FALSE
        if('openNLPmodels.en' %in% missPackages && 'RDRPOSTagger'%in% missPackages && 'wordVectors'%in% missPackages)
        {
          openNLPFailed <- TRUE
          RDRPOSTaggerFailed <- TRUE
          wordVectorsFailed <- TRUE
        }else if('openNLPmodels.en' %in% missPackages && 'RDRPOSTagger'%in% missPackages){
          openNLPFailed <- TRUE
          RDRPOSTaggerFailed <- TRUE
        }else if('RDRPOSTagger'%in% missPackages && 'wordVectors'%in% missPackages){
          RDRPOSTaggerFailed <- TRUE
          wordVectorsFailed <- TRUE
        }else if('wordVectors'%in% missPackages && 'openNLPmodels.en' %in% missPackages){
          wordVectorsFailed <- TRUE
          openNLPFailed <- TRUE
        }else if('openNLPmodels.en' %in% missPackages){
          openNLPFailed <- TRUE
        }else if('RDRPOSTagger' %in% missPackages){
          RDRPOSTaggerFailed <- TRUE
        }else if('wordVectors' %in% missPackages){
          wordVectorsFailed <- TRUE
        }
        missPackages <- missPackages [! missPackages %in% nonCRANPackages]
        tmp1 <- paste0(missPackages, collapse= "','")
        if(openNLPFailed == TRUE && RDRPOSTaggerFailed == TRUE && wordVectorsFailed == TRUE){
          if(tmp1==""){
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,warningHdrRDRPOSTagger,warningHdrLineSep,warningHdrOpenNLPModelsEn,warningHdrLineSep,warningHdrWordVec)  
          }else{
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,"\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep,warningHdrRDRPOSTagger,warningHdrLineSep,warningHdrOpenNLPModelsEn)
          }
        }else if(openNLPFailed == TRUE && RDRPOSTaggerFailed == TRUE){
          if(tmp1==""){
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"),generalMsgWarningHdr,warningHdrRDRPOSTagger,warningHdrLineSep,warningHdrOpenNLPModelsEn)  
          }else{
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"),generalMsgWarningHdr,"\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep,warningHdrRDRPOSTagger,warningHdrOpenNLPModelsEn)
          }
        }else if(openNLPFailed == TRUE && wordVectorsFailed == TRUE){
          if(tmp1==""){
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,warningHdrWordVec,warningHdrLineSepwarningHdr,OpenNLPModelsEn)
          }else{
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,"\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep,warningHdrWordVec,warningHdrLineSep,warningHdrOpenNLPModelsEn)
          }
        }else if(wordVectorsFailed == TRUE && RDRPOSTaggerFailed == TRUE){
          if(tmp1==""){
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, warningHdrRDRPOSTagger, warningHdrLineSep, warningHdrWordVec)
          }else{
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,"\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep, warningHdrRDRPOSTagger, warningHdrLineSep, warningHdrWordVec)
          }      
        }else if(openNLPFailed == TRUE){
          if(tmp1==""){
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, warningHdrOpenNLPModelsEn)
          }else{        
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,"\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep, warningHdrOpenNLPModelsEn)
          }
        }else if(RDRPOSTaggerFailed == TRUE){
          if(tmp1==""){
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, warningHdrRDRPOSTagger)  
          }else{  
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, "\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep, warningHdrRDRPOSTagger)  
          }
        }else if(openNLPFailed == TRUE){
          if(tmp1==""){
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, warningHdrWordVec)
          }else{
            missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, "\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')", warningHdrLineSep, warningHdrWordVec)
          }
        }else{
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, "\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')")  
        }
        write(missPackages_2,paste0("Downloads/",heading_id,"_Missing_Package_List.txt"), sep="\n")
      }
      else{
        shinyjs::hide(paste0(heading_id,"warningDivInner"))
        shinyjs::hide(paste0(heading_id,"warningDownloadNote"))
        shinyjs::hide(paste0(heading_id,"warningDownloadNote2"))
        unlink(paste0("Downloads/",heading_id,"_Missing_Package_List.txt"))
      }
      
      
      
    })
    
    
    shiny::observeEvent(input[[paste0(heading_id,"DownloadButton")]],{
      shinyjs::hide(paste0(heading_id,"DownloadButton"))
      shinyjs::show(paste0(heading_id,"RefreshButton"))
      shinyjs::show(paste0(heading_id,"warningDownloadNote"))
      
      shinyjs::hide(paste0(heading_id,"DownloadButton"))
      missPackages <-unlist( lapply(packageList_2,function(x){if(!(x %in%  installed.packages()[,1])) x}))
      nonCRANPackages <- c('openNLPmodels.en','RDRPOSTagger')
      openNLPFailed <- FALSE
      RDRPOSTaggerFailed <- FALSE
      wordVectorsFailed <- FALSE
      
      
      if('openNLPmodels.en' %in% missPackages && 'RDRPOSTagger'%in% missPackages && 'wordVectors'%in% missPackages)
      {
        openNLPFailed <- TRUE
        RDRPOSTaggerFailed <- TRUE
        wordVectorsFailed <- TRUE
      }else if('openNLPmodels.en' %in% missPackages && 'RDRPOSTagger'%in% missPackages){
        openNLPFailed <- TRUE
        RDRPOSTaggerFailed <- TRUE
      }else if('RDRPOSTagger'%in% missPackages && 'wordVectors'%in% missPackages){
        RDRPOSTaggerFailed <- TRUE
        wordVectorsFailed <- TRUE
      }else if('wordVectors'%in% missPackages && 'openNLPmodels.en' %in% missPackages){
        wordVectorsFailed <- TRUE
        openNLPFailed <- TRUE
      }else if('openNLPmodels.en' %in% missPackages){
        openNLPFailed <- TRUE
      }else if('RDRPOSTagger' %in% missPackages){
        RDRPOSTaggerFailed <- TRUE
      }else if('wordVectors' %in% missPackages){
        wordVectorsFailed <- TRUE
      }
      missPackages <- missPackages [! missPackages %in% nonCRANPackages]
      tmp1 <- paste0(missPackages, collapse= "','")
      if(openNLPFailed == TRUE && RDRPOSTaggerFailed == TRUE && wordVectorsFailed == TRUE){
        if(tmp1==""){
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,warningHdrRDRPOSTagger,warningHdrLineSep,warningHdrOpenNLPModelsEn,warningHdrLineSep,warningHdrWordVec)  
        }else{
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,"\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep,warningHdrRDRPOSTagger,warningHdrLineSep,warningHdrOpenNLPModelsEn)
        }
      }else if(openNLPFailed == TRUE && RDRPOSTaggerFailed == TRUE){
        if(tmp1==""){
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"),generalMsgWarningHdr,warningHdrRDRPOSTagger,warningHdrLineSep,warningHdrOpenNLPModelsEn)  
        }else{
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"),generalMsgWarningHdr,"\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep,warningHdrRDRPOSTagger,warningHdrOpenNLPModelsEn)
        }
      }else if(openNLPFailed == TRUE && wordVectorsFailed == TRUE){
        if(tmp1==""){
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,warningHdrWordVec,warningHdrLineSepwarningHdr,OpenNLPModelsEn)
        }else{
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,"\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep,warningHdrWordVec,warningHdrLineSep,warningHdrOpenNLPModelsEn)
        }
      }else if(wordVectorsFailed == TRUE && RDRPOSTaggerFailed == TRUE){
        if(tmp1==""){
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, warningHdrRDRPOSTagger, warningHdrLineSep, warningHdrWordVec)
        }else{
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,"\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep, warningHdrRDRPOSTagger, warningHdrLineSep, warningHdrWordVec)
        }      
      }else if(openNLPFailed == TRUE){
        if(tmp1==""){
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, warningHdrOpenNLPModelsEn)
        }else{        
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr,"\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep, warningHdrOpenNLPModelsEn)
        }
      }else if(RDRPOSTaggerFailed == TRUE){
        if(tmp1==""){
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, warningHdrRDRPOSTagger)  
        }else{  
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, "\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')",warningHdrLineSep, warningHdrRDRPOSTagger)  
        }
      }else if(openNLPFailed == TRUE){
        if(tmp1==""){
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, warningHdrWordVec)
        }else{
          missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, "\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')", warningHdrLineSep, warningHdrWordVec)
        }
      }else{
        missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), generalMsgWarningHdr, "\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')")  
      }
      write(missPackages_2,paste0("Downloads/",heading_id,"_Missing_Package_List.txt"), sep="\n")
    }
    )
    return(uiWarning)
    
  }
},error=function(e){
  print(e)
})