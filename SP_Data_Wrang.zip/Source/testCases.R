source('wranglingUtils.R')
loadGlobals()
loadPackage <- function(pkgName){
  if (!do.call(require, list(pkgName))) {
    install.packages(pkgName, dependencies = T, repos = "http://cran.us.r-project.org")
    do.call(library, list(pkgName))
  }
}
lapply(packages, FUN = function(p){ loadPackage(p) })

library(compare)
library(testthat)
library(futile.logger)
set.seed(7)


options(warn = -1)


allTestResults <- list()
allTestResultsUnderscoreTime <- list()
allTestResultsGetMode <- list()


dataset <- mtcars


# ==================================================>>>

# testUndescoreTime <- function(){
#   failedTestsunderscoredTime <- list()
#   
#   error <- tryCatch({
#     test_that("Time format check ",{
#       expect_equal(underscoredTime("2017-10-04 15:29:18"),"2017_10_04_15_29_18")
#     })
#     
#   },error = function(e){return(e)})
#   if(!isTRUE(error)){
#     failedTestsunderscoredTime[length(failedTestsunderscoredTime) + 1] <- as.character(error)
#   }
#   
#   if(length(failedTestsunderscoredTime) == 0){
#     return("underscoredTime test passed")
#   }else{
#     return(failedTestsunderscoredTime)
#   }
# }
# 
# 
# 
# testResultsUnderscoredTime <- testUndescoreTime()
# 
# if(testResultsUnderscoredTime != "underscoredTime test passed"){
#   allTestResultsUnderscoreTime[1] = "underscoredTime test" 
#   allTestResultsUnderscoreTime[[2]] = testResultsUnderscoredTime
# }
# 
# if(length(allTestResultsUnderscoreTime) != 0){
#   allTestResults[[length(allTestResults) + 1]] <- allTestResultsUnderscoreTime
# }
# 
# # <<<==================================================
# 
# # ==================================================>>>
# 
# 
# 
# 
# testgetmode <-function(){
#   faildetestsgetmode <- list()
#   
#   error <- tryCatch({
#     test_that("Mode function test ",{
#       expect_equal(getmode(c(1,2,2,3,4)),2)
#     })
#   },error = function(e){return(e)})
#   if(!isTRUE(error)){
#     faildetestsgetmode[length(faildetestsgetmode) + 1] <- as.character(error)
#   }
#   
#   if(length(faildetestsgetmode) == 0){
#     return("getmode test passed")
#   }else{
#     return(faildetestsgetmode)
#   }
# }
# 
# 
# testResultsgetmode <- testgetmode()
# 
# if(testResultsUnderscoredTime != "underscoredTime test passed"){
#   allTestResultsGetMode[1] = "underscoredTime test" 
#   allTestResultsGetMode[[2]] = testResultsgetmode
# }
# 
# if(length(allTestResultsUnderscoreTime) != 0){
#   allTestResults[[length(allTestResults) + 1]] <- allTestResultsGetMode
# }


# <<<==================================================