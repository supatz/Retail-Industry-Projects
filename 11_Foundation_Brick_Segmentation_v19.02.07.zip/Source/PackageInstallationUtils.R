#######################################################################################################################
# Package Installation Script
# Vivek 
# Version 1.05
# Script for easy installation of Foundation Bricks
# * Added script for perfroming package dependency check
#######################################################################################################################
#######################################################################################################################
# Function to write the packages whose installation failed to a file
# Input :
#         installationFailedPackages : list of packages whose installation failed 
#######################################################################################################################
writeInstallatioFailedPackages <-function(installationFailedPackages){
  if(!is.null(installationFailedPackages) && length(installationFailedPackages)>0){
    misspackages <- paste0(installationFailedPackages, collapse= "','")
    messagehead <- "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:"
    installationFailedPackages <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"),messagehead, "\r\ninstall.packages(c('", misspackages, "'), repos = 'http://cloud.r-project.org/')")
    write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")
  }
} 
#######################################################################################################################
# Function to load the packages(basicPackages,packages and dbPackages) which are installed and install which are not present, 
# also check for java version, architecture and check if Java home is set and give appropriate messages.
# Output :
#         dbWarning : initiallyempty but contains suitable message if java related issues occur 
#######################################################################################################################
loadMains <- function(brickName = ""){
  ##hard check for ggplot versionb
  if("ggplot2" %in% installed.packages()[,1] && packageVersion("ggplot2")=='2.2.1.9000') {
    remove.packages("ggplot2")
  }
  
  ##this section is to load basic packages,packages and dbpackages
  installationFailedPackages <<- c()
  packageDependencies <- readRDS("Source/packagesList.RDS")
  basicPackages <- packageDependencies$basicPackagesList
  tryCatch({
    packageInstallStatus <- loadpackage(basicPackages)
    if(!is.null(packageInstallStatus) && packageInstallStatus!=TRUE){
      installationFailedPackages <<- c(installationFailedPackages, packageInstallStatus)
    }
  }, error = function(e){
    print(e)
  })
  packages <- packageDependencies$packagesList
  dbPackages <- packageDependencies$dbPackagesList
  tryCatch({
    packageInstallStatus <- loadpackage(packages)
    if(!is.null(packageInstallStatus) && packageInstallStatus!=TRUE){
      installationFailedPackages <<- c(installationFailedPackages, packageInstallStatus)
    }
  },error=function(e){
    saveRDS(e, "Downloads/packagesError.RDS")
  })
  
  # Check JAVA version
  #min
  javaVersion <- TRUE
  minJavaVersion <- "1.8"
  #javaVersion <- CheckJavaVersion(minJavaVersion)
  # Check JAVA architecture
  matchArchitechture <- TRUE
  dbWarning <- ""
  if(javaVersion == TRUE && matchArchitechture == TRUE){
    tryCatch({
      packageInstallStatus <- loadpackage(dbPackages)
      if(!is.null(packageInstallStatus) && packageInstallStatus!=TRUE){
        installationFailedPackages <- c(installationFailedPackages, packageInstallStatus)
      } 
    },error=function(e){
      dbWarning <- str(e)
      saveRDS(e, "Downloads/dbPackagesError.RDS")
    })
  } 
  # else if(javaVersion == TRUE && matchArchitechture == TRUE && base::Sys.getenv("JAVA_HOME") == ""){
  #   dbWarning <- "the environment variable 'JAVA_HOME' needs to be set to the path where Java is installed"
  # } else if(javaVersion == TRUE && matchArchitechture == FALSE && base::Sys.getenv("JAVA_HOME") == ""){
  #   dbWarning <- "the environment variable 'JAVA_HOME' needs to be set to the path where Java is installed"
  # } else if(javaVersion == FALSE && matchArchitechture == TRUE){
  #   dbWarning <-base::paste0("The installed Java version on the system is less than the minimum version required (Java ", minJavaVersion, ")")
  # } else if(javaVersion == TRUE && matchArchitechture == FALSE){
  #   dbWarning <-"Java and R architectures on this system doesn't match. "
  # }else if(javaVersion == FALSE && matchArchitechture == FALSE){
  #   dbWarning <-"Java is not installed on the system"
  # } else {
  #   dbWarning <-base::paste0("Install minimum Java version (>", minJavaVersion, ") that matches the R architecture on this machine")
  # }  
  # write the failed packages to file
  ##ONLY FOR TEXT MINING WE DONOT CALL THIS FUNCTION AS IT TAKES CARE OF NON CRAN PACKAGES AS WELL FOR WHICH WE DO IT IN LOAD MAINS SECTIOn
  # writeInstallatioFailedPackages(installationFailedPackages)
  if(brickName==""){
    writeInstallatioFailedPackages(installationFailedPackages) 
  }else{
    writeInstallationNonCranPackages(dbWarning)
  }
  return(dbWarning)
} 

#######################################################################################################################
# Function to check if the installed version of Java is 1.8 to match system requirements of 'rJava' Package
# Inputs :
#     verbose: Set to FALSE by default. Else, if set as TRUE, returns additional details about 
#              version of Java and R which has been called inside the function
#     minJavaVersion: minimum Java version required
# 
# Output : Logical TRUE/FALSE output
#     TRUE: If the installed version of Java is 1.8
#     FALSE: If the installed version of Java is not 1.8     
#######################################################################################################################
# CheckJavaVersion <- function(minJavaVersion, verbose = F){
#   tryCatch({
#     OSType <- Sys.info()['sysname']
#     systemInfo <- system("java -version")
#     if(systemInfo == 127){
#       return(FALSE)
#     }else if(systemInfo == 0){
#       sysinfo <- system2("java", "-version", stdout = 'stdout.txt', stderr = 'stderr.txt')
#       sysinfo <- readLines('stderr.txt')
#       sysinfo <- paste(sysinfo,collapse = " ")
#       sysinfo <- substr(sysinfo,stringr::str_locate(sysinfo,'version')[2]+3,stringr::str_locate(sysinfo,'version')[2]+5)
#     }
#     if(verbose == T){
#       base::system("java -version")
#     }
#     if(file.exists('stderr.txt')){
#       file.remove("stderr.txt")
#     }
#     if(file.exists('stdout.txt')){
#       file.remove("stdout.txt")
#     }
#     # Check if the version of Java is 1.8
#     if(sysinfo >= minJavaVersion){
#       return(TRUE)
#     }else{
#       warning('minimum version requirements for Java not met')
#       return(FALSE)
#     }
#   }, error = function(e){
#     warning(e)
#     return(FALSE)
#   }, warning = function(e){
#     warning(e)
#     return(FALSE)
#   })
# }

#######################################################################################################################
# Function to check if the installed version of R is 3.4.3 to match requirements for Foundation Bricks
# Inputs : 
#     minVersion: Minimum R's version  
# 
# Output : 
#     returns R version if it's 3.4.3
#######################################################################################################################


RVersionCheck <- function(minVersion) {
  result <- strsplit(R.Version()$version.string, " ")[[1]][3]
  
  if(result < minVersion){
    warning("minimum version requirement of r not met")
    return(FALSE)
  }else{
    return(TRUE)
  }
}

#######################################################################################################################
# Function to match architecture build of R and java installled on a system(32/64-bit) 
# Inputs: 
#     verbose: Set to FALSE by default. Else, if set as TRUE, returns additional details about 
#              version of Java and R which has been called inside the function
# 
# Output: Logical TRUE/FALSE output
#     TRUE: If the architecture of both R and Java matches(32/64-bit)
#     FALSE: If the architecture of both R and Java doesn't match(32/64-bit)     
#######################################################################################################################

# isJavaRMatch <- function(){
#   OSType <- Sys.info()['sysname']
#   rArch <- R.Version()
#   rArch <- substr(rArch$arch, nchar(rArch$arch)-1, nchar(rArch$arch))
#   if(rArch == "86"){
#     rArch<-"32"
#   } 
#   tryCatch({
#     javaArch <- system(paste0('java -d', rArch, ' -version'))
#     if(javaArch == 0){
#       return(TRUE)
#     }else{
#       return(FALSE)
#     }
#   }, error = function(e){
#     warning("Architecture for the installed Versions of R and java don't match") 
#     return(FALSE)
#   }, warning= function(e){
#     warning("Architecture for the installed Versions of R and java don't match") 
#     return(FALSE)
#   })
# }


#######################################################################################################################
# Function which gives out a list of packages to be installed as dependencies during package instalation
# Inputs :
#     packageName: The package of interest
#     reqVersion: The required version of the package of interest 
#
# Output : 
#     A logical TRUE/FALSE output
#     TRUE: If version requirements have been met
#     FALSE: If version requirement are not met
#######################################################################################################################

checkPackageversion <- function(packageName, reqVersion){
  if(packageVersion(packageName) != reqVersion){
    warning(paste0("Version requirement of '", packageName, "' package not met. Version '", reqVersion, "' is required."))
    return(FALSE)
  }else{
    return(TRUE)
  }
}

#######################################################################################################################
# Function which gives out a list of packages to be installed as dependencies during package instalation
# Inputs :
#     packageList: A list of packages
#
# Output : 
#     The list of dependent packages which is required to be installed before the list of input packages
#######################################################################################################################

PackageDependencyList <- function(packageList){
  
  if(class(packageList) != "character"){
    packageList <- as.character(packageList)
  }
  
  if(length(packageList) == 0){
    stop('input parameter is empty')
  }
  
  # Create a graph object to containing package dependency hierarchy
  dependency.check <- miniCRAN::makeDepGraph(packageList, suggests = FALSE, includeBasePkgs = FALSE)
  
  # Iterates over each element of the object packageList and gives out the individual package dependencies for each of these
  # Elements of packageList 
  result <- list()
  for(i in 1:length(packageList)){
    result[[i]] <- (igraph::topo_sort(dependency.check))}
  
  # For each element in the list, numbers are replaced with package names, remove NAs and reverse the order to get the correct order
  result <- lapply(result, function(x){
    x <- igraph::as_ids(x)
  })
  result <- Reduce(c, result) #append all the lists into one list
  result <- result[!duplicated(result)] #remove duplicates
  
  return(result) 
}


#######################################################################################################################
# Function to load and install packages from a list of packages
# Ref: https://stackoverflow.com/questions/8175912/load-multiple-packages-at-once 
# Inputs: 
#     packageList: Variable to where a list of packages have been saved
# 
# Output: Logical TRUE/FALSE output
#     TRUE: If all the packages' from the list was installed and loaded successfully against each package's name
#     FALSE: If all/one of the packages' from the list couldn't be instaled and loaded successfully 
#            against each one's name   
#######################################################################################################################

loadpackage <- function(packageList){
  # #Extracts the names of all the packages from the installed.packages
  # toInstallPackages <- packageDepList[!(packageDepList %in% installed.packages()[, "Package"])]
  failedPackages <- c()
  if(is.null(packageList) || length(packageList)==0)
    return(NULL)
    #Installs and loads packages not there in installed.packages
  for(i in 1:length(packageList)){
    if(!(packageList[i] %in% installed.packages()[,1]) == TRUE){
      install.packages(packageList[i], dependencies = FALSE, repos = "http://cloud.r-project.org/")
    }
    if(!(packageList[i] %in% installed.packages()[,1]) == TRUE){
      warning(paste0(packageList[i], ": installation failed"))
      failedPackages <- c(failedPackages, packageList[i])
    }
  }
  if(length(failedPackages)>0){
  return(failedPackages)
  }
  else{
    return(TRUE)
  }
}
#######################################################################################################################
#######################################################################################################################
# This function is called only in TEXT MINING BRICK
# Function to check for NON-CRAN Packages, write the packages along with CRAN whose installation failed to a file
#######################################################################################################################
writeInstallationNonCranPackages <-function(dbWarning){
  #trying to install non cran packages (openNLPModels.en and RDRPOSTagger)
  installationFailedOpenNLPModels<<-FALSE
  installationFailedRDRPOSTagger<<-FALSE
  tryCatch({
    if(!("openNLPmodels.en" %in% utils::installed.packages()[,1])){
      utils::install.packages("openNLPmodels.en", repos = "http://datacube.wu.ac.at/" , type = "source")
      if(!("openNLPmodels.en" %in% utils::installed.packages()[,1])){
        installationFailedOpenNLPModels<<-TRUE
      }  
    }
  },error=function(e){
    installationFailedOpenNLPModels<<-TRUE
  })
  tryCatch({
    if(!("RDRPOSTagger" %in% utils::installed.packages()[,1])){
      utils::install.packages('RDRPOSTagger', repos ='http://www.datatailor.be/rcube', type = 'source',INSTALL_opts = '--no-multiarch')
      if(!("RDRPOSTagger" %in% utils::installed.packages()[,1])){
        installationFailedRDRPOSTagger<<-TRUE
      }  
    }
  },error=function(e){
    installationFailedRDRPOSTagger<<-TRUE
  })
  tryCatch({
    if(!("wordVectors" %in% utils::installed.packages()[,1])){
      devtools::install_github('bmschmidt/wordVectors')
      if(!("wordVectors" %in% utils::installed.packages()[,1])){
      }
    }
  },error=function(e){
    warning(e)
  },warning=function(e){
    warning(e)
  })
  # DownloadCoreNLP
  tryCatch({
    library(coreNLP)
    initCoreNLP()
  },error=function(e){
    if(grepl("downloadCoreNLP()",e,fixed = T)) {
      dest_path <- paste0(.libPaths()[1],'/coreNLP/extdata/')
      file.copy(from='Source/StanfordCoreNLP.properties',to=dest_path,overwrite = TRUE)
      downloadCoreNLP()
      initCoreNLP()
    }
    else{
      if(!(dbWarning=="")){
        if(!("rJava" %in% utils::installed.packages()[,1])){
          #utils::install.packages('rJava');
          if(!('rJava' %in% installationFailedPackages)){
            installationFailedPackages <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\n\r\ninstall.packages('rJava', repos = 'http://cloud.r-project.org/' )")
            write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")
          }
        }
      }else{
        shiny::showNotification(e)
      }
    }
  })
  ##THIS CODE CHUNK CHECKS FOR FAILED PACKAGES AND PUTS THEM IN FILE
  
  if(!is.null(installationFailedPackages) && length(installationFailedPackages)>0){
    tmp1 <- paste0(installationFailedPackages, collapse= "','")
    if(installationFailedRDRPOSTagger == TRUE && installationFailedOpenNLPModels ==TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')\r\n\r\n===============Run following command after running previous command================\r\n\r\ninstall.packages('RDRPOSTagger', repos ='http://www.datatailor.be/rcube', type = 'source',INSTALL_opts = '--no-multiarch')\r\n\r\n===============Run following command after running previous command================\r\n\r\ninstall.packages('openNLPmodels.en', repos = 'http://datacube.wu.ac.at/' , type = 'source')")
    }else if(installationFailedRDRPOSTagger == TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')\r\n\r\n Run following command after running previous command \r\n\r\n install.packages('RDRPOSTagger', repos ='http://www.datatailor.be/rcube', type = 'source',INSTALL_opts = '--no-multiarch')")
    }else if(installationFailedOpenNLPModels == TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')\r\n\r\n Run following command after running previous command\r\n\r\n
                                           install.packages('openNLPmodels.en', repos = 'http://datacube.wu.ac.at/' , type = 'source')")
    }else{
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')")
    }
    write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")
  }else{
    if(installationFailedRDRPOSTagger == TRUE && installationFailedOpenNLPModels ==TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command  \r\n\r\n install.packages('RDRPOSTagger', repos ='http://www.datatailor.be/rcube', type = 'source',INSTALL_opts = '--no-multiarch')\r\n\r\n===============Run following command after running previous command================\r\n\r\n
                                           install.packages('openNLPmodels.en', repos = 'http://datacube.wu.ac.at/' , type = 'source')")
      write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")    
    }else if(installationFailedRDRPOSTagger == TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\n\r\ninstall.packages('RDRPOSTagger', repos ='http://www.datatailor.be/rcube', type = 'source',INSTALL_opts = '--no-multiarch')")
      write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")    
    }else if(installationFailedOpenNLPModels == TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\n\r\ninstall.packages('openNLPmodels.en', repos = 'http://datacube.wu.ac.at/' , type = 'source')")
      write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")
    }
    
  }
} 
