#########################################################################
# Build Push script
# Vivekananda 
# Version 1.01
# Script for runnign test cases and uploading metrics during a build push
# Revisions version 01, Anubhav Agrawal 
# * Added script for uploading metrics
#########################################################################
library(testthat)
library(compare)
library(futile.logger)
set.seed(7)
flog.threshold(INFO)
# flog.appender(appender.file("./testCaseSummary.log"))
flog.appender(appender.file("./testCases.log"))
testResults <- as.data.frame(test_file('testCases.R'))
summary <- list()
summary[['Number of tests run']] <- nrow(testResults)#196
summary[['Numeber of tests failed']] <- sum(testResults$failed)
flog.info( knitr::kable(testResults))
flog.info("*************************************************************************************************************")
flog.info("Summary of test cases for this build")
flog.info(knitr::kable(as.data.frame(summary)))
if(sum(testResults$failed) > 0){
  stop()
}else{
  print("All tests passed. Pushing build...")
}


library("devtools")
testPackageName<-"testcovr"
# set value according to brick
# EDA
# Data Wrangling
# Regression
# Classification
# Panel Regression
# Text Mining
# Segmentation
# Quality Check
# SQL
# 
brickName<-"Quality Check"

#############################################################################################################
#####                               METRIC COVERAGE REPORTING STARTS                                    #####
#############################################################################################################
######## IMPORTANT!!!! WORKING PATH NEEDS TO BE brick_name/Source/ ###############
library("devtools")
library('covr')
testPackageName<-"testcovr"
sourceFileLocation<-"utils.R"
testFIleLocation<-"testCases.R"
# set value according to brick 
# EDA
# Data Wrangling
# Regression
# Classification
# Panel Regression
# Text Mining
# Segmentation
# Quality Check
# SQL
brickName<-"Quality Check"


total_coverage<-file_coverage(source_files = sourceFileLocation,test_files = testFIleLocation)

unit_test_coverage_percentage<-"0%"

unit_test_coverage_percentage<-paste0(as.character(round(percent_coverage(total_coverage),2)),"%")
# unit_test_coverage<-strsplit(unit_test_coverage_percentage,split = "%")[[1]][1]
#### Deleting the test package
unlink(testPackageName,recursive = T)
number_of_unit_test<-0
number_of_unit_test<-nrow(testResults)
#### Read Number of lines ####
openedFile <- file("utils.R",open="r")
readsizeof <- 20000
lines_of_code<-0
(while((linesread <- length(readLines(openedFile,readsizeof))) > 0 )
  lines_of_code <- lines_of_code+linesread )
close(openedFile)
lines_of_code = as.character(lines_of_code)
##### upload results to DB ######
## Use RPostgreSQL package to connect into database directly and import tables into dataframes.
library("RPostgreSQL")
## loads the PostgreSQL driver
drv <- dbDriver("PostgreSQL")
## Open a l
con <- dbConnect(drv, host='172.25.1.30', port='5432', dbname="metric", user='postgres', password='postgres')
unit_coverage<-unit_test_coverage_percentage
issues<-"0"
number_of_int_tests<-"0"
## lint function is masked by devtools
detach("package:devtools", unload=TRUE)
library("lintr")
warnings_lint <- lintr::lint("utils.R")
warnings_data_frame <- as.data.frame(warnings_lint)
warnings_list <- as.list(table(warnings_data_frame$type))
issues<-as.character(warnings_list$warning[1])

print(list(brickName,lines_of_code,number_of_unit_test,issues,number_of_int_tests,unit_test_coverage_percentage))
## Submits a statement
dbSendQuery(con, paste0("INSERT INTO eoc_brick_metrics VALUES (\'",brickName,"\',\'",lines_of_code,"\',\'",number_of_unit_test,"\',\'",issues,"\',\'",number_of_int_tests,"\',\'",unit_test_coverage_percentage,"\');"))

## Closes the connection
dbDisconnect(con)
## Frees all resources in the driver
dbUnloadDriver(drv)

#############################################################################################################
#####                               METRIC COVERAGE REPORTING ENDS                                      #####
#############################################################################################################

