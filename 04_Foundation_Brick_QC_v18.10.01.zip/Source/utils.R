
#####--------------------------------GLOBAL VARIABLES----------------------------------#####

operationsList <- NULL
names(operationsList) <- NULL

#'None'='none','Date Format'='date format','Count Blanks'='count blanks','Date Format'='date format','Median'='median','Is'='is','Is Not'='is not'

all_choices <- NULL

dbChoices <- NULL
odbcDbChoices <- NULL
showChoices <- function(connectionMethod){
  if(tolower(connectionMethod == "jdbc")){
    return(dbChoices)
  }else{
    return(odbcDbChoices)
  }
}

#-- Data Table options for Rule List Table
datatableOptions <- NULL

dtRownames <- NULL


dbPath <- NULL
#sqliteDB <- dbConnect(sqlite_drv, dbPath)
#sqlitelocaldb <- src_sqlite(dbPath, create = T)

####---------------------------------->>><<<--------------------------------------####




##---->> Global and Reactive Variables <<----##

##-->> Container for reactive variables used across

queryData <- NULL

#---- Copied from FoundationBrick_QC.RMd for encryption
user_token<-NULL
git_url <- NULL
project_issue_url <- NULL
session_url <- NULL

projectID <- NULL

#------- Seperate list of packages for rJava dependencies
nonJavaPackages <- NULL
javaPackages <- NULL

loadGlobals <- function () 
{
  operationsList <<- c("select", "filter", "mutate", "group_by", 
                       "summarize", "arrange")
  names(operationsList) <<- c("Select", "Filter", "Mutate", 
                              "Group By", "Summarize", "Sort")
  all_choices <<- list(Summarize = c(None = "none", `None - Column Compare` = "column", 
                                     Min = "min", Max = "max", Sum = "sum", Mean = "mean", 
                                     Count = "count", `Count Distinct` = "count distinct", 
                                     `Count NA/NULL` = "count na", `String Length` = "string length", 
                                     `Data Type` = "data type", `Has Unique` = "has.unique"), 
                       Operation = c(None = "none", Equals = "=", `Greater than` = ">", 
                                     `Greater than Or Equal to` = ">=", `Less than` = "<", 
                                     `Less than Or Equal to` = "<=", `Not Equal to` = "!=", 
                                     Between = "between", In = "in", `Not In` = "not in"), 
                       OperationChar = c(None = "none", Equals = "=", In = "in", 
                                         `Not In` = "not in", Like = "like", `Not Like` = "not like"), 
                       OperationChar1 = c(None = "none", Equals = "=", In = "in", 
                                          `Not In` = "not in"), OperationDate = c(None = "none", 
                                                                                  Equals = "=", `Greater than` = ">", `Greater than Or Equal to` = ">=", 
                                                                                  `Less than` = "<", `Less than Or Equal to` = "<=", 
                                                                                  `Not Equal to` = "!=", Between = "between"), SummarizeChar = c(None = "none", 
                                                                                                                                                 `None - Column Compare` = "column", Count = "count", 
                                                                                                                                                 `Count Distinct` = "count distinct", `Count NA` = "count na", 
                                                                                                                                                 `Count Blanks` = "count blanks", `String Length` = "string length", 
                                                                                                                                                 `Data Type` = "data type", `Has Unique` = "has.unique"), 
                       ArithOperation = c(None = "none", Addition = "+", Substraction = "-", 
                                          Multiplication = "*", Division = "/"))
  dbChoices <<- c(SQLite = "sqlite_db", MySQL = "mysql_db", 
                  PostgreSQL = "postgres", Oracle = "oracle", `SQL server` = "sql_server", 
                  Teradata = "teradata", Netezza = "netezza", Hive = "hive", 
                  Other = "other")
  odbcDbChoices <<- c(Hive = "hive",Teradata = "teradata", `SQL server` = "sql_server", Other = "other")
  datatableOptions <<- list(lengthChange = T, pageLength = 20, 
                            lengthMenu = c(10, 20, 30, 40), escape = F, scrollX = T, 
                            fixedColumns = T, searching = F, autoWidth = TRUE, columnDefs = list(list(width = "30px", 
                                                                                                      targets = c(1)), list(width = "200px", targets = c(2, 
                                                                                                                                                         3, 4)), list(width = "150px", targets = c(5, 6))))
  dtRownames <<- F
  dbPath <<- "qcmodule1-sqlite3.db"
  
  user_token<<-""
  git_url <<- "http://mugitlab.mu-sigma.com/api/v3"
  project_issue_url <<- "http://mugitlab.mu-sigma.com/api/v3/projects/97/issues"
  session_url <<- "http://mugitlab.mu-sigma.com/api/v3/session"
  
  
  queryData <<- data.frame(Filters = character(), GroupBy = character(), 
                           Column = character(), Function = character(), Operation = character(), 
                           Argument = character(), Result = character(), Value = character(), 
                           Run = character(), Command = character(), Comparison = character(), 
                           TableName = character(), JoinKeys = character(), caseSensitive = character(), 
                           Remarks = character(), stringsAsFactors = F)
  
  
  packages <<- list(  'devtools'
                             ,'shiny'
                             ,'shinyjs'
                             ,'shinyBS'
                             ,'knitr'
                             ,'DT'
                             ,'dplyr'
                             ,'ggplot2'
                             ,'lubridate'
                             ,'data.table'
                             ,'httr'
                             ,'rjson'
                             , 'zip'
                             , 'plyr'
                             , 'colourpicker'
                             , 'stringr')
  
  dbPackages <<- list(  'rJava'
                          ,'odbc'
                          ,'RPostgreSQL'
                          ,'RMySQL'
                          ,'RSQLite'
                          ,'DBI'
                          ,'RJDBC')

  projectID <<- 97
}


##---------------------------------------##

#-End Global Variables
#-* There are other Global variables defined at the beginning of each section

a = c('connect', 'inDataType_func', 'inDatCols_func', 'getRuleListTableNames', 'getMetafileNames', 'metaFileLoad', 'useMetaFile', 'pcquery',
      'evalQuery', 'dbResultLen', 'clearResults', 'joinTables', 'filterTransform', 'paraTransform', 'inputTreatment', 'evalQuery1', 'evaluateQuery', 'evaluateQuery_db'
      , 'createQuery1', 'createQuery', 'execSqlQuery', 'colExpr', 'filterExpr', 'operationExpr1', 'operationExpr', 'groupbycolsexpr', 'evaluateQuery_local'
      , 'hasUnique', 'fplyr', 'compare', 'dataType', 'evalStr', 'dbCreateNewCol', 'dbCalculatedCol', 'dbDropColumns', 'dbKeepColumns', 'dbTableTopQuery',
      'dbTableTop', 'dbFetchTop', 'dbFetchTopWrapper', 'convertToDate', 'templateLocalInfo', 'templateDBInfo', 'templateCheckSubmit_func_main', 'nullCheckSubmit_func_main'
      , 'duplicationCheck', 'hierarchyCheck', 'uploadedQueries_func')






# INPUT DATA column data types ---------------------
inDataType_func <- function(conList){

    dat <- conList$table

  
  if(is.null(dat)) return(NULL)
  dat <- dplyr::collect(head(dat,n=10))
  
  dtypes <-unlist(lapply(lapply(dat,class),function(x){return(x[1])}))
  data.frame(col=colnames(dat),dataType=dtypes,stringsAsFactors = F)
}


inDatCols_func <- function(conList){
  dat <- inDataType_func(conList)
  if(is.null(dat)) return(NULL)
  dat$col
}




getRuleListTableNames <- function(queryData1){
  
  queryData1 <- queryData1 %>% dplyr::filter(Comparison=='1')
  # Get Alias
  colBreak <- data.frame(do.call(rbind,lapply(queryData1$Column,function(x)strsplit(x,';')[[1]][c(2)])),stringsAsFactors = FALSE)
  colnames(colBreak) <- c('Alias1')
  colBreak$Alias_In_Rule_List <- trimws(unlist(sapply(colBreak$Alias1,function(x){strsplit(x,'\\.')[[1]][1]})))
  # Get Table Names 
  tableBreak <- data.frame(do.call(rbind,lapply(queryData1$TableName,function(x)strsplit(x,';')[[1]][c(1,2)])),stringsAsFactors = FALSE)
  colnames(tableBreak) <- c('table1Name','Table_Name')
  tableBreak <- tableBreak %>% dplyr::filter(!is.na(Table_Name))
  # Join Alias and TableNames
  colBreak <- unique(cbind(colBreak[,'Alias_In_Rule_List',drop=FALSE],tableBreak[,'Table_Name',drop=FALSE]))
  if(!'A' %in% colBreak$Alias_In_Rule_List) colBreak <- rbind(colBreak,c('A',trimws(tableBreak[1,1]))) # hardcoding of [1,1] 
  
  colBreak <- colBreak %>% dplyr::filter(!is.na(colBreak$Table_Name)) %>% dplyr::select(Table_Name,Alias_In_Rule_List) %>% dplyr::arrange(Alias_In_Rule_List) %>% unique
  
}

getMetafileNames <- function(tempLoc){
  files <- dir(tempLoc)
  metaFiles <- grepl('metaFile',files) # logical vector
  if(any(metaFiles)){
    metaFiles <- data.frame(Metafiles = sort(files[metaFiles]),stringsAsFactors = F) # take only the ones that are TRUE
  } else { metaFiles <- data.frame(Metafiles=character())}
}


##-----------------------------------------Meta files
metaFileLoad <- function(varTypeFile, dataset){
  alertNoMetaFile <- ""
  typeFileErrorText <- ""
  typeFileErrorTable <- ""
  typeColumnErrorText <- ""
  if (is.null(varTypeFile))
  {
    typeData <- data.frame("Column"=colnames(dataset))
    typeData$Column.Type <- unname(lapply(dataset,function(x){CheckColumnType(x,2) }))
    alertNoMetaFile <- "NOTE: Upload a relevant meta file mentioning the variable types to be typecasted. 
    The Data Wrangling brick can be used to generate such meta files."
  }else
  {
    alertNoMetaFile <- ""
    typeData <- read.csv(varTypeFile$datapath, stringsAsFactors = FALSE)
    typeData <- typeData[which(typeData$Column %in% colnames(dataset)),]
    if(any(!(typeData$Column.Type %in% c("numeric","factor","character","Date"))))
    {
      typeFileErrorText <- "Error : Invalid type specified. Valid types : numeric, character, Date"
      typeFileErrorTable <- data.frame("Column"=c("SampleColumnName1", "SampleColumnName1","SampleColumnName1"),
                                       "Column.Type"=c("numeric", "factor","character"),
                                       "Reference.Level"=c(NA,"Yes","Male"))
    }
    if(!all(colnames(dataset) %in% typeData$Column))
    {
      typeColumnErrorText <- "Error : The variable type csv does not have entries for all columns of the dataset"
    }
  }#end of if varFileType exists
  return(list(typeData=typeData, colErr=typeColumnErrorText, typeErrorText=typeFileErrorText, 
              typeErrorTable<-typeFileErrorTable, noMetaAlert=alertNoMetaFile))
  }


useMetaFile <- function(dataset, typeData)
{
  datasetNumeric <- as.character(typeData$Column[which(typeData$Column.Type == "numeric")])
  datasetNumericCategorical <- as.character(typeData$Column[which(typeData$Column.Type == "factor")])
  datasetStringCategorical <- as.character(typeData$Column[which(typeData$Column.Type == "character")])
  datasetCategorical <- union(datasetNumericCategorical, datasetStringCategorical)
  datasetDate <- as.character(typeData$Column[which(typeData$Column.Type == "Date")])
  
  orderedNames <- colnames(dataset)
  if(length(datasetCategorical)>0)
  {
    dataset[,datasetCategorical] <- data.frame(sapply(dataset[,datasetCategorical,drop=F],function(x){as.character(x)}),stringsAsFactors = FALSE)
  }
  if(length(datasetNumeric)>0)
  {
    dataset[,datasetNumeric] <-  data.frame(sapply(dataset[,datasetNumeric,drop=F],function(x){as.numeric(x)}),stringsAsFactors = FALSE)
  }
  
  dataset <- dataset[,orderedNames,drop=F]
  
  return(list(dataset=dataset, typeData=typeData, numCols=datasetNumeric, catCols=datasetNumeric))
}



#-------------------------------------->



#-------------------------------------->

# Panel comp



pcquery <- function(inTable1,conList,connDb=connDb,compData,keyCols,panelCols,diffCols,dbTempTable){
  con <- conList$con
  #con <- connObj
  #print('Panel Comparison Dataset Creation')
  table <- inTable1$data
  mainDataColInfo <- inTable1$dataTypes[,c('col','dataType')]
  tableCols <- mainDataColInfo[,'col']
  colTypes <- mainDataColInfo[,'dataType']
  
  if(nrow(compData)==0){
    #showNotification('Add Comparison Time Periods',type='warning')
    return(list(data=NULL,error='Add Comparison Time Periods'))
  }
  
  # Parse the compData which has the time perioed required for comparison
  compDataT <- t(compData[,c(2,3)])
  compDataUnique <- unique(as.vector(compDataT))
  compDataSplit <- data.frame(t(data.frame(sapply(compDataUnique,function(x)strsplit(x,';')))),stringsAsFactors = F)
  cUniqueID <- data.frame(filters=compDataUnique,id=letters[1:length(compDataUnique)],stringsAsFactors = F)
  combinations <- merge(merge(compData,cUniqueID,by.x='Time_1_Value',by.y='filters'),cUniqueID,by.x='Time_2_Value',by.y='filters')
  len <- nrow(compDataSplit)
  
  tableCols1 <- tableCols
  tableCols <- setdiff(tableCols,c(keyCols,panelCols))
  
  

    filterList <- c()
    for(i in 1:len){
      keyValues <- unlist(compDataSplit[i,])
      filterList<- c(filterList,paste(paste(panelCols,'==',keyValues),collapse=' & '))
    }
    
    tableCols1 <- paste(setdiff(tableCols1,c(panelCols)),collapse=",")
    
    mergeMultiple <- function(){tryCatch({ #-------------- Create and join the panels on the key columns
      table1 <- NULL
      eval(parse(text=paste0('table1 <- table %>% dplyr::filter(',filterList[1],') %>% dplyr::select(',tableCols1,')')))
      colOrder <- c(keyCols,setdiff(colnames(table1),c(keyCols)))
      table1 <- table1[,colOrder]
      newNames <- c(keyCols,paste0(setdiff(colnames(table1),c(keyCols)),'_a'))
      colnames(table1) <- newNames
      for(i in 2:nrow(compDataSplit)){
        table2 <- NULL
        eval(parse(text=paste0('table2 <- table %>% dplyr::filter(',filterList[i],') %>% dplyr::select(',tableCols1,')')))
        table2 <- table2[,colOrder]
        newNames <- c(keyCols,paste0(setdiff(colnames(table2),c(keyCols)),'_',letters[i]))
        colnames(table2) <- newNames
        inputsMerge <- merge(table1,table2,by=keyCols)
        table1 <- inputsMerge
      }
      list(data=table1)
    },error=function(e){list(data=NULL,error=e[1])})}
    
    mergedTables <- mergeMultiple()
    if(is.null(mergedTables$data)) return(list(data=NULL,error=mergedTables$error))
    mergedTables <- mergedTables[['data']]
    
    # Diff cols - Create the difference columns across time periods for the colums selected in diffCols variables 
    diffColStr <- c()
    pctDiffColStr <- c()
    
    if(length(diffCols>0)){
      diffColsExpr <- c()
      commonNumCols <- diffCols
      for(i in 1:nrow(combinations)){
        comb <- unlist(combinations[i,c('id.x','id.y')])
        diffColStr <- paste(c(diffColStr
                              ,paste0(' Diff_',commonNumCols,'_',comb[1],'_',comb[2],' = '
                                      ,commonNumCols,'_',comb[1],' - ',commonNumCols,'_',comb[2])),collapse=',')
        pctDiffColStr <- paste(c(pctDiffColStr
                                 ,paste0('PCT_Diff_',commonNumCols,'_',comb[1],'_',comb[2],' = '
                                         ,'(',commonNumCols,'_',comb[1],' - ',commonNumCols,'_',comb[2],')/'
                                         ,commonNumCols,'_',comb[1])),collapse=',')
      }
      mergedTableCols <- setdiff(colnames(mergedTables),keyCols)
      mergedTables <- eval(parse(text=paste0('mergedTables %>% dplyr::mutate(',diffColStr,')')))
      ##print(head(mergedTables))
      newMergedTableCols <- setdiff(colnames(mergedTables),c(keyCols,mergedTableCols))
      mergedTables <- mergedTables[,c(keyCols,newMergedTableCols,mergedTableCols)]
    }
    return(list(data=mergedTables))
  
}






##____________________________________________________________________________________________##
#----------------------------------------------------------------------------------------------#
#------------------------------ CREATE RULE TAB - GLOBAL FUNCTIONS ----------------------------#
#----------------------------------------------------------------------------------------------#








joinTables <- function(type,lhsTable,rhsTable,operationSel,jKeys,lMetricName,rMetricName){
  #print('Joining LHS and RHS tables')
  connObj <- type$con
  
  
    left <- unlist(lapply(jKeys,function(x)x[1]))
    right <- unlist(lapply(jKeys,function(x)x[2]))
    # Merge
    finTable <- merge(lhsTable,rhsTable,by.x=left,by.y=right)
    # Ensure the last column of the lhsTable and rhsTable are the metric column
    # Create comparison column 
    lTable <- finTable[,ncol(finTable)-1]
    rTable <- finTable[,ncol(finTable)]
    return(list(lTable,rTable))
    
  
}

# -- filterTransform handles all the differences in filter condition and syntax between CSV and DB
filterTransform <- function(x,tableAlias,connType,inTables){
  colList <- trimws(x[1])
  opList <- trimws(x[2])
  argList <- trimws(x[3])
  connector <- trimws(x[4])
  dtype <-subset(inTables$tables[[tableAlias]]$dataTypes,col==colList)[,'dataType']
  #dtype <- getColType(tableAlias,colList)
  #dtype <- ''
  
  conobj <- connType # Reading from global variable
  if(is.null(conobj)){
    cmdString <- switch(opList,
                        'between'= {
                          if(dtype=='Date'){
                            #format <- dateFormatDF %>% dplyr::filter(dataName==tableAlias & colName==colList) %>% dplyr::select(inputFormat)
                            format <- 'ymd'
                            vec <- gsub('\\(|\\)','',strsplit(argList,',')[[1]])
                            paste0('between(',colList,",",format,'(',vec[1],"),",format,'(',vec[2],'))')
                          } else {
                            vec <- as.numeric(gsub('\\(|\\)','',strsplit(argList,',')[[1]]))
                            paste0('between(',colList,",",vec[1],",",vec[2],')')
                          }
                        }
                        ,'in'=
                          ,'not in'= {
                            vec <- as.numeric(gsub('\\(|\\)','',strsplit(argList,',')[[1]]))
                            paste(if(opList == 'not in') '!','(',colList,'%in%','c(',argList,'))')
                          },'=' = {paste(colList,'==',argList)}
                        ,'like'= {paste0('grepl(',argList,',',colList,')')}
                        ,'not like'= {paste0('!grepl(',argList,',',colList,')')}
                        ,paste(colList,opList,argList)
    )
    return(paste(cmdString,if(!is.na(connector)) connector))
  }
  else {
    cmdString <- switch(opList,
                        'between'= {
                          vec <- as.numeric(gsub('\\(|\\)','',strsplit(argList,',')[[1]]))
                          paste(colList,'between',vec[1],'and',vec[2])
                        }
                        ,'in'=
                          ,'not in'= {
                            paste(colList,opList,'(',argList,')')
                          }, 
                        paste(colList,opList,argList)
    )
    
    connector <- gsub('&','AND',gsub('\\|','OR',connector))
    return(paste(cmdString,if(!is.na(connector)) connector))
  }
}



#-- Transforming the input parameters based on the input type selected : CSV/ DB
#-- Converts parameters to make them compatible with the platform on which it is running: R/ SQL Database
paraTransform <- function(connType,filters,groupby,funcSel,operationSel,argValue,colSel,tableAlias){
  #print('Transforming Parameters')
  filters <- trimws(filters)
  groupby <- trimws(groupby)
  funcSel <- trimws(funcSel)
  operationSel <- trimws(operationSel)
  argValue <- trimws(argValue)
  
  
  #-- Treat inputs parameters based on CSV or DB connection.
  if(is.null(connType)){ # -- CSV --
    if(trimws(operationSel) %in% c('between')){
      argValue <-  eval(parse(text=paste0('c(',paste0(gsub('\\(|\\)','',unlist(strsplit(argValue,','))),collapse=','),')')))
    }
    else #if(trimws(operationSel) %in% c('in','not in','='))
    {
      if(!funcSel %in% c('column','data type','has unique'))
        argValue <- eval(parse(text=paste0('c(',paste0(unlist(strsplit(argValue,',')),collapse=','),')')))
    }
    
    operationSel <- ifelse(operationSel=='=','==',operationSel)
    operationSel <- ifelse(operationSel=='in','%in%',operationSel)
    funcSel <- ifelse(funcSel=='avg','mean',funcSel)
    
    #-- Column Comparison case - transforming parameters
    if(funcSel=='column'){ 
      filters <- paste(if(filters!='') paste(filters,' & '),'!',colSel,operationSel,argValue)
      funcSel <- 'count'
      operationSel <- '=='
      argValue <- 0
      groupby <- ''
    } else if(funcSel=='has.unique'){
      argValue <- 0
      operationSel <- '=='
    } else {
      # if(!trimws(operationSel) %in% c('in','not in','between')) 
      # argValue <- eval(parse(text=argValue))
    }
    
  } else { # -- DB ---
    operationSel <- ifelse(operationSel=='==','=',operationSel)
    operationSel <- ifelse(operationSel=='%in%','in',operationSel)
    funcSel <- ifelse(funcSel=='mean','avg',funcSel)
    funcSel <- ifelse(funcSel=='string length','length',funcSel)
  }
  
  return(list(filters,groupby,funcSel,operationSel,argValue))
}



#-- Treating inputs based on comparison type : Multiple File QC or Single File QC
#-- Inputs from Rule creation section are captured differently for Single Dataset and Multiple Dataset comparison cases.
#-- This function treats for the inconsitencies

inputTreatment <- function(connType,filters,groupby,colSel,funcSel,operationSel,argValue,comparison,joinKeys,inTables){
  #print('Treating Parameters')
  
  #-- Split paramters on  ';' to separate parameters for either datasets
  #-- If query involves comparison, the paramters are split on ';' to correspond to LHS and RHS  datasets
  if(comparison==1){  
    filters <- trimws(unlist(strsplit(filters,";")))
    groupby <- trimws(unlist(strsplit(groupby,";")))
    operationSel <- trimws(unlist(strsplit(operationSel,";")))
  } else { #-- If query does not involve comparison, the values for second table will be ''
    filters <- c(filters,'')
    groupby <- c(groupby,'')
    operationSel <- c('',operationSel)   
  }
  
  #-- Get alias of secondary dataset
  colSel <- trimws(unlist(strsplit(colSel,";"))) 
  loc <- gregexpr('\\.',colSel[2])[[1]][[1]]  
  table2Alias <- substring(colSel[2],1,loc-1)
  colSel[2] <- substring(colSel[2],loc+1,nchar(colSel[2]))
  
  funcSel <- trimws(unlist(strsplit(funcSel,";")))
  funcSel <- ifelse(trimws(funcSel==''),'none',funcSel)
  
  if(length(funcSel)==1) funcSel <- trimws(c(funcSel,''))
  
  
  #--- PARAMETER TRANFORMATION ---------------------------------------------------------------
  #-- Transform input parameters according to data connection type: CSV or DB
  #-- Break down the filter string to get filters for left and right tables
  filterDT <- matrix(unlist(strsplit(trimws(filters[1]),'\\t')),ncol=4,byrow=TRUE)
  filterDT[nrow(filterDT),4] <- NA
  filters[1] <- paste(apply(filterDT,1,function(x)filterTransform(x,tableAlias='A',connType,inTables)),collapse=" ")
  paraTransform1 <- paraTransform(connType,filters[1],groupby[1],funcSel[1],operationSel[2],argValue,colSel[1],tableAlias='A')
  
  if(comparison==1){ 
    #-- Break down the filter string to get filters for left and right tables
    filterDT <- matrix(unlist(strsplit(trimws(filters[2]),'\\t')),ncol=4,byrow=TRUE)
    filterDT[nrow(filterDT),4] <- NA
    filters[2] <- paste(apply(filterDT,1,function(x)filterTransform(x,tableAlias=trimws(table2Alias),connType,inTables)),collapse=" ")
    paraTransform2 <- 
      paraTransform(connType,filters[2],groupby[2],funcSel[2],operationSel[2],argValue,colSel[2],tableAlias=trimws(table2Alias))
  }
  else paraTransform2 <- as.list(rep('',5))
  
  filters <- c(paraTransform1[[1]],paraTransform2[[1]])
  groupby <- c(paraTransform1[[2]],paraTransform2[[2]])
  funcSel <- c(paraTransform1[[3]],paraTransform2[[3]])
  operationSel <- c(operationSel[1],paraTransform1[[4]]) # For now, arithmetic operator is ''
  argValue <- paraTransform1[[5]] # argValue will be a single value
  
  
  
  # Handling JOIN parameters ----------------------------------------------------------------
  #-- Extracting join keys and transforming input parameters accordingly
  jKeys <- list()
  lKeys <- NULL
  rKeys <- NULL
  
  if(comparison==1 & joinKeys!=''){
    jKeys <- unlist(strsplit(joinKeys,';'))
    lKeys <- trimws(unlist(strsplit(jKeys[1],',')))
    rKeys <- trimws(unlist(strsplit(jKeys[2],',')))
    jKeys <- lapply(c(1:length(lKeys)),function(i){ c(lKeys[i],rKeys[i])})
    
    if(groupby[1]=='')
      colSel[1] <- paste(c(lKeys,colSel[1]),collapse=',')
    if(groupby[2]=='')
      colSel[2] <- paste(c(rKeys,colSel[2]),collapse=',')
  }
  
  return(list(filters,groupby,colSel,funcSel,operationSel,argValue,table2Alias,jKeys))
}



evalQuery <- function(inputDataType, data,inTables,filters,groupby,colSel,funcSel,operationSel,argValue,comparison,joinKeys,caseSensitive,roundOffTheValue){
  # print('Evaluating Query 1')
  print(roundOffTheValue)
  # Any transformation or treatment to input paramters will be handled inside the inputTreatment() function which also
  # calls other functions for treating specific parameters e.g. filterTransform() for treating Filters parameter
  inputTreatment <- inputTreatment(data$con,filters,groupby,colSel,funcSel,operationSel,argValue,comparison,joinKeys,inTables)
  # print('Evaluating Query 1')
  filters <- inputTreatment[[1]]
  groupby <- inputTreatment[[2]]
  colSel <- inputTreatment[[3]]
  funcSel <- inputTreatment[[4]]
  operationSel <- inputTreatment[[5]]
  argValue <- inputTreatment[[6]]
  arithmeticSel <- operationSel[1] # unused
  operationSel <- operationSel[2]
  jKeys <- inputTreatment[[8]] # list of join keys
  caseSensitive <- caseSensitive
  # print('Evaluating Query 1')

    lhs <- evaluateQuery(inputDataType, data,filters[1],groupby[1],colSel[1],funcSel[1],operationSel,0,caseSensitive,roundOffTheValue)
    
    if(comparison=='1'){# FOR CSV - Multi Dataset Comparison ---------------------
      
      table2Alias <- inputTreatment[[7]]
      table2Index <- which(names(inTables$tableNames)==table2Alias)
      
      rhs <- evaluateQuery(inputDataType, list(con=NULL,table=inTables$tables[[table2Index]]$data),filters[2],groupby[2],colSel[2],funcSel[2],operationSel,0,caseSensitive,roundOffTheValue)
      
    } else {
      rhs <- list('',argValue,'')
    }
    
    # Row count
    nlhs <- nrow(lhs[[2]])
    nrhs <- nrow(data.frame(rhs[[2]]))
    
    # Round numeric values to 3 decimal places
    # lval <- ifelse(nlhs==1 & is.numeric(unlist(lhs[[2]])),round(unlist(lhs[[2]]),3),lhs[[2]])
    # rval <- ifelse(nrhs==1 & is.numeric(unlist(rhs[[2]])),round(unlist(rhs[[2]]),3),rhs[[2]])
    lhsval <- ifelse(nlhs==0,'No Rows returned in one of the queries',ifelse(nlhs==1 ,lhs[[2]],"Multi. Rows"))
    rhsval <- ifelse(nrhs==0,'No Rows returned in one of the queries',ifelse(comparison==1,ifelse(nrhs==1,rhs[[2]],"Multi. Rows"),''))
    
    
    comment <- ''
    # Multi-Multi row comparison not supported
    if(nlhs>1 && nrhs>1 && nlhs!=nrhs && ! operationSel %in% c('in','%in%','not in','between')){
      if(comparison==1 & joinKeys!='')
        comment <- 'LHS and RHS rows did not match. Continued with Inner Join.'
      else
        return(list(FALSE,'LHS and RHS rows do not match',''))
    }
    
    if(operationSel=='none'){
      return(list('',lhsval,''))
    }
    
    
    #- Handling JOINS
    if(comparison == 1 & joinKeys!=''){ # For JOINS
      #source('test1.R',local=TRUE)
      finTable <- joinTables(list(con=data$con,db=data$db),lhs[[2]] ,rhs[[2]] ,operationSel,jKeys,lMetricName='',rMetricName='')
      lhs[[2]] <- finTable[[1]]
      rhs[[2]] <- finTable[[2]]
      
    } else { # No JOINS
    
      lhs[[2]] <- lhs[[2]] %>% dplyr::select_(lhs$aggColName)
      if(comparison==1) 
        rhs[[2]] <- rhs[[2]] %>% dplyr::select_(rhs$aggColName)
    }
    
    if(!trimws(arithmeticSel) %in% c('','none')){
      leftV <- unlist(lhs[[2]])
      rightV <- unlist(rhs[[2]])
      lhs[[2]] <- switch(arithmeticSel
                         ,"+" = leftV+rightV
                         ,"-" = leftV-rightV
                         ,"*" = leftV*rightV
                         ,"/" = leftV/rightV
      )
      rhs[[2]] <- argValue
      arithval <- ifelse(nlhs==0,'No Rows returned in one of the queries',ifelse(nlhs==1 ,lhs[[2]],"Multi. Rows"))
      
    }
    
    #-- Compare LHS and RHS -----------
    dat <- data.frame('lhs' = lhs[[2]],stringsAsFactors = F)
    #print('Comparing')
    
    # print(list(funcSel,dat,colnames(dat),operationSel,unlist(rhs[[2]])))
    
    bin <- compare(funcSel,dat,colnames(dat),operationSel,unlist(rhs[[2]]),caseSensitive)
    
    # val <- paste0('Pri: ',lhsval," ; Sec: ",rhsval,' ; ArithVal: ',arithval,' . ',comment)
    val <- paste0(lhsval," ; ",rhsval,' . ',comment)
    bin <- list(bin[[1]],val,'')
    
    return(bin)
    
   
}




evaluateQuery <- function(inputDataType, conList,filters,groupby,colSel,funcSel,operationSel,argValue,caseSensitive,roundOffTheValue){
  #print('Evaluating Query')

    val <- evaluateQuery_local(inputDataType, conList,filters,groupby,colSel,funcSel,operationSel,argValue,caseSensitive,roundOffTheValue)
   
    return(val)
  
 
}




# Creates arguemtns in SELECT statement
colExpr <- function(colSel,funcSel){
  #print('colexpr')
  str <- switch(funcSel
                ,'min'=,'max'=,'avg'=,'sum'=,'count'=,'length'= paste0(funcSel,'(',colSel,')')
                ,'count'=paste0('count','(',colSel,')')
                ,'count na'=paste0('count(*)')
                ,'count distinct'=paste('count( distinct',colSel,')')
                ,'count blanks'=,'count na'=paste('count(',colSel,')')
                ,'has.unique'=paste('count( distinct',colSel,')=count(*)')
                ,'none'=,'column'= colSel
  )
  
}


# Creates arguments in FILTER statement
filterExpr <- function(colSel,funcSel,filter){
  minor <- switch(funcSel
                  ,'count blanks'=paste(colSel," = '' ")
                  ,'count na'= paste(colSel,'is null'),'')
  complete <- paste(if(filter!='' | minor!= '') 'where ',filter,if(minor!='' & filter!='') 'and',minor)
  #complete <- ''
  return(complete)
}



# creates comparison arguments in SELECT statement for Multiple Dataset  QC
operationExpr1 <- function(operationSel,argValue,where=0){
  expr <- switch(operationSel
                 ,'>'=,'>='=,'<'=,'<='=,'='=,'!='= paste(operationSel,argValue)
                 ,'in'=paste('in (',argValue,')')
                 ,'not in'=paste('not in (',argValue,')')
                 ,'between'={
                   vec <- as.numeric(gsub('\\(|\\)','',strsplit(argValue,',')[[1]]))
                   paste('between',vec[1],'and',vec[2]) 
                 }
                 ,'is'=,'is not'=paste(operationSel,argValue))
  return(paste0(ifelse(where,'where col',''),expr))
}



# creates arguments in FILTER statement
operationExpr <- function(funcSel,colSel,operationSel,argValue,where=0){
  if(funcSel=='has.unique') return('')
  expr <- switch(operationSel
                 ,'>'=,'>='=,'<'=,'<='=,'='=,'!='= paste(operationSel,argValue)
                 ,'in'=paste('in (',argValue,')')
                 ,'not in'=paste('not in (',argValue,')')
                 ,'between'={
                   vec <- as.numeric(gsub('\\(|\\)','',strsplit(argValue,',')[[1]]))
                   paste('between',vec[1],'and',vec[2]) 
                 }
                 ,'is'=,'is not'=paste(operationSel,argValue))
  return(paste0(ifelse(where,'where col',''),expr))
}

# creates arguments in GROUP BY statement
groupbycolsexpr <- function(groupbycols,funcSel){
  switch(funcSel
         ,'none'=''
         ,if(groupbycols!='') paste('group by',groupbycols) else '')
}



## Wrapper function for evaluating the inputs
evaluateQuery_local <- function(inputDataType, data,filters,groupby,colSel,funcSel,operationSel,argValue,caseSensitive,roundOffTheValue){
  
  data <- data$table
 # eval(parse(text=paste(data,"[,'",colSel,"']")))
  #subset(data,select = colSel)
  #print('Evaluating query on local')
  data[,which(colnames(data)==colSel)] <- roundOffDataFrame(as.data.frame(data[,which(colnames(data)==colSel)]),roundOff = T,precision = 2)
  cmdString <- 'data'
  
  #-- Filter data if any input data filter has been provided
  if(trimws(filters)!=''){
    cmdString <- paste(cmdString,'%>% dplyr::filter(',filters,')')
    data <- eval(parse(text=paste('data %>% dplyr::filter(',filters,')')))
  }
  
  #-- Group by data based on the group_by columns provided
  if(trimws(groupby)!=''){ 
    cmdString <- paste(cmdString,'%>% dplyr::group_by(',groupby,')')
    data <- eval(parse(text=paste('data %>% dplyr::group_by(',groupby,')')))
  }
 
  #groupbyCols <- trimws(unlist(strsplit(groupby,",")))
  aggColName <- paste0(gsub(" ","_",funcSel),"_",colSel) ## This name is provided as the column name to the new aggregated columns created.
  
  valList <- switch(funcSel,
                    'min'=,
                    'max'=,
                    'mean'=,
                    'sum'=,
                    'median'=,
                    'count'=,
                    'count distinct'=,
                    'count na'=,
                    'count blanks'=,
                    'string length' = fplyr(data,colSel,funcSel),
                    'has.unique'= hasUnique(data,colSel,funcSel),
                    'data type'= dataType(inputDataType,colSel),
                    'none'={
                      cmdStr <- paste('data %>% dplyr::select(',colSel,')')
                      val <- eval(parse(text=cmdStr))
                      list('',val,cmdStr)  # All values must be returned in this format list(res,val,cmdString)
                    })
  
  #**MAINTAIN THE ORDER OF IF CONDITIONS BELOW
  if(funcSel=='has.unique'){
    cmdString1 <- valList[[3]]
    cmdString1 <- gsub('data %>%','',cmdString1)
    valList[[3]] <- paste(cmdString,'%>%',cmdString1)
    return(valList)
  }
  
  #val <- valList
  cmdString1 <- valList[[3]]
  cmdString1 <- gsub('data %>%','',cmdString1)
  cmdString <- paste(cmdString,'%>%',cmdString1)
  valList[[3]] <- cmdString
  
  if(operationSel=='none' && groupby == ''){
    val <- unlist(dplyr::collect(valList[[2]]))
    if(length(val)>1) val <- 0
    else val <- valList[[2]]
    return(list('',val,cmdString))
  }
  
  #if(sum(c('tbl','data.frame') %in% class(valList[[2]]))){
  if(!funcSel %in% c('none'))
    valList$aggColName <- aggColName  #valList[[2]] <- valList[[2]] %>% dplyr::select_(aggColName)
  else
    valList$aggColName <- colSel
  #valList[[2]] <- valList[[2]] %>% dplyr::select_(colSel)
  #}
 
  return(valList)
}


# Checks for No Duplicates in a column: CSV / Data.frames
hasUnique <- function(data,colSel,funcSel){
  cmdString0 <- paste0('data %>% dplyr::select(',colSel,') %>% dplyr::summarize(n_dist=dplyr::n_distinct(',colSel,'),n=dplyr::n()) %>% dplyr::mutate(l=n-n_dist) %>% dplyr::ungroup() %>% dplyr::select(l)') # %>% dplyr::summarize(sum(l)) %>% dplyr::dplyr::collect(n=Inf) %>% unlist')
  
  cmdString <- paste0('data %>% dplyr::select(',colSel,') %>% dplyr::summarize(n_dist=dplyr::n_distinct(',colSel,'),n=dplyr::n()) %>% dplyr::mutate(l=n-n_dist) %>% dplyr::ungroup() %>% dplyr::select(l) ') #%>% summarize(sum(l)) %>% collec (n=Inf) %>% unlist')
  val <- data.frame(a=eval(parse(text=cmdString0)))
  colnames(val) <- paste0('hasUnique_',colSel)
  #res <- ifelse(val[1,1]==0,TRUE,FALSE)
  list('',val,cmdString,aggColName=colnames(val))
}

#-- Evaluates the aggregation function in the QC checks for Local CSV datasets
#-- Aggregations are handled by this function. Also provides the commnand string being executed for these aggregations.
fplyr <- function(data,colSel,funcSel){
  #print('Executing Summarize functions')
  
  aggColName <- paste0(gsub(" ","_",funcSel),"_",colSel)

  print('here')
  cmdString <- switch(funcSel,
                      'min'=,'max'=,'mean'=,'sum'={
                        paste0('data %>% dplyr::summarize(',aggColName,"="
                               ,funcSel,'(as.numeric(',colSel,')',ifelse(funcSel=='count','))',',na.rm=T)) '))
                      },
                      'median'={
                        paste0('data %>% dplyr::select(',colSel,') %>% dplyr::filter(ntile(',colSel,', 2) == 1) %>% dplyr::summarize(',aggColName,"=",'max(',colSel,'))')
                      },
                      'count'={
                        paste0('data %>% dplyr::select(',colSel,') %>% dplyr::summarize(',aggColName,"=",'dplyr::n())')
                      },
                      'count distinct'=,'has.unique'={
                        paste0('data %>% dplyr::summarize(',aggColName,"=",'dplyr::n_distinct(',colSel,'))')
                      },
                      'count na'={
                        paste0('data %>% dplyr::select(',colSel,') %>% dplyr::filter(is.na(',colSel,')) %>% dplyr::summarize(',aggColName,"=",'dplyr::n())')
                      },
                      'count blanks'={
                        paste0("data %>% dplyr::select(",colSel,") %>% dplyr::filter(trimws(",colSel,") == '') %>% dplyr::summarize(",aggColName,"=","dplyr::n()) ")
                      },
                      'string length'={
                        paste0("data %>% dplyr::select(",colSel,") %>% dplyr::mutate(",aggColName," = nchar(",colSel,")) %>% dplyr::select(",aggColName,")")
                      })
  print(cmdString)
  val <- eval(parse(text=cmdString))
  val <- val %>% dplyr::ungroup()
  return(list('',val,cmdString))
}


#-- Evaluates the comparison in QC checks on local CSV datasets
compare <- function(funcSel,val,colSel,operationSel,argValue,caseSensitive){
  #print('Comparing with the arguments')
  
  valcolsel <- colnames(val)
  
  if(funcSel[1]=='data type'){
    res <- (argValue==val)
    return(list(res,val))
  }
  
  if(operationSel=='%in%'){
    
    if(class(valcolsel) == "character"){
      # print('###########')
      
      if(caseSensitive == FALSE){
        val <- eval(parse(text=paste0("val %>% dplyr::select(",colSel,") %>% dplyr::mutate(",colSel,"=tolower(",colSel,"))")))
        argValue <- tolower(argValue)
      }
      
    }
    # print(list(val,argValue))
    res <- eval(parse(text=paste0("val %>% dplyr::filter(!",valcolsel," %in% ","argValue",") %>% dplyr::summarize(dplyr::n()) %>% dplyr::collect %>% unlist")))
    
    # res <- eval(parse(text=paste0("val %>% dplyr::filter(!",valcolsel," %in% ","argValue",") %>% dplyr::summarize(dplyr::n()) %>% dplyr::collect %>% unlist")))
    res <- ifelse(res==0,TRUE,FALSE)
    return(list(res,val))
  }
  else if(operationSel=='not in'){
    if(class(valcolsel) == "character"){
      
      if(caseSensitive == FALSE){
        val <- eval(parse(text=paste0("val %>% dplyr::select(",colSel,") %>% dplyr::mutate(",colSel,"=tolower(",colSel,"))")))
        argValue <- tolower(argValue)
      }
      
    }
    res <- eval(parse(text=paste0("val %>% dplyr::filter(",valcolsel," %in% ","argValue",") %>% dplyr::summarize(dplyr::n()) %>% dplyr::collect %>% unlist")))
    res <- ifelse(res==0,TRUE,FALSE)
    return(list(res,val))
  }
  else if(operationSel=='between'){
    str <- paste('val %>% dplyr::filter(!(',valcolsel,'>=',argValue[1],' &',valcolsel,'<=',argValue[2],
                 ')) %>% dplyr::collect(n=Inf) %>% unlist %>% length')
    res <- eval(parse(text=(str))) 
    res <- ifelse(res==0,TRUE,FALSE)
    return(list(res,val))
  }
  else
  { 
    if(class(valcolsel) == "character"){
      if(caseSensitive == FALSE){
        val <- eval(parse(text=paste0("val %>% dplyr::select(",colSel,") %>% dplyr::mutate(",colSel,"=tolower(",colSel,"))")))
        argValue <- tolower(argValue)
      }
      
    }
    lhs <- val[,valcolsel]
    argValue <- unlist(argValue)
    cString <- paste0('sum(!lhs ',operationSel,' argValue)')
    res <- eval(parse(text= cString))
    res <- ifelse(res==0,TRUE,FALSE)
    return(list(res,val))
  }
  
}


dataType <- function(data,col){
  val <- data[col,2,drop=F]
  colnames(val) <- c(paste0('data_type_',col))
  return(list('',val,''))}



evalStr <- function(str){ eval(parse(text=str)) }













##-------------------------------->>>> CONVERT COLUMN TO DATE ##------------------------>>>>


convertToDate <- function(table,dateFormatcolSel,dateFormat){
  
  #print(paste0('Converting ',dateFormatcolSel,' column to Date format'))
  table[,dateFormatcolSel] <- switch(dateFormat,
                                     'ymd'=lubridate::ymd(table[,dateFormatcolSel]),
                                     'ydm'=lubridate::ydm(table[,dateFormatcolSel]),
                                     'dym'=lubridate::dym(table[,dateFormatcolSel]),
                                     'dmy'=lubridate::dmy(table[,dateFormatcolSel]),
                                     'mdy'=lubridate::mdy(table[,dateFormatcolSel]),
                                     'myd'=lubridate::myd(table[,dateFormatcolSel]),
                                     'ymd hm'=lubridate::ymd_hm(table[,dateFormatcolSel]),
                                     'ydm hm'=lubridate::ydm_hm(table[,dateFormatcolSel]),
                                     'dym hm'=lubridate::dym_hm(table[,dateFormatcolSel]),
                                     'dmy hm'=lubridate::dmy_hm(table[,dateFormatcolSel]),
                                     'mdy hm'=lubridate::mdy_hm(table[,dateFormatcolSel]),
                                     'myd hm'=lubridate::myd_hm(table[,dateFormatcolSel]),
                                     'ymd hms'=lubridate::ymd_hms(table[,dateFormatcolSel]),
                                     'ydm hms'=lubridate::ydm_hms(table[,dateFormatcolSel]),
                                     'dym hms'=lubridate::dym_hms(table[,dateFormatcolSel]),
                                     'dmy hms'=lubridate::dmy_hms(table[,dateFormatcolSel]),
                                     'mdy hms'=lubridate::mdy_hms(table[,dateFormatcolSel]),
                                     'myd hms'=lubridate::myd_hms(table[,dateFormatcolSel])
  )
  table
  
}







##________________________________________________________________________________________________________________________##
##-------------------------------------------------->>QUICK CHECKS<<--------------------------------------------------##



##______TEMPLATE CHECKS_______##
templateLocalInfo <- function(tempFilePath){
  tryCatch({
    #print('Reading template file')
    
    if(is.null(tempFilePath)) return()
    tempFile <- read.csv(tempFilePath$datapath,stringsAsFactors = F,nrows = 10)
    
    return(list(data=tempFile))
  },error=function(e){list(data=NULL,error=e[1])})
}




templateCheckSubmit_func_main <- function(colData,templateType,templateFile,inDataHead,conList){
  colnamesPresent <- F
  colnamesAbsentList <- c()
  colnamesCorrectOrder <- F
  colnamesWrongOrderList <- c()
  colnamesCorrectCase <- F
  colnamesWrongCaseList <- c()
  colnamesExtra <- F
  colCorrectType <- F
  colWrongTypeList <- c()
  extraColumns <- NULL
  #colnamesActInTemp <- F
  colnamesTempInAct <- F
  colnamesAbsentInActList <- c()
  
  
  connObj <- conList$con
  tempTableDBName <- conList$db
  
  # if(length(inTables$tables)==0) return()
  # if(is.null(inTables$tables[[1]]$data)) return()
  #if(is.null(inDataReactive$mainData$table)) return()
  
  # if(templateType=='CSV'){
  #   # Compare with local CSV
  #   actCols <- colnames(inDataHead)
  #   # templateFile <- templateLocalInfo(rinput$templateFile)
  #   if(is.null(templateFile)) return()
  #   tempCols <- colnames(templateFile)
  # } else {
  #   # Compare with DB table
  #   actCols <- colnames(inDataHead)
  #   #if(is.null(templateDBInfo(tempTableDBName,connObj))) return()
  #   #templateColInfo <- templateDBInfo(templateFile,tempTableDBName,connObj)[[1]]
  #   #templateFile <- templateDBInfo(templateFile,tempTableDBName,connObj)[[2]]
  #   #tempCols <- templateColInfo$name
  #   tempCols <- colnames(templateFile)
  # }
  
  if(is.null(templateFile)) return()
  actCols <- colnames(inDataHead)
  tempCols <- colnames(templateFile)
  
  #Check if original table has all the columns in template Table and Report extra columns if present ----------------
  if(!(FALSE %in% (actCols %in% tempCols))){
    colnamesPresent <- T
    colnamesCorrectCase <- T
  } else {
    # Did they not match because of CASE?. Check for case --------------
    if(!(FALSE %in% (tolower(actCols) %in% tolower(tempCols)))){
      colnamesPresent <- T
      colnamesCorrectCase <- F
      colnamesWrongCaseList <- unique(c(actCols[!(actCols %in% tolower(actCols))]),tempCols[!(tempCols %in% tolower(tempCols))])
      actCols <- tolower(actCols)
      tempCols <- tolower(tempCols)
    }
    else {
      colnamesAbsentList <- actCols[!(actCols %in% tempCols)]
    }
  }
  #Check if template table has all the columns in actTable Table and Report extra columns if present ----------------
  if(!(FALSE %in% (tempCols %in% actCols))){
    colnamesTempInAct <- T
  }
  else {
    colnamesAbsentInActList <- tempCols[(!(tempCols %in% actCols))]
  }
  
  # Check for presence of extra columns ----------------
  if(colnamesPresent==T){
    extraColCheck <- actCols %in% tempCols
    if(FALSE %in% (extraColCheck)){
      colnamesExtra <- T
      extraColumns <- actCols[!extraColCheck]
      #return() # Will exit from the reactive function.
    }
  }
  
  if(colnamesPresent==T & colnamesTempInAct==T){
    #Check for correctness of order of columns -----------------
    colOrderDF <- merge(data.frame(actCols,order1=c(1:length(actCols))),data.frame(tempCols,order2=c(1:length(tempCols))),by.x='actCols',by.y='tempCols')
    colOrderDF$flag <- colOrderDF$order1 == colOrderDF$order2
    if(!(FALSE %in% colOrderDF$flag)){
      #Order does not match. Report
      colnamesCorrectOrder <- T
    } else {
      colnamesWrongOrderList <- colOrderDF[FALSE %in% colOrderDF$flag,'actCols']
    }
    
    # Data type checks with the template data --------------------
    tempColData <- data.frame(t(data.frame(lapply(templateFile,class),stringsAsFactors = F)))
    colnames(tempColData) <- 'datatype'
    tempColData$column <- row.names(tempColData)
    colnames(colData) <- c('column','datatype')
    colMerge <- merge(colData,tempColData,by='column')
    colMerge$flag <- colMerge$datatype.x == colMerge$datatype.y
    if(!(FALSE %in% colMerge$flag)){
      #Column types do not match
      colCorrectType <- T
      #return()
    } else {
      colWrongTypeList <- colMerge[FALSE %in% colMerge$flag,'column']
    }
  }
  
  Task <- c('All columns of Data present in Template?','All columns of Template present in Data?','Column cases match?','Column order match?','Column Data type match?')
  Result <- toupper(c(colnamesPresent,colnamesTempInAct,colnamesCorrectCase,colnamesCorrectOrder,colCorrectType))
  Fails <- list(colnamesAbsentList,colnamesAbsentInActList,colnamesWrongCaseList,'',colWrongTypeList)
  Fails <- unlist(lapply(Fails,function(vector)paste(vector,collapse=',')))
  
  checkTable <- data.frame(Task,Result,'Failed Columns'=Fails,stringsAsFactors = F)
  return(checkTable)
  
}


##______MISSING VALUE CHECKS_______##

nullCheckSubmit_func_main <- function(conList,cols){
  
  #conList <- list(con=connObj,table=inTable1)
  con <- conList$con
  if(is.null(conList$table)) return()
  
  #cols <- inDataReactive$cols

    cnDat <- data.frame(NA_Count = t(data.frame(lapply(conList$table,function(col){sum(is.na(col))}),stringsAsFactors = F)))
    cnDat$Column <- row.names(cnDat)
    cnDat <- cnDat[,c('Column','NA_Count')]
    cnDat <- cnDat[order(-cnDat$NA_Count),]
    

  return(cnDat)
  
}



##______DUPLICATION CHECK_______##


duplicationCheck <- function(levelCols,conList){
  tryCatch({
    
    if(is.null(conList$table)) return()
    
    
      
      failsTable <- eval(parse(text=paste0('conList$table %>% dplyr::group_by(',paste(levelCols,collapse=','),') %>% dplyr::summarize(Row_Count=dplyr::n()) %>% dplyr::filter(Row_Count > 1)')))
      if(nrow(failsTable)>0){
        res <- F
      } else {res <- T}
      return(list(res=res,failsTable=head(failsTable,n=100)))  # Limit to 100 cases
      
  
  },error=function(e){showNotification(e[1],type='error')})
}

##______MAPPING / HIERARCHY CHECKS_______##


hierarchyCheck <- function(cols,conList){
  
  
  if(is.null(conList$table)) return()
  if(length(cols)<2) return()
  resultOps <- list()
  

    gDat <- conList$table
    checkListHierarchy <- cols
    coln <- colnames(gDat)
    indexOfCols <- sapply(cols,function(x)which(colnames(gDat)==x))
    for(i in 1:(length(indexOfCols)-1)){
      col_a <- coln[indexOfCols[i+1]]
      col_b <- coln[indexOfCols[i]]
      p <- eval(parse(text=paste0('gDat %>% dplyr::rename(a=',col_a,', b=',col_b,') %>% dplyr::group_by(b,a) %>% dplyr::summarize(V1=dplyr::n())')))
      n <- p %>% dplyr::group_by(a) %>% dplyr::summarize(V1=length(b)) %>% dplyr::filter(V1>1)
      p <- merge(p,n,by='a')
      falseTableTop <- p[,c('b','a')]
      falseTableTop <-  falseTableTop[order(falseTableTop$a),]
      colnames(falseTableTop) <- c(col_b,col_a)
      resultOps[[i]] <- list(col_b,col_a,head(falseTableTop,n=100))
      
    }
    
    return(resultOps)
    

}





#--------------------UPLOAD RULE LIST ----------------___---------#


uploadedQueries_func <- function(path,queryData){
  #print('Uploading Rule List File')
  #print(path)
  tryCatch({
    uploadedDat <- read.csv(path,header=T,stringsAsFactors = F)
    if(is.null(uploadedDat$caseSensitive)){
      uploadedDat$caseSensitive <- lapply(1:length(uploadedDat$Column),function(x){TRUE})
    }
    if(is.null(uploadedDat$Remarks)){
      uploadedDat$Remarks <- lapply(1:length(uploadedDat$Column),function(x){""})
    }
    requiredCols <- c('Filters','GroupBy','Column','Function','Operation','Argument','Result','Value','Run','caseSensitive','Remarks')
    dim <- dim(uploadedDat)
    condition <- (dim[2]>=length(requiredCols)) & (dim[1]>0) & 
      !(FALSE %in% (requiredCols %in% colnames(uploadedDat)))
    if(!condition){
      #showNotification('Incorrect File!',type='error')
      return(list(data=NULL,error='Incorrect File!',message=''))
    }
    
    newColumns <- c('Comparison','TableName','JoinKeys','caseSensitive','Remarks')
    newColumnsDefault <- c('0','','',FALSE,'')
    
    for(i in 1:length(newColumns)){
      if(!newColumns[i] %in% colnames(uploadedDat))
        uploadedDat[newColumns[i]] <- newColumnsDefault[i]
    }
    
    
    # # Following columns were added later to the Rule List. Hence handling separately for backward compatibility
    # if(!'Comparison' %in% colnames(uploadedDat))
    #   uploadedDat$Comparison <- '0'
    # 
    # if(!'TableName' %in% colnames(uploadedDat))
    #   uploadedDat$TableName <- ''
    # print("Check Point utils 5")
    # if(!'JoinKeys' %in% colnames(uploadedDat)){
    #   uploadedDat$JoinKeys <- ''
    #   message <- "The uploaded Rule List was created using an older version of the Brick. Please note that some queries may fail due to incompatibility. Recreate the failed rules using this version. "
    #   
    # }
    
    
    # requiredCols <- c(requiredCols,'Comparison','TableName','JoinKeys')
    requiredCols <- c(requiredCols,newColumns)
    
    #print("Check Point utils 6")
    # If function is '' replace with 'none' and if '_' replace with 'column'
    uploadedDat <- uploadedDat[,requiredCols]
    uploadedDat <- data.frame(lapply(uploadedDat,FUN=function(x){gsub('"','',x)}),stringsAsFactors = F)
    uploadedDat <- uploadedDat %>% dplyr::mutate(Function=ifelse(Function %in% c('','_'),ifelse(Function == '','none','column'),Function),
                                          Operation=ifelse(Operation=='','none',Operation)) %>% dplyr::select_at(vars(one_of(requiredCols))) #select(Filters,GroupBy,Column,Function,Operation,Argument,Result,Value,Run,Comparison,TableName,JoinKeys)
    #print("Check Point utils 7")
    uploadedDat$Result <- ''
    uploadedDat$Value <- ''
    uploadedDat$Run <- '0'
    uploadedDat$Command <- ''
    
    queryData <- queryData %>% dplyr::filter(row.names(queryData) < 0)
    queryData <- rbind(queryData,uploadedDat)
    #print("Check Point utils 8")
    return(list(data=queryData,error='',message=message))
    
  },error=function(e){
    #showNotification(e[1],type='error')
    return(list(data=NULL,error=e[1],message=''))
  })
}
