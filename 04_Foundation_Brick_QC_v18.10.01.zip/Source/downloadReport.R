
downloadReport <- function(working_dir,reactData,rinput,dateTime){
  print(rinput$panelCompSubmit)
  require(rmarkdown)
rmarkdown::render('Source/Report.Rmd',
        params = list(working_dir = working_dir,reactData = reactData,input = rinput),
        switch(rinput$format,
               #PDF = pdf_document(),
               PrettyHTML = prettydoc::html_pretty(css = paste0("../Styles/pretty_styles.css")),
               HTML = html_document(css = paste0("../Styles/styles.css") ,toc= T,toc_float= T)

               #,MSWord = word_document(toc = T)
          ),output_dir = paste0("Downloads/") , output_file = paste("FoundationBrick_QC_Report_"
                                                                                           ,dateTime,
                                                        sep = '',
                                                        switch( rinput$format, PDF = '.pdf', HTML = '.html',
                                                                PrettyHTML = '_pretty.html', MSWord = ".doc"
                                                  ))
    )
  
}