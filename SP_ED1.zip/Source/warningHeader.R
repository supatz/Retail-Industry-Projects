####################################################################################################################################
# Steps to include warning UI
# 1. Copy the warningHeader.R to brick's Source folder
# 2. Delete the following section from main Rmd's css (styles_old.css, styles0.css)
#       h2{
#       position: relative;
#       left: -1%;
#       bottom: 3px;
#       border-bottom: 2px solid #444444;
#       font-size: 24px;
#       font-family: Arial, Helvetica, sans-serif;
#       font-weight: 600;
#       color:#444444;
#       }
# 
# 3. Add the following section in your main Rmd's css
#       h2{
#       display:none;
#       }
#       .warningDiv{
#         border-bottom: 2px solid #444444;
#         height:50px;
#         margin-bottom:20px;
#         
#       }
#       .warningButton{
#         background-color:white !important;
#         border:none;
#         padding:0px !important;
#       }
#       .warningButton:hover{
#         background-color:white !important;
#         border:none;
#         padding:0px !important;
#       }
#       .warningButton:focus{
#         background-color:white !important;
#         border:none;
#         padding:0px !important;
#       }
#       .warningButton:active{
#         background-color:white !important;
#         border:none;
#         padding:0px !important;
#       }
# 4. Add this section to your brick's Rmd
# 
#       ```{r warning Header,echo=FALSE, results='asis', warning=FALSE, message=FALSE}
#       shinyjs::useShinyjs(rmd = T)
#       reactive({
#         for(i in 1:nrow(packageList))
#         {
#           packageList_2 <- unlist(strsplit(as.character(packageList[packageList$heading==packageList$heading[i],"packages"]),","))
#           x <-unlist(lapply(packageList_2,function(x){x %in%  installed.packages()[,1]}))
#           if(FALSE %in% x){
#             shinyjs::show(paste0(packageList$heading_id[i],"warningDivInner"))
#             shinyjs::show(paste0(packageList$heading_id[i],"DownloadButton"))
#           }
#           
#         }
#       })
#       ```
# 5. Add these three lines after every section's header (delete section description and add it after these three lines in tags$p)
#       
#       heading <- "Quick Peek"
#       header<- warningHeader(heading,packageList,input,output,session)
#       eval(parse(text=header))
#       
# 6. Make a package list csv with heading, heading_id, packages as columns and save it in source folder
# 
# 7. Add these lines to utils file.
#         if(file.exists("Source/packageList.csv")){
#           packageList <<- read.csv("Source/packageList.csv")
#         } else if(file.exists("packageList.csv")){
#           packageList <<- read.csv("packageList.csv")
#         } else {
#           packageList <<- NULL
#         }
# 8. Add warningHeader file to th efile sourcing list in mainUtils


######################################################################################################################################


tryCatch({
warningHeader<-function(heading,packageList,input,output,session){
  
    
  heading_id <- paste(unlist(strsplit(heading," ")),collapse="_")
  packageList_1 <- packageList[packageList$heading==heading,"packages"]
  packageList_2 <- unlist(strsplit(as.character(packageList_1),","))
  
  
  warningMessage <- "Warning: This section has some missing packages"
  refreshTooltip <- "Click to refresh the missing package list"
  downloadTooltip <- "Download the list of missing packages"

######################################################  UI String  ###################################################################  
  uiWarning<-paste0(' 
shiny::div(
shiny::div(class="warningDiv",
                  shiny::tags$p(class="headin2","',heading,'"),
                  shinyjs::hidden(shiny::tags$div(style="display: inline-block;float: right;margin-top: 20px;",id="',heading_id,'warningDivInner",
                                                  shiny::tags$img(src="Logos/warning.png",title="Package missing",height="21",width="21"),
                                                  shiny::tags$p("',warningMessage,'",class="warningImage",style="display: inline-block;"),
                                                  shinyjs::hidden(shiny::actionButton(paste0("',heading_id,'","DownloadButton"),class="warningButton",title="',downloadTooltip,'",label=
                                                                 shiny::tags$img(src="Logos/downloadPackage.png",height="18",width="18" ))),
                                                  shinyjs::hidden(shiny::actionButton(paste0("',heading_id,'","RefreshButton"),class="warningButton",title="',refreshTooltip,'",label=
                                                                 shiny::tags$img(src="Logos/refresh.png",height="22",width="22" )))
                                                  
                  ))),

                  shinyjs::hidden(shiny::div(id=paste0("',heading_id,'","warningDownloadNote"),shiny::tags$p("The missing package list has been successfully downloaded at Downloads/ as \'',heading_id,'_Missing_Package_List.txt\'",style="color:green"))),

                  shinyjs::hidden(shiny::div(id=paste0("',heading_id,'","warningDownloadNote2"),shiny::tags$p("The missing package list has been successfully updated at Downloads/ as \'',heading_id,'_Missing_Package_List.txt\'",style="color:green")))
)

')
  
  
#########################################################################################################################################
  
  
  shiny::observeEvent(input[[paste0(heading_id,"RefreshButton")]],{
              
              x <-unlist( lapply(packageList_2,function(x){x %in%  installed.packages()[,1]}))
              if(FALSE %in% x){
                shinyjs::hide(paste0(heading_id,"warningDownloadNote"))
                shinyjs::show(paste0(heading_id,"warningDownloadNote2"))
                shinyjs::show(paste0(heading_id,"warningDivInner"))
              }
              else{
                shinyjs::hide(paste0(heading_id,"warningDivInner"))
                shinyjs::hide(paste0(heading_id,"warningDownloadNote"))
                shinyjs::hide(paste0(heading_id,"warningDownloadNote2"))
                unlink(paste0("Downloads/",heading_id,"_Missing_Package_List.txt"))
              }
             
              missPackages <-unlist( lapply(packageList_2,function(x){if(!(x %in%  installed.packages()[,1])) x}))
              
              
                tmp1 <- paste0(missPackages, collapse= "','")
                missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')")
                write(missPackages_2,paste0("Downloads/",heading_id,"_Missing_Package_List.txt"), sep="\n")
              
  })
  
  
  shiny::observeEvent(input[[paste0(heading_id,"DownloadButton")]],{
              shinyjs::hide(paste0(heading_id,"DownloadButton"))
              shinyjs::show(paste0(heading_id,"RefreshButton"))
              shinyjs::show(paste0(heading_id,"warningDownloadNote"))
    
              shinyjs::hide(paste0(heading_id,"DownloadButton"))
              missPackages <-unlist( lapply(packageList_2,function(x){if(!(x %in%  installed.packages()[,1])) x}))
               

               
              tmp1 <- paste0(missPackages, collapse= "','")
              missPackages_2 <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\n\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')")
              write(missPackages_2,paste0("Downloads/",heading_id,"_Missing_Package_List.txt"), sep="\n")
            }
  )
  return(uiWarning)
  
}
},error=function(e){
  print(e)
})