resaveCode <- 'resave <- function(..., list = character(), file) {
  previous  <- load(file)
var.names <- c(list, as.character(substitute(list(...)))[-1L])
for (var in var.names) assign(var, get(var, envir = parent.frame()))
save(list = unique(c(previous, var.names)), file = file)
}'

licenseCode <- 'license <- \"End User License Agreement
1. This is an agreement between Licensor and Licensee, who is being licensed to use the named Software.
2. Licensee acknowledges that this is only a limited nonexclusive license. Licensor is and remains the owner of all titles, rights, and interests in the Software.
3. This Software is subject to a limited warranty.
4. Mu Sigma expressly forbids reverse engineering or taking this code. You have been warned.\"'
# This is only an example EULA\"'

code1 <- 'options(keep.source = FALSE)
srcfile <- srcfilecopy(\"\", license)
srcref <- srcref(srcfile, c(1,1,9999,9999))'

code2 <- function(path){
  return(paste0('if(length(functionNames)>0)
                {
                save(file = paste0(\"', path,'\"), list = functionNames[1])
                }'))
}

code3 <- function(path)
{
  return(paste0('for(name in functionNames)
                {
                encCode<-paste0(\"attr(\",name,\", \\\"srcref\\\") <- srcref
                resave(file=paste0(\\\"', path,'\\\"),\",name,\")\")
                eval(parse(text = encCode))
                }'))
}

generateFunctionNamesPart2 <- function(fileName)
{
  s <- readLines(fileName)  
  tmp1 <- gregexpr("<-[ ]*function", s)
  f <- lapply(c(1:length(s)), function(x){
    if(tmp1[[x]][1]>0 && substr(s[[x]], 1, 1) !="#")
    {
      return(c(gsub(" ", "", substr(s[[x]], 1, tmp1[[x]][1]-1)), x))
    }else
      return(NA)
  })
  f <- f[!is.na(f)]
  previous <- FALSE
  if(length(f)>1)
  {
    tmp <- unlist(lapply(2:length(f), function(x){
      previous <<- isInnerFunction(s, x, f, previous)
      return(previous)
    }))
    tmp <- c(FALSE, tmp)
    f <- f[!tmp]
  }
  f <- unlist(lapply(f, function(x) x[1]))
  return(f)
}

isInnerFunction <- function(s, fIndex, fList, previous = FALSE)
{
  lookBack <- 1
  if(previous)
    lookBack <- fIndex - 1
  potentialParent <- as.numeric(fList[[fIndex - lookBack]][2])
  stringToSearch <- strsplit(s[as.numeric(fList[[fIndex]][2])], "<-")[[1]][1]
  # range <- paste0(s[potentialParent:(as.numeric(fList[[fIndex]][2])-1)], stringToSearch, collapse = "\n")
  range <- paste0(s[potentialParent:(as.numeric(fList[[fIndex]][2])-1)], collapse = "\n")
  open <- gregexpr("[{]", range)[[1]]
  close <- gregexpr("[}]", range)[[1]]
  if(length(open) != length(close))
    return(TRUE)
  stackParanthesis <- c()
  tmp <- unlist(lapply(sort(union(open, close)), function(x){
    c <- substr(range, x, x)
    if(c == '}')
    {
      if(stackParanthesis[length(stackParanthesis)] == '{')
        stackParanthesis <<- head(stackParanthesis, -1)
    }else
    {
      stackParanthesis <<- c(stackParanthesis, c)
    }
  }))
  if(length(stackParanthesis)==0)
    return(FALSE)
  return(TRUE)
}

################################################################################

getFilePath <- function(fileName)
{
  tmp <- strsplit(fileName, "/")[[1]]
  return(paste0(paste0(tmp[1:(length(tmp)-1)], collapse = "/"), "/"))
}

getFileName <- function(fileName)
{
  tmp <- strsplit(fileName, "/")[[1]]
  tmp <- tmp[length(tmp)]
  return(strsplit(tmp, "[.]R")[[1]][1])
}

doAllTheJazz <- function(fileName)
{
  path <- getFilePath(fileName)
  name <- getFileName(fileName)
  newName <- paste0(path, name, ".RData")
  x <- generateFunctionNamesPart2(fileName)
  tmp <- paste0("functionNames <- c(", paste0(paste0("\"", x, "\""), collapse = ","),")")
  code <- paste0("\n\n", resaveCode, "\n\n", licenseCode, "\n\n", code1, "\n\n", tmp, "\n\n", code2(newName), "\n\n", code3(newName))
  s <- readLines(fileName)
  newS <- append(s, code)
  writeLines(newS, fileName)
  source(fileName)
  unlink(fileName)
}


mainFunc <- function(filePath)
{
  deleteFiles <- c("buildPush.R", "testCases.R", "testCases.log", "UpdateBricksVersion.py", "devPackageTest.R")
  deleteFiles <- paste0(filePath, "/Source/", deleteFiles)
  tmp <- lapply(deleteFiles, function(x) unlink(x))
  files <- list.files(path = filePath, pattern = "*.R$", recursive = T) #, "Source/mainUtils.R")
  files <- setdiff(files,  "Source/encryptor.R")
  fileNames <- paste0(filePath, "/", files)
  tmp <- lapply(fileNames, function(x) doAllTheJazz(x))
  saveRDS(list(), paste0(filePath, "/Source/firstRun.RDS"))
}

tryCatch({
  brickPath <- getwd()
  mainFunc(brickPath)
  print("Encrypted successfully...")
}, error = function(e){
  print(paste0("Encryption failed: ", e$message)) 
})
