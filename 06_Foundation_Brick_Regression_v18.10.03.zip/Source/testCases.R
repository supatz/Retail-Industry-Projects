# Title : Regression Analysis
# Created : Apr 11, 2017 10:00 AM
# Author : Jewel James, Vivekanand Mishra, Shreyas Shekar, Ashutosh Singh
# This is the entire collection of test cases written for the regression brick

source("./RegressionUtils.R")
loadGlobals()
loadPackage <- function(pkgName){
  if (!do.call(require, list(pkgName))) {
    install.packages(pkgName, dependencies = T, repos = "http://cloud.r-project.org/")
    do.call(library, list(pkgName))
  }
}
lapply(packages, FUN = function(p){ loadPackage(p) })
library(caret)
library(compare)
library(testthat)
library(futile.logger)
set.seed(7)
options(warn = -1) 

# flog.threshold(INFO)

failedTestResults <- list()
allTestResults <- list()
allTestResultsMAPE = list()
allTestResultsGAM = list()
allTestResultsOLS = list()
allTestResultsStepwise = list()
allTestResultsRF = list()
allTestResultsQR = list()
allTestResultsPDT = list()
allTestResultsSVR = list()
allTestResultsPLS = list()
allTestResultsShrinkage = list()
allTestResultsLARS = list()
allTestResultsnn = list()
allTestResultsMARS  = list()
alltestResultsLASSO = list()
allTestResultsflexmix = list()
allTestResultsLASSO = list()
allTestResultsxgboost = list()
allTestResultsRobust <- list()
allTestResultsOlsfeature <- list()
allTestResultsPlsfeature <- list()
allTestResultsMARSfeature <- list()
alltestResLARSFeat <- list()
alltestResxgbFeat <- list()
alltestResRFFeat <- list()
alltestRespredFunc <- list()
alltestResAvgEnsem <- list()
alltestResStackEnsem <- list()

# Reading datasets

trainingDataDF <- read.csv("../JenkinsTestData/hotelTrainingData.csv")
testingDataDF <- read.csv("../JenkinsTestData/hotelTestingData.csv")

# Set seed
# set.seed(7)


testMAPE <- function(){
  failedTestsMAPE <- list()
  error <- tryCatch({
    test_that("Mape calculation is correct", {
      expect_equal(round(mape(y = c(1,3,5,3,6,2), yhat = c(1,2,3,1,4,5)),5),53.88889)
    })
  },error = function(e){return(e)})
  if(!isTRUE(error)){
    failedTestsMAPE[length(failedTestsMAPE)+1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Mape function ignores 0 values in y", {
      expect_equal(round(mape(y = c(1,3,5,0,6,2), yhat = c(1,2,3,1,4,5)),5),51.33333)
    })
  },error = function(e){return(e)})
  if(!isTRUE(error)){
    failedTestsMAPE[length(failedTestsMAPE)+1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Returns NA if NA in actual or predicted values", {
      expect_true(is.na(mape(y = c(1,2,5,3,6,NA), yhat =c(1,2,3,1,4,5))))
    })
  },error = function(e){return(e)})
  if(!isTRUE(error)){
    failedTestsMAPE[length(failedTestsMAPE)+1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Returns warning if actual and predicted have different length", {
      expect_warning(mape(y = c(1,3,5), yhat = c(1,2,3,1,4,5)), "Actual and predicted vectors of unequal length. MAPE incorrect.")
    })
  },error = function(e){return(e)})

  if(!isTRUE(error)){
    failedTestsMAPE[length(failedTestsMAPE)+1] <- as.character(error)
  }
  if(length(failedTestsMAPE) == 0){
    return("MAPE test passed")
  }
  else{
    return(failedTestsMAPE)
  }
}


testResultsMAPE <- testMAPE()

if(testResultsMAPE!= "MAPE test passed"){
  allTestResultsMAPE[1] = "Mape Test"
  allTestResultsMAPE[[2]] = testResultsMAPE
}

# If mape fails the length will be nonzero
if(length(allTestResultsMAPE) != 0){
  # Mape test has failed already
  allTestResults[[length(allTestResults)+1]] <- allTestResultsMAPE
}
# Models Testing -----------

returnIndex <<- function(data, match=NULL){
  if(is.null(match)){
    return(1:ncol(data))
  }
  else{
    return(which(!colnames(data) %in% match))
  }
}




# GAM tests

# trainingData <- read.csv("../JenkinsTestData/hotelTrainingData.csv")
# testingData <- read.csv("../JenkinsTestData/hotelTestingData.csv")



# Random Forest regression
print("RF test started")

trainingData <- trainingDataDF[,1:20]
testingData <- testingDataDF[,1:20]
testRFModel <- function(){
  failedTestsRFModel <- list()
  set.seed(7)
  
  RFModel1 <- RFModelFunction(trainingData, testingData, predictedVariable="Occupancy", 
                              RFNoOfTrees=100, RFmtry=2, RFMinNodeSize=1)
  RFModel2 <- RFModelFunction(trainingData, testingData, predictedVariable="Occupancy", 
                              RFNoOfTrees=1000, RFmtry=3, RFMinNodeSize=5)
  RFModel3 <- RFModelFunction(trainingData, testingData, predictedVariable="Occupancy", 
                              RFNoOfTrees=2000, RFmtry=4, RFMinNodeSize=10)
  
  testEachRF <- function(modelObject, modelType, trainingData, testingData, trainingPred, testingPred){
    error <- tryCatch({
      test_that("RFModel calculation is correct", {
        expect_equal(class(modelObject$model), c("ranger"))
      })
    },error = function(e){return(e)})
    
    if(!isTRUE(error)){
      failedTestsRFModel[length(failedTestsRFModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Number of rows in prediction equal to testing data in RF", {
        expect_equal(length(modelObject$testingPred), nrow(testingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsRFModel[length(failedTestsRFModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Training predictions are equal in RF", {
        expect_equal(all(round(modelObject$pred)== round(trainingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsRFModel[length(failedTestsRFModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Testing predictions are equal in RF", {
        expect_equal(all(round(modelObject$testingPred) == round(testingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsRFModel[length(failedTestsRFModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Number of rows in fitted equal to training data in RF", {
        expect_equal(length(modelObject$pred), nrow(trainingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsRFModel[length(failedTestsRFModel)+1] <- as.character(error)
    }
  }
  
  # 
  runRFModel1 <- testEachRF(modelObject=RFModel1, modelType="RFModel1 parameters", trainingData=trainingData, 
                            testingData=testingData, trainingPred=trainingDataDF$RFModel1Pred, testingPred=testingDataDF$RFModel1Pred)
  runRFModel2 <- testEachRF(modelObject=RFModel2, modelType="RFModel2 parameters", trainingData=trainingData, 
                            testingData=testingData, trainingPred=trainingDataDF$RFModel2Pred, testingPred=testingDataDF$RFModel2Pred)
  runRFModel3 <- testEachRF(modelObject=RFModel3, modelType="RFModel3 parameters", trainingData=trainingData, 
                            testingData=testingData, trainingPred=trainingDataDF$RFModel3Pred, testingPred=testingDataDF$RFModel3Pred)
  
  # 
  if(length(failedTestsRFModel) == 0){
    return("RFModel test passed")
  }
  else{
    return(failedTestsRFModel)
  }
}
testResultsRFModel <- testRFModel()
# if(testResultsRFModel!= "RFModel test passed"){
#   flog.info(testResultsRFModel)
#   stop(testResultsRFModel)
# }else{
#   print("RFModel test passed completely")
# }
if(testResultsRFModel!= "RFModel test passed"){
  allTestResultsRF[1] = "RF Test"
  allTestResultsRF[[2]] = testResultsRFModel
}
# If RF fails the length will be nonzero
if(length(allTestResultsRF) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsRF
}

print("RF test completed")


# OLS regression
# print("OLS test started")
# 
# trainingData <- trainingDataDF[,1:20]
# testingData <- testingDataDF[,1:20]
# testOLSModel <- function(){
#   failedTestsOLSModel <- list()
#   set.seed(7)
#   
#   OLSModel1 <- OLSFunction(trainingData, testingData, predictedVariable="Occupancy", 
#                            withIntercept= TRUE,'#000000','#000000')
#   OLSModel2 <- OLSFunction(trainingData, testingData, predictedVariable="Occupancy", 
#                            withIntercept= FALSE,'#000000','#000000')
#   
#   testEachOLS <- function(modelObject, modelType, trainingData, testingData, trainingPred, testingPred){
#     error <- tryCatch({
#       test_that("OLSModel calculation is correct", {
#         expect_equal(class(modelObject$model), c("lm"))
#       })
#     },error = function(e){return(e)})
#     
#     if(!isTRUE(error)){
#       failedTestsOLSModel[length(failedTestsOLSModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Number of rows in prediction equal to testing data in OLS", {
#         expect_equal(length(modelObject$modelPredictionsTesting), nrow(testingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsOLSModel[length(failedTestsOLSModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       # print(trainingPred[1:4])
#       # print(modelObject$pred[1:4])
#       test_that("Training predictions are equal in OLS", {
#         expect_equal(all(round(modelObject$modelPredictionsTraining)== round(trainingPred)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsOLSModel[length(failedTestsOLSModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Testing predictions are equal in OLS", {
#         expect_equal(all(round(modelObject$modelPredictionsTesting) == round(testingPred)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsOLSModel[length(failedTestsOLSModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Number of rows in fitted equal to training data in OLS", {
#         expect_equal(length(modelObject$modelPredictionsTraining), nrow(trainingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsOLSModel[length(failedTestsOLSModel)+1] <- as.character(error)
#     }
#   }
#   
#   # 
#   runOLSModel1 <- testEachOLS(modelObject=OLSModel1, modelType="OLSModel1 parameters", trainingData=trainingData, 
#                             testingData=testingData, trainingPred=trainingDataDF$OLSModel1Pred, testingPred=testingDataDF$OLSModel1Pred)
#   runOLSModel2 <- testEachOLS(modelObject=OLSModel2, modelType="OLSModel2 parameters", trainingData=trainingData, 
#                             testingData=testingData, trainingPred=trainingDataDF$OLSModel2Pred, testingPred=testingDataDF$OLSModel2Pred)
# 
#   # 
#   if(length(failedTestsOLSModel) == 0){
#     return("OLSModel test passed")
#   }
#   else{
#     return(failedTestsOLSModel)
#   }
# }
# testResultsOLSModel <- testOLSModel()
# 
# if(testResultsOLSModel!= "OLSModel test passed"){
#   allTestResultsOLS[1] = "OLS Test"
#   allTestResultsOLS[[2]] = testResultsOLSModel
# }
# # If OLS fails the length will be nonzero
# if(length(allTestResultsOLS) != 0){
#   allTestResults[[length(allTestResults)+1]] <- allTestResultsOLS
# }
# 
# print("OLS test completed")




# GAM regression
print("GAM test started")

# trainingData <- trainingDataDF[,1:20]
# testingData <- testingDataDF[,1:20]
# testGAMModel <- function(){
#   failedTestsGAMModel <- list()
#   set.seed(7)
# 
#   GAMModel1 <<- gamFunction(trainingData, predictedVariable="Occupancy", smoothListCol=c("AvgDailyRate","Compet_Occupancy"), gamWithIntercept=TRUE, testingData ,'#000000','#000000')
#   GAMModel2 <<- gamFunction(trainingData, predictedVariable="Occupancy", smoothListCol=c("AvgDailyRate","Compet_Occupancy"), gamWithIntercept=FALSE, testingData ,'#000000','#000000')
#   GAMModel3 <<- gamFunction(trainingData, predictedVariable="Occupancy", smoothListCol=c(), gamWithIntercept=TRUE, testingData ,'#000000','#000000')
#   GAMModel4 <<- gamFunction(trainingData, predictedVariable="Occupancy", smoothListCol=c(), gamWithIntercept=FALSE, testingData ,'#000000','#000000')
# 
#   testEachGAM <- function(modelObject, modelType, trainingData, testingData, trainingPred, testingPred){
#     error <- tryCatch({
#       test_that("GAMModel calculation is correct", {
#         expect_equal(class(modelObject$model), c("gam","glm","lm"))
#       })
#     },error = function(e){return(e)})
# 
#     if(!isTRUE(error) && !is.null(error)){
#       failedTestsGAMModel[length(failedTestsGAMModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Number of rows in prediction equal to testing data in GAM", {
#         expect_equal(length(modelObject$testingPredictions), nrow(testingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error) && !is.null(error)){
#       failedTestsGAMModel[length(failedTestsGAMModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       # print(trainingPred[1:4])
#       # print(modelObject$pred[1:4])
#       test_that("Training predictions are equal in GAM", {
#         expect_equal(all(round(modelObject$fitted)== round(trainingPred)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error) && !is.null(error)){
#       failedTestsGAMModel[length(failedTestsGAMModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Testing predictions are equal in GAM", {
#         expect_equal(all(round(modelObject$testingPredictions) == round(testingPred)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error) && !is.null(error)){
#       failedTestsGAMModel[length(failedTestsGAMModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Number of rows in fitted equal to training data in GAM", {
#         expect_equal(length(modelObject$fitted), nrow(trainingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error) && !is.null(error)){
#       failedTestsGAMModel[length(failedTestsGAMModel)+1] <- as.character(error)
#     }
#   }
# 
#   #
#   failedTestsGAMModel <- testEachGAM(modelObject=GAMModel1, modelType="GAMModel1 parameters", trainingData=trainingData,
#                               testingData=testingData, trainingPred=trainingDataDF$GAMModel1Pred, testingPred=testingDataDF$GAMModel1Pred)
#   failedTestsGAMModel <- testEachGAM(modelObject=GAMModel2, modelType="GAMModel2 parameters", trainingData=trainingData,
#                               testingData=testingData, trainingPred=trainingDataDF$GAMModel2Pred, testingPred=testingDataDF$GAMModel2Pred)
#   failedTestsGAMModel <- testEachGAM(modelObject=GAMModel3, modelType="GAMModel3 parameters", trainingData=trainingData,
#                               testingData=testingData, trainingPred=trainingDataDF$GAMModel3Pred, testingPred=testingDataDF$GAMModel3Pred)
#   failedTestsGAMModel <- testEachGAM(modelObject=GAMModel4, modelType="GAMModel4 parameters", trainingData=trainingData,
#                               testingData=testingData, trainingPred=trainingDataDF$GAMModel4Pred, testingPred=testingDataDF$GAMModel4Pred)
#   rm(GAMModel1, GAMModel2, GAMModel3, GAMModel4)
#   if(length(failedTestsGAMModel) == 0){
#     return("GAMModel test passed")
#   }
#   else{
#     return(failedTestsGAMModel)
#   }
# }
# testResultsGAMModel <- testGAMModel()
# 
# if(testResultsGAMModel!= "GAMModel test passed"){
#   allTestResultsGAM[1] = "GAM Test"
#   allTestResultsGAM[[2]] = testResultsGAMModel
# }
# # If GAM fails the length will be nonzero
# if(length(allTestResultsGAM) != 0){
#   allTestResults[[length(allTestResults)+1]] <- allTestResultsGAM
# }

print("GAM test completed")





# Stepwise regression
print("Stepwise test started")

# trainingData <- trainingDataDF[,1:20]
# testingData <- testingDataDF[,1:20]
# testStepwiseModel <- function(){
#   failedTestsStepwiseModel <- list()
#   set.seed(7)
#   
#   StepwiseModel1 <- StepwiseFunction(trainingData, testingData, predictedVariable="Occupancy", 
#                                      stepWithIntercept=TRUE, stepDirection="both",'#000000','#000000')
#   StepwiseModel2 <- StepwiseFunction(trainingData, testingData, predictedVariable="Occupancy", 
#                                      stepWithIntercept=FALSE, stepDirection="both",'#000000','#000000')
#   StepwiseModel3 <- StepwiseFunction(trainingData, testingData, predictedVariable="Occupancy", 
#                                      stepWithIntercept=TRUE, stepDirection="backward",'#000000','#000000')
#   StepwiseModel4 <- StepwiseFunction(trainingData, testingData, predictedVariable="Occupancy", 
#                                      stepWithIntercept=FALSE, stepDirection="backward",'#000000','#000000')
#   StepwiseModel5 <- StepwiseFunction(trainingData, testingData, predictedVariable="Occupancy", 
#                                      stepWithIntercept=TRUE, stepDirection="forward",'#000000','#000000')
#   StepwiseModel6 <- StepwiseFunction(trainingData, testingData, predictedVariable="Occupancy", 
#                                      stepWithIntercept=FALSE, stepDirection="forward",'#000000','#000000')
#   
#   testEachStepwise <- function(modelObject, modelType, trainingData, testingData, trainingPred, testingPred){
#     error <- tryCatch({
#       test_that("StepwiseModel calculation is correct", {
#         expect_equal(class(modelObject$model), c("lm"))
#       })
#     },error = function(e){return(e)})
#     
#     if(!isTRUE(error)){
#       failedTestsStepwiseModel[length(failedTestsStepwiseModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Number of rows in prediction equal to testing data in Stepwise", {
#         expect_equal(length(modelObject$testingPredictions), nrow(testingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsStepwiseModel[length(failedTestsStepwiseModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       # print(trainingPred[1:4])
#       # print(modelObject$pred[1:4])
#       test_that("Training predictions are equal in Stepwise", {
#         expect_equal(all(round(modelObject$fitted)== round(trainingPred)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsStepwiseModel[length(failedTestsStepwiseModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Testing predictions are equal in Stepwise", {
#         expect_equal(all(round(modelObject$testingPredictions) == round(testingPred)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsStepwiseModel[length(failedTestsStepwiseModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Number of rows in fitted equal to training data in Stepwise", {
#         expect_equal(length(modelObject$fitted), nrow(trainingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsStepwiseModel[length(failedTestsStepwiseModel)+1] <- as.character(error)
#     }
#   }
#   
#   # 
#   runStepwiseModel1 <- testEachStepwise(modelObject=StepwiseModel1, modelType="StepwiseModel1 parameters", trainingData=trainingData, 
#                               testingData=testingData, trainingPred=trainingDataDF$StepwiseModel1Pred, testingPred=testingDataDF$StepwiseModel1Pred)
#   runStepwiseModel2 <- testEachStepwise(modelObject=StepwiseModel2, modelType="StepwiseModel2 parameters", trainingData=trainingData, 
#                               testingData=testingData, trainingPred=trainingDataDF$StepwiseModel2Pred, testingPred=testingDataDF$StepwiseModel2Pred)
#   runStepwiseModel3 <- testEachStepwise(modelObject=StepwiseModel3, modelType="StepwiseModel3 parameters", trainingData=trainingData, 
#                                         testingData=testingData, trainingPred=trainingDataDF$StepwiseModel3Pred, testingPred=testingDataDF$StepwiseModel3Pred)
#   runStepwiseModel4 <- testEachStepwise(modelObject=StepwisetestDummyVarCreationResults != 'Dummy Variable creation test passed'
#     return(failedTestsStepwiseModel)
#   }
# }
# testResultsStepwiseModel <- testStepwiseModel()
# 
# if(testResultsStepwiseModel!= "StepwiseModel test passed"){
#   allTestResultsStepwise[1] = "Stepwise Test"
#   allTestResultsStepwise[[2]] = testResultsStepwiseModel
# }
# # If Stepwise fails the length will be nonzero
# if(length(allTestResultsStepwise) != 0){
#   allTestResults[[length(allTestResults)+1]] <- allTestResultsStepwise
# }

print("Stepwise test completed")




# Quantile regression model
print("QR test started")

trainingData <- trainingDataDF[,1:20]
testingData <- testingDataDF[,1:20]
# Removing linear dependent columns
trainingDataLinDepModel <- lm(formula = Occupancy ~ ., data = trainingData)
trainingDataLinDepCols <- names(trainingDataLinDepModel$coefficients[which(is.na(trainingDataLinDepModel$coefficients) == TRUE)])
trainingDataQR <- trainingData[,!colnames(trainingData) %in% trainingDataLinDepCols]

testingDataLinDepModel <- lm(formula = Occupancy ~ ., data = testingData)
testingDataLinDepCols <- names(testingDataLinDepModel$coefficients[which(is.na(testingDataLinDepModel$coefficients) == TRUE)])
testingDataQR <- testingData[,!colnames(testingData) %in% testingDataLinDepCols]

testQRModel <- function(){
  failedTestsQRModel <- list()
  
  QRModel <- QRModelFunction(trainingData=trainingDataQR, testingData=testingDataQR, predictedVariable="Occupancy",tau= 0.5,
                             QRFormula=(paste0("Occupancy ~ .")))
  
  testEachQR <- function(modelObject, modelType, trainingData, testingData, trainingPred, testingPred){
    error <- tryCatch({
      test_that("QRModel calculation is correct", {
        expect_equal(class(modelObject$model), c("rq"))
      })
    },error = function(e){return(e)})
    
    if(!isTRUE(error)){
      print(error)
      # failedTestsQRModel[length(failedTestsQRModel)+1] <- as.character(error)
      failedTestsQRModel[length(failedTestsQRModel)+1] <- as.character(NULL)
    }
    ##
    error <- tryCatch({
      test_that("Number of rows in prediction equal to testing data in QR", {
        expect_equal(length(modelObject$testingPred), nrow(testingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsQRModel[length(failedTestsQRModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Training predictions are equal in QR", {
        expect_equal(all(round(modelObject$pred)== round(trainingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsQRModel[length(failedTestsQRModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Testing predictions are equal in QR", {
        expect_equal(all(round(modelObject$testingPred) == round(testingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsQRModel[length(failedTestsQRModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Number of rows in fitted equal to training data in QR", {
        expect_equal(length(modelObject$pred), nrow(trainingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsQRModel[length(failedTestsQRModel)+1] <- as.character(error)
    }
  }
  
  # 
  runQRModel <- testEachQR(modelObject=QRModel, modelType="SVRModel", trainingData=trainingData, testingData=testingData,
                           trainingPred=trainingDataDF$QRModelPred, testingPred=testingDataDF$QRModelPred)
  
  # 
  if(length(failedTestsQRModel) == 0){
    return("QRModel test passed")
  }
  else{
    return(failedTestsQRModel)
  }
}
testResultsQRModel <- testQRModel()

if(testResultsQRModel!= "QRModel test passed"){
  allTestResultsQR[1] = "QR Test"
  allTestResultsQR[[2]] = testResultsQRModel
}
# If QR fails the length will be nonzero
if(length(allTestResultsQR) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsQR
}

print("QR test completed")




# Robust Tests

testRobust <- function(trainingData, testingData, predictedVariable, colsWithNA = NULL, depColumns = NULL){
  failedTestsRobust = list()
  
  # Building Models
  
  robustObject <- robustFunction(trainingData =  trainingData, testingData = testingData, predictedVariable = "Occupancy", robustwithIntercept = FALSE ,'#000000','#000000')
  robustObjectI <- robustFunction(trainingData =  trainingData, testingData = testingData, predictedVariable ="Occupancy", robustwithIntercept = TRUE,'#000000','#000000' )
  robustObjectSinglePredictor <- robustFunction(trainingData =  trainingData[, c(1,4)], testingData = testingData, predictedVariable = "Occupancy", robustwithIntercept = FALSE ,'#000000','#000000')
  robustObjectSinglePredictorI <- robustFunction(trainingData =  trainingData[, c(1,4)], testingData = testingData, predictedVariable = "Occupancy", robustwithIntercept = TRUE,'#000000','#000000' )
  
  testEachRobust <- function(modelObject, modelType, trainingData, testingData){
    
    failedTestsEachRobust <- list()
    failedTestsEachRobust[1]  <- modelType
    
    error <- tryCatch({
      test_that("Class of built model robust", {
        expect_equal(class(modelObject$model), c("rlm", "lm"))
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      # failedTestsEachRobust[length(failedTestsEachRobust)+1] <- as.character(error)
      failedTestsEachRobust[length(failedTestsEachRobust)+1] <- as.character(NULL)
    }
    error <- tryCatch({
      test_that("Number of rows in prediction equal to testing data robust", {
        expect_equal(length(modelObject$testingPredictions), nrow(testingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachRobust[length(failedTestsEachRobust)+1] <- as.character(error)
    }
    error <- tryCatch({
      test_that("Number of rows in fitted equal to training data robust", {
        expect_equal(length(modelObject$fitted), nrow(trainingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachRobust[length(failedTestsEachRobust)+1] <- as.character(error)
    }
    if(length(failedTestsEachRobust) == 1){
      return("Test passed")
    }
    else{
      
      failedTestsRobust[[length(failedTestsRobust) + 1]] <-  failedTestsEachRobust
      return(failedTestsRobust)
    }
  }
  
  failedTestsRobust <- testEachRobust(modelObject = robustObject, modelType = "Robust model without intercept", trainingData = trainingData, testingData = testingData)
  failedTestsRobust <- testEachRobust(modelObject = robustObjectI, modelType = "Robust model with intercept", trainingData = trainingData, testingData = testingData)
  failedTestsRobust <- testEachRobust(modelObject = robustObjectSinglePredictor, modelType = "Robust model with intercept and a single predictor", trainingData = trainingData, testingData = testingData)
  failedTestsRobust <- testEachRobust(modelObject = robustObjectSinglePredictorI, modelType = "Robust model without intercept and a single predictor", trainingData = trainingData, testingData = testingData)
}

testResultsRobust <- testRobust(trainingData =  trainingDataQR, testingData =  testingDataQR, predictedVariable = "Occupancy",  colsWithNA = c("building_type_NA"))

if(as.character(testResultsRobust)[1] != "Test passed"){
  allTestResultsRobust[1] = "Robust Test"
  allTestResultsRobust[[2]] = testResultsRobust
}

# If Stepwise fails the length will be nonzero

if(length(allTestResultsRobust) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsRobust
}





# Party Decision Trees regression model
print("PDT test started")

trainingData <- trainingDataDF[,1:20]
testingData <- testingDataDF[,1:20]
testPDTModel <- function(){
  failedTestsPDTModel <- list()
  
  PDTModel1 <- PDTModelFunction(trainingData, testingData, predictedVariable="Occupancy", 
                               PDTpValue=0.01, PDTminsplit=5, PDTminbucket=2)
  PDTModel2 <- PDTModelFunction(trainingData, testingData, predictedVariable="Occupancy", 
                               PDTpValue=0.5, PDTminsplit=20, PDTminbucket=7)
  PDTModel3 <- PDTModelFunction(trainingData, testingData, predictedVariable="Occupancy", 
                               PDTpValue=0.95, PDTminsplit=30, PDTminbucket=10)
  
  testEachPDT <- function(modelObject, modelType, trainingData, testingData, trainingPred, testingPred){
    error <- tryCatch({
      test_that("PDTModel calculation is correct", {
        expect_equal(class(modelObject$model)[1], c("constparty"))
      })
    },error = function(e){return(e)})
    
    if(!isTRUE(error)){
      failedTestsPDTModel[length(failedTestsPDTModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Number of rows in prediction equal to testing data in PDT", {
        expect_equal(length(modelObject$testingPred), nrow(testingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsPDTModel[length(failedTestsPDTModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Training predictions are equal in PDT", {
        expect_equal(all(round(modelObject$pred)== round(trainingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsPDTModel[length(failedTestsPDTModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Testing predictions are equal in PDT", {
        expect_equal(all(round(modelObject$testingPred) == round(testingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsPDTModel[length(failedTestsPDTModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Number of rows in fitted equal to training data in PDT", {
        expect_equal(length(modelObject$pred), nrow(trainingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsPDTModel[length(failedTestsPDTModel)+1] <- as.character(error)
    }
  }
  
  # 
  runPDTModel1 <- testEachPDT(modelObject=PDTModel1, modelType="PDTModel1", trainingData=trainingData, testingData=testingData,
                              trainingPred=trainingDataDF$PDTModel1Pred, testingPred=testingDataDF$PDTModel1Pred)
  runPDTModel2 <- testEachPDT(modelObject=PDTModel2, modelType="PDTModel2", trainingData=trainingData, testingData=testingData,
                              trainingPred=trainingDataDF$PDTModel2Pred, testingPred=testingDataDF$PDTModel2Pred)
  runPDTModel3 <- testEachPDT(modelObject=PDTModel3, modelType="PDTModel3", trainingData=trainingData, testingData=testingData,
                              trainingPred=trainingDataDF$PDTModel3Pred, testingPred=testingDataDF$PDTModel3Pred)
  
  # 
  if(length(failedTestsPDTModel) == 0){
    return("PDTModel test passed")
  }
  else{
    return(failedTestsPDTModel)
  }
}
testResultsPDTModel <- testPDTModel()

if(testResultsPDTModel!= "PDTModel test passed"){
  allTestResultsPDT[1] = "PDT Test"
  allTestResultsPDT[[2]] = testResultsPDTModel
}
# If PDT fails the length will be nonzero
if(length(allTestResultsPDT) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsPDT
}

print("PDT test completed")




# Support vector regression model
print("SVR test started")

trainingData <- trainingDataDF[,1:20]
testingData <- testingDataDF[,1:20]
testSVRModel <- function(){
  failedTestsSVRModel <- list()
  
  SVRModel <- SVRModelFunction(trainingData, testingData, predictedVariable="Occupancy")

  testEachSVR <- function(modelObject, modelType, trainingData, testingData, trainingPred, testingPred){
    error <- tryCatch({
      test_that("SVRModel calculation is correct", {
        expect_equal(class(modelObject$model)[1], c("svm.formula"))
      })
    },error = function(e){return(e)})
    
    if(!isTRUE(error)){
      failedTestsSVRModel[length(failedTestsSVRModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Number of rows in prediction equal to testing data in SVR", {
        expect_equal(length(modelObject$testingPred), nrow(testingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsSVRModel[length(failedTestsSVRModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Training predictions are equal in SVR", {
        expect_equal(all(round(modelObject$pred)== round(trainingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsSVRModel[length(failedTestsSVRModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Testing predictions are equal in SVR", {
        expect_equal(all(round(modelObject$testingPred) == round(testingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsSVRModel[length(failedTestsSVRModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Number of rows in fitted equal to training data in SVR", {
        expect_equal(length(modelObject$pred), nrow(trainingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsSVRModel[length(failedTestsSVRModel)+1] <- as.character(error)
    }
  }
  
  # 
  runSVRModel <- testEachSVR(modelObject=SVRModel, modelType="SVRModel", trainingData=trainingData, testingData=testingData,
                             trainingPred=trainingDataDF$SVRModelPred, testingPred=testingDataDF$SVRModelPred)
  
  # 
  if(length(failedTestsSVRModel) == 0){
    return("SVRModel test passed")
  }
  else{
    return(failedTestsSVRModel)
  }
}
testResultsSVRModel <- testSVRModel()
# if(testResultsRFModel!= "RFModel test passed"){
#   flog.info(testResultsRFModel)
#   stop(testResultsRFModel)
# }else{
#   print("RFModel test passed completely")
# }
if(testResultsSVRModel!= "SVRModel test passed"){
  allTestResultsSVR[1] = "SVR Test"
  allTestResultsSVR[[2]] = testResultsSVRModel
}
# If SVR fails the length will be nonzero
if(length(allTestResultsSVR) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsSVR
}

print("SVR test completed")



# PLS regression
print("PLS test started")

trainingData <- trainingDataDF[,1:20]
testingData <- testingDataDF[,1:20]
testPLSModel <- function(){
  failedTestsPLSModel <- list()
  
  PLSModel <- PLSModelFunction(trainingData, testingData, predictedVariable="Occupancy")
  
  testEachPLS <- function(modelObject, modelType, trainingData, testingData, trainingPred, testingPred){
    error <- tryCatch({
      test_that("PLSModel calculation is correct", {
        expect_equal(class(modelObject$model), c("mvr"))
      })
    },error = function(e){return(e)})
    
    if(!isTRUE(error)){
      failedTestsPLSModel[length(failedTestsPLSModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Number of rows in prediction equal to testing data in PLS", {
        expect_equal(length(modelObject$testingPred), nrow(testingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsPLSModel[length(failedTestsPLSModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Training predictions are equal in PLS", {
        expect_equal(all(round(modelObject$pred)== round(trainingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsPLSModel[length(failedTestsPLSModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Testing predictions are equal in PLS", {
        expect_equal(all(round(modelObject$testingPred) == round(testingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsPLSModel[length(failedTestsPLSModel)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Number of rows in fitted equal to training data in PLS", {
        expect_equal(length(modelObject$pred), nrow(trainingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)){
      failedTestsPLSModel[length(failedTestsPLSModel)+1] <- as.character(error)
    }
  }
  
  # 
  runPLSModel <- testEachPLS(modelObject=PLSModel, modelType="PLSModel", trainingData=trainingData, testingData=testingData,
                             trainingPred=trainingDataDF$PLSModelPred, testingPred=testingDataDF$PLSModelPred)
  
  # 
  if(length(failedTestsPLSModel) == 0){
    return("PLSModel test passed")
  }
  else{
    return(failedTestsPLSModel)
  }
}
testResultsPLSModel <- testPLSModel()
# if(testResultsRFModel!= "RFModel test passed"){
#   flog.info(testResultsRFModel)
#   stop(testResultsRFModel)
# }else{
#   print("RFModel test passed completely")
# }
if(testResultsPLSModel!= "PLSModel test passed"){
  allTestResultsPLS[1] = "PLS Test"
  allTestResultsPLS[[2]] = testResultsPLSModel
}
# If PLS fails the length will be nonzero
if(length(allTestResultsPLS) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsPLS
}

print("PLS test completed")



# xgboost regression

print("xgboost test started")

# trainingData <- trainingDataDF[,1:20]
# testingData <- testingDataDF[,1:20]
# testxgboostModel <- function(){
#   failedTestsxgboostModel <- list()
#   
#   xgboostModel1 <- xgboostModelFunction(trainingData, testingData, predictedVariable="Occupancy", xgboostMaxDepth=2, xgboostLeraningRate=0.01, 
#                                        xgboostNoOfIterations=1)
#   xgboostModel2 <- xgboostModelFunction(trainingData, testingData, predictedVariable="Occupancy", xgboostMaxDepth=10, xgboostLeraningRate=0.5, 
#                                        xgboostNoOfIterations=10)
#   xgboostModel3 <- xgboostModelFunction(trainingData, testingData, predictedVariable="Occupancy", xgboostMaxDepth=20, xgboostLeraningRate=1, 
#                                        xgboostNoOfIterations=20)
#   
#   testEachxgboost <- function(modelObject, modelType, trainingData, testingData, trainingPred, testingPred){
#     error <- tryCatch({
#       test_that(" Class of built model xgboost", {
#         expect_equal(class(modelObject$model), c("xgb.Booster")) 
#       })
#     },error = function(e){return(e)})
#     
#     if(!isTRUE(error)){
#       failedTestsxgboostModel[length(failedTestsxgboostModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Number of rows in prediction equal to testing data in xgboost", {
#         expect_equal(length(modelObject$testingPred), nrow(testingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsxgboostModel[length(failedTestsxgboostModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Training predictions are equal in xgboost", {
#         expect_equal(all(round(modelObject$pred)== round(trainingPred)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsxgboostModel[length(failedTestsxgboostModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Testing predictions are equal in xgboost", {
#         expect_equal(all(round(modelObject$testingPred) == round(testingPred)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsxgboostModel[length(failedTestsxgboostModel)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Number of rows in fitted equal to training data in xgboost", {
#         expect_equal(length(modelObject$pred), nrow(trainingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsxgboostModel[length(failedTestsxgboostModel)+1] <- as.character(error)
#     }
#   }
#   
#   # 
#   runxgboostModel1 <- testEachxgboost(modelObject=xgboostModel1, modelType="xgboostModel1", trainingData=trainingData, testingData=testingData,
#                                       trainingPred=trainingDataDF$xgboostModel1Pred, testingPred=testingDataDF$xgboostModel1Pred)
#   runxgboostModel2 <- testEachxgboost(modelObject=xgboostModel2, modelType="xgboostModel2", trainingData=trainingData, testingData=testingData,
#                                       trainingPred=trainingDataDF$xgboostModel2Pred, testingPred=testingDataDF$xgboostModel2Pred)
#   runxgboostModel3 <- testEachxgboost(modelObject=xgboostModel3, modelType="xgboostModel3", trainingData=trainingData, testingData=testingData,
#                                       trainingPred=trainingDataDF$xgboostModel3Pred, testingPred=testingDataDF$xgboostModel3Pred)
# 
#   # 
#   if(length(failedTestsxgboostModel) == 0){
#     return("xgboostModel test passed")
#   }
#   else{
#     return(failedTestsxgboostModel)
#   }
# }
# testResultsxgboostModel <- testxgboostModel()
# 
# if(testResultsxgboostModel!= "xgboostModel test passed"){
#   allTestResultsxgboost[1] = "xgboost Test"
#   allTestResultsxgboost[[2]] = testResultsxgboostModel
# }
# # If xgboost fails the length will be nonzero
# if(length(allTestResultsxgboost) != 0){
#   allTestResults[[length(allTestResults)+1]] <- allTestResultsxgboost
# }

print("xgboost test completed")




# shrinkage regression tests
testShrinkage <- function(trainingData, testingData, predictedVariable){
  failedTestsShrinkage <- list()
  
  shrinkageObject <-
    shrinkageModelFunction(
      trainingData =  trainingDataQR,
      testingData = testingDataQR,
      predictedVariable = "Occupancy"
    )
  shrinkageObjectSinglePredictor <-
    shrinkageModelFunction(
      trainingData =  trainingDataQR[, c(1,4)],
      testingData = testingDataQR[, c(1,4)],
      predictedVariable = "Occupancy"
    )
  
  testShrinkageModel <- function(modelObject, modelType, trainingData, testingData, trainingPred, testingPred){
    
    failedTestsEachShrinkage <- list()
    failedTestsEachShrinkage[1]  <- modelType
    error <- tryCatch({
      test_that("Class of built model shrinkage", {
        #print(modelObject$model)
        expect_equal(class(modelObject$model), c("shrink")) 
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      
      failedTestsEachShrinkage[length(failedTestsEachShrinkage)+1] <- as.character(error)
    }
    error <- tryCatch({
      test_that("Number of rows in prediction equal to testing data for shrinkage", {
        expect_equal(length(modelObject$testingPred), nrow(testingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      # print("debug1")
      failedTestsEachShrinkage[length(failedTestsEachShrinkage)+1] <- as.character(error)
    }
    
    error <- tryCatch({
      test_that("Training predictions are equal for shrinkage", {
        expect_equal(all(round(modelObject$pred)== round(trainingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      # print("debug2")
      failedTestsEachShrinkage[length(failedTestsEachShrinkage)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Testing predictions are equal for shrinkage", {
        expect_equal(all(round(modelObject$testingPred) == round(testingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error)&& !is.null(error)){
      print("debug3")
      failedTestsEachShrinkage[length(failedTestsEachShrinkage)+1] <- as.character(error)
    }
    
    error <- tryCatch({
      test_that("Number of rows in fitted equal to training data for shrinkage", {
        expect_equal(length(modelObject$pred), nrow(trainingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      # print("debug4")
      failedTestsEachShrinkage[length(failedTestsEachShrinkage)+1] <- as.character(error)
    }
    if(length(failedTestsEachShrinkage) == 1){
      return("Test passed")
    }
    else{
      
      failedTestsShrinkage[length(failedTestsShrinkage) + 1] <-  failedTestsEachShrinkage
      return(failedTestsShrinkage)
    }
  }
  
  failedTestsShrinkage <-
    testShrinkageModel(
      modelObject = shrinkageObject,
      modelType = "Shrinkage linear model",
      trainingData = trainingData,
      testingData = testingData,
      testingPred = testingDataDF$shrinkageObjectPred,
      trainingPred = trainingDataDF$shrinkageObjectPred
    )
  failedTestsShrinkage <-
    testShrinkageModel(
      modelObject = shrinkageObjectSinglePredictor,
      modelType = "Shrinkage model with single predictor",
      trainingData = trainingData[, c(1,4)],
      testingData = testingData[, c(1,4)],
      testingPred = testingDataDF$shrinkageObjectSinglePredictorPred,
      trainingPred =trainingDataDF$shrinkageObjectSinglePredictorPred
    )
  
}
testResultsShrinkage <- testShrinkage(trainingData =  trainingData, testingData =  testingData, predictedVariable = "Occupancy")
if(as.character(testResultsShrinkage)[1] != "Test passed"){
  allTestResultsShrinkage[1] = "Shrinkage Test"
  allTestResultsShrinkage[[2]] = testResultsShrinkage
}
if(as.character(testResultsShrinkage)[1] != "Test passed"){
  allTestResultsShrinkage[1] = "Shrinkage Test"
  allTestResultsShrinkage[[2]] = testResultsShrinkage
}
# If OLS fails the length will be nonzero
if(length(allTestResultsShrinkage) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsShrinkage
}

# LARS!!!!!!!!!!!!!!!!!
# testLARS <- function(trainingData, testingData, predictedVariable){
#   failedTestsLARS = list()
#   
#   # Building Models
#   LARSObject <-
#     larsModelFunction(
#       trainingData =  trainingData,
#       testingData = testingData,
#       predictedVariable = "Occupancy",
#       larsWithIntercept = FALSE
#     )
#   LARSObjectI <-
#     larsModelFunction(
#       trainingData =  trainingData,
#       testingData = testingData,
#       predictedVariable = "Occupancy",
#       larsWithIntercept = TRUE
#     )
#   LARSObjectSinglePredictor <-
#     larsModelFunction(
#       trainingData =  trainingData[, c(1,4)],
#       testingData = testingData[, c(1,4)],
#       predictedVariable = "Occupancy",
#       larsWithIntercept = FALSE
#     )
#   LARSObjectSinglePredictorI <-
#     larsModelFunction(
#       trainingData =  trainingData[, c(1,4)],
#       testingData = testingData[, c(1,4)],
#       predictedVariable = "Occupancy",
#       larsWithIntercept = TRUE
#     )
#   
#   testEachLARS <- function(modelObject, modelType, trainingData, testingData, testingPred,trainingPred){
#     
#     
#     failedTestsEachLARS <- list()
#     failedTestsEachLARS[1]  <- modelType
#     error <- tryCatch({
#       test_that("Class of built model LARS", {
#         expect_equal(class(modelObject$model), c("lars" ))
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsEachLARS[length(failedTestsEachLARS)+1] <- as.character(error)
#     }
#     error <- tryCatch({
#       test_that("Number of rows in prediction equal to testing data for LARS", {
#         expect_equal(length(modelObject$testingPred), nrow(testingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsEachLARS[length(failedTestsEachLARS)+1] <- as.character(error)
#     }
#     
#     error <- tryCatch({
#       test_that("Training predictions are equal for LARS", {
#         expect_equal(all(round(modelObject$pred)== round(trainingPred)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsEachLARS[length(failedTestsEachLARS)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Testing predictions are equal for LARS", {
#         expect_equal(all(round(modelObject$testingPred) == round(testingPred)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsEachLARS[length(failedTestsEachLARS)+1] <- as.character(error)
#     }
#     
#     error <- tryCatch({
#       test_that("Number of rows in fitted equal to training data for LARS", {
#         expect_equal(length(modelObject$pred), nrow(trainingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error)){
#       failedTestsEachLARS[length(failedTestsEachLARS)+1] <- as.character(error)
#     }
#     if(length(failedTestsEachLARS) == 1){
#       return("Test passed")
#     }
#     else{
#       
#       failedTestsLARS[length(failedTestsLARS) + 1] <-  failedTestsEachLARS
#       return(failedTestsLARS)
#     }
#   }
#   
#   failedTestsLARS <-
#     testEachLARS(
#       modelObject = LARSObject,
#       modelType = "LARS model without intercept",
#       trainingData = trainingData,
#       testingData = testingData,
#       testingPred = testingDataDF$LARSObjectPred,
#       trainingPred = trainingDataDF$LARSObjectPred
#     )
#   failedTestsLARS <-
#     testEachLARS(
#       modelObject = LARSObjectI,
#       modelType = "LARS model with intercept",
#       trainingData = trainingData,
#       testingData = testingData,
#       testingPred = testingDataDF$LARSObjectIPred,
#       trainingPred = trainingDataDF$LARSObjectIPred
#     )
#   failedTestsLARS <-
#     testEachLARS(
#       modelObject = LARSObjectSinglePredictorI,
#       modelType = "LARS model with intercept and a single predictor",
#       trainingData = trainingData[, c(1,4)],
#       testingData = testingData[, c(1,4)],
#       testingPred = testingDataDF$LARSObjectISinglePredictorIPred,
#       trainingPred = trainingDataDF$LARSObjectISinglePredictorIPred
#     )
#   failedTestsLARS <-
#     testEachLARS(
#       modelObject = LARSObjectSinglePredictor,
#       modelType = "LARS model without intercept and a single predictor",
#       trainingData = trainingData[, c(1,4)],
#       testingData = testingData[, c(1,4)],
#       testingPred = testingDataDF$LARSObjectSinglePredictorPred,
#       trainingPred = trainingDataDF$LARSObjectSinglePredictorPred
#     )
# }
# testResultsLARS <- testLARS(trainingData =  trainingData, testingData =  testingData, predictedVariable = "Occupancy")
# if(as.character(testResultsLARS)[1] != "Test passed"){
#   allTestResultsLARS[1] = "LARS Test"
#   allTestResultsLARS[[2]] = testResultsLARS
# }
# # If OLS fails the length will be nonzero
# if(length(allTestResultsLARS) != 0){
#   allTestResults[[length(allTestResults)+1]] <- allTestResultsLARS
# }
# LASSO
testLASSO <- function(trainingData, testingData, predictedVariable){
  failedTestsLASSO = list()
  
  # Building Models
  LASSOObject <-
    AdaptiveLASSOModelFunction(
      trainingData =  trainingData,
      testingData = testingData,
      predictedVariable = "Occupancy",
      larsWithIntercept = FALSE,
      alpha=1
    )
  LASSOObjectI <-
    AdaptiveLASSOModelFunction(
      trainingData =  trainingData,
      testingData = testingData,
      predictedVariable = "Occupancy",
      larsWithIntercept = TRUE,
      alpha=1
    )
  # LASSOObjectSinglePredictor <-
  #   AdaptiveLASSOModelFunction(
  #     trainingData =  trainingData,
  #     testingData = testingData,
  #     predictedVariable = "Occupancy",
  #     larsWithIntercept = FALSE
  #   )
  # LASSOObjectSinglePredictorI <-
  #   AdaptiveLASSOModelFunction(
  #     trainingData =  trainingData,
  #     testingData = testingData,
  #     predictedVariable = "Occupancy",
  #     larsWithIntercept = TRUE
  #   )
  # 
  testEachLASSO <- function(modelObject, modelType, trainingData, testingData,testingPred, trainingPred){

    failedTestsEachLASSO <- list()
    failedTestsEachLASSO[1]  <- modelType
    error <- tryCatch({
      print(class(modelObject$model))
      test_that("Class of built model LASSO", {
        expect_equal(class(modelObject$model), c("elnet","glmnet"))
      })
    },error = function(e){return(e)})
    print(error)
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachLASSO[length(failedTestsEachLASSO)+1] <- as.character(error)
    }
    error <- tryCatch({
      print(length(modelObject$testingPred))
      print(nrow(testingData))
      test_that("Number of rows in prediction equal to testing data for LASSO", {
        expect_equal(length(modelObject$testingPred), nrow(testingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachLASSO[length(failedTestsEachLASSO)+1] <- as.character(error)
    }
    print(error)
    error <- tryCatch({
      test_that("Training predictions are equal for LASSO", {
        expect_equal(all(round(modelObject$pred)== round(trainingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachLASSO[length(failedTestsEachLASSO)+1] <- as.character(error)
    }
    print(error)
    ##
    error <- tryCatch({
      test_that("Testing predictions are equal for LASSO", {
        expect_equal(all(round(modelObject$testingPred) == round(testingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachLASSO[length(failedTestsEachLASSO)+1] <- as.character(error)
    }
    print(error)
    error <- tryCatch({
      test_that("Number of rows in fitted equal to training data for LASSO", {
        expect_equal(length(modelObject$pred), nrow(trainingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachLASSO[length(failedTestsEachLASSO)+1] <- as.character(error)
    }
    print(error)
    if(length(failedTestsEachLASSO) == 1){
      return("Test passed")
    }
    else{
      
      failedTestsLASSO[length(failedTestsLASSO) + 1] <-  failedTestsEachLASSO
      return(failedTestsLASSO)
    }
  }
  
  failedTestsLASSO <-
    testEachLASSO(
      modelObject = LASSOObject,
      modelType = "LASSO model without intercept",
      trainingData = trainingData,
      testingData = testingData,
      testingPred = testingDataDF$LASSOObjectPred,
      trainingPred = trainingDataDF$LASSOObjectPred
    )
  failedTestsLASSO <-
    testEachLASSO(
      modelObject = LASSOObjectI,
      modelType = "LASSO model with intercept",
      trainingData = trainingData,
      testingData = testingData,
      testingPred = testingDataDF$LASSOObjectIPred,
      trainingPred = trainingDataDF$LASSOObjectIPred
    )
  # failedTestsLASSO <- testEachLASSO(modelObject = LASSOObjectSinglePredictorI, modelType = "LASSO model with intercept and a single predictor", trainingData = trainingData, testingData = testingData)
  # failedTestsLASSO <- testEachLASSO(modelObject = LASSOObjectSinglePredictor, modelType = "LASSO model without intercept and a single predictor", trainingData = trainingData, testingData = testingData)
}
testResultsLASSO <- testLASSO(trainingData =  trainingData, testingData =  testingData, predictedVariable = "Occupancy")
# print(testResultsLASSO)
if(as.character(testResultsLASSO)[1] != "Test passed"){
  allTestResultsLASSO[1] = "LASSO Test"
  allTestResultsLASSO[[2]] = testResultsLASSO
}
# If OLS fails the length will be nonzero
if(length(allTestResultsLASSO) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsLASSO
}
# MARS!!!!!!!!!!!!!!!!!
testMARS <- function(trainingData, testingData, predictedVariable){
  failedTestsMARS = list()
  
  # Building Models
  MARSObject <-
    marsModelFunction(
      trainingData =  trainingData,
      testingData = testingData,
      predictedVariable = "Occupancy"
      
    )
  
  MARSObjectSinglePredictor <-
    marsModelFunction(
      trainingData =  trainingData[, c(1,4)],
      testingData = testingData[, c(1,4)],
      predictedVariable = "Occupancy"
      
    )
  
  
  testEachMARS <- function(modelObject, modelType, trainingData, testingData, testingPred, trainingPred){
    
    
    failedTestsEachMARS <- list()
    failedTestsEachMARS[1]  <- modelType
    error <- tryCatch({
      test_that("Class of built model MARS", {
        expect_equal(class(modelObject$model), c("earth" ))
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachMARS[length(failedTestsEachMARS)+1] <- as.character(error)
    }
    error <- tryCatch({
      test_that("Number of rows in prediction equal to testing data for MARS", {
        expect_equal(length(modelObject$testingPred), nrow(testingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachMARS[length(failedTestsEachMARS)+1] <- as.character(error)
    }
    
    error <- tryCatch({
      test_that("Training predictions are equal for MARS", {
        expect_equal(all(round(modelObject$pred)== round(trainingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachMARS[length(failedTestsEachMARS)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Testing predictions are equal for MARS", {
        expect_equal(all(round(modelObject$testingPred) == round(testingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachMARS[length(failedTestsEachMARS)+1] <- as.character(error)
    }
    
    error <- tryCatch({
      test_that("Number of rows in fitted equal to training data for MARS", {
        expect_equal(length(modelObject$pred), nrow(trainingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachMARS[length(failedTestsEachMARS)+1] <- as.character(error)
    }
    if(length(failedTestsEachMARS) == 1){
      return("Test passed")
    }
    else{
      
      failedTestsMARS[length(failedTestsMARS) + 1] <-  failedTestsEachMARS
      return(failedTestsMARS)
    }
  }
  
  failedTestsMARS <-
    testEachMARS(
      modelObject = MARSObject,
      modelType = "MARS model ",
      trainingData = trainingData,
      testingData = testingData,
      testingPred = testingDataDF$MARSObjectPred,
      trainingPred = trainingDataDF$MARSObjectPred
    )
  failedTestsMARS <-
    testEachMARS(
      modelObject = MARSObjectSinglePredictor,
      modelType = "MARS model with single predictor",
      trainingData = trainingData[, c(1,4)],
      testingData = testingData[, c(1,4)],
      testingPred = testingDataDF$MARSObjectSinglePredictorPred,
      trainingPred = trainingDataDF$MARSObjectSinglePredictorPred
    )
}
testResultsMARS <- testMARS(trainingData =  trainingData, testingData =  testingData, predictedVariable = "Occupancy")
# print(testResultsMARS)
if(as.character(testResultsMARS)[1] != "Test passed"){
  allTestResultsMARS[1] = "MARS Test"
  allTestResultsMARS[[2]] = testResultsMARS
}
# If OLS fails the length will be nonzero
if(length(allTestResultsMARS) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsMARS
}
# # flexmix!!!!!!!!!!!!!!!!!
# testflexmix <- function(trainingData, testingData, predictedVariable){
#   failedTestsflexmix = list()
# 
#   # Building Models
#   flexmixObject <-
#     flexmixModelFunction(
#       trainingData =  trainingDataQR,
#       testingData = testingDataQR,
#       predictedVariable = "Occupancy"
# 
#     )
# 
#   # flexmixObjectSinglePredictor <-
#   #   flexmixModelFunction(
#   #     trainingData =  trainingDataQR,
#   #     testingData = testingDataQR,
#   #     predictedVariable = "Occupancy"
#   # 
#   #   )
# 
# 
#   testEachflexmix <- function(modelObject, modelType, trainingData, testingData, testingPred, trainingPred){
# 
# 
#     failedTestsEachflexmix <- list()
#     failedTestsEachflexmix[1]  <- modelType
#     error <- tryCatch({
#       test_that("Class of built model flexmix", {
#         expect_equal(class(modelObject$model)[1], c("flexmix" ))
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error) && !is.null(error)){
#       failedTestsEachflexmix[length(failedTestsEachflexmix)+1] <- as.character(error)
#     }
#     error <- tryCatch({
#       test_that("Number of rows in prediction equal to testing data for flexmix", {
#         expect_equal(length(modelObject$testingPred), nrow(testingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error) && !is.null(error)){
#       failedTestsEachflexmix[length(failedTestsEachflexmix)+1] <- as.character(error)
#     }
# 
#     error <- tryCatch({
#       test_that("Training predictions are equal for flexmix", {
#         # print("flexmix training... comparison")
#         # print(round(modelObject$pred,2))
#         # print(round(trainingPred,2))
#         expect_equal(all(round(modelObject$pred,2)== round(trainingPred,2)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error) && !is.null(error)){
#       failedTestsEachflexmix[length(failedTestsEachflexmix)+1] <- as.character(error)
#     }
#     ##
#     error <- tryCatch({
#       test_that("Testing predictions are equal for flexmix", {
#         # print("flexmix testing... comparison")
#         # print(round(modelObject$testingPred,2))
#         # print(round(testingPred,2))
#         expect_equal(all(round(modelObject$testingPred,2) == round(testingPred,2)), TRUE )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error) && !is.null(error)){
#       failedTestsEachflexmix[length(failedTestsEachflexmix)+1] <- as.character(error)
#     }
# 
#     error <- tryCatch({
#       test_that("Number of rows in fitted equal to training data for flexmix", {
#         expect_equal(length(modelObject$pred), nrow(trainingData) )
#       })
#     },error = function(e){return(e)})
#     if(!isTRUE(error) && !is.null(error)){
#       failedTestsEachflexmix[length(failedTestsEachflexmix)+1] <- as.character(error)
#     }
#     if(length(failedTestsEachflexmix) == 1){
#       return("Test passed")
#     }
#     else{
# 
#       failedTestsflexmix[length(failedTestsflexmix) + 1] <-  failedTestsEachflexmix
#       return(failedTestsflexmix)
#     }
#   }
# 
#   failedTestsflexmix <-
#     testEachflexmix(
#       modelObject = flexmixObject,
#       modelType = "flexmix model ",
#       trainingData = trainingData,
#       testingData = testingData,
#       testingPred = testingDataDF$flexmixObjectPred,
#       trainingPred = trainingDataDF$flexmixObjectPred
#     )
#   # failedTestsflexmix <-
#   #   testEachflexmix(
#   #     modelObject = flexmixObjectSinglePredictor,
#   #     modelType = "flexmix model with single predictor",
#   #     trainingData = trainingData,
#   #     testingData = testingData,
#   #     testingPred = testingDataDF$flexmixObjectSinglePredictorPred,
#   #     trainingPred = trainingDataDF$flexmixObjectSinglePredictorPred
#   #   )
# }
# 
# 
# # ##&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
# testResultsflexmix <- testflexmix(trainingData =  trainingData, testingData =  testingData, predictedVariable = "Occupancy")
# if(as.character(testResultsflexmix)[1] != "Test passed"){
#   allTestResultsflexmix[1] = "flexmix Test"
#   allTestResultsflexmix[[2]] = testResultsflexmix
# }
# # If OLS fails the length will be nonzero
# if(length(allTestResultsflexmix) != 0){
#   allTestResults[[length(allTestResults)+1]] <- allTestResultsflexmix
# }
# ##&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
# nn!!!!!!!!!!!!!!!!!
testnn <- function(trainingData, testingData, predictedVariable){
  failedTestsnn = list()
  
  # Building Models
  nnObject <-
    nnModelFunction(
      trainingData =  trainingData,
      testingData = testingData,
      predictedVariable = "Occupancy",
      nnLearningRate = 0.01,
      nnMomentum = 0.01,
      nnHiddenAct = "sigm",
      nnEpoch = 100,
      nnBatchSize = 100,
      mlpHidden = c("10","10")
    )
  
  nnObjectSinglePredictor <-
    nnModelFunction(
      trainingData =  trainingData[, c(1,4)],
      testingData = testingData[, c(1,4)],
      predictedVariable = "Occupancy",
      nnLearningRate = 0.01,
      nnMomentum = 0.01,
      nnHiddenAct = "sigm",
      nnEpoch = 100,
      nnBatchSize = 100,
      mlpHidden = c("10","10")
    )
  
  
  testEachnn <- function(modelObject, modelType, trainingData, testingData, testingPred, trainingPred){
    
    
    failedTestsEachnn <- list()
    failedTestsEachnn[1]  <- modelType
    error <- tryCatch({
      test_that("Class of built model neural network", {
        expect_equal(class(modelObject$model), c("list" ))
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachnn[length(failedTestsEachnn)+1] <- as.character(error)
    }
    error <- tryCatch({
      test_that("Number of rows in prediction equal to testing data for neural network", {
        expect_equal(length(modelObject$testingPred), nrow(testingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachnn[length(failedTestsEachnn)+1] <- as.character(error)
    }
    
    error <- tryCatch({
      test_that("Training predictions are equal for neural network", {
        expect_equal(all(round(modelObject$pred)== round(trainingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachnn[length(failedTestsEachnn)+1] <- as.character(error)
    }
    ##
    error <- tryCatch({
      test_that("Testing predictions are equal for neural network", {
        expect_equal(all(round(modelObject$testingPred) == round(testingPred)), TRUE )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachnn[length(failedTestsEachnn)+1] <- as.character(error)
    }
    
    error <- tryCatch({
      test_that("Number of rows in fitted equal to training data for neural network", {
        expect_equal(length(modelObject$pred), nrow(trainingData) )
      })
    },error = function(e){return(e)})
    if(!isTRUE(error) && !is.null(error)){
      failedTestsEachnn[length(failedTestsEachnn)+1] <- as.character(error)
    }
    if(length(failedTestsEachnn) == 1){
      return("Test passed")
    }
    else{
      
      failedTestsnn[length(failedTestsnn) + 1] <-  failedTestsEachnn
      return(failedTestsnn)
    }
  }
  
  failedTestsnn <-
    testEachnn(
      modelObject = nnObject,
      modelType = "nn model ",
      trainingData = trainingData,
      testingData = testingData,
      testingPred = testingDataDF$nnObjectPred,
      trainingPred = trainingDataDF$nnObjectPred
    )
  failedTestsnn <-
    testEachnn(
      modelObject = nnObjectSinglePredictor,
      modelType = "nn model with single predictor",
      trainingData = trainingData[, c(1,4)],
      testingData = testingData[, c(1,4)],
      testingPred = testingDataDF$nnObjectSinglePredictorPred,
      trainingPred = trainingDataDF$nnObjectSinglePredictorPred
    )
}
testResultsnn <- testnn(trainingData =  trainingData, testingData =  testingData, predictedVariable = "Occupancy")
if(as.character(testResultsnn)[1] != "Test passed"){
  allTestResultsnn[1] = "nn Test"
  allTestResultsnn[[2]] = testResultsnn
}

if(length(allTestResultsnn) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsnn
}


# Final check of all models
#### -------- Feature slection test cases --------------------- ####

source("Utils/00.CommonMethods_Individual.R")
# source("Utils/DummyVariableCreation.R")
defaultTypeCutOff <- 0
rawData <- read.csv("../JenkinsTestData/hotelTestingData.csv", na.strings = c("NA",NA))
included <- c("location_type_DOWNTOWN","Compet_Occupancy","Compet_AvgDailyRate","Occupancy")
dataset <- rawData[,included]
dataset <- na.omit(dataset)
predictedVariable <- "Occupancy"
newData <- dataset
stdData <- rescaler.data.frame(dataset, type = "sd")
colnames(stdData) <- make.names(colnames(stdData))
colnames(newData) <- make.names(colnames(newData))
linDepModelData <- cbind(dataset[,predictedVariable],newData)
colnames(linDepModelData) <- c(predictedVariable, colnames(newData))
# # 
linDepModel <- lm(formula =as.formula(paste0(predictedVariable,"~.")),data=linDepModelData)
linDepCols <<- names(linDepModel$coefficients[which(is.na(linDepModel$coefficients) == TRUE)])
newData <- newData[, !(colnames(newData) %in% linDepCols)]
stdData <- stdData[, !(colnames(stdData) %in% linDepCols)]
dataset <- dataset[, !(colnames(dataset) %in% linDepCols)]

### Test OLS ###
# OLSVarImpOrig <<- data.frame(Features = c("Compet_Occupancy","location_type_DOWNTOWN","Compet_AvgDailyRate"), 
#                             Importance = c(9.01, 2.59, 2.13))
# OLSVarImpOrig$Importance <- round(as.numeric(as.character(OLSVarImpOrig$Importance)),2)
# 
# testOLSfeature <- function(predictedVariable,newData, dataset, OLSVarImpOrig){
#   failedTestsOlsfeature <- list()
#   
#   olsFeatureObject <- OLSVarImpFun(predictedVariable,newData, dataset)
#   OLSVarImpFun <- varImp(olsFeatureObject)
#   OLSVarImpFun <- data.frame(Features=rownames( OLSVarImpFun),Importance = round(OLSVarImpFun$Overall,2))
#   OLSVarImpFun <-  OLSVarImpFun[with(OLSVarImpFun, order(-Importance)),]
#   rownames(OLSVarImpFun) <- 1:nrow(OLSVarImpFun)
#   error <- tryCatch({
#     test_that("Class of OLS model object is correct", {
#       expect_equal(class(olsFeatureObject), "lm" )
#     })
#   },error = function(e){return(e)})
#   if(!isTRUE(error) && !is.null(error)){
#     failedTestsOlsfeature[length(failedTestsOlsfeature)+1] <- as.character(error)
#   }
# 
#   error <- tryCatch({
#     test_that("Feature importances are equal for OLS", {
# 
#       comparison <- compare::compare(OLSVarImpOrig, OLSVarImpFun)$result
#       print(comparison)
#       expect_equal(comparison, TRUE )
#     })
#   },error = function(e){return(e)})
#   if(!isTRUE(error) && !is.null(error)){
#     failedTestsOlsfeature[length(failedTestsOlsfeature)+1] <- as.character(error)
#   }
#   
#   if(length(failedTestsOlsfeature) == 0){
#     return("Test passed")
#   } else{
#     return(failedTestsOlsfeature)}
# }
# 
# testResultsFeatureSelectionOLS <- testOLSfeature(predictedVariable,newData, dataset, OLSVarImpOrig)
# 
# # OLSVarImpOrig$Importance <- round(as.numeric(as.character(OLSVarImpOrig$Importance)),2)
# # testResultsFeatureSelectionOLS <- testOLSfeature(predictedVariable,newData, dataset, OLSVarImpOrig)
# if(as.character(testResultsFeatureSelectionOLS)[1] != "Test passed"){
#   allTestResultsOlsfeature[1] = "Feature Selection OLS Test"
#   allTestResultsOlsfeature[[2]] = testResultsFeatureSelectionOLS
# }
# 
# if(length(allTestResultsOlsfeature) != 0){
#   allTestResults[[length(allTestResults)+1]] <- allTestResultsOlsfeature
# }


### Test PLS ###
PLSVarImpOrig <<- data.frame(Features = c("Compet_Occupancy","Compet_AvgDailyRate","location_type_DOWNTOWN"),
                             Importance = c(100.00,31.47,0.00))
PLSVarImpOrig$Importance <- round(as.numeric(as.character(PLSVarImpOrig$Importance)),2)
testPLSfeature <- function(predictedVariable,stdData, dataset, PLSVarImpOrig){
  failedTestsPLSfeature <- list()
  plsFeatureObject <- PLSVarImpFun(predictedVariable,stdData, dataset)
  PLSVarImpFun <- varImp(plsFeatureObject)$importance
  PLSVarImpFun <- data.frame(Features=rownames(PLSVarImpFun),Importance = round(PLSVarImpFun$Overall,2))
  PLSVarImpFun <-  PLSVarImpFun[with(PLSVarImpFun, order(-Importance)),]
  rownames(PLSVarImpFun) <- 1:nrow(PLSVarImpFun)
  
  error <- tryCatch({
    test_that("Class of PLS model object is correct", {
      expect_equal(class(plsFeatureObject), c("train","train.formula") )
    })
  },error = function(e){return(e)})
  if(!isTRUE(error) && !is.null(error)){
    failedTestsPLSfeature[length(failedTestsPLSfeature)+1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Feature importances are equal for PLS", {
      comparison <- compare::compare(PLSVarImpOrig, PLSVarImpFun)$result
      expect_equal(comparison, TRUE )
    })
  },error = function(e){return(e)})
  if(!isTRUE(error) && !is.null(error)){
    failedTestsPLSfeature[length(failedTestsPLSfeature)+1] <- as.character(error)
  }
  
  if(length(failedTestsPLSfeature) == 0){
    return("Test passed")
  } else{
    return(failedTestsPLSfeature)}
}


testResultsFeatureSelectionPLS <- testPLSfeature(predictedVariable,stdData, dataset, PLSVarImpOrig)
if(as.character(testResultsFeatureSelectionPLS)[1] != "Test passed"){
  allTestResultsPlsfeature[1] = "Feature Selection PLS Test"
  allTestResultsPlsfeature[[2]] = testResultsFeatureSelectionPLS
}

if(length(allTestResultsPlsfeature) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsPlsfeature
}

### Test MARS ###
MARSVarImpOrig <<- data.frame(Features = c("Compet_Occupancy"), Importance = c(100.00))
MARSVarImpOrig$Importance <- round(as.numeric(as.character(MARSVarImpOrig$Importance)),2)
testMARSfeature <- function(predictedVariable,newData, dataset, MARSVarImpOrig){
  failedTestsMARSfeature <- list()
  MARSFeatureObject <- MARSRegression(predictedVariable,newData, dataset)
  ranks <-  MARSFeatureObject[[1]][,4, drop = FALSE] 
  MARSVarImpFun <- data.frame(Features = row.names(ranks), Importance = as.vector(MARSFeatureObject[[1]][,4]))
  colnames(MARSVarImpFun) <- c("Features","Importance")
  MARSVarImpFun <-  MARSVarImpFun[with(MARSVarImpFun, order(-Importance)),]
  rownames(MARSVarImpFun) <- 1:nrow(MARSVarImpFun)
  
  error <- tryCatch({
    test_that("Class of MARS model object is correct", {
      expect_equal(class(MARSFeatureObject[[2]]), "earth")
    })
  },error = function(e){return(e)})
  if(!isTRUE(error) && !is.null(error)){
    failedTestsMARSfeature[length(failedTestsMARSfeature)+1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Feature importances are equal for MARS", {
      comparison <- compare::compare(MARSVarImpOrig, MARSVarImpFun)$result
      expect_equal(comparison, TRUE )
    })
  },error = function(e){return(e)})
  if(!isTRUE(error) && !is.null(error)){
    failedTestsMARSfeature[length(failedTestsMARSfeature)+1] <- as.character(error)
  }
  
  if(length(failedTestsMARSfeature) == 0){
    return("Test passed")
  } else{
    return(failedTestsMARSfeature)}
}


testResultsFeatureSelectionMARS <- testMARSfeature(predictedVariable,newData, dataset, MARSVarImpOrig)
if(as.character(testResultsFeatureSelectionMARS)[1] != "Test passed"){
  allTestResultsMARSfeature[1] = "Feature Selection MARS Test"
  allTestResultsMARSfeature[[2]] = testResultsFeatureSelectionMARS
}

if(length(allTestResultsMARSfeature) != 0){
  allTestResults[[length(allTestResults)+1]] <- allTestResultsMARSfeature
}




# ---------------- > LARS Feature selection start 
larsFeatImpDf <<- data.frame(Features  = c("Compet_Occupancy","location_type_DOWNTOWN","Compet_AvgDailyRate"), 
Importance = c(189.76,0.23,0.23))

rfFeatImpDf <<- data.frame(Features  = c("Compet_Occupancy","Compet_AvgDailyRate","location_type_DOWNTOWN"), 
Importance = c(100.00,51.58,42.67))


testLARSFeature <- function(y, newData, dataset){
    failedTestLARSFeat <- list()
    featImp <- LARSRegression(y, newData, dataset)
    
    testFeatImp <- function(featImp){
      failedTestLARSFeatEach <- list()

      beta <- featImp[[1]]
      larsObject <- featImp[[2]]
      failedTestLARSFeatEach[1] <- "LARS Feature Imp"

      error <- tryCatch({
        test_that("Class of LARS feature importance model",{
            expect_equal(class(larsObject), c("lars"))
        })
      },error = function(e){return(e)})
      if(!isTRUE(error) && !is.null(error)){
        failedTestLARSFeatEach[length(failedTestLARSFeatEach) + 1] <- as.character(error)
      }

      # error <- tryCatch({
      #   test_that("Comparison of LARS feature data-frames",{
      #     larsDataFrame <- as.data.frame(featImp[[1]][,2])
      #     colnames(larsDataFrame)[1] <- "Importance"
      #     rownames(larsDataFrame) <- featImp[[1]][,1]
      #     larsDataFrame[,"Importance"] <- round(larsDataFrame[, "Importance"], 2)
      #     vidf <- data.frame(Features = rownames(larsDataFrame), Importance = as.vector(larsDataFrame[,"Importance"]))
      #     comparisonResult <- compare::compare(vidf,larsFeatImpDf)$result
      #       expect_equal(comparisonResult, TRUE)
      #   })
      # },error = function(e){return(e)})
      if(!isTRUE(error) && !is.null(error)){
        failedTestLARSFeatEach[length(failedTestLARSFeatEach) + 1] <- as.character(error)
      }
      if(length(failedTestLARSFeatEach) == 1){
        return("Test passed")
      }
      else{
        
        failedTestLARSFeat[length(failedTestLARSFeat) + 1] <-  failedTestLARSFeatEach
        return(failedTestLARSFeat)
      }

    }

    failedTestLARSFeat <- testFeatImp(featImp)
}
testResLARSFeat <- testLARSFeature(y = predictedVariable, newData = newData, dataset = dataset)
if(as.character(testResLARSFeat)[1] != "Test passed"){
  alltestResLARSFeat[1] = "LARS Feature Test"
  alltestResLARSFeat[[2]] = testResLARSFeat
}


if(length(alltestResLARSFeat) != 0){
  allTestResults[[length(allTestResults)+1]] <- alltestResLARSFeat
}


# ---------------- > LARS Feature selection end

# ------------------> RF  Feature selction start


# testRFFeature <- function(input.data,
#                           dependent.variable,
#                           independent.variables, numTrees,
#                           mTry, minNodeSize, 
#                           splitRule, Importance){
#     failedTestRFFeat <- list()
#     featImp <- RandomForestVariableImportance(input.data,
#                                              dependent.variable,
#                                              independent.variables, numTrees,
#                                              mTry, minNodeSize, 
#                                              splitRule, Importance)
#     
#     testFeatImp <- function(featImp){
#       failedTestRFFeatEach <- list()
# 
#       beta <- featImp[[1]]
#       RFObject <- featImp[[2]]
#       failedTestRFFeatEach[1] <- "RF Feature Imp"
# 
#       error <- tryCatch({
#         test_that("Class of RF feature importance model",{
#             expect_equal(class(RFObject), c("ranger"))
#         })
#       },error = function(e){return(e)})
#       if(!isTRUE(error) && !is.null(error)){
#         failedTestRFFeatEach[length(failedTestRFFeatEach) + 1] <- as.character(error)
#       }
# 
#       error <- tryCatch({
#         test_that("Comparison of RF feature data-frames",{
#           rfVarImp <- as.data.frame(featImp[[1]])
# 
#           vidf <- data.frame(Features = rownames(rfVarImp), Importance = as.vector(rfVarImp[,1]))
#           comparisonResult <- compare::compare(vidf,rfFeatImpDf)$result
#             expect_equal(comparisonResult, TRUE)
#         })
#       },error = function(e){return(e)})
#       if(!isTRUE(error) && !is.null(error)){
#         failedTestRFFeatEach[length(failedTestRFFeatEach) + 1] <- as.character(error)
#       }
#       if(length(failedTestRFFeatEach) == 1){
#         return("Test passed")
#       }
#       else{
#         
#         failedTestRFFeat[length(failedTestRFFeat) + 1] <-  failedTestRFFeatEach
#         return(failedTestRFFeat)
#       }
# 
#     }
# 
#     failedTestRFFeat <- testFeatImp(featImp)
# }
# 
# rfData <- cbind( dataset[,predictedVariable], newData)
# colnames(rfData) <- gsub(" ", "_", colnames(rfData))
# colnames(rfData)[1] <- predictedVariable
# RFNoOfTreesFS <- 100
# RFmtryFS <- 1
# RFMinNodeSizeFS <- 5
# testResRFFeat <- testRFFeature(input.data= rfData,
#                                              dependent.variable= predictedVariable,
#                                              independent.variables= names(rfData[,-1]), numTrees= RFNoOfTreesFS,
#                                              mTry= RFmtryFS, minNodeSize= RFMinNodeSizeFS, 
#                                              splitRule= "variance", Importance= "impurity")
# if(as.character(testResRFFeat)[1] != "Test passed"){
#   alltestResRFFeat[1] = "Random Forest Feature Test"
#   alltestResRFFeat[[2]] = testResRFFeat
# }
# 
# 
# if(length(alltestResRFFeat) != 0){
#   allTestResults[[length(allTestResults)+1]] <- alltestResRFFeat
# }

# ------------------> RF  Feature selction end


# -------------------> XGB Feature selection start

testxgbFeature <- function(predictedVariable, newData, dataset,xgboostMaxDepthFS,xgboostLeraningRateFS, xgboostNoOfIterationsFS){
    failedTestxgbFeat <- list()
    featImp <- xgbVarImpFun(predictedVariable, newData, dataset,xgboostMaxDepthFS,xgboostLeraningRateFS, xgboostNoOfIterationsFS)
    
    testFeatImp <- function(featImp){
      failedTestxgbFeatEach <- list()

      beta <- featImp

      failedTestxgbFeatEach[1] <- "XgBost Feature Imp"

      error <- tryCatch({
        test_that("Class of XgBoost feature importance model",{
            expect_equal(class(beta), c("xgb.Booster"))
        })
      },error = function(e){return(e)})
      if(!isTRUE(error) && !is.null(error)){
        failedTestxgbFeatEach[length(failedTestxgbFeatEach) + 1] <- as.character(error)
      }

      if(length(failedTestxgbFeatEach) == 1){
        return("Test passed")
      }
      else{
        
        failedTestxgbFeat[length(failedTestxgbFeat) + 1] <-  failedTestxgbFeatEach
        return(failedTestxgbFeat)
      }

    }

    failedTestxgbFeat <- testFeatImp(featImp)
}

xgboostMaxDepthFS <- 4
xgboostLeraningRateFS <- 0.3
xgboostNoOfIterationsFS <- 10
testResxgbFeat <- testxgbFeature(predictedVariable, newData, dataset,xgboostMaxDepthFS,xgboostLeraningRateFS,xgboostNoOfIterationsFS)
if(as.character(testResxgbFeat)[1] != "Test passed"){
  alltestResxgbFeat[1] = "XgBoost Feature Test"
  alltestResxgbFeat[[2]] = testResxgbFeat
}



if(length(alltestResxgbFeat) != 0){
  allTestResults[[length(allTestResults)+1]] <- alltestResxgbFeat
}

# -------------------> XGB Feature selection end




testDummyVarCreation <- function(){
  failedTestResults <- list()
  data <- data.frame(cbind("Name" = c("Monika", "B", "C", "D", "E", "F", "A"), "Employment_type" = c("Salaried", "Self-Employed", "Business", "Unemployed", "Investor", "Salaried", "Business")))
  referenceLevel = "Investor"
  expected_output <- data.frame(rbind(c(0,1,0,0), c(0,0,1,0),c(1,0,0,0),c(0,0,0,1),c(0,0,0,0),c(0,1,0,0),c(1,0,0,0)))
  colnames(expected_output) <- paste(colnames(data["Employment_type"]),
                                     unique(data['Employment_type'])[unique(data['Employment_type']) != referenceLevel],sep='_')
  typedata <- data.frame( "Column" = c("Name", "Employent_type"), "Column.Type" = c("character", "character"), "Forced.Reference" = c(NA, "Investor"))
  result <- tryCatch({
    output <- DummyVarCreation(data["Employment_type"], typedata = typedata)
    test_that("Column dummification is correct",{
      expect_equivalent(output[[1]], expected_output)
    })
  }, error = function(e){return(e)})
  if(!isTRUE(result)){
    failedTestResults <- c(failedTestResults, as.character(result))
  }
  if(length(failedTestResults) == 0){
    return("Dummy Variable creation test passed")
  } else {
    return(failedTestResults)
  }
}

testDummyVarCreationResults <- testDummyVarCreation()
# if(testDummyVarCreationResults != 'Dummy Variable creation test passed') {
#   allResults <- c(allResults,'DummyVarCreationtest', testDummyVarCreationResults)
# }

if(testDummyVarCreationResults != 'Dummy Variable creation test passed'){
  allTestResults[[length(allTestResults)+1]] <- testDummyVarCreationResults
}





# tryCatch({
#   if(length (allTestResults)!= 0){
#     # flog.info(unlist(allTestResults))
#     # stop(unlist(allTestResults))
#     # print(allTestResults)

#   }else{
#     print("All tests passed")
#   }
# })


predData <- data.frame("location_type_DOWNTOWN" = 
 c(0 ,                   
 4 ,                   
 4 ,                   
 2 ,                   
39 ,                   
 2 ,                   
 1 ,                   
 3 ,                   
 4 ,                   
11 ),

"Compet_Occupancy"  = 
c(0.7751971,
0.3147547,
0.4674128,
0.3108382,
0.6135490,
0.5115396,
0.4348527,
0.2808349,
0.5024319,
0.4574356),

"Compet_AvgDailyRate" = 
c(104.26250,
 85.44427,
 67.43545,
 95.52010,
 77.14126,
113.31206,
 60.45565,
 56.21718,
 89.06446,
 83.20844),

"Occupancy" = 
c(0.9170911,
0.2499559,
0.4061508,
0.3757225,
0.6532772,
0.5264706,
0.4375770,
0.2303465,
0.5190013,
0.3828049))

OLSObject <- OLSFunction(trainingData = predData,
                           testingData = predData,
                           predictedVariable = predictedVariable,
                           withIntercept = T, color1 = '#ffffff', color2 = '#ffffff')


modelSubmit = list()
modelSubmit$OLS <- list(
  name = "OLS",
  model  = OLSObject$model,
  pred = OLSObject$modelPredictionsTraining,
  mape = OLSObject$trainingMAPE,
  testingPred = OLSObject$modelPredictionsTesting,
  testingMAPE = OLSObject$testingMAPE,
  predict = OLSObject$predict 
)

typeData <-data.frame("Column"=colnames(predData))
          typeData$Column.Type <- unname(lapply(predData,FUN = function(x){CheckColumnType(x,defaultTypeCutOff)}))
          typeData$Forced.Reference <- rep(NA,length(names(predData)))

testpreparePredDataAndRun <- function(predDataSet,
                                      blacklist,
                                      blacklist_col,
                                      modelToPredict,
                                      modelSubmit,
                                      typeData,
                                      trainingData,
                                      predictedVariable,
                                      catdatainit
                                      ){
failedTestPrepareAndPred <- list()

predcitions <- preparePredDataAndRun(predDataSet, blacklist,blacklist_col,modelToPredict,modelSubmit,typeData,trainingData,predictedVariable,catdatainit)

modelPredictionsTraining <<- c(
0.8831483,
0.2833762,
0.4549434,
0.2906276,
0.6288405,
0.5615669,
0.4082086,
0.2094601,
0.5224889,
0.4557372)



testPred <- function(predictions){
  failedTestPrepareAndPredEach <- list()
  failedTestPrepareAndPredEach[1] <- "Test of predict function"
      error <- tryCatch({
        test_that("Predictions by the predict function",{
            expect_equal(as.vector(round(predcitions$modelPredictionsTraining, 2)), round(modelPredictionsTraining,2))
        })
      },error = function(e){return(e)})
      if(!isTRUE(error) && !is.null(error)){
        failedTestPrepareAndPredEach[length(failedTestPrepareAndPredEach) + 1] <- as.character(error)
      }

      if(length(failedTestPrepareAndPredEach) == 1){
        return("Test passed")
      }
      else{
        
        failedTestPrepareAndPred[length(failedTestPrepareAndPred) + 1] <-  failedTestPrepareAndPredEach
        return(failedTestPrepareAndPred)
      }
}
failedTestPrepareAndPred <- testPred(predictions)
}

testPredMethod <- testpreparePredDataAndRun(predDataSet = predData,
                                      blacklist = TRUE,
                                      blacklist_col = c(),
                                      modelToPredict = "OLS",
                                      modelSubmit = modelSubmit,
                                      typeData = typeData,
                                      trainingData = predData,
                                      predictedVariable = predictedVariable,
                                      catdatainit = data.frame()
                                      )                        

print("testPredMethod = ")
print(testPredMethod)
if(as.character(testPredMethod)[1] != "Test passed"){
  alltestRespredFunc[1] = "Predict function Test"
  alltestRespredFunc[[2]] = testPredMethod
}


if(length(testPredMethod) != 0){
  allTestResults[[length(allTestResults)+1]] <- testPredMethod
}

# print(allTestResults)







stepwiseObject <- StepwiseFunction(trainingData = predData ,testingData = predData, predictedVariable = predictedVariable,  
                                     stepWithIntercept = T, stepDirection = "both", color1 = '#ffffff', color2 = '#ffffff')



modelSubmit$stepwise <- list(
  name = "stepwise",
  model  = stepwiseObject$model,
  pred = stepwiseObject$fitted,
  mape = stepwiseObject$trainingMape,
  testingPred = stepwiseObject$testingPredictions,
  testingMAPE = stepwiseObject$testingMAPE,
  predict = stepwiseObject$predict 
)

mapeData <<- data.frame(Model=character(),Mape=double(),DataType = character(),stringsAsFactors = FALSE)
modelsToAverage <<- c("OLS","stepwise")
modelsToStack <<- c("OLS","stepwise")
testbuildAvgEnsemble <- function(modelsToAverage,modelSubmit,predictedVariable,trainingData,testingData){

  failedtestbuildAvgEnsemble <- list() 

  avgEnsembleOut <- buildAvgEnsemble(modelsToAverage,modelSubmit,predictedVariable,trainingData,testingData,mapeData)


  testAvgEn <- function(avgEnsembleOut){
    failedtestbuildAvgEnsembleEach <- list()
    failedtestbuildAvgEnsembleEach[1] <- "Test of average ensemble"
  
    error <- tryCatch({
        test_that("Avg ensemble mape with avg",{
            expect_equal(avgEnsembleOut[[1]],  48.05239)
        })
      },error = function(e){return(e)})
      if(!isTRUE(error) && !is.null(error)){
        failedtestbuildAvgEnsembleEach[length(failedtestbuildAvgEnsembleEach) + 1] <- as.character(error)
      }


    error <- tryCatch({
        test_that("Avg ensemble model submit list",{
            expect_equal(class(avgEnsembleOut[[2]]),  "list")
        })
      },error = function(e){return(e)})
      if(!isTRUE(error) && !is.null(error)){
        failedtestbuildAvgEnsembleEach[length(failedtestbuildAvgEnsembleEach) + 1] <- as.character(error)
      }
    error <- tryCatch({
        test_that("Avg ensemble mape",{
            expect_equal(class(avgEnsembleOut[[3]]),  48.05239)
        })
      },error = function(e){return(e)})
      if(!isTRUE(error) && !is.null(error)){
        failedtestbuildAvgEnsembleEach[length(failedtestbuildAvgEnsembleEach) + 1] <- as.character(error)
      }
    error <- tryCatch({
        test_that("Avg ensemble training mape",{
            expect_equal(class(avgEnsembleOut[[4]]),  43.18066)
        })
      },error = function(e){return(e)})
      if(!isTRUE(error) && !is.null(error)){
        failedtestbuildAvgEnsembleEach[length(failedtestbuildAvgEnsembleEach) + 1] <- as.character(error)
      }

    if(length(failedtestbuildAvgEnsembleEach) == 1){
        return("Test passed")
      }
      else{
        
        failedtestbuildAvgEnsemble[length(failedtestbuildAvgEnsemble) + 1] <-  failedtestbuildAvgEnsembleEach
        return(failedtestbuildAvgEnsemble)
      }
  
  }
  failedtestbuildAvgEnsembleEach <- testAvgEn(avgEnsembleOut)
}



avgEnsembleOutTest <- buildAvgEnsemble(modelsToAverage,modelSubmit,predictedVariable,trainingData,testingData,mapeData)
# print(avgEnsembleOutTest)


if(as.character(avgEnsembleOutTest)[1] != "Test passed"){
  alltestResAvgEnsem[1] = "Avg ensemble test"
  alltestResAvgEnsem[[2]] = avgEnsembleOutTest
}


if(length(avgEnsembleOutTest) != 0){
  allTestResults[[length(allTestResults)+1]] <- avgEnsembleOutTest
}




testbuildStackedEnsemble <- function(modelsToStack,modelSubmit,trainingData,testingData,predictedVariable){
  failedtestbuildStackedEnsemble <- list() 

  stackedEnsembleOut <- buildStackedEnsemble(modelsToStack,modelSubmit,trainingData,testingData,predictedVariable)


  testStackEn <- function(stackedEnsembleOut){
    failedtestbuildStackedEnsembleEach <- list()
    failedtestbuildStackedEnsembleEach[1] <- "Test of stacked ensemble"
  
    error <- tryCatch({
        test_that("Avg ensemble mape with stack",{
            expect_equal(stackedEnsembleOut[[1]],  9.764339)
        })
      },error = function(e){return(e)})
      if(!isTRUE(error) && !is.null(error)){
        failedtestbuildStackedEnsembleEach[length(failedtestbuildStackedEnsembleEach) + 1] <- as.character(error)
      }


    error <- tryCatch({
        test_that("Avg ensemble model submit list",{
            expect_equal(class(stackedEnsembleOut[[3]]),  "list")
        })
      },error = function(e){return(e)})
      if(!isTRUE(error) && !is.null(error)){
        failedtestbuildStackedEnsembleEach[length(failfailedtestbuildStackedEnsembleEachedtestbuildAvgEnsembleEach) + 1] <- as.character(error)
      }

    error <- tryCatch({
        test_that("Avg ensemble training mape",{
            expect_equal(class(stackedEnsembleOut[[2]]),   9.764339)
        })
      },error = function(e){return(e)})
      if(!isTRUE(error) && !is.null(error)){
        failedtestbuildStackedEnsembleEach[length(failedtestbuildStackedEnsembleEach) + 1] <- as.character(error)
      }

    if(length(failedtestbuildStackedEnsembleEach) == 1){
        return("Test passed")
      }
      else{
        
        failedtestbuildStackedEnsemble[length(failedtestbuildStackedEnsemble) + 1] <-  failedtestbuildStackedEnsembleEach
        return(failedtestbuildStackedEnsemble)
      }
  
  }
  failedtestbuildStackedEnsembleEach <- testStackEn(stackedEnsembleOut)
}



stackedEnsembleOutTest <- buildStackedEnsemble(modelsToStack,modelSubmit,predData,predData,predictedVariable)
# print("Wat............")
# print(stackedEnsembleOutTest)


if(as.character(stackedEnsembleOutTest)[1] != "Test passed"){
  alltestResStackEnsem[1] = "Avg ensemble test"
  alltestResStackEnsem[[2]] = avgEnsembleOutTest
}


if(length(avgEnsembleOutTest) != 0){
  allTestResults[[length(allTestResults)+1]] <- stackedEnsembleOutTest
}

if(length(allTestResults)==0){
  print("All test cases passed")
}

#Loading inputs ----
InputNamedlist<- list()
InputNamedlist<- readRDS("../JenkinsTestData/InputNamedList.RDS")

TOLSModel<-InputNamedlist$TOLSModel
trnData<-InputNamedlist$trnData
residuals<-InputNamedlist$residuals
predicted<-InputNamedlist$predicted
y<-InputNamedlist$y
yhat<-InputNamedlist$yhat
actual<-InputNamedlist$actual
i<-InputNamedlist$i
tesData<-InputNamedlist$tesData
predVar<-InputNamedlist$predVar
xgbMax<-InputNamedlist$xgbMax
xgbLR<-InputNamedlist$xgbLR
xgbNitr<-InputNamedlist$xgbNitr
smLCol<-InputNamedlist$smLCol
gamWIn<-InputNamedlist$gamWIn
gRmarsB_x<-InputNamedlist$gRmarsB_x
gRmarsB_y<-InputNamedlist$gRmarsB_y
gRlarsB_x<-InputNamedlist$gRlarsB_x
gRlarsB_y<-InputNamedlist$gRlarsB_y
newData<-InputNamedlist$newData
dataset<-InputNamedlist$dataset
con<-InputNamedlist$con
data1<-InputNamedlist$data1
cvRobust<-InputNamedlist$cvRobust
robust_y<-InputNamedlist$robust_y
robust_x<-InputNamedlist$robust_x
CV_x<-InputNamedlist$CV_x
CV_y<-InputNamedlist$CV_y
incptFlg<-InputNamedlist$incptFlg
dirctn<-InputNamedlist$dirctn
color1<-InputNamedlist$color1
color2<-InputNamedlist$color2
indx<-InputNamedlist$indx
mode<-InputNamedlist$mode
cvK<-InputNamedlist$cvK
shr_x<-InputNamedlist$shr_x
shr_y<-InputNamedlist$shr_y
rfdata<-InputNamedlist$rfdata
xgbData<-InputNamedlist$xgbData
xgbtes<-InputNamedlist$xgbtes
corPlotFun<-InputNamedlist$corPlotFun
ROLSModel<-InputNamedlist$ROLSModel
resVsfit<-InputNamedlist$resVsfit
reshis<-InputNamedlist$reshis
genQQ<-InputNamedlist$genQQ
actVsprd<-InputNamedlist$actVsprd
gamF<-InputNamedlist$gamF
larsMf<-InputNamedlist$larsMf
fmixMf<-InputNamedlist$fmixMf
gRmarsB<-InputNamedlist$gRmarsB
gRlarsB<-InputNamedlist$gRlarsB
time1<-InputNamedlist$time1
unscT<-InputNamedlist$unscT
OlsvarsImf<-InputNamedlist$OlsvarsImf
calcF1LM<-InputNamedlist$calcF1LM
rlmCV<-InputNamedlist$rlmCV
rswCV<-InputNamedlist$rswCV
rrbCV<-InputNamedlist$rrbCV
rGamCV<-InputNamedlist$rGamCV
gDisPlot<-InputNamedlist$gDisPlot
CAlign<-InputNamedlist$CAlign
AvgCol<-InputNamedlist$AvgCol
obsplIn<-InputNamedlist$obsplIn
obdatasplt<-InputNamedlist$obdatasplt
RFVarImp<-InputNamedlist$RFVarImp
rshrCV<-InputNamedlist$rshrCV
larsWIn <- FALSE
con <- "SQLiteConnection"
color1 <- '#ffffff'
color2 <- '#ffffff'
cvK <- 3

# Testing function vifPlottingFunction()
TestvifPlottingFunction <- function(OLSModel,color1,results)
{
  failedTests <- list()
  set.seed(50)
  obj <- vifPlottingFunction(OLSModel,color1)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test vifPlottingFunction' ,{
        expect_equal(
          names(obj), names(results)
        )
        expect_equal(
          (obj$mapping), (results$mapping)
        )
        expect_equal(
          dim(obj), dim(results)
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestvifPlottingFunction(TOLSModel,color1 = '#ffffff',ROLSModel)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n vifPlottingFunction() test starts \n",
                                                                x, "vifPlottingFunction() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n vifPlottingFunction() test starts\n", x, "\n vifPlottingFunction() test ends\n\n")))
  }
})

### end of vifPlottingFunction() test


# Testing function correlationPlotFunction()
TestcorrelationPlotFunction <- function(trainingData,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-correlationPlotFunction(trainingData)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test correlationPlotFunction' ,{
        expect_equal(
          names(obj), names(results)
        )
        expect_equal(
          (obj$mapping), (results$mapping)
        )
        expect_equal(
          dim(obj), dim(results)
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestcorrelationPlotFunction(trnData,corPlotFun)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n correlationPlotFunction() test starts \n",
                                                                x, "correlationPlotFunction() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n correlationPlotFunction() test starts\n", x, "\n correlationPlotFunction() test ends\n\n")))
  }
})

### end of correlationPlotFunction() test

# Testing function residualVsFittedPlot()
TestresidualVsFittedPlot <- function(residuals,predicted, color1, color2,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-residualVsFittedPlot(residuals,predicted, color1, color2)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test residualVsFittedPlot' ,{
        expect_equal(
          names(obj), names(results)
        )
        expect_equal(
          (obj$mapping), (results$mapping)
        )
        expect_equal(
          dim(obj), dim(results)
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestresidualVsFittedPlot(residuals,predicted, '#ffffff' , '#ffffff',resVsfit)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n residualVsFittedPlot() test starts \n",
                                                                x, "residualVsFittedPlot() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n residualVsFittedPlot() test starts\n", x, "\n residualVsFittedPlot() test ends\n\n")))
  }
})

### end of residualVsFittedPlot() test

# Testing function residualHistogram()
TestresidualHistogram <- function(y,yhat, color1,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-residualHistogram(y,yhat, color1)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test residualHistogram' ,{
        expect_equal(
          names(obj), names(results)
        )
        expect_equal(
          length(obj), length(results)
        )
        expect_equal(
          dim(obj), dim(results)
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestresidualHistogram(y,yhat, '#ffffff',reshis)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n residualHistogram() test starts \n",
                                                                x, "residualHistogram() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n residualHistogram() test starts\n", x, "\n residualHistogram() test ends\n\n")))
  }
})




### end of residualHistogram() test

# Testing function genericQQ()
TestgenericQQ <- function(y,yhat, color1, color2,results) 
{
  failedTests <- list()
  set.seed(50)
  obj <-genericQQ(y,yhat, color1, color2) 
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test genericQQ' ,{
        expect_equal(
          names(obj), names(results)
        )
        expect_equal(
          length(obj), length(results)
        )
        expect_equal(
          dim(obj), dim(results)
        )
        expect_equal(
          obj$labels,results$labels
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestgenericQQ(y,yhat, '#ffffff','#ffffff',genQQ)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n genericQQ() test starts \n",
                                                                x, "genericQQ() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n genericQQ() test starts\n", x, "\n genericQQ() test ends\n\n")))
  }
})

### end of genericQQ() test

# Testing function actualVsPredictedPlot()
TestactualVsPredictedPlot <- function(actual,predicted, color1, color2,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-actualVsPredictedPlot(actual,predicted, color1, color2)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test actualVsPredictedPlot' ,{
        expect_equal(
          names(obj), names(results)
        )
        expect_equal(
          length(obj), length(results)
        )
        expect_equal(
          dim(obj), dim(results)
        )
        })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestactualVsPredictedPlot(actual,predicted, '#ffffff','#ffffff',actVsprd)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n actualVsPredictedPlot() test starts \n",
                                                                x, "actualVsPredictedPlot() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n actualVsPredictedPlot() test starts\n", x, "\n actualVsPredictedPlot() test ends\n\n")))
  }
})

### end of actualVsPredictedPlot() test

# # Testing function xgboostModelFunction()
# TestxgboostModelFunction <- function(trainingData, testingData, predictedVariable, xgboostMaxDepth, xgboostLeraningRate,
#                                      xgboostNoOfIterations,results)
# {
#   failedTests <- list()
#   set.seed(50)
#   obj <-xgboostModelFunction(trainingData, testingData, predictedVariable, xgboostMaxDepth, xgboostLeraningRate,
#                               xgboostNoOfIterations)
#                              # Test 1
#                              error <- tryCatch(
#                                {
#                                  test_that( 'Test xgboostModelFunction' ,{
#                                    expect_equal(
#                                      obj, results
#                                    )
#                                  })
#                                },error = function(e)
#                                {
#                                  return(e)
#                                }
#                              )
#                              if(!isTRUE(error))
#                              {
#                                failedTests[length(failedTests)+1] <- as.character(error)
#                              }
# 
#                              if(length(failedTests) == 0)
#                                return("Result: Test passed")
#                              else
#                                return(failedTests)
# }# end of function
# 
# xgbmf <-xgboostModelFunction(trnData, tesData, "Compet_Occupancy", 4, 0.3, 10)
# result <- TestxgboostModelFunction(rfdata, tesData, predVar, xgbMax, xgbLR, xgbNitr,xgbmf)
# 
# lapply(result, function(x){
#   if(x != "Result: Test passed")
#   {
#     failedTestResults <<- append(failedTestResults, list(paste0("\n \n xgboostModelFunction() test starts \n",
#                                                                 x, "xgboostModelFunction() test ends \n \n")))
#   }else
#   {
#     allTestResults <<- append(allTestResults, list(paste0("\n\n xgboostModelFunction() test starts\n", x, "\n xgboostModelFunction() test ends\n\n")))
#   }
# })
# 
# ### end of xgboostModelFunction() test

# Testing function gamFunction()
TestgamFunction <- function(trainingData, predictedVariable, smoothListCol, gamWithIntercept, testingData, color1, color2 ,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-gamFunction(trainingData, predictedVariable, smoothListCol, gamWithIntercept, testingData, color1, color2 )
    # Test 1
    error <- tryCatch(
      {
        test_that( 'Test gamFunction' ,{
          expect_equal(
            class(obj), class(results)
          )
          expect_equal(dim(obj),dim(results))
        })
      },error = function(e)
      {
        return(e)
      }
    )
    if(!isTRUE(error))
    {
      failedTests[length(failedTests)+1] <- as.character(error)
    }
    
    if(length(failedTests) == 0)
      return("Result: Test passed")
    else
      return(failedTests)
  }# end of function
  
  result <- TestgamFunction(trnData,predicted, smLCol, gamWIn, tesData,'#ffffff','#ffffff',gamF)
  
  lapply(result, function(x){
    if(x != "Result: Test passed")
    {
      failedTestResults <<- append(failedTestResults, list(paste0("\n \n gamFunction() test starts \n",
                                                                  x, "gamFunction() test ends \n \n")))
    }else
    {
      allTestResults <<- append(allTestResults, list(paste0("\n\n gamFunction() test starts\n", x, "\n gamFunction() test ends\n\n")))
    }
  })
   
  ### end of gamFunction() test
  
  # Testing function larsModelFunction()
  TestlarsModelFunction <- function(trainingData, testingData, predictedVariable, larsWithIntercept,results)
  {
    failedTests <- list()
    set.seed(50)
    obj <-larsModelFunction(trainingData, testingData, predictedVariable, larsWithIntercept)
    # Test 1
    error <- tryCatch(
      {
        test_that( 'Test larsModelFunction' ,{
          expect_equal(
            obj, results
          )
        })
      },error = function(e)
      {
        return(e)
      }
    )
    if(!isTRUE(error))
    {
      failedTests[length(failedTests)+1] <- as.character(error)
    }
    
    if(length(failedTests) == 0)
      return("Result: Test passed")
    else
      return(failedTests)
  }# end of function
  
  result <- TestlarsModelFunction(trnData,tesData,predicted,larsWIn ,larsMf)
  
  lapply(result, function(x){
    if(x != "Result: Test passed")
    {
      failedTestResults <<- append(failedTestResults, list(paste0("\n \n larsModelFunction() test starts \n",
                                                                  x, "larsModelFunction() test ends \n \n")))
    }else
    {
      allTestResults <<- append(allTestResults, list(paste0("\n\n larsModelFunction() test starts\n", x, "\n larsModelFunction() test ends\n\n")))
    }
  })
  
  ### end of larsModelFunction() test

# Testing function flexmixModelFunction()
TestflexmixModelFunction <- function(trainingData, testingData, predictedVariable,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-flexmixModelFunction(trainingData, testingData, predictedVariable)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test flexmixModelFunction' ,{
        expect_equal(class(obj),class(results))
        expect_equal(names(obj),names(results))
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestflexmixModelFunction(trnData,tesData, predVar,fmixMf)


lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n flexmixModelFunction() test starts \n",
                                                                x, "flexmixModelFunction() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n flexmixModelFunction() test starts\n", x, "\n flexmixModelFunction() test ends\n\n")))
  }
})

### end of flexmixModelFunction() test

# Testing function giveRankMARSBasic()
TestgiveRankMARSBasic <-  function(x, y,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-giveRankMARSBasic(x, y)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test giveRankMARSBasic' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestgiveRankMARSBasic(gRmarsB_x,gRmarsB_y,gRmarsB)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n giveRankMARSBasic() test starts \n",
                                                                x, "giveRankMARSBasic() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n giveRankMARSBasic() test starts\n", x, "\n giveRankMARSBasic() test ends\n\n")))
  }
})

### end of giveRankMARSBasic() test

# Testing function giveRankLARSBasic()
TestgiveRankLARSBasic <-  function(x, y,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-giveRankLARSBasic(x, y)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test giveRankLARSBasic' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestgiveRankLARSBasic(gRlarsB_x,gRlarsB_y,gRlarsB)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n giveRankLARSBasic() test starts \n",
                                                                x, "giveRankLARSBasic() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n giveRankLARSBasic() test starts\n", x, "\n giveRankLARSBasic() test ends\n\n")))
  }
})

### end of giveRankLARSBasic() test

# Testing function underscoredTime()
TestunderscoredTime <-  function(time,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-underscoredTime(time)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test underscoredTime' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

time1 <- "2018-06-29 13:43:10 IST"
result <- TestunderscoredTime(time1,unscT)


lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n underscoredTime() test starts \n",
                                                                x, "underscoredTime() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n underscoredTime() test starts\n", x, "\n underscoredTime() test ends\n\n")))
  }
})

### end of underscoredTime() test

# Testing function OLSVarImpFun()
TestOLSVarImpFun <-  function(predictedVariable,newData, dataset,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-OLSVarImpFun(predictedVariable,newData, dataset)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test OLSVarImpFun' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestOLSVarImpFun(predVar,newData, dataset,OlsvarsImf)


lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n OLSVarImpFun() test starts \n",
                                                                x, "OLSVarImpFun() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n OLSVarImpFun() test starts\n", x, "\n OLSVarImpFun() test ends\n\n")))
  }
})

### end of OLSVarImpFun() test


# Testing function calcF1()
TestcalcF1 <-  function(data,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-calcF1(data)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test calcF1' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestcalcF1(data1,calcF1LM)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n calcF1() test starts \n",
                                                                x, "calcF1() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n calcF1() test starts\n", x, "\n calcF1() test ends\n\n")))
  }
})

### end of calcF1() test

# Testing function runlmCrossValidation()
TestrunlmCrossValidation <-  function(cvControl, x, y, color, interceptflag,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-runlmCrossValidation(cvControl, x, y, color, interceptflag)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test runlmCrossValidation' ,{
       
          expect_equal(dim(obj), dim(results))
          expect_equal(length(obj), length(results))
        
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }

  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestrunlmCrossValidation(cvRobust, CV_x, CV_y, color2, incptFlg,rlmCV)


lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n runlmCrossValidation() test starts \n",
                                                                x, "runlmCrossValidation() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n runlmCrossValidation() test starts\n", x, "\n runlmCrossValidation() test ends\n\n")))
  }
 })

## end of runlmCrossValidation() test

# Testing function runstepwiseCrossValidation()
TestrunstepwiseCrossValidation <-  function(cvControl, x, y, color,direction, interceptflag,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-runstepwiseCrossValidation(cvControl, x, y, color,direction, interceptflag)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test runstepwiseCrossValidation' ,{
        expect_equal(dim(obj), dim(results))
        expect_equal(length(obj), length(results))
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }

  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestrunstepwiseCrossValidation(cvRobust, robust_x, robust_y,color1,dirctn, F,rswCV)


lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n runstepwiseCrossValidation() test starts \n",
                                                                x, "runstepwiseCrossValidation() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n runstepwiseCrossValidation() test starts\n", x, "\n runstepwiseCrossValidation() test ends\n\n")))
  }
})

### end of runstepwiseCrossValidation() test

# Testing function runRobustCrossValidation()
TestrunRobustCrossValidation <-  function(cvControl, x, y, color,interceptflag,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-runRobustCrossValidation(cvControl, x, y, color, interceptflag)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test runRobustCrossValidation' ,{
        expect_equal(dim(obj), dim(results))
        expect_equal(length(obj), length(results))
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }

  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestrunRobustCrossValidation(cvRobust, robust_x, robust_y,color1,F,rrbCV)


lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n runRobustCrossValidation() test starts \n",
                                                                x, "runRobustCrossValidation() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n runRobustCrossValidation() test starts\n", x, "\n runRobustCrossValidation() test ends\n\n")))
  }
})

 ### end of runRobustCrossValidation() test

# Testing function runGAMCrossValidation()
TestrunGAMCrossValidation <-  function(trainingData,predictedVariable,smoothListCol,gamWithIntercept,color1,cvK,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-runGAMCrossValidation(trainingData,predictedVariable,smoothListCol,gamWithIntercept,color1,cvK)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test runGAMCrossValidation' ,{
        expect_equal(dim(obj), dim(results))
        expect_equal(length(obj), length(results))
        
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }

  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestrunGAMCrossValidation(trnData,predVar,smLCol ,  gamWIn,color1,cvK,rGamCV)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n runGAMCrossValidation() test starts \n",
                                                                x, "runGAMCrossValidation() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n runGAMCrossValidation() test starts\n", x, "\n runGAMCrossValidation() test ends\n\n")))
  }
 })

## end of runGAMCrossValidation() test

# Testing function generateDistributionPlot()
TestgenerateDistributionPlot <-  function(data, indexes, predVariable, color, secColor, mode,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-generateDistributionPlot(data, indexes, predVariable, color, secColor, mode)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test generateDistributionPlot' ,{
        expect_equal(
          names(obj), names(results)
        )
        expect_equal(
         length(obj), length(results)
        )
        expect_equal(
          dim(obj), dim(results)
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestgenerateDistributionPlot(data1,indx,"pred",color1,color2,mode,gDisPlot)


lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n generateDistributionPlot() test starts \n",
                                                                x, "generateDistributionPlot() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n generateDistributionPlot() test starts\n", x, "\n generateDistributionPlot() test ends\n\n")))
  }
})

## end of generateDistributionPlot() test
# Testing function columnalign()
Testcolumnalign <-  function(x,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-columnalign(x)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test columnalign' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- Testcolumnalign(trnData,CAlign)


lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n columnalign() test starts \n",
                                                                x, "columnalign() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n columnalign() test starts\n", x, "\n columnalign() test ends\n\n")))
  }
})

### end of columnalign() test

# Testing function avgColor()
TestavgColor <-  function(primaryColor, secondaryColor,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-avgColor(primaryColor, secondaryColor)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test avgColor' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestavgColor(color1, color2,AvgCol)


lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n avgColor() test starts \n",
                                                                x, "avgColor() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n avgColor() test starts\n", x, "\n avgColor() test ends\n\n")))
  }
})

### end of avgColor() test

# Testing function obtainSplitIndices()
TestobtainSplitIndices <-  function(dataset, k,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-obtainSplitIndices(dataset, k)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test obtainSplitIndices' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestobtainSplitIndices(dataset, 3,obsplIn)


lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n obtainSplitIndices() test starts \n",
                                                                x, "obtainSplitIndices() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n obtainSplitIndices() test starts\n", x, "\n obtainSplitIndices() test ends\n\n")))
  }
})

### end of obtainSplitIndices() test

# Testing function obtsinDataSplit()
TestobtsinDataSplit <-  function(dataset, k, kseq,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-obtsinDataSplit(dataset, k, kseq)
  # Test 1
  error <- tryCatch(
    {
      test_that( 'Test obtsinDataSplit' ,{
        expect_equal(
          obj, results
        )
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestobtsinDataSplit(data1, 3,1,obdatasplt)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n obtsinDataSplit() test starts \n",
                                                                x, "obtsinDataSplit() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n obtsinDataSplit() test starts\n", x, "\n obtsinDataSplit() test ends\n\n")))
  }
})

### end of obtsinDataSplit() test
# Testing function RandomForestVariableImportance()

TestRandomForestVariableImportance <-  function(input.data,dependent.variable,independent.variables,numTrees,mTry,minNodeSize,
                                                splitRule,Importance,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-RandomForestVariableImportance(input.data,dependent.variable,independent.variables,numTrees,mTry,minNodeSize,
                                       splitRule,Importance)
  error <- tryCatch(
    {
      test_that( 'Test RandomForestVariableImportance' ,{
        expect_equal(names(obj), names(results))
        expect_equal(dim(obj), dim(results))
        expect_equal(length(obj), length(results))
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function


result <- TestRandomForestVariableImportance(rfdata,"Compet_Occupancy",names(rfdata[2:31]),100,5,5,"variance","impurity",RFVarImp)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n RandomForestVariableImportance() test starts \n",
                                                                x, "RandomForestVariableImportance() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n RandomForestVariableImportance() test starts\n", x, "\n RandomForestVariableImportance() test ends\n\n")))
  }
})

### end of RandomForestVariableImportance() test

#Testing function runShrinkCrossValidation()
TestrunShrinkCrossValidation <-  function(x,y,color,cvControl,results)
{
  failedTests <- list()
  set.seed(50)
  obj <-runShrinkCrossValidation(x,y,color,cvControl)
  error <- tryCatch(
    {
      test_that( 'Test runShrinkCrossValidation' ,{
        expect_equal(names(obj), names(results))
          expect_equal(dim(obj), dim(results))
          expect_equal(length(obj), length(results))
        
      })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }

  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- TestrunShrinkCrossValidation(shr_x,shr_y,color1,cvRobust,rshrCV)

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n \n runShrinkCrossValidation() test starts \n",
                                                                x, "runShrinkCrossValidation() test ends \n \n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\n runShrinkCrossValidation() test starts\n", x, "\n runShrinkCrossValidation() test ends\n\n")))
  }
})

### end of runShrinkCrossValidation() test
