library(devtools)
library(shiny)
library(shinyjs)
library(shinyBS)
library(knitr)
library(DT)
library(dplyr)
library(ggplot2)
library(rJava)
library(RPostgreSQL)
library(RMySQL)
library(RSQLite)
library(lubridate)
library(data.table)
library(DBI)
library(RJDBC)
library(httr)
library(rjson)
library(zip)
library(plyr)
# library(odbc)

workflowTables <- NULL
inTables <- list(tables=list(), tableNames=c())
input <- NULL
fileCounter <- 1
tableCounter <- 1
tableNameColFlag <- 0

rUpdate <- list(calColsAutosave=0,
                          ruleListAutosave=0,
                          submitQueryUpdate=0,
                          calColsTable=0,
                          dupsTable=0,
                          missingValueTable=0,
                          colCheckTable=0,
                          hierarchyCheckTable=0,
                          panelCompTable=0,
                          dataManipulationTable=0,
                          queryTable=0,
                          updateInputData=0
)

defaultConnParams <- list( #---Store the connection paramters in global variable
  dbButton1 = "postgres",
  dbName = "test",
  dbName1 = NULL,
  dbHost = "172.25.1.30",
  dbPort = "5432",
  dbUsername = "postgres",
  dbPassword = "postgres",
  dbTable = "qc_brick_test_hotel",
  dbDriverLocation = NULL,
  dbDriverClass = NULL,
  driverOptions = 0,
  connectionString = NULL,
  connectionMethod = "jdbc")




uploadedQueries_func <- function(path,queryData){
  #print('Uploading Rule List File')
  #print(path)
  tryCatch({
    uploadedDat <- read.csv(path,header=T,stringsAsFactors = F)
    requiredCols <- c('Filters','GroupBy','Column','Function','Operation','Argument','Result','Value','Run','caseSensitive','Remarks')
    dim <- dim(uploadedDat)
    condition <- (dim[2]>=length(requiredCols)) & (dim[1]>0) & 
      !(FALSE %in% (requiredCols %in% colnames(uploadedDat)))
    if(!condition){
      #showNotification('Incorrect File!',type='error')
      return(list(data=NULL,error='Incorrect File!',message=''))
    }
    
    newColumns <- c('Comparison','TableName','JoinKeys','caseInsensitive','commentRule')
    newColumnsDefault <- c('0','','',FALSE,'')
    
    for(i in 1:length(newColumns)){
      if(!newColumns[i] %in% colnames(uploadedDat))
        uploadedDat[newColumns[i]] <- newColumnsDefault[i]
    }
  
    requiredCols <- c(requiredCols,newColumns)
    
    #print("Check Point utils 6")
    # If function is '' replace with 'none' and if '_' replace with 'column'
    uploadedDat <- uploadedDat[,requiredCols]
    uploadedDat <- data.frame(lapply(uploadedDat,FUN=function(x){gsub('"','',x)}),stringsAsFactors = F)
    uploadedDat <- uploadedDat %>% mutate(Function=ifelse(Function %in% c('','_'),ifelse(Function == '','none','column'),Function),
                                          Operation=ifelse(Operation=='','none',Operation)) %>% select_at(vars(one_of(requiredCols))) #select(Filters,GroupBy,Column,Function,Operation,Argument,Result,Value,Run,Comparison,TableName,JoinKeys)
    #print("Check Point utils 7")
    uploadedDat$Result <- ''
    uploadedDat$Value <- ''
    uploadedDat$Run <- '0'
    uploadedDat$Command <- ''
    
    queryData <- queryData %>% filter(row.names(queryData) < 0)
    queryData <- rbind(queryData,uploadedDat)
    #print("Check Point utils 8")
    return(list(data=queryData,error='',message=message))
    
  },error=function(e){
    #showNotification(e[1],type='error')
    return(list(data=NULL,error=e[1],message=''))
  })
}


connect <- function(cParams){
  
  dbButton1 <- cParams$dbButton1
  dbName <- cParams$dbName
  dbName1 <- cParams$dbName1
  dbHost <- cParams$dbHost
  dbPort <- as.integer(cParams$dbPort)
  dbUsername <- cParams$dbUsername
  dbPassword <- cParams$dbPassword
  dbTable <- cParams$dbTable
  dbDriverLocation <- cParams$dbDriverLocation
  dbDriverClass <- trimws(cParams$dbDriverClass)
  driverOptions <- cParams$driverOptions
  connectionString <- trimws(cParams$connectionString)
  connectionMethod <- trimws(cParams$connectionMethod)
  
  if(tolower(connectionMethod) == "jdbc"){
    
    #print("Trying to establish JDBC connection...")
    
    tryCatch({
      if(driverOptions==1){
        cp <- list.files(dbDriverLocation, pattern = "[.]jar", full.names=TRUE, recursive=TRUE)
        driver <- JDBC(dbDriverClass,cp,identifier.quote='`')
      } else {
        driver <-  switch(dbButton1
                          ,'sqlite_db'= RSQLite::SQLite()
                          ,'mysql_db'= RMySQL::MySQL()
                          ,'postgres'= RPostgreSQL::PostgreSQL()
                          ,NULL
        )
      }
      
      if(is.null(driver)){
        #showNotification('JDBC driver not available. Please provide the location of JDBC driver and Class manually')
        return(list(NULL,'JDBC driver not available. Please provide the location of JDBC driver and Class manually'))
      }
      
      #print('Loading DB driver')
      
      my_db <- switch(dbButton1
                      ,'sqlite_db' = dbConnect(driver,dbName1)
                      ,'mysql_db' = dbConnect(driver,url='jdbc:mysql://',
                                              port=dbPort,host=dbHost,dbname=dbName,password=dbPassword,user=dbUsername)
                      ,'postgres' = dbConnect(driver,paste0("jdbc:postgresql://",''),
                                              port=dbPort,host=dbHost,dbname=dbName,password=dbPassword,user=dbUsername)
                      ,'sql_server' = {
                        dbConnect(drv=driver,url=paste0('jdbc:sqlserver://',dbHost,":",dbPort),user=dbUsername,password=dbPassword)
                        
                      }
                      ,'teradata' = dbConnect(driver,paste0('jdbc:teradata://',dbHost,',DATABASE=',dbName), password=dbPassword,user=dbUsername)
                      ,'oracle'= {
                        #require(ROracle)
                        # connect.string <- paste("(DESCRIPTION=","(ADDRESS=(PROTOCOL=tcp)(HOST=", dbHost, ")(PORT=", dbPort, "))"
                        #                       ,"(CONNECT_DATA=(SID=", sid, ")))", sep = "")
                        #con1 <- dbConnect(driver, user = dbUsername, password = dbPassword, dbname=connect.string)
                        con1 <- dbConnect(driver, url=paste0("jdbc:oracle:thin:@//",dbHost,":",dbPort,"/",dbName), dbUsername, dbPassword)
                        con1
                      }
                      ,'netezza'= {
                        dbConnect(driver, paste0("jdbc:netezza://",dbHost,":",dbPort,"//",dbName), user=dbUsername, password=dbPassword)
                      }
                      ,'hive'= {
                        str <- paste0("dbConnect(driver,url='",connectionString,"',user='",dbUsername,"',password='",dbPassword,"')")
                        
                        con <- eval(parse(text=str))
                        con
                      }
                      ,'other'= {
                        str <- paste0("dbConnect(driver,url='",connectionString,"',user='",dbUsername,"',password='",dbPassword,"')")
                        
                        con <- eval(parse(text=str))
                        con
                      }
      )
      
      #print("Success!")
      return(my_db)
    }
    ,error = function(e){
      #showNotification(paste('DB error:',e[1]),type='error');
      print(paste("Error in connecting to database",e))
      return(NULL)
    })
  }else{
    tryCatch({
      
      #print('Trying to establish ODBC connection...')
      
      my_db <- switch(dbButton1,
                      'hive'= {
                        str <- paste0("dbConnect(odbc::odbc(), dsn =\"",as.character(connectionString),"\", uid =\"",dbUsername, "\", pwd =\"",dbPassword,"\")")
                        
                        con <- eval(parse(text=str))
                        con
                      }
                      ,'other'= {
                        str <- paste0("dbConnect(odbc::odbc(), dsn =\"",as.character(connectionString),"\", uid =\"",dbUsername, "\", pwd =\"",dbPassword,"\")")
                        
                        con <- eval(parse(text=str))
                        con
                      }
      )
      #print("Success!")
      return(my_db)
    }
    ,error = function(e){
      #showNotification(paste('DB error:',e[1]),type='error')
      print(paste('Error in establishing connection!',e))
      return(NULL)
    }
    )
  }
}

inputDataSet_func <- function(mode="csv", datapath = "", tableName="hotel", connectionParams=defaultConnParams, queryData){
  tryCatch({
    #print('Collating inputs')
    queryData <<- queryData %>% filter(row.names(queryData) <0)
    
    if(mode!='csv'){ # FOR DB --------------------------------
      connectionObj <- connect(connectionParams)
      
      if(is.null(tableName)) return()
      if(is.null(connectionObj)) return()
      
      conList <- list(con=connectionObj,db=connectionParams$dbButton1)
      
      tryCatch({
        dbUpdateWrapper(conList, paste0('DROP TABLE IF EXISTS qcTempManTable_',gsub('-','',as.Date(Sys.time()))))
        dbUpdateWrapper(conList, paste0('DROP TABLE IF EXISTS qcTempTable_',gsub('-','',as.Date(Sys.time()))))
        
      }, error = function(e){
        
        print(paste("Error in dropping temporary tables",e))
      })
      
      inputTables <- readInputTables(mode="db", datapath=datapath, connectionObj, connectionParams)
      tableName <- inputTables$tables[[1]]$name
      conList <- list(con=connectionObj,table=tableName,db=connectionParams$dbButton1)
    }
    else{ # FOR CSV --------------------------------
      # browser()
      inputTables <- readInputTables(mode="csv", datapath=datapath, connectionObj, connectionParams)
      dat <- inputTables$tables[[1]]$data
      conList <- list(con=NULL,table=dat,db=NULL)
    }
    # else return()
    
    if(is.null(conList$table)) {
      return()
    }
    #inDataReactive$mainData <- conList
    #print('Done Collating')
    return(list(connList=conList, inputTables=inputTables))
  },error=function(e) 
  {
    print(c("Error in reading input dataset",e))
  })
}

inDataType_func <- function(conList){
  if(is.null(conList$con)){ # CSV --------
    dat <- conList$table
  }
  else { # DB  ---------
    fn <- function(){tryCatch(dbFetchTop(conList),error=function(e){message(e[1])})}
    dat <- fn()
    #inDataHead <<- dat
  }
  
  if(is.null(dat)) return(NULL)
  dat <- collect(head(dat,n=10))
  
  dtypes <-unlist(lapply(lapply(dat,class),function(x){return(x[1])}))
  data.frame(col=colnames(dat),dataType=dtypes,stringsAsFactors = F)
}


tableExistsCheck <- function(connObj, connParams, counter){
  if(length(connParams$dbTable) == counter){
    for(tableName in connParams$dbTable){
      name <- trimws(tableName)
      flag <- dbExistsTableWrapper(connObj,name)
      if(!flag){
        paste(paste0('Table Does Not Exist : ',name),type='error')
        return(FALSE)
      }
    }
    return(TRUE)
  }else{
    print("The connection parameters did not contain the number of tables required to run this workflow")
    return(FALSE)
  }
}

clearResults <- function(con){
  if(class(con)=='SQLiteConnection') return()
  if(is.null(DBI::dbGetInfo(con)$odbcdriver)){
    if(dbResultLen(con)){
      dbClearResult(dbListResults(con)[[1]])
    }
  }else{
    return()
  }
}

##----------------------------------------->>>>
##---------------------->> DB COLUMN FUNCTIONS

dbCreateNewCol <- function(data,table,newCol,newColType){
  con <- data$con
  #print(c('Altering table \'',table,'\' to add new column ',newCol, ' of type ', newColType))
  tryCatch({
    
    dbUpdateWrapper(data,paste('ALTER TABLE',table,'ADD',newCol,newColType))
    
  }, error = function(e){
    
    print(paste("Error in creating new column",e))
  })
  
  clearResults(con)
}


dbCalculatedCol <- function(data,table,connDb,newColName,expression,coln){ 
  con<-data$con
  # Wrap column names in double quotes in the expression for calculated columns
  #Dynamically compute the datatype of the calculated column
  #print('Creating Derived Columns')
  #print(paste0('expression',expression))
  #print(paste('Computing new column : ',newColName))
  coln <- tolower(coln)
  
  if(!tolower(newColName) %in% coln){  #-- Create new column if colname does not exist already.
    query <- dbTableTopQuery(list(con=con,table=table,db=connDb))
    dat <- dbColumnInfo(dbSendQuery(con,paste("select",expression," as newcol from (" ,query, ") a")))
    #print(c("ColumnInfo: ", dat))
    clearResults(con)
    colType <- as.character(dat[1,"type"])
    dbCreateNewCol(data,table,newColName,colType) #--Create the new column
    clearResults(con)
  }
  #Update the new column with the computed values
  tryCatch({
    val <- dbUpdateWrapper(data,paste("UPDATE",table,"SET",newColName,"=",expression))
    
  }, error = function(e){
    
    print("Error in creating new column in database",e)
  })
  
  clearResults(con)
  #print(c("DB Calculated col returned: ", val))
  return(val)
}


#--Drop columns
dbDropColumns <- function(conList,table,colNames){
  con <- conList$con
  #print(paste('Dropping columns : ',colNames))
  tryCatch({
    invisible(sapply(colNames,FUN=function(colName)
    {
      dbUpdateWrapper(conList,paste("ALTER TABLE",table,"DROP COLUMN",colName))
    }))
    
  }, error = function(e){
    
    print(paste("Error in dropping column",e))
  })
  
}


dbKeepColumns <- function(conList,table,connDb=connDb,colNames){
  #head <- dbGetQuery(con,paste('SELECT * FROM',table,'LIMIT 10'))
  head <- dbFetchTop(list(con=con,table=table,db=connDb))
  colnames <- colnames(head)
  removeCols <- setdiff(colnames,colNames)
  dbDropColumns(conList,table,removeCols)
}


##------------------<<
# 
# dbChoices <- c('SQLite'='sqlite_db'
#                ,'MySQL'='mysql_db'
#                ,'PostgreSQL'='postgres'
#                ,'Oracle'='oracle'
#                ,'SQL server'='sql_server'
#                ,'Teradata'='teradata'
#                ,'Netezza'='netezza'
#                ,'Other'='other')

##-------DB TOP 10 ROWS FUNCTIONS------>>
dbExistsTableWrapper <- function(connectionObj, tableName){
  flag <- FALSE
  tableName <- trimws(tableName)
  if(is.null(DBI::dbGetInfo(connectionObj)$odbcdriver)){
    flag <- trimws(tableName) %in% DBI::dbListTables(connectionObj)
  }else{
    if(tolower(DBI::dbGetInfo(connectionObj)$dbms.name)=="hive"){
      result <- odbc::dbGetQuery(connectionObj, "show tables")
      flag <- tableName %in% result[[1]]
    }
  }
  #print(flag)
  return(flag)
}


dbTableTopQuery <- function(conList,n=10){
  #print(paste("Printing top 10 rows from table",conList$table))
  conDB <- as.character(class(conList$con))
  query <- switch(conList$db#connectionParams$dbButton1
                  ,'oracle'={
                    paste('select * from',conList$table,' where rownum <=',n)
                  }
                  ,'mysql_db' = ,'postgres' = paste('select * from',conList$table,'limit',n)
                  ,'sql_server' = ,'teradata' = paste('select top',n,' * from', conList$table)
                  ,paste('select * from', conList$table,'limit',n)
  )
  return(query)
}

dbTableTop <- function(conList,n=10){
  query <- dbTableTopQuery(conList,n)
  dbSendQuery(conList$con,query)
}

dbFetchTop <- function(conList,n=10){
  con <- conList$con
  if(!class(con)=="SQLiteConnection") clearResults(conList$con)
  res <- dbTableTop(conList,n)
  dat <- dbFetch(res,n=n)
  if(!class(con)=="SQLiteConnection") clearResults(conList$con)
  dat
}

##-->> A wrapper to dbFetchTop  
dbFetchTopWrapper <- function(conList,n=10){
  fn <- function(){
    tryCatch(dbFetchTop(conList,n)
             ,error=function(e){message(e[1])})
  }
  dat <- fn()
}

##-->> A wrapper for update statement execution based on driver and flavor
dbUpdateWrapper <- function(conList, statement){
  con <- conList$con
  db <- conList$db
  #print(c('Executing Update/Alter statement : ',statement))
  # dbExecute(con, statement)
  
  if(is.null(DBI::dbGetInfo(con)$odbcdriver)){
    if(db == 'hive'){
      
      dbSendUpdate(con, statement)
      
    }else{
      DBI::dbExecute(con, statement)
      
    }
  }
  #Using ODBC driver
  else{
    #print('Using ODBC driver...')
    ret <- odbc::dbGetQuery(con,statement)
    # print (c('Returned: ',ret))
  }
}

dbResultLen <- function(con){
  if(is.null(DBI::dbGetInfo(con)$odbcdriver)){
    return(length(dbListResults(con)))
  }
  else{
    return()
  }
}
##------------------<<


readInputTables <- function(mode="csv", datapath, connectionObj, connectionParams=defaultConnParams){
  inputTables <- list(tables=list(), tableNames=c())
  #print('Reading inputs')
  counter <- ifelse(mode =='csv',fileCounter,tableCounter)
  
  if(mode=='csv'){
    #print('Reading local input datasets')
    if(is.null(input$file1)){
      print("This workflow seems to be configured for databases but CSV was selected. Exiting!")
      return(NULL)
    }
    connObj <<- NULL
    connDb <<- NULL
    
    #iterate over datapath instead of counter; datapath is now a single string, make it a list instead
    for(i in 1:counter){
      # name <- input[[paste0('file',i)]]$name
      # if(is.null(name)){
      #   print("No such file")
      #   return()
      #   }
      alias <- LETTERS[i]
      path <- datapath
      name <- basename(datapath)

      #print(paste("Data Path:", path))
      # data <- read.csv(path,stringsAsFactors = F)
      data <- as.data.frame(fread(path,stringsAsFactors = F,header = T),stringsAsFactors = F)
      #print("File read complete")
      colnames(data)<-make.names(colnames(data))
      #print("Preparing data frame...")
      cols <- colnames(data)
      dim <- dim(data)
      #print("Reading data type")
      dataTypes <- inDataType_func(list(con=NULL,table=data,db=connDb))
      head <- head(data,n=10)
      keyCols <- ''
      
      #print("creating table...")
      inputTables$tables[[i]] <- list(name=name,alias=alias,path=path,data=data,cols=cols,dim=dim,dataTypes=dataTypes,keyCols=keyCols,head=head)
      # reactData$reportTableData[[i]] <<- list(name=name,data=head,dim=dim,dataTypes=dataTypes)
      
    }
  } else {
    #print('Reading DB inputs')
    connDb <- connectionParams$dbButton1
    
    if(counter>0){
      if(!tableExistsCheck(connectionObj, connectionParams, counter)) return()
    }
    tableNameList <- connectionParams$dbTable
    i <- 1
    for(tableName in tableNameList){
      name <- trimws(tableName)
      if(name=='') return()
      alias <- LETTERS[i]
      #print(paste("Loading table",name, "from DB"))
      conList <- list(con=connectionObj,table=name,db=connDb)
      path <- NULL
      data <- name
      head <- dbFetchTopWrapper(conList) # Head here will only have top 10 rows of the table
      cols <- colnames(head)
      dim <- c('',length(cols))
      dataTypes <- inDataType_func(conList)
      keyCols <- ''
      
      inputTables$tables[[i]] <- list(name=name,alias=alias,path=path,data=data,cols=cols,dim=dim,dataTypes=dataTypes,keyCols=keyCols,head=head)
      # reactData$reportTableData[[i]] <- list(name=name,data=head,dim=dim,dataTypes=dataTypes)
      
    }
  }
  inputTables$tableNames <- unlist(lapply(inputTables$tables,function(x) x$name))
  names(inputTables$tableNames) <- LETTERS[1:counter]
  names(inputTables$tables) <- LETTERS[1:counter]
  return(inputTables)
}

getMetafileNames <- function(tempLoc){
  files <- dir(tempLoc)
  metaFiles <- grepl('metaFile',files) # logical vector
  if(any(metaFiles)){
    metaFiles <- data.frame(Metafiles = sort(files[metaFiles]),stringsAsFactors = F) # take only the ones that are TRUE
  } else { metaFiles <- data.frame(Metafiles=character())}
  return(metaFiles)
}



getRuleListTableNames <- function(queryData1){
  
  queryData1 <- queryData1 %>% filter(Comparison=='1')
  # Get Alias
  colBreak <- data.frame(do.call(rbind,lapply(queryData1$Column,function(x)strsplit(x,';')[[1]][c(2)])),stringsAsFactors = FALSE)
  colnames(colBreak) <- c('Alias1')
  colBreak$Alias_In_Rule_List <- trimws(unlist(sapply(colBreak$Alias1,function(x){strsplit(x,'\\.')[[1]][1]})))
  # Get Table Names 
  tableBreak <- data.frame(do.call(rbind,lapply(queryData1$TableName,function(x)strsplit(x,';')[[1]][c(1,2)])),stringsAsFactors = FALSE)
  colnames(tableBreak) <- c('table1Name','Table_Name')
  tableBreak <- tableBreak %>% filter(!is.na(Table_Name))
  # Join Alias and TableNames
  colBreak <- unique(cbind(colBreak[,'Alias_In_Rule_List',drop=FALSE],tableBreak[,'Table_Name',drop=FALSE]))
  if(!'A' %in% colBreak$Alias_In_Rule_List) colBreak <- rbind(colBreak,c('A',trimws(tableBreak[1,1]))) # hardcoding of [1,1] 
  
  colBreak <- colBreak %>% filter(!is.na(colBreak$Table_Name)) %>% select(Table_Name,Alias_In_Rule_List) %>% arrange(Alias_In_Rule_List) %>% unique
  
  return(colBreak)
  
}

workFlowInput <- function(workflowPath){
  
  tryCatch({
    
    #print("Processing workflow input")
    # output$workflowText <- renderPrint({''})
    wPath <- workflowPath # Read uploaded zip path
    
    if(!dir.exists('../Downloads/Automation'))
      dir.create('../Downloads/Automation')
    
    tempLoc <- './Downloads/Automation/temp/'
    tempLocDir <- './Downloads/Automation/temp'
    
    
    if(dir.exists(tempLocDir))
      unlink(tempLocDir,recursive = TRUE) # Delete directory
    dir.create(tempLocDir) # Create directory
    
    unzip(wPath, exdir=getwd(), overwrite = TRUE)
    
    if(!file.exists(paste0(tempLoc,'Rule_list.csv'))){
      print('Rule_list.csv missing!')
      return()
    }
    
    
    uploadPath <- paste0(tempLoc,'Rule_list.csv')
    
    #print(c("Reading Rules from ",uploadPath, "..."))
    queryData1 <- read.csv(uploadPath, stringsAsFactors = F) 
    #print("Read sucess!")
    queryData1 <- data.frame(lapply(queryData1,FUN=function(x){gsub('"','',x)}),stringsAsFactors = F)
    #print("Replaced \" with  \" \" ")
    
    #print(c("is.na(as.numeric(queryData1$Comparison)))",(is.na(as.numeric(queryData1$Comparison)))))
    
    if(!is.na(as.numeric(queryData1$Comparison))){
      if(sum(as.numeric(queryData1$Comparison))>0)
      {   
        #If TRUE  => Rule list contains Multiple Dataset Comparison
        #print("Rule List contains multiple dataset comparison")
        
        if(!'TableName' %in% colnames(queryData1)) return()
        
        tableNameColFlag <<- 1
        colBreak <- getRuleListTableNames(queryData1)
        workflowTables <<- colBreak
        #print(c("Workflow Tables:", workflowTables))
        
        ## Check for presence of metaFiles
        metaFiles <- getMetafileNames(tempLoc)
        
      }
    }
    
    return(queryData1)
  },error=function(e){print(paste("Error in reading the workflow file",e))})
}

metaFileLoad <- function(varTypeFile, dataset){
  alertNoMetaFile <- ""
  typeFileErrorText <- ""
  typeFileErrorTable <- ""
  typeColumnErrorText <- ""
  if (is.null(varTypeFile))
  {
    typeData <- data.frame("Column"=colnames(dataset))
    typeData$Column.Type <- unname(lapply(dataset,function(x){CheckColumnType(x,2) }))
    alertNoMetaFile <- "NOTE: Upload a relevant meta file mentioning the variable types to be typecasted. 
    The Data Wrangling brick can be used to generate such meta files."
  }else
  {
    alertNoMetaFile <- ""
    typeData <- read.csv(varTypeFile$datapath, stringsAsFactors = FALSE)
    typeData <- typeData[which(typeData$Column %in% colnames(dataset)),]
    if(any(!(typeData$Column.Type %in% c("numeric","factor","character","Date"))))
    {
      typeFileErrorText <- "Error : Invalid type specified. Valid types : numeric, character, Date"
      typeFileErrorTable <- data.frame("Column"=c("SampleColumnName1", "SampleColumnName1","SampleColumnName1"),
                                       "Column.Type"=c("numeric", "factor","character"),
                                       "Reference.Level"=c(NA,"Yes","Male"))
    }
    if(!all(colnames(dataset) %in% typeData$Column))
    {
      typeColumnErrorText <- "Error : The variable type csv does not have entries for all columns of the dataset"
    }
  }#end of if varFileType exists
  return(list(typeData=typeData, colErr=typeColumnErrorText, typeErrorText=typeFileErrorText, 
              typeErrorTable<-typeFileErrorTable, noMetaAlert=alertNoMetaFile))
}

runOptions <- function(qData,runOption){
  
  
  switch(runOption,
         'Run Selected'={
           rows <- input$queryTable_rows_selected
           #print(rows)
           if(length(rows)==0) {
             # showNotification('No Rows Selected!',type='warning')
             return(NULL)
           }
           qData[rows,'Run'] <- '0'
           qData[-rows,'Run'] <- '1'
           qData
         }
         ,'Run All'={
           qData[,'Run'] <- '0'
           qData
         }
         ,'Run Newly Added'={
           qData
         }
         ,qData)
}


#-- Transforming the input parameters based on the input type selected : CSV/ DB
#-- Converts parameters to make them compatible with the platform on which it is running: R/ SQL Database
paraTransform <- function(connType,filters,groupby,funcSel,operationSel,argValue,colSel,tableAlias){
  #print('Transforming Parameters')
  filters <- trimws(filters)
  groupby <- trimws(groupby)
  funcSel <- trimws(funcSel)
  operationSel <- trimws(operationSel)
  argValue <- trimws(argValue)
  
  
  #-- Treat inputs parameters based on CSV or DB connection.
  if(is.null(connType)){ # -- CSV --
    if(trimws(operationSel) %in% c('between')){
      argValue <-  eval(parse(text=paste0('c(',paste0(gsub('\\(|\\)','',unlist(strsplit(argValue,','))),collapse=','),')')))
    }
    else #if(trimws(operationSel) %in% c('in','not in','='))
    {
      if(!funcSel %in% c('column','data type','has unique'))
        argValue <- eval(parse(text=paste0('c(',paste0(unlist(strsplit(argValue,',')),collapse=','),')')))
    }
    
    operationSel <- ifelse(operationSel=='=','==',operationSel)
    operationSel <- ifelse(operationSel=='in','%in%',operationSel)
    funcSel <- ifelse(funcSel=='avg','mean',funcSel)
    
    if(!(is.na(funcSel) | is.null(funcSel))){
      #-- Column Comparison case - transforming parameters
      if(funcSel=='column'){ 
        filters <- paste(if(filters!='') paste(filters,' & '),'!',colSel,operationSel,argValue)
        funcSel <- 'count'
        operationSel <- '=='
        argValue <- 0
        groupby <- ''
      } else if(funcSel=='has.unique'){
        argValue <- 0
        operationSel <- '=='
      } else {
        # if(!trimws(operationSel) %in% c('in','not in','between')) 
        # argValue <- eval(parse(text=argValue))
      }
      
    }else{
      funcSel <- "none"
    }
  } else { # -- DB ---
    operationSel <- ifelse(operationSel=='==','=',operationSel)
    operationSel <- ifelse(operationSel=='%in%','in',operationSel)
    funcSel <- ifelse(funcSel=='mean','avg',funcSel)
    funcSel <- ifelse(funcSel=='string length','length',funcSel)
  }
  
  return(list(filters,groupby,funcSel,operationSel,argValue))
}

#-- Treating inputs based on comparison type : Multiple File QC or Single File QC
#-- Inputs from Rule creation section are captured differently for Single Dataset and Multiple Dataset comparison cases.
#-- This function treats for the inconsitencies

inputTreatment <- function(connType,filters,groupby,colSel,funcSel,operationSel,argValue,comparison,joinKeys,inTables){
  #print('Treating Parameters')
  #-- Split paramters on  ';' to separate parameters for either datasets
  #-- If query involves comparison, the paramters are split on ';' to correspond to LHS and RHS  datasets
  if(comparison==1){  
    filters <- trimws(unlist(strsplit(filters,";")))
    groupby <- trimws(unlist(strsplit(groupby,";")))
    operationSel <- trimws(unlist(strsplit(operationSel,";")))
  } else { #-- If query does not involve comparison, the values for second table will be ''
    filters <- c(filters,'')
    groupby <- c(groupby,'')
    operationSel <- c('',operationSel)   
  }
  
  #-- Get alias of secondary dataset
  colSel <- trimws(unlist(strsplit(colSel,";"))) 
  loc <- gregexpr('\\.',colSel[2])[[1]][[1]]  
  table2Alias <- substring(colSel[2],1,loc-1)
  colSel[2] <- substring(colSel[2],loc+1,nchar(colSel[2]))
  
  funcSel <- trimws(unlist(strsplit(funcSel,";")))
  funcSel <- ifelse(trimws(funcSel==''),'none',funcSel)
  
  if(length(funcSel)==1) funcSel <- trimws(c(funcSel,''))
  
  
  #--- PARAMETER TRANFORMATION ---------------------------------------------------------------
  #-- Transform input parameters according to data connection type: CSV or DB
  #-- Break down the filter string to get filters for left and right tables
  filterDT <- matrix(unlist(strsplit(trimws(filters[1]),'\\t')),ncol=4,byrow=TRUE)
  filterDT[nrow(filterDT),4] <- NA
  filters[1] <- paste(apply(filterDT,1,function(x)filterTransform(x,tableAlias='A',connType,inTables)),collapse=" ")
  paraTransform1 <- paraTransform(connType,filters[1],groupby[1],funcSel[1],operationSel[2],argValue,colSel[1],tableAlias='A')
  
  if(comparison==1){ 
    #-- Break down the filter string to get filters for left and right tables
    filterDT <- matrix(unlist(strsplit(trimws(filters[2]),'\\t')),ncol=4,byrow=TRUE)
    filterDT[nrow(filterDT),4] <- NA
    filters[2] <- paste(apply(filterDT,1,function(x)filterTransform(x,tableAlias=trimws(table2Alias),connType,inTables)),collapse=" ")
    paraTransform2 <- 
      paraTransform(connType,filters[2],groupby[2],funcSel[2],operationSel[2],argValue,colSel[2],tableAlias=trimws(table2Alias))
  }
  else paraTransform2 <- as.list(rep('',5))
  
  filters <- c(paraTransform1[[1]],paraTransform2[[1]])
  groupby <- c(paraTransform1[[2]],paraTransform2[[2]])
  funcSel <- c(paraTransform1[[3]],paraTransform2[[3]])
  operationSel <- c(operationSel[1],paraTransform1[[4]]) # For now, arithmetic operator is ''
  argValue <- paraTransform1[[5]] # argValue will be a single value
  
  
  
  # Handling JOIN parameters ----------------------------------------------------------------
  #-- Extracting join keys and transforming input parameters accordingly
  jKeys <- list()
  lKeys <- NULL
  rKeys <- NULL
  
  if(comparison==1 & joinKeys!=''){
    jKeys <- unlist(strsplit(joinKeys,';'))
    lKeys <- trimws(unlist(strsplit(jKeys[1],',')))
    rKeys <- trimws(unlist(strsplit(jKeys[2],',')))
    jKeys <- lapply(c(1:length(lKeys)),function(i){ c(lKeys[i],rKeys[i])})
    
    if(groupby[1]=='')
      colSel[1] <- paste(c(lKeys,colSel[1]),collapse=',')
    if(groupby[2]=='')
      colSel[2] <- paste(c(rKeys,colSel[2]),collapse=',')
  }
  
  return(list(filters,groupby,colSel,funcSel,operationSel,argValue,table2Alias,jKeys))
}




# -- filterTransform handles all the differences in filter condition and syntax between CSV and DB
filterTransform <- function(x,tableAlias,connType,inTables){
  colList <- trimws(x[1])
  opList <- trimws(x[2])
  argList <- trimws(x[3])
  connector <- trimws(x[4])
  dtype <-subset(inTables$tables[[tableAlias]]$dataTypes,col==colList)[,'dataType']
  #dtype <- getColType(tableAlias,colList)
  #dtype <- ''
  
  conobj <- connType # Reading from global variable
  if(is.null(conobj)){
    cmdString <- switch(opList,
                        'between'= {
                          if(dtype=='Date'){
                            #format <- dateFormatDF %>% filter(dataName==tableAlias & colName==colList) %>% select(inputFormat)
                            format <- 'ymd'
                            vec <- gsub('\\(|\\)','',strsplit(argList,',')[[1]])
                            paste0('between(',colList,",",format,'(',vec[1],"),",format,'(',vec[2],'))')
                          } else {
                            vec <- as.numeric(gsub('\\(|\\)','',strsplit(argList,',')[[1]]))
                            paste0('between(',colList,",",vec[1],",",vec[2],')')
                          }
                        }
                        ,'in'=
                          ,'not in'= {
                            vec <- as.numeric(gsub('\\(|\\)','',strsplit(argList,',')[[1]]))
                            paste(if(opList == 'not in') '!','(',colList,'%in%','c(',argList,'))')
                          },'=' = {paste(colList,'==',argList)}
                        ,'like'= {paste0('grepl(',argList,',',colList,')')}
                        ,'not like'= {paste0('!grepl(',argList,',',colList,')')}
                        ,paste(colList,opList,argList)
    )
    return(paste(cmdString,if(!is.na(connector)) connector))
  }
  else {
    cmdString <- switch(opList,
                        'between'= {
                          vec <- as.numeric(gsub('\\(|\\)','',strsplit(argList,',')[[1]]))
                          paste(colList,'between',vec[1],'and',vec[2])
                        }
                        ,'in'=
                          ,'not in'= {
                            paste(colList,opList,'(',argList,')')
                          }, 
                        paste(colList,opList,argList)
    )
    
    connector <- gsub('&','AND',gsub('\\|','OR',connector))
    return(paste(cmdString,if(!is.na(connector)) connector))
  }
}


nullCheckSubmit_func <- function(inTables){
  if(length(inTables$tables)==0) return()
  
  tryCatch({
    cnDat <- nullCheckSubmit_func_main(list(table=inTables$tables[[1]]$data,con=connObj,db=connDb),inTables$tables[[1]]$cols)
    reactData$missingValueTable <- cnDat
    
  },error=function(e){
    print(paste("Error in null check", e))
    }
  )
}



nullCheckSubmit_func_main <- function(conList,cols){
  
  #conList <- list(con=connObj,table=inTable1)
  con <- conList$con
  if(is.null(conList$table)) return()
  
  #cols <- inDataReactive$cols
  
  if(is.null(con)){# CSV ----------
    cnDat <- data.frame(NA_Count = t(data.frame(lapply(conList$table,function(col){sum(is.na(col))}),stringsAsFactors = F)))
    cnDat$Column <- row.names(cnDat)
    cnDat <- cnDat[,c('Column','NA_Count')]
    cnDat <- cnDat[order(-cnDat$NA_Count),]
    
  } else {# DB -----------
    getTemplateString <- function(colName){paste0("sum(case when ",colName," is null then 1 else 0 end) as ",colName)}
    select1 <- paste(unlist(lapply(cols,getTemplateString)),collapse=",")
    query <- paste0('select count(*) as rowcnt, ',select1,' from ',conList$table)
    cnDat <- dbGetQuery(con,query)
    rowCnt <- cnDat$rowcnt[1]
    cnDat <- data.frame(t(cnDat),stringsAsFactors = F)
    colnames(cnDat) <- c('Null_Count')
    cnDat$column <- row.names(cnDat)
    cnDat <- cnDat[,c('column','Null_Count')]
    cnDat <- cnDat[cnDat$column!='rowcnt',]
    cnDat <- cnDat[order(-cnDat$Null_Count),]
  }
  
  return(cnDat)
  
}



levelCheckSubmit_func <- function(rinput=input){
  tryCatch({
    levelCols <- rinput$levelCols
    
    if(length(levelCols)==0) {
      showNotification('Level Columns Not Found',type='error')
      return()
    }
    #print('Checking For Duplicates.....')
    res <- duplicationCheck(levelCols,conList=list(table=inTables$tables[[1]]$data,con=connObj,db=connDb))
    #print(res)
    failsTable <- res$failsTable
    failsTable <- failsTable[order(-failsTable[,which(tolower(colnames(failsTable))=='row_count')]),]
    res <- res$res
    
    reactData$levelText <- ifelse(res,paste0('<pre>Columns : ',paste(isolate(rinput$levelCols),collapse=', '),'</br>Result : PASSED - No Duplicates Found</pre>'),paste0('<pre>Columns : ',paste(isolate(rinput$levelCols),collapse=', '),'</br>Result : FAILED - Duplicates Found</pre>'))
    
    
    reactData$dupsTable <- failsTable
    
  },error=function(e)showNotification(e[1],type='error'))
}



dataType <- function(data,col){
  val <- data[col,2,drop=F]
  colnames(val) <- c(paste0('data_type_',col))
  return(list('',val,''))}



# Wrapper function 
execSqlQuery <- function(conList,query){
  #print(c("Executing Query: ", query))
  table <- dbSendQuery(conList$con,query)
  result <- dbFetch(table)
  
  if(!class(conList$con)=="SQLiteConnection") clearResults(conList$con)
  
  #Format the output as required for JDBC and ODBC seperately
  if( (!is.null(DBI::dbGetInfo(conList$con)$odbcdriver)) & 
      (tolower(as.character(class(conList$con))) == "hive"))
  {
    #print("ODBC Hive detected")
    
    #Tests for purely numeric data, then does as.numeric on each element 
    #because as.numeric(result) was returning weird values for Hive database
    if(suppressWarnings(all(!is.na(as.numeric(as.character(result)))))){
      result[] <- lapply(result, as.numeric)
    }
    
  }
  #print(c("Result: ", result))
  return(result)
}



# creates arguments in FILTER statement
operationExpr <- function(funcSel,colSel,operationSel,argValue,where=0){
  if(funcSel=='has.unique') return('')
  expr <- switch(operationSel
                 ,'>'=,'>='=,'<'=,'<='=,'='=,'!='= paste(operationSel,argValue)
                 ,'in'=paste('in (',argValue,')')
                 ,'not in'=paste('not in (',argValue,')')
                 ,'between'={
                   vec <- as.numeric(gsub('\\(|\\)','',strsplit(argValue,',')[[1]]))
                   paste('between',vec[1],'and',vec[2]) 
                 }
                 ,'is'=,'is not'=paste(operationSel,argValue))
  return(paste0(ifelse(where,'where col',''),expr))
}

# creates arguments in GROUP BY statement
groupbycolsexpr <- function(groupbycols,funcSel){
  switch(funcSel
         ,'none'=''
         ,if(groupbycols!='') paste('group by',groupbycols) else '')
}



# Creates arguments in FILTER statement
filterExpr <- function(colSel,funcSel,filter){
  minor <- switch(funcSel
                  ,'count blanks'=paste(colSel," = '' ")
                  ,'count na'= paste(colSel,'is null'),'')
  complete <- paste(if(filter!='' | minor!= '') 'where ',filter,if(minor!='' & filter!='') 'and',minor)
  #complete <- ''
  return(complete)
}



# Creates arguemtns in SELECT statement
colExpr <- function(colSel,funcSel){
  #print('colexpr')
  str <- switch(funcSel
                ,'min'=,'max'=,'avg'=,'sum'=,'count'=,'length'= paste0(funcSel,'(',colSel,')')
                ,'count'=paste0('count','(',colSel,')')
                ,'count na'=paste0('count(*)')
                ,'count distinct'=paste('count( distinct',colSel,')')
                ,'count blanks'=,'count na'=paste('count(',colSel,')')
                ,'has.unique'=paste('count( distinct',colSel,')=count(*)')
                ,'none'=,'column'= colSel
  )
  
}


# Function that creates the SQL query for single dataset QC checks
createQuery <- function(conList,filters,groupby,colSel,funcSel,operationSel,argValue){
  #print('Evaluating query on db')
  
  #creating query that returns results similar t  o fplyr function in previous code
  tableName <- conList$table
  filter <- gsub('&','AND',gsub('\\|','OR',filters))
  groupbycols <- groupby
  opExpr <- operationExpr(funcSel,colSel,operationSel,argValue)
  #colSel <- colSel[length(colSel)] # iF more than 1 column are passed, take the last one as colSel, others will go to extraCols
  
  from <- paste('from', tableName)
  where <- filterExpr(colSel,funcSel,filter)
  groupby <- groupbycolsexpr(groupbycols,funcSel)
  select2 <- 'select col, count(*) as cnt '
  
  # final total query
  query <- ''
  res <- ''
  val <- ''
  
  #extraCols <- ifelse(groupbycols!='',groupbycols,ifelse(length(colSel)>1),paste(colSel[1:length(colSel)-1],collapse=", "))
  
  if(opExpr!='' | funcSel=='has.unique') 
  {
    select <- paste('select case when ',colExpr(colSel,funcSel),' ',opExpr,' then 1 else 0 end as col')
    query <- paste(select2,'from (',select,from,where,groupby,') sub where col = 0 group by col')
    
    res <- execSqlQuery(conList,query)
    if(nrow(res)==0) res<-data.frame()    ## No rows returned implies no FALSE conditions found.
    res <- res[res$col==0,2]
    res <- ifelse(is.null(res),TRUE,FALSE)
  }
  
  select <- paste('select (',colExpr(colSel,funcSel),') as col')
  query1 <- paste('select col ','from (',select,from,where,groupby,') sub')
  val0 <- execSqlQuery(conList,query1)
  
  val <- ifelse(nrow(val0)>1,'Mult. Rows',ifelse(nrow(val0)==0,'',val0[1,1]))

  if(val=='' & res==T){
    val <- 0
    if(!(argValue=='0' & (operationSel=='=' | operationSel=='<=' | operationSel=='>='))){
      res <- F
    }
  }
  
  # If inter select query returns no rows, then count(*) does not give 0 to check for 0/FALSE cases.
  # Since, there are no rows returned , it means that the filters are all false and any aggregation sums to 0. 
  innerQuery <- paste(select,from,where,groupby)
  #print(c("Create Query returned: ", list(res,val,innerQuery)))
  return(list(res,val,innerQuery))
}





# Function that evaluate all database check on single primary dataset
evaluateQuery_db <- function(data,filters,groupby,colSel,funcSel,operationSel,argValue){ 
  
  switch(funcSel
         ,'data type'={
           val <- dataType(inDataType_func(data),colSel)
           argValue <- ifelse(argValue=='logical','bool',argValue)
           res <- ifelse(operationSel!='none',val==argValue,'')
           list(res,val,'')}
         ,{
           createQuery(data,filters,groupby,colSel,funcSel,operationSel,argValue)
         }
  )
}



# Checks for No Duplicates in a column: CSV / Data.frames
hasUnique <- function(data,colSel,funcSel){
  cmdString0 <- paste0('data %>% dplyr::select(',colSel,') %>% dplyr::summarize(n_dist=n_distinct(',colSel,'),n=n()) %>% dplyr::mutate(l=n-n_dist) %>% dplyr::ungroup() %>% select(l)') # %>% dplyr::summarize(sum(l)) %>% dplyr::collect(n=Inf) %>% unlist')
  
  cmdString <- paste0('data %>% select(',colSel,') %>% summarize(n_dist=n_distinct(',colSel,'),n=n()) %>% mutate(l=n-n_dist) %>% ungroup() %>% select(l) ') #%>% summarize(sum(l)) %>% collec (n=Inf) %>% unlist')
  val <- data.frame(a=eval(parse(text=cmdString0)))
  colnames(val) <- paste0('hasUnique_',colSel)
  #res <- ifelse(val[1,1]==0,TRUE,FALSE)
  list('',val,cmdString,aggColName=colnames(val))
}




#-- Evaluates the aggregation function in the QC checks for Local CSV datasets
#-- Aggregations are handled by this function. Also provides the commnand string being executed for these aggregations.
fplyr <- function(data,colSel,funcSel){
  #print('Executing Summarize functions')
  
  # browser()
  aggColName <- paste0(gsub(" ","_",funcSel),"_",colSel)
  
  cmdString <- switch(funcSel,
                      'min'=,'max'=,'mean'=,'sum'={
                        paste0('data %>% dplyr::summarize(',aggColName,"="
                               ,funcSel,'(as.numeric(',colSel,')',ifelse(funcSel=='count','))',',na.rm=T)) '))
                      },
                      'median'={
                        paste0('data %>% select(',colSel,') %>% filter(ntile(',colSel,', 2) == 1) %>% dplyr::summarize(',aggColName,"=",'max(',colSel,'))')
                      },
                      'count'={
                        paste0('data %>% select(',colSel,') %>% dplyr::summarize(',aggColName,"=",'n())')
                      },
                      'count distinct'=,'has.unique'={
                        paste0('data %>% dplyr::summarize(',aggColName,"=",'n_distinct(',colSel,'))')
                      },
                      'count na'={
                        paste0('data %>% select(',colSel,') %>% filter(is.na(',colSel,')) %>% dplyr::summarize(',aggColName,"=",'n())')
                      },
                      'count blanks'={
                        paste0("data %>% select(",colSel,") %>% filter(trimws(",colSel,") == '') %>% dplyr::summarize(",aggColName,"=","n()) ")
                      },
                      'string length'={
                        paste0("data %>% select(",colSel,") %>% mutate(",aggColName," = nchar(",colSel,")) %>% select(",aggColName,")")
                      })
  
  
  val <- eval(parse(text=cmdString))
  val <- val %>% ungroup()
  return(list('',val,cmdString))
}



## Wrapper function for evaluating the inputs
evaluateQuery_local <- function(data,filters,groupby,colSel,funcSel,operationSel,argValue,caseSensitive){
  
  # browser()
  data <- data$table
  #print('Evaluating query on local')
  cmdString <- 'data'
  
  #-- Filter data if any input data filter has been provided
  if(trimws(filters)!=''){
    cmdString <- paste(cmdString,'%>% filter(',filters,')')
    data <- eval(parse(text=paste('data %>% filter(',filters,')')))
  }
  
  #-- Group by data based on the group_by columns provided
  if(trimws(groupby)!=''){ 
    cmdString <- paste(cmdString,'%>% group_by(',groupby,')')
    data <- eval(parse(text=paste('data %>% group_by(',groupby,')')))
  }
  
  #groupbyCols <- trimws(unlist(strsplit(groupby,",")))
  aggColName <- paste0(gsub(" ","_",funcSel),"_",colSel) ## This name is provided as the column name to the new aggregated columns created.
  
  valList <- switch(funcSel,
                    'min'=,
                    'max'=,
                    'mean'=,
                    'sum'=,
                    'median'=,
                    'count'=,
                    'count distinct'=,
                    'count na'=,
                    'count blanks'=,
                    'string length' = fplyr(data,colSel,funcSel),
                    'has.unique'= hasUnique(data,colSel,funcSel),
                    'data type'= dataType(inDataType_func(data),colSel),
                    'none'={
                      cmdStr <- paste('data %>% select(',colSel,')')
                      val <- eval(parse(text=cmdStr))
                      list('',val,cmdStr)  # All values must be returned in this format list(res,val,cmdString)
                    })
  
  #**MAINTAIN THE ORDER OF IF CONDITIONS BELOW
  if(funcSel=='has.unique'){
    cmdString1 <- valList[[3]]
    cmdString1 <- gsub('data %>%','',cmdString1)
    valList[[3]] <- paste(cmdString,'%>%',cmdString1)
    return(valList)
  }
  
  #val <- valList
  cmdString1 <- valList[[3]]
  cmdString1 <- gsub('data %>%','',cmdString1)
  cmdString <- paste(cmdString,'%>%',cmdString1)
  valList[[3]] <- cmdString
  
  if(operationSel=='none' && groupby == ''){
    val <- unlist(collect(valList[[2]]))
    if(length(val)>1) val <- 0
    else val <- valList[[2]]
    return(list('',val,cmdString))
  }
  
  #if(sum(c('tbl','data.frame') %in% class(valList[[2]]))){
  if(!funcSel %in% c('none'))
    valList$aggColName <- aggColName  #valList[[2]] <- valList[[2]] %>% select_(aggColName)
  else
    valList$aggColName <- colSel
  #valList[[2]] <- valList[[2]] %>% select_(colSel)
  #}
  
  return(valList)
}


evaluateQuery <- function(conList,filters,groupby,colSel,funcSel,operationSel,argValue,caseSensitive){
  #print('Evaluating Query')
  
  if(is.null(conList$con)){ # Local CSV ---------
    val <- evaluateQuery_local(conList,filters,groupby,colSel,funcSel,operationSel,argValue,caseSensitive)
    return(val)
  }
  else { # Database -----------
    bin <- evaluateQuery_db(conList,filters,groupby,colSel,funcSel,operationSel,argValue)
    return(bin)
  }
}


#-- Evaluates the comparison in QC checks on local CSV datasets
compare <- function(funcSel,val,colSel,operationSel,argValue,caseSensitive){
  #print('Comparing with the arguments')
  
  valcolsel <- colnames(val)
  
  if(funcSel[1]=='data type'){
    res <- (argValue==val)
    return(list(res,val))
  }
  
  if(operationSel=='%in%'){
    
    if(class(valcolsel) == "character"){
      # print('###########')
      #print(caseSensitive)
      #print('---------------------')
      if(caseSensitive == FALSE){
        val <- eval(parse(text=paste0("val %>% select(",colSel,") %>% mutate(",colSel,"=tolower(",colSel,"))")))
        argValue <- tolower(argValue)
      }
      
    }
    #print(list(val,argValue))
    res <- eval(parse(text=paste0("val %>% filter(!",valcolsel," %in% ","argValue",") %>% dplyr::summarize(n()) %>% collect %>% unlist")))
    
    # res <- eval(parse(text=paste0("val %>% filter(!",valcolsel," %in% ","argValue",") %>% dplyr::summarize(n()) %>% collect %>% unlist")))
    res <- ifelse(res==0,TRUE,FALSE)
    return(list(res,val))
  }
  else if(operationSel=='not in'){
    if(class(valcolsel) == "character"){
      
      if(caseSensitive == FALSE){
        val <- eval(parse(text=paste0("val %>% select(",colSel,") %>% mutate(",colSel,"=tolower(",colSel,"))")))
        argValue <- tolower(argValue)
      }
      
    }
    res <- eval(parse(text=paste0("val %>% filter(",valcolsel," %in% ","argValue",") %>% dplyr::summarize(n()) %>% collect %>% unlist")))
    res <- ifelse(res==0,TRUE,FALSE)
    return(list(res,val))
  }
  else if(operationSel=='between'){
    str <- paste('val %>% filter(!(',valcolsel,'>=',argValue[1],' &',valcolsel,'<=',argValue[2],
                 ')) %>% collect(n=Inf) %>% unlist %>% length')
    res <- eval(parse(text=(str))) 
    res <- ifelse(res==0,TRUE,FALSE)
    return(list(res,val))
  }
  else
  { 
    if(class(valcolsel) == "character"){
      if(caseSensitive == FALSE){
        val <- eval(parse(text=paste0("val %>% select(",colSel,") %>% mutate(",colSel,"=tolower(",colSel,"))")))
        argValue <- tolower(argValue)
      }
      
    }
    lhs <- val[,valcolsel]
    argValue <- unlist(argValue)
    # browser()
    if(operationSel!=""){
      
      cString <- paste0('sum(!lhs ',operationSel,' argValue)')
      res <- eval(parse(text= cString))
      
    }else{
      res <- 0
    }
    res <- ifelse(res==0,TRUE,FALSE)
    return(list(res,val))
  }
  
}

evalQuery <- function(data,inTables,filters,groupby,colSel,funcSel,operationSel,argValue,comparison,joinKeys,caseSensitive){
  #print('Evaluating Query 1')
  # Any transformation or treatment to input paramters will be handled inside the inputTreatment() function which also
  # calls other functions for treating specific parameters e.g. filterTransform() for treating Filters parameter
  inputTreatment <- inputTreatment(data$con,filters,groupby,colSel,funcSel,operationSel,argValue,comparison,joinKeys,inTables)
  
  filters <- inputTreatment[[1]]
  groupby <- inputTreatment[[2]]
  colSel <- inputTreatment[[3]]
  funcSel <- inputTreatment[[4]]
  operationSel <- inputTreatment[[5]]
  argValue <- inputTreatment[[6]]
  arithmeticSel <- operationSel[1] # unused
  operationSel <- operationSel[2]
  jKeys <- inputTreatment[[8]] # list of join keys
  caseSensitive <- caseSensitive
  if(is.null(data$con)){ # FOR CSV ---------------------
    
    # browser()
    lhs <- evaluateQuery(data,filters[1],groupby[1],colSel[1],funcSel[1],operationSel,0,caseSensitive)
    
    if(comparison=='1'){# FOR CSV - Multi Dataset Comparison ---------------------
      
      table2Alias <- inputTreatment[[7]]
      table2Index <- which(names(inTables$tableNames)==table2Alias)
      
      rhs <- evaluateQuery(list(con=NULL,table=inTables$tables[[table2Index]]$data),filters[2],groupby[2],colSel[2],funcSel[2],operationSel,0,caseSensitive)
      
    } else {
      rhs <- list('',argValue,'')
    }
    
    # Row count
    nlhs <- nrow(lhs[[2]])
    nrhs <- nrow(data.frame(rhs[[2]]))
    
    # Round numeric values to 3 decimal places
    # lval <- ifelse(nlhs==1 & is.numeric(unlist(lhs[[2]])),round(unlist(lhs[[2]]),3),lhs[[2]])
    # rval <- ifelse(nrhs==1 & is.numeric(unlist(rhs[[2]])),round(unlist(rhs[[2]]),3),rhs[[2]])
    lhsval <- ifelse(nlhs==0,'No Rows returned in one of the queries',ifelse(nlhs==1 ,lhs[[2]],"Multi. Rows"))
    rhsval <- ifelse(nrhs==0,'No Rows returned in one of the queries',ifelse(comparison==1,ifelse(nrhs==1,rhs[[2]],"Multi. Rows"),''))
    
    
    comment <- ''
    # Multi-Multi row comparison not supported
    if(nlhs>1 && nrhs>1 && nlhs!=nrhs && ! operationSel %in% c('in','%in%','not in','between')){
      if(comparison==1 & joinKeys!='')
        comment <- 'LHS and RHS rows did not match. Continued with Inner Join.'
      else
        return(list(FALSE,'LHS and RHS rows do not match',''))
    }
    
    if(operationSel=='none' || operationSel==""){
      return(list('',lhsval,''))
    }
    
    
    #- Handling JOINS
    if(comparison == 1 & joinKeys!=''){ # For JOINS
      #source('test1.R',local=TRUE)
      finTable <- joinTables(list(con=data$con,db=data$db),lhs[[2]] ,rhs[[2]] ,operationSel,jKeys,lMetricName='',rMetricName='')
      lhs[[2]] <- finTable[[1]]
      rhs[[2]] <- finTable[[2]]
      
    } else { # No JOINS
      lhs[[2]] <- lhs[[2]] %>% select_(lhs$aggColName)
      if(comparison==1) 
        rhs[[2]] <- rhs[[2]] %>% select_(rhs$aggColName)
    }
    
    if(!trimws(arithmeticSel) %in% c('','none')){
      leftV <- unlist(lhs[[2]])
      rightV <- unlist(rhs[[2]])
      lhs[[2]] <- switch(arithmeticSel
                         ,"+" = leftV+rightV
                         ,"-" = leftV-rightV
                         ,"*" = leftV*rightV
                         ,"/" = leftV/rightV
      )
      rhs[[2]] <- argValue
      arithval <- ifelse(nlhs==0,'No Rows returned in one of the queries',ifelse(nlhs==1 ,lhs[[2]],"Multi. Rows"))
      
    }
    
    #-- Compare LHS and RHS -----------
    dat <- data.frame('lhs' = lhs[[2]],stringsAsFactors = F)
    #print('Comparing')
    
    #print(list(funcSel,dat,colnames(dat),operationSel,unlist(rhs[[2]])))
    
    bin <- compare(funcSel,dat,colnames(dat),operationSel,unlist(rhs[[2]]),caseSensitive)
    
    # val <- paste0('Pri: ',lhsval," ; Sec: ",rhsval,' ; ArithVal: ',arithval,' . ',comment)
    val <- paste0(lhsval," ; ",rhsval,' . ',comment)
    bin <- list(bin[[1]],val,'')
    #print(paste("evalQuery -> evaluateQuery returned", bin))
    return(bin)
    
  } else { ## FOR DB ---------------------
    
    if(comparison==0){
      bin <- evaluateQuery_db(data,filters[1],groupby[1],colSel[1],funcSel[1],operationSel,argValue)
      #print(c("evalQuery -> evaluateQuery_db returned: ", bin))
      return(bin)
      
    } else { # FOR DB - Multi Table Comparison ---------------------
      
      table2Alias <- inputTreatment[[7]]
      table2Index <- which(names(inTables$tableNames)==table2Alias)
      table2Name <- inTables$tableNames[table2Index]
      
      # Direct column comparison case within primary dataset.
      # Can be handled by evaluateQuery_db function instead of considering both sides separately
      # if(table2Alias == 'A' & funcSel[1]=='none' & funcSel[2]=='none' ){ 
      #   argValue <- colSel[2]
      #   bin <- evaluateQuery_db(data,filters[1],groupby[1],colSel[1],funcSel[1],operationSel,argValue)
      #   return(bin)
      # }
      
      lhs <- createQuery1(data,filters[1],groupby[1],colSel[1],funcSel[1],operationSel,0,'qclhstable')
      rhs <- createQuery1(list(con=data$con,table=table2Name,db=data$db),filters[2],groupby[2],colSel[2],funcSel[2],operationSel,0,'qcrhstable')
      nlhs <- dbGetQuery(data$con,'select count(*) from qclhstable;')
      nrhs <- dbGetQuery(data$con,'select count(*) from qcrhstable;')
      lhsval <- 'Mult. Rows'
      rhsval <- 'Mult. Rows'
      
      # Read values from tables only if nrow == 1
      if(nlhs==1){ lhsval <- round(unlist(dbGetQuery(data$con,'select * from qclhstable;')),3)
      }
      if(nrhs==1){ rhsval <- round(unlist(dbGetQuery(data$con,'select * from qcrhstable;')),3)
      }
      
      if(nlhs>1 & nrhs>1 & nlhs!=nrhs){
        return(list(FALSE,'LHS and RHS rows do not match',''))
      }
      
      # Multi- Multi rows comparison not supported
      # if(!((nlhs==1 | nrhs==1) | operationSel %in% c('in','not in')))
      #   return(list(FALSE,'Multiple row comparison on both sides not supported',''))
      # 
      
      #- Handling JOINS
      if(comparison==1 & (!trimws(arithmeticSel) %in% c('','none'))){ # For JOINS
        if(joinKeys!='')
          finTable <- joinTables(list(con=data$con,db=data$db),'qclhstable','qcrhstable',operationSel,jKeys,lMetricName='col',rMetricName='col')
        else if(joinKeys=='')
          finTable <- joinTables(list(con=data$con,db=data$db),'qclhstable','qcrhstable',operationSel,'',lMetricName='col',rMetricName='col')
        # This will create a merged table with the name 'qcjointable' which has the join column, 
        # the left metric and the right metric values
      }
      
      
      #-- COMPARISON
      #-- First check if arithmetic operation is being done on lhs and rhs results
      if(!trimws(arithmeticSel) %in% c('','none')){
        #-- If Arithmetic Operation on lhs and rhs selected 
        newCol <- 'compoundcol'
        expression <- switch(arithmeticSel
                             ,'+' = 'lMetric + rMetric'
                             ,'-' = 'lMetric - rMetric'
                             ,'*' = 'lMetric * rMetric'
                             ,'/' = 'lMetric / rMetric'
        )
        
        # Create the new calculated column based on the arithmetic expression
        dbCalculatedCol(data,'qcjointable',data$db,newCol,expression,'')
        
        data1 <- data
        data1$table <- 'qcjointable'
        colSel <- newCol
        # bin <- evaluateQuery_db(data,filters[1],groupby[1],colSel[1],funcSel[1],operationSel,argValue)
        bin <- evaluateQuery_db(data1,'','',colSel,'none',operationSel,argValue)
        res <- bin[[1]]
        lhsval <- bin[[2]]
        rhsval <- ''
        
      } else { 
        #-- Query for comparing LHStable and RHStable 
        
        if(operationSel %in% c('in','not in')){
          query <- paste0('select count(*) from (select distinct col from qclhstable) a join (select distinct col from qcrhstable) b on a.col = b.col ')
          query1 <- paste0('select count(distinct col) from qcrhstable')
          cnt <- dbGetQuery(data$con,query)
          cnt1 <- dbGetQuery(data$con,query1)
          res <- ifelse(operationSel=='in' & cnt==cnt1,TRUE,ifelse(operationSel=='not in' & cnt==0,TRUE,FALSE))
          
        } else if(comparison==1 & joinKeys!=''){ # For JOIN cases
          top <- dbFetchTopWrapper(list(con=data$con,table='qcjointable',db=data$db))
          if(nrow(top)==0){ 
            res <- FALSE
            out <- 'No rows in the merged dataset'
          }
          else {
            query <- paste0('select count(*) from qcjointable where not lMetric ',operationSel,' rMetric')
            res <- dbGetQuery(data$con,query)
            res <- ifelse(res>0,FALSE,TRUE)
          }
        } else { # For all other cases
          query <- paste0('select count(*) from (select col from qclhstable) a join (select col from qcrhstable) b on not a.col ',operationSel,' b.col')  
          res <- dbGetQuery(data$con,query)
          res <- ifelse(res>0,FALSE,TRUE)
        }
      }
      tryCatch({
        dbUpdateWrapper(data,'DROP TABLE IF EXISTS qclhstable')
        dbUpdateWrapper(data,'DROP TABLE IF EXISTS qcrhstable')
        
      }, error = function(e){
        
        print(e)
      })
      #print(c("evalQuery -> comparision returned: ", bin))
      
      #print(list(res,paste0(lhsval," ; ",rhsval),''))
      return(list(res,paste0(lhsval," ; ",rhsval),''))
    }
  }
}




runQueries_func <- function(queryData, dataPackage, inputTables){
  tryCatch({
    if(is.na(queryData[1,'Column'])) return()  ##-- Return if no queries in queryTable
    # if(is.null(isolate(inDataReactive$inData))) return() ##-- Return if no data input
    
    print('Executing queries in the table')
    
    runOption <- input$runOptions
    
    queryQ <- list(correct=0, incorrect=0)
    
    runOption <- input$runOptions
    qData <- runOptions(queryData,runOption)  ##-- Creating a queryData (rules list) subset based on the runOptions selection. 'queryData' is global
    if(is.null(qData)) return()
    
    # progress <- shiny::Progress$new()
    # on.exit(progress$close())
    # progress$set(message = "Executing Rules...")
    
    
    for(i in 1:nrow(qData)){
      query <- qData[i,c('Filters','GroupBy','Column','Function','Operation','Argument','Run','Comparison','JoinKeys','caseSensitive')]
      
      #print(query)
      row <- unlist(query)
      nRun <- trimws(row['Run'])
      evalRun <- function(){
        tryCatch(# Call function that evaluates the QC check
          {
            bin <- evalQuery(dataPackage, inputTables ,as.character(row['Filters']),
                            as.character(row['GroupBy']),as.character(row['Column']),
                            as.character(row['Function']),as.character(row['Operation']),
                            as.character(row['Argument']),as.character(row['Comparison']),row['JoinKeys']
                            ,row['caseSensitive'])
          }
          #,warning=function(w){showNotification(paste0('Warning in Rule',i,':',w[1]),type='warning');NULL}
          ,error=function(e){
            print(paste0('Error in Rule',i,':',e[1]))
            }
        )
      }
      
      bin <- evalRun()
      #print(bin)
      #if(!is.null(bin)){
      if(bin[[1]]!='error'){
        if(bin[[1]]==TRUE){
          queryData[i,'Result'] <- 'Passed'
        }
        else if(bin[[1]]==FALSE){
          queryData[i,'Result'] <- 'Failed'
        }
        else{
          queryData[i,'Result'] <- '-'
        }
        # queryData[i,'Result'] <<- ifelse(bin[[1]],'Passed','Failed')
        queryData[i,'Value'] <- bin[[2]]
        queryData[i,'Command'] <- bin[[3]]
      }
      else {
        queryData[i,'Result'] <- 'Error'
        queryData[i,'Value'] <- bin[[2]]  ## bin[[2]] contains the error string returned by the error handler
        queryData[i,'Command'] <- 'Error'
      }
      queryData[i,'Run'] <- '1'
      
      
      
    }
    
    
    #print(queryData)
    queryQ$correct <- sum(queryData$Result=='Passed',na.rm=T)
    queryQ$incorrect <- sum(queryData$Result=='Failed',na.rm=T)
    
    rUpdate$queryTable <- rUpdate$queryTable + 1
  },error=function(e){
      print(c("Error in evalQuery", e))
  })
  return(queryData)
}


runWorkflow <- function(workflowZipFile = "D:/QC/Downloads/Automation/WorkFlow 2017_12_20 13_36_36.zip", mode="csv", datapath="", connectionParams=defaultConnParams){
  # browser()
  tryCatch({
    #print("Reading input dataset...")
    
    print('Running automated workflow')
    
    #Inputs and values from the shiny environment ----------------------------------
    cParams <- connectionParams

    workingDir <- getwd()
    wPath <- workflowZipFile # Read uploaded zip path
    
    tempLoc <- './Downloads/Automation/temp/'
    tempLocDir <- './Downloads/Automation/temp'
    
    if(dir.exists(tempLocDir)){
      unlink(tempLocDir, recursive = TRUE) # Delete directory
    }
    
    dir.create(tempLocDir)
    unzip(wPath, exdir = getwd(), overwrite = TRUE)
    
    uploadPath <- tempLoc
    
    # File read ----------------------------------
    fileNames <- c('globalVars.RDS','inputs.RDS')
    
    for(i in 1:length(fileNames)){
      fileExists <- file.exists(paste0(uploadPath,fileNames[i]))
      if(!fileExists){
        print(paste0(fileNames[i],' does not exist'))
        return()
      }
    }
    
    input <<- readRDS(paste0(uploadPath,'inputs.RDS'))
    # print(c("Input retrieved: ",input))
    
    queryData <- workFlowInput(workflowZipFile)
    
    inputDataset <- inputDataSet_func(mode=mode, datapath=datapath, tableName=connectionParams$dbTable, connectionParams=connectionParams, queryData=queryData)
    
    conList <- inputDataset$connList
    inputTables <- inputDataset$inputTables
    
    ruleList_location <- paste0(uploadPath,'Rule_list.csv')
    derivedColsList_location <- paste0(uploadPath,'Derived_columns_list.csv')
    #print(list(uploadPath,file.exists(derivedColsList_location),dir(uploadPath)))
    gVars <- readRDS(paste0(uploadPath,'globalVars.RDS'))
    templateFile_location <- paste0(uploadPath,'Template.csv')
    
    ##- Checking Table Name Aliases and modifying them accordingly in case of descrepancy
    ##- The Alias in inTables$tables and inTables$tablesNames are replaced with the aliases from the Uploaded Rule List
    ##- Aliases are stores in two places : 1. names(inTables$tableNames) 2. inTables$tables[[i]]$alias
    if(tableNameColFlag)
    {
      maxAlpha <- which(LETTERS == workflowTables$Alias_In_Rule_List[nrow(workflowTables)])
      if(nrow(workflowTables) < length(inputTables$tableNames)){
        nextNum <- maxAlpha+1
        names(inputTables$tableNames) <- c(workflowTables$Alias_In_Rule_List,LETTERS[nextNum:length(inTables$tableNames)])
      } else {
        names(inputTables$tableNames) <- workflowTables$Alias_In_Rule_List[1:length(inputTables$tableNames)]
      }
      names(inputTables$tables) <- names(inputTables$tableNames)
      lapply(c(1:length(inputTables$tableNames)),function(i){
        inputTables$tables[[i]]$alias <- names(inputTables$tableNames)[i]
      })
    }
    
    if(input$metaFileSubmit==1){
      for(i in 1:fileCounter){
        #file <- input[[paste0('metaFile',i)]]
        file <- list()
        file$datapath <- paste0(tempLoc,'metaFile',i,'.csv')
        if(!file.exists(file$datapath)) next
        metaOut <- metaFileLoad(file,inputTables$tables[[i]]$data)
        if(trimws(metaOut$typeErrorText)!=''){
          #print(metaOut$typeErrorText)
          return()
        }
        
        inputTables$tables[[i]]$data <- useMetaFile(inputTables$tables[[i]]$data,metaOut$typeData)$dataset
        inputTables$tables[[i]]$dataTypes <- inDataType_func(list(con=NULL,table=inputTables$tables[[i]]$data,db=connDb))
        
        # showNotification(paste0('Dataset ',i,' updated based on Metafile',i))
      }
    }
    
    # inDataType_df <- inDataType_func(inDataReactive$inData)
    # inDatCols_df <- inDataType_df$col
    # inDataType <- function(){inDataType_df}
    # inDatCols <- function(){inDatCols_df}
    #mainDataChangeRefresh()
    
    #print('Running Automated Checks')
    # STEP 2
    # STEP 2a # Automated checks ----------------------------------
    #====================Commenting it for now. Need to implement this later====================
    
    # if(input$templateCheckSubmit & file.exists(templateFile_location)){
    #   templateCheckSubmit_func(rinput=input)
    #   print('Template check complete')
    #   #print(reactData$colCheckTable)
    # }
    # 
    # if(input$nullCheckSubmit){
    #   # updateCheckboxInput(session,'nullCheck',value=1)
    #   nullCheckSubmit_func(inputTables)
    #   print('Missing value check complete')
    #   #print(reactData$missingValueTable)
    # }
    # if(input$levelCheckSubmit){
    #   # updateCheckboxInput(session,'levelCheck',value=1)
    #   levelCheckSubmit_func(rinput=input)
    #   # updateSelectInput(session,'levelCols',selected=input$levelCols)
    #   print('l')
    #   #print(reactData$dupsTable)
    # }
    # if(input$hierarchyCheckSubmit){
    #   # updateCheckboxInput(session,'hierarchyCheck',value=1)
    #   hierarchyCheckSubmit_func(rinput=input)
    #   # updateSelectInput(session,'hierarchyCols',selected=input$hierarchyCols)
    #   print('Hierarchy check complete')
    #   #print(reactData$hierarchyFailsTable)
    # }
    # 
    # 
    # # STEP 2b # Panel data comparison ----------------------------------
    # #if(input$panelCompCheck){   
    # if(input$panelCompSubmit){
    #   print('Running Panel Comparison')
    #   # updateCheckboxInput(session,'panelCompCheck',value=1)
    #   pUpdate <<- TRUE
    #   panelCompSubmit_func(gVars$panelComp,rinput=input)
    #   
    #   # inDataType_df <- inDataType_func(inDataReactive$inData)
    #   # inDatCols_df <- inDataType_df$cols
    #   
    #   uCols <- input$keyColumns
    #   numCols <- mainDataColInfo[tolower(mainDataColInfo$Sclass) %in% c('double','float','numeric','integer'),'name']
    #   numCols <- setdiff(numCols,c(input$panelColumns,input$keyColumns))
    # 
    #   panelComp$Data <- gVars$panelComp$Data
    #   reactData$panelCompTable <- gVars$panelComp$Data
    #   rUpdate$panelCompTable <-  rUpdate$panelCompTable + 1
    # }
    # 
    # # STEP 2c # Derived columns ----------------------------------
    # dbTempTable <- ''
    # dbTempManTable <- ''
    # 
    # #- If derived column expression exists, create.
    # if(file.exists(derivedColsList_location)){
    #   print('Creating Derived Columns')
    #   #lapply(calColList$cal_Cols,createCols)
    #   uploadedCalCols_func(derivedColsList_location)
    #   # inDataType_df <- inDataType_func(inDataReactive$inData)
    #   # inDatCols_df <- inDataType_df$cols
    # }
    # 
    # #- Date Format Conversion
    # if(input$dateFormatSubmit>0){
    #   print('Convertin Columns To Date Format') 
    #   # inDataReactive$inData$table <- convertToDate(inDataReactive$inData$table,input$dateFormatcolSel,input$dateFormat)
    #   if(input$panelCompSubmit == 0 ){                      #to uptade date column in original data when panel Comparision Data not created
    #     # inputTables$tables[[1]]$data <-  inDataReactive$inData$table
    #     # inputTables$tables[[1]]$dataTypes <- inDataType_func(inDataReactive$inData)
    #   }
    #   # inDataType_df <- inDataType_func(inDataReactive$inData)
    #   # inDatCols_df <- inDataType_df$cols
    #   # print(class(inDataReactive$inData$table$date))
    # }
    
    #print('Loading Rule List')
    # STEP 3 # Read rule list ----------------------------------
    #uploadedQueries_func(ruleList_location)
    if(!file.exists(ruleList_location)){
      print("Rule_list.csv not found")
      return()
    }
    out <- uploadedQueries_func(ruleList_location,queryData)
    
    if(is.null(out$data)){
      #print(out$error)
      return()
    } else {
      queryData <<- out$data
      rUpdate$submitQueryUpdate <- rUpdate$submitQueryUpdate + 1
      if(is.null(out$message)){
        output$validPopup <- renderUI({
          bsModal(id='validationAlert',trigger='',title="NOTE",size='large',p(out$message))
        })
        # toggleModal(session,"validationAlert",toggle="open")
      }
    }
    
    
    #print('Executing Rules')
    
    # STEP 4 # Run rules from Rule List ----------------------------------
    if(nrow(queryData)>0){
      print(c("Run QUeries on ", queryData))
      dataPackage <- list(con=conList$con, table=inputTables$tables[[1]]$data, db=conList$db)
      workflowResult <- runQueries_func(queryData, dataPackage, inputTables)
    }
    
    print('Work Flow Execution Complete')
    return(workflowResult)
  },error=function(e)print(e))
}

