
go <- NULL
connectionParams <- NULL
git_url <- NULL
project_issue_url <- NULL
session_url <- NULL
projectID <- 89
packages <- NULL
dbPackages <- NULL
miscPackages <- NULL

loadGlobals <- function(){
  go <<- NULL
  connectionParams <<- NULL
  git_url <<- "http://mugitlab.mu-sigma.com/api/v3"
  project_issue_url <<- "http://mugitlab.mu-sigma.com/api/v3/projects/89/issues"
  session_url <<- "http://mugitlab.mu-sigma.com/api/v3/session"
  projectID <<- 89
  packages <<- c("shiny","mice", "imputeTS", "data.table", "knitr", "rmarkdown", "dplyr", 
              "dummies", "stats", "lattice", "car", "forecast", "shinyBS", "ggplot2",
              "smbinning", "e1071", "shinyjs", "scales", "shinyBS", 
              "httr", "rjson", "DT", "devtools", "VIM","DiagrammeR", "DiagrammeRsvg", "magrittr","rsvg")
  dbPackages <<- c("rJava", "RPostgreSQL", "RMySQL", "RSQLite", "DBI","RJDBC","odbc")

}



underscoredTime <- function(time){
 time <- gsub(time,pattern = ":",replacement = "_")
 time <- gsub(time,pattern = "-",replacement = "_")
 return(gsub(time,pattern = " ",replacement = "_"))
}



getmode <- function(v) {
            v <- v[!is.na(v)]
            uniqv <- unique(v)
            uniqv[which.max(tabulate(match(v, uniqv)))]
            }







