
ggtsGraphs <- function(x, plot.type=c("partial","histogram","scatter","spectrum"),
                       points=FALSE, smooth=FALSE,
                       lag.max, na.action= stats::na.contiguous, theme=NULL, ...){
  
  if(!xts::is.xts(x))
    stop('Xts object needs to be passed')
  # browser()
  tsplot_xts <- x
  
  if(!stats::is.ts(x)){
    x <- stats::ts(zoo::coredata(x))
  }
  if(missing(lag.max)){
    lag.max <- round(min(max(10*log10(length(x)), 3*(stats::frequency(x))), length(x)/3))
  }
  dots <- list(...)
  if(is.null(dots$xlab))
    dots$xlab <- ""
  if(is.null(dots$ylab))
    dots$ylab <- ""
  labs <- match(c("xlab", "ylab", "main"), names(dots), nomatch=0)
  print(labs)
  
  # #Set up grid for plots
  # gridlayout <- matrix(c(1,2,1,3), nrow=2)
  # grid::grid.newpage()
  # grid::pushViewport(grid::viewport(layout = grid::grid.layout(nrow(gridlayout), ncol(gridlayout))))
  
  #Add ts plot with points
  # matchidx <- as.data.frame(which(gridlayout == 1, arr.ind = TRUE))
  tsplot <- zoo::autoplot.zoo(tsplot_xts)  
  
  tsplot <- tsplot + ggplot2::labs(x=dots$xlab,y=dots$ylab) + ggplot2::ggtitle(dots$main) 
  
  if(points){
    tsplot <- tsplot + ggplot2::geom_point(size=0.5, y = x)
  }
  if(smooth){
    tsplot <- tsplot + ggplot2::geom_smooth(method="loess", se=FALSE, ggplot2::aes(y = x ))
  }
  tsplot <- tsplot + ggplot2::geom_hline(yintercept = 0,  color = "blue") + ggplot2::theme_bw()
  
  
  if(!is.null(theme)){
    tsplot <- tsplot + theme
  }
  
  # tsplot <- tsplot+scale_x_continuous(limits = c(0,30))
  
  # print(tsplot,
  #       vp = grid::viewport(layout.pos.row = matchidx$row,
  #                           layout.pos.col = matchidx$col))
  
  
  acfplot <- do.call(forecast::ggAcf, c(x=quote(x), lag.max=lag.max, na.action = na.action, dots[-labs])) + ggplot2::ggtitle(NULL)
  forecast::ggtsdisplay
  print("ACF Plot")
  print(acfplot)
  
  if(!is.null(theme)){
    acfplot <- acfplot + theme
  }
  
  
  lastplot <- forecast::ggPacf(x, lag.max=lag.max, na.action = na.action) + ggplot2::ggtitle(NULL)
  #Match y-axis
  acfplotrange <- ggplot2::layer_scales(acfplot)$y$range$range
  pacfplotrange <- ggplot2::layer_scales(lastplot)$y$range$range
  yrange <- range(c(acfplotrange, pacfplotrange))
  acfplot <- acfplot + ggplot2::ylim(yrange) + ggplot2::theme_bw()
  lastplot <- lastplot + ggplot2::ylim(yrange) + ggplot2::theme_bw()
  if(!is.null(theme)){
    lastplot <- lastplot + theme
  }
  
  
  # matchidx <- as.data.frame(which(gridlayout == 2, arr.ind = TRUE))
  # print(acfplot,
  #       vp = grid::viewport(layout.pos.row = matchidx$row,
  #                           layout.pos.col = matchidx$col))
  # 
  # #Add last plot
  # matchidx <- as.data.frame(which(gridlayout == 3, arr.ind = TRUE))
  # print(lastplot,
  #       vp = grid::viewport(layout.pos.row = matchidx$row,
  #                           layout.pos.col = matchidx$col))
  
  return(list(tsplot, acfplot, lastplot))
}


#Histogram
univarHistPlot <- function(data,uniCol){
  x = data[,uniCol]
  distHistogram <- ggplot2::ggplot(data,
                          ggplot2::aes(x = x)) +
    ggplot2::geom_histogram(
      ggplot2::aes(y = ..count..),
      colour = 'black',
      fill = 'blue',
      size = 0.2,
      alpha=0.7
    ) +
    # stat_function(ggplot2::aes(color = "Normal"), fun = dnorm,
    #               args = list(
    #                 mean = mean(data[, uniCol]),
    #                 sd = sd(data[, uniCol])
    #               )
    # ) +
    ggplot2::labs(x=uniCol,y='Frequency') +
    ggplot2::ggtitle("Histogram of Residuals") +
    ggplot2::theme_bw() + 
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5),panel.border=ggplot2::element_rect(size=0.1),legend.position = c(0.8, 0.8),panel.grid.major.x=ggplot2::element_blank()) +
    ggplot2::scale_colour_manual("", values = c('#000000', "#EE7600")) +
    ggplot2::scale_linetype_manual("", 
                          values = c("Normal" = 2, "Density" = 1))  +
    ggplot2::guides(
      fill = ggplot2::guide_legend(keywidth = 1, keyheight = 1),
      linetype = ggplot2::guide_legend(keywidth = 3, keyheight = 1),
      colour = ggplot2::guide_legend(keywidth = 3, keyheight = 1)
    )
}

#Ljung Box ggplot

ljungBoxPlot <- function (z, lag = NULL, main = NULL) 
{
  if (is.null(lag)) {
    lag = 10
  }
  k = lag
  n = length(z)
  aux = stats::acf(z, plot = FALSE, lag.max = k, na.action = na.pass)
  p.value = vector("numeric")
  Q = vector("numeric")
  for (j in 1:k) {
    rho = aux$acf[2:(j + 1), , 1]
    Q[j] = sum(n * (n + 2) * rho^2/(n - 1:j))
    p.value[j] = 1 - pchisq(Q[j], df = j)
  }
  if (is.null(main)) {
    main = expression("p values for Ljung-Box statistic")
  }
  
  data <- data.frame(p_value=p.value,lag=c(1:k))
  
  ljungPlot <- ggplot2::ggplot(data,ggplot2::aes(x=lag,y=p_value)) + 
    ggplot2::geom_point(size=2) + 
    ggplot2::ggtitle('p values for Ljung-Box statistic') + 
    ggplot2::labs(x='Lag',y='p-value') + 
    ggplot2::xlim(0,k) + 
    ggplot2::ylim(0,1) + 
    ggplot2::geom_abline(mapping=ggplot2::aes(intercept = 0.05,slope = 0),
                         colour='blue',linetype=2) +
    ggplot2::theme_bw() +
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5))
  
  return(ljungPlot)
}

#----------------------------------------------------------------------------------------------------------------#
#--------- HTS --------------------------------------------------------------------------------------------------#

updatePlots <- function(suffix,name,yVar,TimeVar,input,output,reactData){
   # browser()
  model_name <- suffix
  model_name2 <- ifelse(model_name=='arima','',paste0('_',model_name))
  
  hts_level_plots <- ifelse(model_name=='arima','hts_level_plots',paste0('hts_',model_name,'_level_plots'))
  model_summary <- ifelse(model_name=='arima','model_summary',paste0('hts_',model_name,'_model_summary'))
  reconciliation_table <- paste0('reconciliation_table_',model_name)
  hts_accuracy_output <- ifelse(model_name=='arima','hts_accuracy_output',paste0('hts_',model_name,'_accuracy_output'))
  hts_download_forecast<-paste0('hts_download_forecast_',model_name)
  hts_ggts_residuals <- paste0('hts_ggts_residuals_',model_name)
  hts_ggts_acf <- paste0('hts_ggts_acf_',model_name)
  hts_ggts_pacf <- paste0('hts_ggts_pacf_',model_name)
  hts_hist_residuals <- paste0('hts_hist_residuals_',model_name)
  hts_ljung_residuals <- paste0('hts_ljung_residuals_',model_name)
  
  hts_level <- ifelse(model_name=='arima','hts_level',paste0('hts_',model_name,'_level'))
  hts_node <- ifelse(model_name=='arima','hts_node',paste0('hts_',model_name,'_node'))
  
  
  # Print outputs and plots
  output[[hts_level_plots]] <- plotly::renderPlotly({

    tryCatch({
      hts_level <- input[[hts_level]]
      hts_node <- input[[hts_node]]
      outcome <- shiny::isolate(reactData$models[[model_name]])
      data <- shiny::isolate(reactData$hts_data)
      hts_data_time <- shiny::isolate(reactData$hts_data_time)
      hts_train_time <- shiny::isolate(reactData$hts_train_time)
      hts_val_time <- shiny::isolate(reactData$hts_val_time)
      out <-
        plotHts(data,
                outcome,
                hts_level,
                hts_node,
                hts_data_time,
                hts_train_time,
                hts_val_time)
      reactData[[hts_level_plots]] <- out
    },error=function(e){plotly::plot_ly()})
  })
  
  # output[[hts_download_forecast]] <- shiny::downloadHandler(
  #   
  #   filename = paste('hts_forecast_',yVar,'_',model_name,'.csv',sep=""),
  #   content = function(file) {
  #     hts_level <- input[[hts_level]]
  #     hts_node <- input[[hts_node]]
  #     outcome <- shiny::isolate(reactData$models[[model_name]])
  #     hts_val_time <- shiny::isolate(reactData$hts_val_time)
  #     hts_forecast_dataset <- download_forecast_hts(outcome,hts_level,hts_node,hts_val_time,yVar,TimeVar)
  #     write.csv(hts_forecast_dataset,file)
  #   }
  # )
  
  observeEvent(input[[hts_download_forecast]],{
    tryCatch({
      progress <- shiny::Progress$new()
      # Make sure it closes when we exit this reactive, even if there's an error
      on.exit(progress$close())
      progress$set(message = "Downloading forecast...")
      filename = paste('hts_forecast_',yVar,'_',model_name,'.csv',sep="")
      hts_level <- input[[hts_level]]
      hts_node <- input[[hts_node]]
      outcome <- shiny::isolate(reactData$models[[model_name]])
      hts_val_time <- shiny::isolate(reactData$hts_val_time)
      hts_forecast_dataset <- download_forecast_hts(outcome,hts_level,hts_node,hts_val_time,yVar,TimeVar)     
      write.csv(hts_forecast_dataset,file = paste0("Downloads/",filename),row.names=FALSE)
      shiny::showNotification('The downloaded file can be found in Downloads folder')
    },error=function(e){
      shiny::showNotification(e)
    }
    )
  })  
  
  output[[model_summary]] <- shiny::renderPrint({
  
    tryCatch({
       # browser()
      print('######################',quote=FALSE)
      print('    MODEL SUMMARY     ',quote=FALSE)
      print('######################',quote=FALSE)
      print('',quote=FALSE)
      
      modelName <- name
      data <- shiny::isolate(reactData$hts_data)
      hts_method <- shiny::isolate(reactData$hts_method_selected)
      hts_base_level <- reactData$hts_base_level
      hts_node <- input[[hts_node]]
      
      models <- model_list[[modelName]]
      selected_model <- get_hts_model_summary(data,models,model_name,hts_method,hts_base_level,hts_node)
      reactData[[model_summary]] <- selected_model
      # saveRDS(selected_model, "Downloads/selected_model.RDS")
      if(is.null(selected_model[[1]]) | is.null(selected_model) | is.na(selected_model)){
        print('No models were built for the selected level')
      } else return(selected_model)
      
    },error=function(e){})
  })
  
  output[[hts_accuracy_output]] <- shiny::renderPrint({
  
    tryCatch({
      hts_node <- input[[hts_node]]
      print('#################',quote=FALSE)
      print('    ACCURACY     ',quote=FALSE)
      print('#################',quote=FALSE)
      print('',quote=FALSE)
      outcome <-  shiny::isolate(reactData$models[[model_name]])
      out_accuracy <- getAccuracy_func(outcome,shiny::isolate(reactData$hts_train),shiny::isolate(reactData$hts_validation))
      print('Train MAPE',quote=FALSE)
      train_mape <- out_accuracy$train_mape['MAPE',hts_node,drop=FALSE]
      print(train_mape)
      print('Test MAPE',quote=FALSE)
      test_mape <- out_accuracy$test_mape['MAPE',hts_node,drop=FALSE]
      print(test_mape)
      reactData[[hts_accuracy_output]] <- list(Train_Mape=train_mape,Test_Mape=test_mape)  
      
    },error=function(e){})
  })
  
  output[[reconciliation_table]] <- shiny::renderDataTable({
    tryCatch({
      # browser()
      hts_level <- input[[hts_level]]
      hts_node <- input[[hts_node]]
      HierarchyColumns <- reactData$HierarchyColumns
      hts_method <- reactData$hts_method_selected
      outcome <- shiny::isolate(reactData$models[[model_name]])
      hts_method <- reactData$hts_method_selected
      reconData <- get_reconciliation_table(reactData$processed_dataset,hts_level,hts_node,outcome,HierarchyColumns,hts_method)
      numCols <- getNumColNames(reconData)
      # out <- DT::datatable(reconData,options = list(scrollY= TRUE,dom='t')) %>% formatRound(numCols,2)
      # out <- DT::datatable(roundOffDataFrame(reconData, input$checkbox_displayPrecision, input$slider_precision),options = list(scrollY= TRUE,dom='t'))
       out <- roundOffDataFrame(reconData, input$checkbox_displayPrecision, input$slider_precision)#,options = list(scrollY= TRUE,dom='t')
      
            reactData[[reconciliation_table]] <- out
      
    },error=function(e){})
  })
  
  # output[[reconciliation_table]] <- shiny::renderDataTable({
    # tryCatch({
    #      browser()
    #   hts_level <- input[[hts_level]]
    #   hts_node <- input[[hts_node]]
    #   HierarchyColumns <- reactData$HierarchyColumns
    #   hts_method <- reactData$hts_method_selected
    #   outcome <- shiny::isolate(reactData$models[[model_name]])
    #   hts_method <- reactData$hts_method_selected
    #   reconData <- get_reconciliation_table(reactData$processed_dataset,hts_level,hts_node,outcome,HierarchyColumns,hts_method)
    #   numCols <- getNumColNames(reconData)
    #   # out <- DT::datatable(reconData,options = list(scrollY= TRUE,dom='t')) %>% formatRound(numCols,2)
    #   out <- DT::datatable(roundOffDataFrame(reconData, input$checkbox_displayPrecision, input$slider_precision),options = list(scrollY= TRUE,dom='t'))
    #   reactData[[reconciliation_table]] <- out
    # 
    # },error=function(e){})
  # })
  
  # ****** Residual Plots **********
  residuals_reactive <- shiny::reactive({
    hts_level <- input[[hts_level]]
    hts_node <- input[[hts_node]]
    outcome <- shiny::isolate(reactData$models[[model_name]])
    Residuals <- get_node_residuals(outcome$forecasts,hts_node)
    # Residuals <- stats::ts(Residuals)
    hts_train_time <- shiny::isolate(reactData$hts_train_time)
    Residuals_xts <- xts::as.xts(Residuals,order.by=reactData$hts_train_time)
    # Residuals_df <- data.frame(x=Residuals,Data=reactData$hts_train_time)
    residualPlots <- ggtsGraphs(Residuals_xts,lag.max=length(Residuals)-1,xlab='Time',ylab='Residual')
    residualPlots
  })
  
  output[[hts_ggts_residuals]] <- shiny::renderPlot({
    tryCatch({
      
      resid_plot <- residuals_reactive()[[1]]
      reactData[[hts_ggts_residuals]] <- resid_plot
      resid_plot
    },error=function(e){print(e)})
  })
  
  output[[hts_ggts_acf]] <- shiny::renderPlot({
    tryCatch({
      acf_plot <- residuals_reactive()[[2]]
      reactData[[hts_ggts_acf]] <- acf_plot
      acf_plot
    },error=function(e){print(e)})
  })
  
  output[[hts_ggts_pacf]] <- shiny::renderPlot({
    tryCatch({
      pacf_plot <- residuals_reactive()[[3]]
      reactData[[hts_ggts_pacf]] <- pacf_plot
      pacf_plot
    },error=function(e){print(e)})
  })
  
  
  output[[hts_hist_residuals]] <- shiny::renderPlot({
    tryCatch({
      hts_level <- input[[hts_level]]
      hts_node <- input[[hts_node]]
      outcome <- shiny::isolate(reactData$models[[model_name]])
      Residuals <- get_node_residuals(outcome$forecasts,hts_node)
      # out <- hist(Residuals, breaks="FD", ggplot2::xlab="Residuals",main="Histogram of Residuals")
      Residuals_df <- data.frame(Residuals=Residuals)
      hts_hist <- univarHistPlot(Residuals_df,'Residuals')
      reactData[[hts_hist_residuals]] <- hts_hist
      return(hts_hist)
    },error=function(e){})
  })
  
  output[[hts_ljung_residuals]] <- shiny::renderPlot({
    tryCatch({
      hts_level <- input[[hts_level]]
      hts_node <- input[[hts_node]]
      outcome <- shiny::isolate(reactData$models[[model_name]])
      Residuals <- get_node_residuals(outcome$forecasts,hts_node)
      # Box.Ljung.Test(Residuals,lag=length(Residuals)-1)
      hts_ljungPlot <- ljungBoxPlot(Residuals,lag=length(Residuals)-1) 
      # out <- recordPlot()
      reactData[[hts_ljung_residuals]] <- hts_ljungPlot
      return(hts_ljungPlot)
    },error=function(e){})
  })
  
}

#----------------------------------------------------------------------------------------------------------------#
#--------- NON-HTS ----------------------------------------------------------------------------------------------#


updateNonHtsPlots <- function(suffix,name,yVar,TimeVar,input,output,reactData,residuals=NULL){
  print('plotting funcs')
  
  model_name <- suffix
  fitted_model_desc <- ifelse(model_name=='arima','fitted_model_desc',paste0('fitted_model_',model_name))
  accuracy <- ifelse(model_name=='arima','accuracy',paste0("accuracy_",model_name))
  forecast_graph <- ifelse(model_name=='arima','forecast_graph',paste0('forecast_graph_',model_name))
  download_forecast <- paste0('download_forecast_',model_name)
  ggts_residuals <- paste0('ggts_residuals_',model_name)
  ggts_acf <- paste0('ggts_acf_',model_name)
  ggts_pacf <- paste0('ggts_pacf_',model_name)
  hist_residuals <- paste0('hist_residuals_',model_name)
  ljung_residuals <- paste0('ljung_residuals_',model_name)
  
  outcome <- reactData$models[[suffix]]
  fit <- outcome$model
  
  # Remove call from HoltWinters and SVR as it shows data
  fit_model_summary <- fit
  if(model_name %in% c("hw","svr","tbats")){
    fit_model_summary$call <- NULL
  }
  
  forecast_validation <- outcome$forecasts
  
  forecast_dataset <- reactive({
    fcast_data <- data.frame(TimeVar=time(reactData$xts_validation_data),yVar=forecast_validation$mean)
    colnames(fcast_data) <- c(TimeVar,yVar)
    return(fcast_data)
  })

  output[[fitted_model_desc]] <- shiny::renderPrint({
  
    print('###############',quote=FALSE)
    print('     Model     ',quote=FALSE)
    print('###############',quote=FALSE)
    print('',quote=FALSE)
    print(fit_model_summary)
    reactData[[fitted_model_desc]] <- fit_model_summary
  })
  # 
  # output[[download_forecast]] <- shiny::downloadHandler(
  # 
  #   filename = paste('forecast_',yVar,'_',model_name,'.csv',sep=""),
  #   content = function(file) {
  #     write.csv(forecast_dataset(),file)
  #   }
  # )
  observeEvent(input[[download_forecast]],{
    tryCatch({
      progress <- shiny::Progress$new()
      # Make sure it closes when we exit this reactive, even if there's an error
      on.exit(progress$close())
      progress$set(message = "Downloading forecast...")
      filename = paste('forecast_',yVar,'_',model_name,'.csv',sep="")
      write.csv(forecast_dataset(),file = paste0("Downloads/",filename),row.names=FALSE)
      shiny::showNotification('The downloaded file can be found in Downloads folder')
    },error=function(e){
      shiny::showNotification(e)
    }
    )
  })
  
  output[[accuracy]] <- shiny::renderPrint({
    print('##################',quote=FALSE)
    print('     Accuracy     ',quote=FALSE)
    print('##################',quote=FALSE)
    print('',quote=FALSE)
    out_accuracy <- getAccuracy_func(outcome,reactData$xts_train_data,reactData$xts_validation_data)
    print('Train MAPE',quote = FALSE)
    print(out_accuracy$train_mape)
    print('Test MAPE',quote=FALSE)
    print(out_accuracy$test_mape)
    reactData[[accuracy]] <- out_accuracy
  })
  if(is.null(residuals))
    residuals <- forecast_validation$residuals
  
  diff_rows <- length(stats::time(reactData$xts_train_data))-length(residuals)
  if(diff_rows>0){
    Residuals <- c(rep(NA,diff_rows),residuals)
  }
  else{
    Residuals <- residuals
  }
  
  Residuals_xts <-
    xts::as.xts(as.vector(Residuals),
                order.by = stats::time(reactData$xts_train_data))
  # Residuals_df <- data.frame(x=Residuals,Data=reactData$hts_train_time)
  residualPlots <- ggtsGraphs(Residuals_xts,lag.max=length(Residuals)-1,xlab='Time',ylab='Residual')
  
  output[[ggts_residuals]] <- shiny::renderPlot({
    reactData[[ggts_residuals]] <- residualPlots[[1]]
    residualPlots[[1]]
  })
  
  output[[ggts_acf]] <- shiny::renderPlot({
    reactData[[ggts_acf]] <- residualPlots[[2]]
    residualPlots[[2]]
  })
  
  output[[ggts_pacf]] <- shiny::renderPlot({
    reactData[[ggts_pacf]] <- residualPlots[[3]]
    residualPlots[[3]]
  })
  
  output[[hist_residuals]] <- shiny::renderPlot({
    Residuals_df <- data.frame(Residuals=as.vector(Residuals))
    hist <- univarHistPlot(Residuals_df,'Residuals')
    reactData[[hist_residuals]] <-  hist
    return(hist)
  })
  
  output[[ljung_residuals]] <- shiny::renderPlot({
    # LSTS::Box.Ljung.Test(Residuals,lag=length(residuals)-1)
    ljungPlot <- ljungBoxPlot(Residuals,lag=length(Residuals)-1)
    reactData[[ljung_residuals]] <- ljungPlot
    return(ljungPlot)
  })
  
  
}






#----------------------------------------------------------------------------------------------------------------#
#--------- SMOOTHING FUNCTIONS ----------------------------------------------------------------------------------#

# preprocess_smoothing_data <- function(hierarchy_columns,data){
#   hierarchy_columns <- hierarchy_columns
#   level_inputs <- unlist(lapply(c(1:length(hierarchy_columns)),function(i) input[[paste0('smooth_level_',i)]]))
#   filter_string  <- paste(paste(hierarchy_columns,'==',shQuote(level_inputs)),collapse=' & ')
#   smoothing_dataset <- data %>% filter_(filter_string)
#   return(smoothing_dataset)
# }
# 
# 
# get_smoothened_data <- function(data,smoothing_method,smoothing_columns,TimeZone,params=list()){
#   
#   smoothened_object <- switch(smoothing_method,
#                               "Moving Average"={
#                                 
#                                 smoothObjList <- lapply(smoothing_columns,function(x){
#                                   
#                                   data_params <- c('x'= list(data[,x]),params)
#                                   obj <- do.call(TTR::SMA,data_params)
#                                   indexTZ(obj) <- TimeZone
#                                   
#                                   return(obj)
#                                 })
#                                 
#                                 names(smoothObjList) <- smoothing_columns
#                                 
#                                 for(i in 1:length(smoothing_columns))
#                                   attr(smoothObjList[[i]],'dimnames') <- list(NULL,smoothing_columns[i])
#                                 
#                                 return(smoothObjList)
#                                 
#                               },
#                               "Simple Exponential Smoothing"={
#                                 smoothObjList <- lapply(smoothing_columns,function(x) {
#                                   
#                                   data_params <- c(y= list(ts(data[,x])),params)
#                                   model <- do.call(forecast::ses,data_params)
#                                   obj <- xts::as.xts(timeSeries(model$fitted,attr(model$x,'index')))
#                                   indexTZ(obj) <- TimeZone
#                                   return(obj)
#                                 })
#                                 
#                                 names(smoothObjList) <- smoothing_columns
#                                 
#                                 for(i in 1:length(smoothing_columns))
#                                   attr(smoothObjList[[i]],'dimnames') <- list(NULL,smoothing_columns[i])
#                                 
#                                 return(smoothObjList)
#                               }
#   )
#   
# }

a <- function(b,...){
  print(is.null(list(...)))
  print(!is.null(list(...)))
}


