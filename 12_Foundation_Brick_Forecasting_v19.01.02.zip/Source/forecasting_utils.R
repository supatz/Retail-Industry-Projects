# source('Source/forecast-gts.R')

#----------------------------------------------------------------------------------------------------------------#
#--------- COMMON FUNCTIONS -------------------------------------------------------------------------------------#
packages <- NULL
dbPackages <- NULL
projectID <- NULL

loadGlobals <- function() {
  packages <<- c("plyr","png","grid","ggplot2","shiny","gridExtra","htmlTable","moments","xtable","knitr","rmarkdown","igraph",
                "corrgram","pander","dplyr","tseries","GGally","corrr","corrplot","nFactors","data.table","lsr","spaa",
                "car","forecast","reshape2","reshape","qpcR","sp","dummies","GPArotation","cluster","ggfortify","stats","DandEFA",
                "deldir","viridis","lattice", "shinyjs", "stringi", "dendextend", "colourpicker", "httr", "rjson", "shinyBS", 
                "forcats","zoo","xts", "gridExtra","htmltools","dygraphs", "lubridate","DT","urca","tseries",'egcm','timeSeries','jsonlite',
                'hts','reshape2','plotly','earth','RColorBrewer','prophet','LSTS','vars','e1071','rucm',"padr","imputeTS")

  
  dbPackages <<- c("rJava", "RPostgreSQL", "RMySQL", "RSQLite", "DBI","RJDBC","odbc")
  projectID <<- 141

  if(file.exists("Source/packageList.csv")){
    packageList <<- read.csv("Source/packageList.csv")
  } else if(file.exists("packageList.csv")){
    packageList <<- read.csv("packageList.csv")
  } else {
    packageList <<- NULL
  }
  }

# Function to load the packages
loadPackage <- function(pkgName) {
  if (!do.call(require, list(pkgName))) {
    install.packages(pkgName, dependencies = T, repos = "http://cran.us.r-project.org")
    do.call(library, list(pkgName))
  }
}


getNumColNames <- function(data){
  require(lubridate)
  logical <- sapply(data,function(x) is.numeric(x) & !is.Date(x))
  colnames(data)[logical]
}

getCharColNames <- function(data){
  logical <- sapply(data,is.character)
  colnames(data)[logical]
}

getFactorColNames <- function(data){
  logical <- sapply(data,is.factor)
  colnames(data)[logical]
}


# remove_factors <- function(data){
#   data <- lapply(data,function(x){
#     if(is.factor(x))
#       return(as.character(x))
#     else 
#       return(x)
#   })
# }

make_xts <- function(data,timeVar){
  cols <- dplyr::setdiff(colnames(data),timeVar)
  xts_data <- xts::as.xts(data[,cols],order.by=data[,timeVar])
  if(dim(xts_data)[2]==1){
    colnames(xts_data) <- cols
  }
  return(xts_data)
}


#----------------------------------------------------------------------------------------------------------------#
#--------- DATA ROLLUP BY TIME ----------------------------------------------------------------------------------#
  

find_roll_range <- function(data,roll_level){
  
   roll_range <- switch(roll_level,
                        "seconds"={
                          roll_min <- 1
                          no_sec <- xts::nseconds(data)
                          if (no_sec > 59) {
                            roll_max <- 59
                          }
                          else
                            roll_max <- no_sec
                          list("roll_min"=roll_min,"roll_max"=roll_max)
                        },
                        "minutes"={
                          roll_min <- 1
                          no_min <- xts::nminutes(data)
                          if (no_min > 59) {
                            roll_max <- 59
                          }
                          else
                            roll_max <- no_min
                          list("roll_min"=roll_min,"roll_max"=roll_max)
                        },
                        "hours"={
                          roll_min <- 1
                          no_hours <- xts::nminutes(data)
                          if (no_hours > 23) {
                            roll_max <- 23
                          }
                          else
                            roll_max <- no_hours
                          list("roll_min"=roll_min,"roll_max"=roll_max)
                        },
                        "days"={
                          roll_min <- 1
                          no_days <- xts::ndays(data)
                          if (no_days > 30) {
                            roll_max <- 30
                          }
                          else
                            roll_max <- no_days
                          list("roll_min"=roll_min,"roll_max"=roll_max)
                        },
                        "months"={
                          roll_min <- 1
                          no_months <-xts::nmonths(data)
                          if (no_months > 11) {
                            roll_max <- 11
                          }
                          else
                            roll_max <- no_months
                          list("roll_min"=roll_min,"roll_max"=roll_max)
                        },
                        "years"={
                          roll_min <- 1
                          no_years <- xts::nyears(data)
                          roll_max <- no_years
                          list("roll_min"=roll_min,"roll_max"=roll_max)
                        }
                        
                        )
}



roll_data_by_time <- function(Roll_Level,data,TimeVar,DTformat,TimeZone,AnomalyVar,Roll_Option,Roll_Period){
  #data[,TimeVar] <- parse_date_time(data[,TimeVar],orders = DTformat,tz = TimeZone)
  data <- make_xts(data,TimeVar)
  ep <- xts::endpoints(data[,AnomalyVar],on = Roll_Level, k=Roll_Period)
  rolled_data <- xts::period.apply(data[,AnomalyVar],INDEX = ep,FUN = Roll_Option)
  rolled_df <- data.frame(TimeVar = zoo::index(rolled_data), AnomalyVar= zoo::coredata(rolled_data))
  colnames(rolled_df)[1] <- TimeVar
  return(rolled_df)
}


rollupDataByTime <- function(data,HierarchyColumns,Roll_Level,TimeVar,DTformat,TimeZone,AnomalyVar,Roll_Option,Roll_Period){
  
  if(!is.null(HierarchyColumns)){
    
    unique_hierarchy_values <- as.matrix(unique(data[,HierarchyColumns]),nrows = nrow(data))
    
    colnames(unique_hierarchy_values) <- HierarchyColumns
    
    getFilterString <- function(nameList,values){
      paste(paste(nameList,'==',shQuote(values)),collapse=' & ')
    }
    
    split_rolled_data <- apply(unique_hierarchy_values,1,function(x) {
      fstring <- getFilterString(HierarchyColumns,x)
      split <- data %>% dplyr::filter_(fstring) 
      rolled_data <- roll_data_by_time(Roll_Level,split,TimeVar,DTformat,TimeZone,AnomalyVar,Roll_Option,Roll_Period)
      x <- data.frame(t(x),stringsAsFactors = F)
      colnames(x) <- colnames(unique_hierarchy_values)
      dat <- cbind(data.frame(x),rolled_data) #Attaching the hierarchy columns
      colnames(dat) <- gsub('AnomalyVar.','',colnames(dat))
      dat[,unique(colnames(dat))] # To remove duplicate columns
    })
    
    rolled_df <- do.call(rbind, split_rolled_data)
    
    row.names(rolled_df) <- c(1:nrow(rolled_df))
  }
  else{
    rolled_df <- roll_data_by_time(Roll_Level,data,TimeVar,DTformat,TimeZone,AnomalyVar,Roll_Option,Roll_Period)
  }
  
  # update processed dataset and eda dataset
  colnames(rolled_df) <- gsub('AnomalyVar.','',colnames(rolled_df))
  
  return(rolled_df)
}




#--------------------------Reconciliation_Tables---------------------------#

get_reconciliation_table <- function(data,hts_level,hts_node,outcome,HierarchyColumns,hts_method){
 
  hts_level <- as.numeric(hts_level)
  forecast_aggts <- as.data.frame(hts::aggts(outcome$forecasts))
  base_aggts <- as.data.frame(outcome$forecasts$origfcasts)
  if (hts_level != 0){
    hts_node_column <- HierarchyColumns[hts_level]
    ini_split <- data[data[hts_node_column] == hts_node,]}
  else{
    ini_split <- data
  }
  
  if(length(HierarchyColumns) >= hts_level+1){
    hts_children_column <- HierarchyColumns[hts_level+1]
  }
  else{
    return(utils::head(forecast_aggts)[hts_node])
    
  }
  unique_children <-  as.character(unique(ini_split[hts_children_column])[,1])
  
  if(hts_method!='comb'){
  reconciliation_columns <- c(hts_node,unique_children)
  output <- utils::head(forecast_aggts)[reconciliation_columns]
  }
  else{
    reconciliation_weights <- outcome$forecasts$reconciliation_weights
    recon_colnames <- c(paste0(hts_node,'_forecast'),paste0(hts_node,'_base_forecast'),"Reconciliation_error",unique_children)
    node_table <- cbind(forecast_aggts[hts_node],base_aggts[hts_node],forecast_aggts[hts_node]-base_aggts[hts_node],base_aggts[unique_children])
    colnames(node_table) <- recon_colnames
    output <- rbind(c(rep('-',3),reconciliation_weights[unique_children]),node_table)
    rownames(output) <- c('weights',seq(1:nrow(node_table)))
    output <- utils::head(output)
    }
  
  
  #output <- data.frame(lapply(output,function(x) round(x,2)),stringsAsFactors = FALSE,check.names=FALSE)
  return(output)
}


#----------------------------------------------------------------------------------------------------------------#
#--------- WRAPPER FUNCTION FOR MODELS --------------------------------------------------------------------------#


##-- Global variable for storing all the models created by hts package
model_list <- list()



tsModel <- function(data,fmethod,params=list(),save_models=TRUE){
  #browser()
  print(paste0('Building ',fmethod,' model'))
    # Switch returns a list of two : First values is the acutal function name for creating the model and second is the parameter list
   # The first value is redundant with fmethod but fmethod can be a different name from the actual function name and can be mapped using this.
  params <- switch(fmethod,
                   'arima'={
                     params <- c(y=list(data),params)
                     list('Arima',params)  # Arima from forecast package.
                   }
                   ,'auto.arima'={
                     data <- ts(c(data),frequency=params$freq)
                     params$freq <- NULL
                     params <- c(x=list(data),params)
                     list('auto.arima',params)
                   }
                   ,'ets'={
                     params <- c(y=list(data),params)
                     list('ets',params)
                   }
                   ,'HoltWinters'={
                     params <- c(x=list(data),params)
                     list('HoltWinters',params)
                   }
                   ,'tbats'={
                     data <- as.numeric(data)
                     params <- c(y=list(data),params)
                     list('tbats',params)
                   }
                   ,'earth_custom'={
                     params <- c(x=list(data),params)
                     list('earth_custom',params)
                   }
                   ,'prophet' = {
                     #params <- c(df=list(data),params)
                     library(prophet)
                     list('fit.prophet',params)
                   },'VAR' = {
                     params <- c(y=list(data),params)
                     library("vars")
                     list('VAR',params)
                   },'ucm'= {
                       data <- data.frame(Y=c(data))
                       colnames(data) <- 'Y'
                       formula <- stats::as.formula('Y~0')
                       
                       if(!is.null(params$xreg)){
                         xreg <- data.frame(params$xreg)
                         data <- cbind(data,xreg)
                         formula <- stats::as.formula(paste0('Y ~ ',paste(colnames(xreg),collapse=' + ')))
                         params$xreg <- params$data <- NULL
                       }
                       params$xreg <- NULL
                       params <- c(formula=list(formula),data=list(data),params)
                       list(rucm::ucm,params)
                       
                     }
                     ,'SVR' = {
                       data <- data.frame(Y=c(data))
                       colnames(data) <- 'Y'
                       formula <- 'Y ~ '
                       lag_cols <- NULL
                       xreg_cols <- NULL
                       
                       if(params$n_lag>0){
                         data <- create_lagged_cols(data,'Y',params$n_lag)
                         params$n_lag <- NULL
                         lag_cols <- attr(data,'lagged_columns')
                       }
                       
                       if(!is.null(params$xreg)){
                         xreg <- data.frame(params$xreg)
                         row_diff <- nrow(xreg)-nrow(data)
                         if(row_diff>0)
                           xreg <- xreg[-c(1:row_diff),,drop=FALSE]
                         data <- cbind(data,xreg)
                         xreg_cols <- colnames(xreg)
                         params$xreg <- params$data <- NULL
                       }
                       
                       if(length(c(lag_cols,xreg_cols))==0) stop('No regressor variables provided.')
                       
                       formula <- as.formula(paste0(formula,paste(c(lag_cols,xreg_cols),collapse=' + ')))
                       params$xreg <- NULL
                       params <- c(formula=list(formula), data=list(data),params)
                       list(e1071::svm,params)
                     }
                   
                   )
  # browser()
  # Build the model using the fmethod(model function) and parameters provided
  model <- do.call(params[[1]],params[[2]])
  
  # Save this model to a global list
  if(exists('model_list') & save_models){
    print('Saving model')
    model_list[[fmethod]] <<- c(model_list[[fmethod]],list(model))
    
  }
  
  if(fmethod=='HoltWinters'){
    if(tryCatch(stats::is.ts(model$fitted[,'level']),error=function(x){return(FALSE)}))
      model$fitted <- model$fitted[,-2,drop=FALSE]
      
    if(tryCatch(stats::is.ts(model$fitted[,'trend']),error=function(x){return(FALSE)}))
      model$fitted <- model$fitted[,-2,drop=FALSE]
    
    if(tryCatch(stats::is.ts(model$fitted[,'season']),error=function(x){return(FALSE)}))
      model$fitted <- model$fitted[,-2,drop=FALSE]
  }
   
if(fmethod=='ucm'){
      model1 <- model
      model <- model$model
      parList <- dplyr::setdiff(names(model1),c('model','call'))
      invisible(lapply(parList,function(x){
        model[[x]] <<- model1[[x]]
      }))
      model$residuals <- stats::fitted(model) - model$y
      model$fitted <- stats::fitted(model)
      model_list$ucm[[1]]$call <<- NULL
    }
    
    if(fmethod=='SVR'){
      model$params <- params[[2]]
    }

   if(fmethod=='prophet'){
    model$fitted <- stats::predict(model,data)[,'yhat']
    model$residuals <- model$fitted - data[,'y']

   }
  
  if(fmethod=='VAR'){
    model$fitted <- stats::fitted(model)[,1,drop=FALSE]
  }
  

  
  return(model)
}



fCast <- function(data,isHts=FALSE,fmethod,ahead=10,params=list(),htsParams=list(),...){
#browser()
  require(forecast)

  if(isHts|hts::is.hts(data)){ # For hts series ----
    require(hts)

    htsParams <- c(htsParams,keep.fitted = TRUE, keep.resid = TRUE )
    
    
    params1 <- c('object' = list(data), h = list(ahead), htsParams, FUN = list(function(x){
   
      if(fmethod=='prophet'){
        args <- params
        values <- c(x)
        x <- data.frame(ds=args$ds_train,y=values)
        
        args['ds_train'] <- NULL
        args$xreg <- NULL
        
        prophet_obj <- do.call(prophet::prophet,args)
        if(!is.null(params$xreg)){
          x <- cbind(x,data.frame(params$xreg,stringsAsFactors = FALSE))
        
          prophet_obj <- prophet::add_regressor(prophet_obj,name=colnames(params$xreg)[1], prior.scale = NULL, standardize = "auto")
          
        }
        
        args <- list()
        args$m <- prophet_obj
        args$df <- x
        
        model <- tsModel(x, fmethod, params=args)
      }
      else if(fmethod=='VAR'){
        args <- params
        yVar <<- list(...)$yVar
        lag_order <<- args$p
        values <- c(x)
        x <- data.frame(values)
        colnames(x) <- yVar
        x <- cbind(x,args$endogen)

        args$endogen <- NULL
        model <- tsModel(x, fmethod, params=args)
      }
      else if(fmethod=='HoltWinters'){
        args <- params
        hw_freq <<- list(...)$hw_freq
        
        if(!is.null(hw_freq))
          x <- ts(c(x),frequency = hw_freq)
        
        args$hw_freq <- NULL
        model <- tsModel(x, fmethod, params=args)
      }
      else{
        model <- tsModel(x, fmethod, params=params)
      }
      model}
    )  
    )
    

    
    forecastValues <- do.call(forecast.gts,params1)
    print('Hts forecast created')
    return(list(model = NULL, isHts = isHts, forecasts = forecastValues))
    
  } else { # For Non-hts series ----
    
    modelObj <- tsModel(data,fmethod, params)
    
    if(fmethod=='VAR'){
      yVar <<- list(...)$yVar
    }
    
    if(fmethod %in% c('prophet','VAR','ucm'))
      params1 <- c(model=list(modelObj),h=list(ahead),htsParams)
    else 
      params1 <- c(object=list(modelObj),h=list(ahead),htsParams)
    forecastValues <- do.call(forecast::forecast,params1)
    print('Forecast created')
    return(list(model = modelObj, isHts = isHts, forecasts = forecastValues))
  }
  
}


  
  #----------------------------------------------------------------------------------------------------------------#
  #--------- SVM --------------------------------------------------------------------------------------------------#


  forecast.svm <- function(object,h,xreg=NULL){
    print('forecast.svm')
    data <- object$params$data
    xyvars <- all.vars(object$call$formula)
    yvar <- xyvars[1]
    lags <- length(dplyr::setdiff(xyvars,c(yvar,colnames(xreg))))
    lag_values <- utils::tail(data[,yvar],lags)
    
    if(h==0)
      stop('h cannot be zero!')
    
    predictions <- data.frame(do.call(rbind,lapply(c(1:h),FUN = function(x){
      lag_values <- utils::tail(lag_values,lags) # Values equal to number of lags required
      lag_data <- t(rev(lag_values)) # Reverse i.e last value is lag_1 and second_last is lag 2 so on..
      
      if(!is.null(xreg)){  # Adds xreg values 
        xreg_lag_data <- xreg[x,,drop=FALSE]
        lag_data <- cbind(lag_data,xreg_lag_data)
      }
      
      colnames(lag_data) <- dplyr::setdiff(xyvars, yvar) # give same column names as the predictors in the model
      
      pred <- stats::predict(object, lag_data) # Predict
      lag_values <<- c(lag_values, pred) # Add the prediction to the actual array
      return(pred)
    })),stringsAsFactors = FALSE)
    
    colnames(predictions) <-  c('mean')
    return(predictions)
  }
  
  
  
  #----------------------------------------------------------------------------------------------------------------#
  #--------- UCM --------------------------------------------------------------------------------------------------#
  

  
  forecast.SSModel <- function(model,h,xreg=NULL){
    # browser()
    print('forecast.SSModel')
    ucm_inputs <- dimnames(model$T)[[1]]
    
    level <- any(ucm_inputs=='level')
    slope <- any(ucm_inputs=='slope')
    
    season_length <- length(grep('^sea_dummy',ucm_inputs)) + 1
    cycle <- any(ucm_inputs=='cycle')
    
    # calculate cycle period
    loc <- grep('cycle',dimnames(attr(model$terms,'factors'))[[2]])
    if(length(loc)>0)
      cycle_period <- eval(parse(text=dimnames(attr(model$terms,'factors'))[[2]][loc]))$period
    
    if(!is.null(xreg)){
      xreg <- data.frame(xreg)
      xreg_cols_concat <- paste(colnames(xreg), collapse=' + ')
      
      cmdStr <- paste("rep(NA,nrow(xreg)) ~ ",xreg_cols_concat)
      
      if(level | slope){
        if(level & slope)
          cmdStr <- paste0(cmdStr," + ",'SSMtrend(2, Q = list(model$est.var.level, model$est.var.slope))')
        else 
          if(level)
            cmdStr <- paste0(cmdStr," + ",'SSMtrend(1, Q = list(model$est.var.level))')
          else if(slope)
            cmdStr <- paste0(cmdStr," + ",'SSMtrend(1, Q = list(model$est.var.slope))')
      }
      
      if(season_length>1){
        cmdStr <- paste0(cmdStr," + ",'SSMseasonal(',season_length,', Q = model$est.var.season)')
      }
      
      if(cycle){
        cmdStr <- paste0(cmdStr," + ","SSMcycle(",cycle_period,", Q= model$est.var.cycle)")
      }
      
      newdata <- SSModel(eval(parse(text=cmdStr)), H = model$irr.var, data=xreg)
      pred <- data.frame(stats::predict(model, newdata=newdata))
      colnames(pred) <- c('mean')
      return(pred)
    } else {
      pred <- data.frame(stats::predict(model, n.ahead=h))
      colnames(pred) <- c('mean')
      return(pred)
    }
    
  }
  
  #----------------------------------------------------------------------------------------------------------------#
  #--------- VARS--------------------------------------------------------------------------------------------------#
  
  
forecast.varest  <- function(model,h,xreg=NULL){
  
  tryCatch({
    
    if(h==0)
      stop('h cannot be NULL')
    
    dumvar <- NULL
    
    if(!is.null(xreg)){
      dumvar <- xreg
    }
    
    
    if(!is.null(dumvar)){
      if(h!=dim(dumvar)[1])
      stop('h and dumvar sizes dont match')
    }
    predictions <- as.data.frame(stats::predict(model,n.ahead=h,dumvar=dumvar)$fcst[[yVar]][,c("fcst","lower","upper")])
    
    colnames(predictions) <- c('mean','lower','upper')
    
    return(predictions)
  },error=function(e){print(e)})
  
}


  #-----------------------------------------------------------------------------------------------------------------#
  #--------- PROPHET -----------------------------------------------------------------------------------------------#
  
forecast.prophet <- function(model,h,xreg=NULL){
  tryCatch({
  # browser()
  if(dim(h)[1]==0)
    stop('h cannot be NULL')
  
   future <- h
  if(!is.null(xreg)){
    future <- cbind(future,data.frame(xreg,stringsAsFactors = FALSE))
  }
  
  predictions <- stats::predict(model,future)[,c('yhat','yhat_lower','yhat_upper')]

  colnames(predictions) <- c('mean','lower','upper')

  return(predictions)
  },error=function(e){print(e)})
}



#-- ACCURACY FUNCTION -------------------------------
# Wrapper function for getting accuracies
getAccuracy_func <- function(fitObj,trainObj,validationObj,metric='MAPE'){
  if(hts::is.hts(fitObj$forecasts)){
    test_accuracy <- hts::accuracy.gts(fitObj$forecasts,validationObj)[metric,,drop=FALSE]
    fitObj$forecasts$bts <- fitObj$forecasts$fitted # When train accuracy is required
    trainObj <- stats::window(trainObj,start=length(trainObj[[1]][,1])-length(fitObj$forecasts$fitted[,1])+1)
    train_accuracy <- hts::accuracy.gts(fitObj$forecasts,trainObj)[metric,,drop=FALSE]
    
  } else {
      diff_rows <- length(trainObj)-length(fitObj$model$fitted)
      if(diff_rows>0)
        fitObj$model$fitted <- c(rep(NA,diff_rows),fitObj$model$fitted)
      train_accuracy <- forecast::accuracy(fitObj$model$fitted,trainObj)[,metric] # Train accuracy
      test_accuracy <- forecast::accuracy(fitObj$forecasts$mean,validationObj)[,metric] # Test accuracy
  }
  return(list(train_mape=train_accuracy,test_mape=test_accuracy))
}





#----------------------------------------------------------------------------------------------------------------#
#--------- MARS--------------------------------------------------------------------------------------------------#


earth_custom <- function(x,nlag,xreg=NULL){
  print('earth_custom')
  lagged_train <- do.call(cbind,lapply(c(0:nlag),function(i){  
    dplyr::lag(c(x),i)}
  ))
 
  lag_colnames <- paste0('mars_data_lag_',c(1:nlag))
  colnames(lagged_train) <- c('target',lag_colnames)
  lagged_train <- data.frame(lagged_train,stringsAsFactors = FALSE)
  formula = paste0('target ~ ',paste(lag_colnames,collapse=' + '))
  
  
  if(!is.null(xreg)){
    xreg_cols <- colnames(xreg)
    lagged_train <- cbind(lagged_train,data.frame(xreg,stringsAsFactors = FALSE))
    
    formula <- paste0(c(formula,xreg_cols),collapse=' + ')
  }
  
  lagged_train <- lagged_train[complete.cases(lagged_train),]
  
  fit <- earth::earth(formula=eval(parse(text=formula)),data=lagged_train,nfold = 2,ncross = 30,varmod.method = 'earth',keepxy=TRUE)
}


forecast.earth <- function(object,h,xreg=NULL){
  print('forecast.earth')
  data <- object$data
  lags <- length(grep(pattern = '^mars_data_lag_',object$namesx))# One is the target variables and all others are lags
  
  lag_values <- utils::tail(data$target,lags)
  
  if(h==0)
    stop('h cannot be zero!')
  
  predictions <- data.frame(do.call(rbind,lapply(c(1:h),FUN = function(x){
    lag_values <- utils::tail(lag_values,lags) # Values equal to number of lags required
    lag_data <- t(rev(lag_values)) # Reverse i.e last value is lag_1 and second_last is lag 2 so on..
    
    if(!is.null(xreg)){  # Adds xreg values 
      xreg_lag_data <- xreg[x,,drop=FALSE]
      lag_data <- cbind(lag_data,xreg_lag_data)
    }
    
    colnames(lag_data) <- object$namesx # give same column names as the predictors in the model
    
    pred <- stats::predict(object,lag_data,interval='pint') # Predict
    lag_values <<- c(lag_values,pred$fit) # Add the prediction to the actual array
    return(pred)
  })),stringsAsFactors = FALSE)
  
  colnames(predictions) <-  c('mean','lower','upper')
  return(predictions)
}



#----------------------------------------------------------------------------------------------------------------#
#--------- PLOT FUNCTIONS-----------------------------------------------------------------------------------------#



# getTsPlots <- function(actual,outcome){
#   p <- plotly::plot_ly() %>%
#     plotly::add_lines(x = time(actual), y = actual,
#               color = I("black"), name = "observed") %>%
#     add_ribbons(x = time(outcome$mean), ymin = outcome$lower[, 2], ymax = outcome$upper[, 2],
#                 color = I("gray95"), name = "95% confidence") %>%
#     add_ribbons(x = time(outcome$mean), ymin = outcome$lower[, 1], ymax = outcome$upper[, 1],
#                 color = I("gray80"), name = "80% confidence") %>%
#     plotly::add_lines(x = time(outcome$mean), y = outcome$mean, color = I("blue"), name = "prediction")
#   
#   return(list(p))
# }
# 
# 
# getHtsPlots <- function(actual,outcome,colors=NULL){
#   require(RColorBrewer)
#   require(plotly)
#   require(hts)
#   
#   pred <- hts::aggts(outcome)
#   actual <- hts::aggts(actual)
#   plot_list <- list()
#   n <- length(outcome$labels)
#   for(j in 1:n){
#     level <- j-1
#     nodeNames <- outcome$labels[[paste0('Level ',level)]]
#     tsObj_actual <- actual[,nodeNames,drop=FALSE]
#     tsObj_pred <- pred[,nodeNames,drop=FALSE]
#     
#     if(is.null(colors))
#       colors <- c(brewer.pal(8,'Set1'),brewer.pal(8,'Dark2'))
#     
#     p <- plotly::plot_ly()
#     for(i in 1:length(nodeNames)){
#       name <- nodeNames[i]
#       p <- plotly::add_lines(p,x = time(tsObj_actual), y = tsObj_actual[,name],
#                      color = I(colors[i]), name = paste0(name,".observed")) %>%
#         plotly::add_lines(x = time(tsObj_pred), y = tsObj_pred[,name], color = I(colors[i]), name = paste0(name,'.predicted'),line=list(dash='dash')) %>% 
#         layout(annotations = list(x=time(tsObj_actual)[2],y=tsObj_actual[,name][1],text=name, showarrow = FALSE))
#     }
#     plot_list[[j]] <- p
#   }
#   
#   return(plot_list)
# }
# 
# 
# 
# #-- PLOTTING FUNCTION  -------------------------------
# 
# getPlots_func <- function(actual,outcome,colors=NULL){
#   if(is.hts(outcome)){
#     return(getHtsPlots(actual,outcome,colors))
#   } else {
#     return(getTsPlots(actual,outcome))
#   }
# }


download_forecast_hts <- function(outcome,hts_level,hts_node,hts_val_time,yVar,TimeVar,...){
  
  
  outcome <- outcome$forecasts
  predicted_agg <- hts::aggts(outcome)
  pred_start_time <- hts_val_time
  
  hts_fcast <- data.frame(TimeVar=pred_start_time,predicted_agg)
  colnames(hts_fcast)[1] <- TimeVar
  return(hts_fcast)
}


plotHts <- function(data, outcome, hts_level, hts_node, hts_data_time, hts_train_time, hts_val_time, ...){
  corporate_forecast_data <- list(...)$corporate_forecast_data
  
  outcome <- outcome$forecasts
  actual_agg <- hts::aggts(data)
  predicted_agg <- hts::aggts(outcome)
  #validation_agg <- hts::aggts(validation)
  
  actual_times <- hts_data_time
  train_times <- hts_train_time
  pred_start_time <- hts_val_time


  forecast_boundary_x <- utils::tail(train_times,1)
  len <- length(hts_node)
  colors <- c(RColorBrewer::brewer.pal(8,'Set1'),RColorBrewer::brewer.pal(8,'Dark2'))
  #colors <- rep('black',10)
  
  # yVar <<- list(...)$yVar
  # yVar <- "quantity"
  
  plot <- plotly::plot_ly() %>% plotly::add_trace(x= rep(forecast_boundary_x,2),
                                  y=c(min(c(actual_agg[,hts_node],predicted_agg[,hts_node])),max(c(actual_agg[,hts_node],predicted_agg[,hts_node])))
                                  ,mode='lines'
                                  ,name='Forecast boundary'
                                  ,line = list(color = 'green',dash='dash'))
  for(i in 1:len){
    node_name <- hts_node[i]
    plot <- plotly::add_lines(plot, actual_times, y = actual_agg[,node_name],mode='lines+markers',
                      color = I('black'), name = paste0(node_name,".actual")) %>%
      # plotly::add_lines(x = time(validation_agg), y = validation_agg[,hts_node],
      #           color = I("darkgrey"), name = "Validation") %>%
      plotly::add_lines(x = pred_start_time, y = predicted_agg[,node_name],
                color = I('red'),mode='lines+markers', name = paste0(node_name,".forecast"),line=list(dash='dot'))
    

    
    if(!is.null(corporate_forecast_data) && node_name=="Total"){
      plot <-  plotly::add_lines(plot,x=pred_start_time,y=corporate_forecast_data,color = I('green'),mode='lines+markers',name="Total.corporate")
    }
    
    

    if(!is.null(outcome$fitted)){
      actual_time <- stats::time(outcome$histy)
      # if(length(list(...))!=0){
      #   method = list(...)$fmethod
      #   if(method=='VAR'){
      # 
      #     outcome$fitted <- outcome$fitted[1:(length(actual_time)-as.numeric(lag_order)),]
      #   }
      # }
      outcome$bts <- outcome$fitted
      fitted_time <- stats::time(outcome$bts)
      na_index <- which(!is.na(outcome$bts[,1]))
      
      if(length(na_index) > 0)
        outcome$bts <- ts(outcome$bts[1:max(na_index),],frequency = frequency(outcome$bts),start=1)
      
      fitted_time <- utils::tail(train_times,length(stats::time(outcome$bts)))
      fitted_agg <- hts::aggts(outcome)
      
      plot <- plot  %>% plotly::add_lines(x = fitted_time, y = fitted_agg[,node_name],
                                  color = I("blue"), name = "Fitted") %>%
        plotly::add_lines(
          x = c(utils::tail(fitted_time, n = 1), pred_start_time[1]),
          y = c(utils::tail(fitted_agg[, node_name], n = 1), predicted_agg[, node_name][1]),
          color = I("red"),
          line = list(dash = 3),
          showlegend = F
        )
    }
    
  }
  
  return(plot)
  
}



get_hts_model_summary <- function(data,models,model_name,hts_method,hts_base_level,hts_node){
  
 # model_list <- model_list # Read from global variable and write to a local variable
  
  node_names <- NULL
  labels <- data$labels
  label_level <- switch(hts_method,
                        'bu'=length(labels)-1,
                        'mo'=hts_base_level,
                        'tdgsa'=0,
                        'tdgsf'=0,
                        'comb'=NULL)
  
  if(hts_method!='comb'){ 
    # For methods other than comb
    node_names <- data$labels[[paste0('Level ',label_level)]]
    names(models) <- node_names
  } else { 
    node_names <- unlist(data$labels)
    names(models) <- node_names
  }
  
  selected_model <- models[hts_node]
  
}


#-- Aggregates the residual values for each node in the hierarchy
  get_node_residuals <- function(htsObj,hts_node){
    htsObj$bts <- htsObj$histy
    actual <- c(hts::aggts(htsObj)[,hts_node])
    htsObj$bts <- htsObj$fitted
    fitted <- c(hts::aggts(htsObj)[,hts_node])
    diff_rows <- length(actual)-length(fitted)


    if(diff_rows>0)
      fitted <- c(rep(NA,diff_rows),fitted)
 
    residuals <- c(actual-fitted)
    return(residuals)
    
  }


  #----------------------------------------------------------------------------------------------------------------#
  #--------- DATA FORMATTING UTILS --------------------------------------------------------------------------------#
  

roundOffDataFrame <- function(data, roundOff = FALSE, precision = 4)
{
  if(roundOff) {
    data <- as.data.frame(sapply(data, function (x) {
                y <- class(x)
                if(y == "numeric") {
                    return(round(x, precision))
                }else if(y == "factor"){
                  return(as.character(x))
                }
                return(x)
            }))
  }
  return(data)
}

#----RAM size check---#
findRAMSize <- function (osType) {
  if (osType  ==  "Windows") {
    maxRAM <- as.numeric(utils::memory.limit()) * 1024 ^ 2
  } else if (osType  ==  "Linux") {
    maxRAM <- floor(as.numeric(system("awk '/MemTotal/ {print $2}' /proc/meminfo", intern = TRUE)) / 1024) * 1024 ^ 2
  } else if (osType  ==  "Darwin") {
    cmdOutput <- system("sysctl hw.memsize", intern = TRUE)
    maxRAM <- substr(cmdOutput, 13, nchar(cmdOutput))
    maxRAM <- (as.numeric(maxRAM) / (1024 * 1024)) * 1024 ^ 2
  } else {
    maxRAM <- 102400 * 1024 ^ 2
  }
  return(maxRAM)
}




get_imputation_method_name <- function(method){
  

  if(is.null(method)){return()}

  switch(method,
         "locf"="Last Observation carry Forward", 
         "nocb"="Next Observation carry Backward", 
         "interpolation"="Interpolation",
         "mean"="Mean",
         "median"="Median",
         "mode"="Mode",                          
         "kalman"="Kalman Smoothing and State Space Models",
         "ma"="Weighted Moving Average",
         "replace"="Replace with a specific value",
         "seadec"="Seasonal Decomposition",
         "seasplit"="Seasonal Split"
  )}



# Function for get Filter String
getFilterString <- function(nameList,values){
  paste(paste(nameList,'==',shQuote(values)),collapse=' & ')
}

#----------------------------------------------------------------------------------------------------------------#
#--------- LAGGED VARIABLES -------------------------------------------------------------------------------------#




create_lagged_cols <- function(dataset,columns_to_lag,n_lag,time_variable=NULL){
  
  print('Creating lagged columns')
  
  n_lag <- n_lag
  actual_columns <- colnames(dataset)
  columns_lagged <- columns_to_lag
  if(!is.null(time_variable))
    dataset <- dataset %>% plotly::arrange_(time_variable)
  
  lagged_cols_data <- lapply(columns_lagged, function(x) {
    
    all_cols <- colnames(dataset)
    lag_cols <- paste0(x,'_lag_',c(1:n_lag))
    not_there <- lag_cols[!lag_cols %in% all_cols]
    
    if(length(not_there)==0){
      return(NULL)
    }
    
    start_lag <- as.numeric(stringr::str_sub(not_there[1],-1))
    
    
    singlecol_lagged_data <-  do.call(cbind,lapply(c(start_lag:n_lag), function(i){
      dplyr::lag(c(dataset[[x]]),i)   }))
    
    extra_lag_colnames <- paste0(x,'_lag_',c(start_lag:n_lag))
    
    colnames(singlecol_lagged_data) <- extra_lag_colnames
    return(singlecol_lagged_data)
    
  })
  
  lagged_cols_data <- lagged_cols_data[!sapply(lagged_cols_data,is.null)]
  
  if(!length(lagged_cols_data)==0){
    binded <- cbind(dataset,lagged_cols_data)
    binded <- binded[-c(1:n_lag),]
    dataset <- binded
  }
  
  lagged_column_names <- dplyr::setdiff(colnames(dataset),actual_columns)
  attr(dataset,'lagged_columns') <- lagged_column_names
  
  return(dataset)
}


# Impute ts

impute_ts <- function(data,method,input,...){
  
  switch(method,
         'locf'={
           data <- imputeTS::na.locf(data,option = "locf",na.remaining = "rev")
         },
         'nocb'={
           data <- imputeTS::na.locf(data,option = "nocb",na.remaining = "rev")
         },
         'interpolation'={
           interpolation_option <- input$interpolation_option
           data <- imputeTS::na.interpolation(data,option = interpolation_option)
         },
         'kalman'={
           kalman_model <- input$kalman_model
           data <- imputeTS::na.kalman(data,model = kalman_model)
         },
         'ma'={
           moving_avg_method <- input$moving_avg_method
           moving_avg_window <- input$moving_avg_window
           data <- imputeTS::na.ma(data,k = moving_avg_window,weighting=moving_avg_method)
         },
         'mean'={
           data <- imputeTS::na.mean(data,option ="mean")
         },
         'median' = {
           data <- imputeTS::na.mean(data,option ="median")
         },
         'mode' = {
           data <- imputeTS::na.mean(data,option ="mode")
         },
         'replace'= {
           replace_fill <- input$replace_fill
           data <- imputeTS::na.replace(data,fill = replace_fill)
         }

  )
}

# Non -HTS  check for missing,inequally spaced values and update UI

update_ui_and_text_if_missing_values <- function(datetime_vector_length,datetime_length,output){
  if (datetime_vector_length==datetime_length){
    output$missing_value_text <- shiny::renderText("The data doesn't have missing values")
    output$imputation_ui <- shiny::renderUI({})
  }
  else if(datetime_vector_length>datetime_length){
    output$missing_value_text <- shiny::renderText("The data has missing DateTime values")
    output$imputation_ui <- shiny::renderUI(imputation_method_ui())
  }
  else{
    output$missing_value_text <- shiny::renderText("The data has duplicate values or inequally spaced time intervals")
    output$imputation_ui <- shiny::renderUI({})
    
  }
  return(output)
}

# HTS check for missing,duplicate,inequally spaced values

update_lists_if_missing_values_hts <- function(unique_hierarchy_values,HierarchyColumns,datetime_vector_length,reactData){
  split_data_to_check_missing <- apply(unique_hierarchy_values,1,function(x) {
    fstring <- getFilterString(HierarchyColumns,x)
    split_data <- reactData$processed_dataset %>% plotly::arrange_(reactData$TimeVar) %>% dplyr::filter_(fstring)
    datetime_length <- length(split_data[,reactData$TimeVar])
    # Can be implemented similar to Non-HTS but won't be optimized probably
    if (length(unique(split_data[,reactData$TimeVar]))<datetime_length){
      reactData$duplicate_splits <- c(reactData$duplicate_splits,last(x)[[1]])
    }
    else if (datetime_vector_length==datetime_length){
      reactData$correct_splits <- c(reactData$correct_splits,last(x)[[1]])
    }
    else if(datetime_vector_length>datetime_length){
      reactData$missing_splits <- c(reactData$missing_splits,last(x)[[1]])
      uhv_data <- matrix(as.vector(x),nrow=1)
      reactData$unique_hierarchy_values_missing <- rbind(reactData$unique_hierarchy_values_missing,uhv_data)
    }
    else{
      reactData$duplicate_or_inequal_splits <- c(reactData$duplicate_or_inequal_splits,last(x)[[1]])
    }
  })
}

# Update Text and UI for HTS

update_ui_and_text_if_missing_values_hts <- function(output,reactData,unique_hierarchy_values,no_of_panels_last_level){
  
  output$missing_value_text <- shiny::renderText({
    
    duplicate_text <- NULL
    duplicate_or_inequal_text <- NULL
    correct_text <- NULL
    missing_text <- NULL        
    
    
    if (length(reactData$duplicate_splits) > 0) {
      duplicate_text <-
        paste0(
          "The ",
          dplyr::last(colnames(unique_hierarchy_values)),
          " has duplicate datetime values for panels :- ",
          paste(
            reactData$duplicate_splits,
            sep = " ",
            collapse = ", "
          )
        )
    }
    if (length(reactData$duplicate_or_inequal_splits) > 0) {
      duplicate_or_inequal_text <-
        paste0(
          "The ",
          dplyr::last(colnames(unique_hierarchy_values)),
          " has duplicate or inequally spaced datetime values for panels :- ",
          paste(
            reactData$duplicate_or_inequal_splits,
            sep = " ",
            collapse = ", "
          )
        )
    }
    if (length(reactData$correct_splits) == no_of_panels_last_level) {
      correct_text <- paste0("The data doesn't have missing values")
      return(correct_text)
    }
    if (length(reactData$missing_splits) > 0) {
      missing_text <-
        paste0(
          "The ",
          dplyr::last(colnames(unique_hierarchy_values)),
          " has missing datetime values for panels :- ",
          paste(
            reactData$missing_splits,
            sep = " ",
            collapse = ", "
          )
        )
    }
    combined_string <-
      stringr::str_c("</br",
                     duplicate_text,
                     duplicate_or_inequal_text,
                     missing_text,
                     sep = "</br>")
    textOutput_to_display <- htmltools::HTML(combined_string)
  })
  
  output$imputation_ui <- shiny::renderUI({
    if(length(reactData$duplicate_splits)==0 &&  length(reactData$duplicate_or_inequal_splits)==0 && length(reactData$missing_splits)>0){
      imputation_ui <- imputation_method_ui()
    }
  })
}

# Imputation UI function
imputation_method_ui <- function(){
  htmltools::tagList(shiny::tags$br(),
          shiny::column(3,shiny::selectInput('imputation_method',
                               'Select the method to impute the data',
                               choices=c("Last observation carry forward"="locf",
                                         "Next observation carry backward"="nocb",
                                         "Interpolation"="interpolation",
                                         "Kalman smoothing and State Space Model"="kalman",
                                         "Weighted Moving Average"="ma",
                                         "Mean"="mean",
                                         "Median"="median",
                                         "Mode"="mode",
                                         "Replace with a specific value"="replace"
                                         # "Seasonally Decomposed"="seadec",
                                         #"Seasonally splitted"="seasplit"
                               ))),
          
          shiny::conditionalPanel("input.imputation_method=='interpolation'",
                           shiny::column(3,shiny::selectInput(inputId = "interpolation_option",
                                                label = "Select algo to be used",
                                                choices = c("linear","spline","stine"),
                                                selected = "linear"))),
          shiny::conditionalPanel("input.imputation_method=='kalman'",
                           shiny::column(3,shiny::selectInput(inputId = "kalman_model",
                                                label = "Select model to be used",
                                                choices = c("auto.arima","StructTS"),
                                                selected = "auto.arima"))),
          shiny::conditionalPanel("input.imputation_method=='ma'",
                           shiny::column(3,shiny::selectInput(inputId = "moving_avg_method",
                                                label = "Select method to be used",
                                                choices = c("Simple Moving Average"="simple",
                                                            "Linear Weighted Moving Average"="linear",
                                                            "Exponential Weighted Moving Average"="exponential"))),
                           shiny::column(3,numericInput(inputId = "moving_avg_window",
                                                 label = "Moving Average Window",
                                                 value = 1,
                                                 min = 1,
                                                 step = 1))),
          shiny::conditionalPanel("input.imputation_method=='replace'",
                           shiny::column(3,numericInput(inputId = "replace_fill",
                                                 label = "Enter the value",
                                                 value = 0))),
      
          
          shiny::column(class='button_pad',2,actionButton("imputation_submit","Submit"))
  )
}

#prediction interval function
prdIntrvl80 <- function(data){
  # browser()
  zscore80 <- 1.282
  zscore95 <- 1.960
  sigma <- mean(data[["mean"]] - data[["lower"]])/zscore95
  data[["upper80"]] <- data[["mean"]] + sigma * zscore80
  data[["lower80"]] <- data[["mean"]] - sigma * zscore80
  return(data)
} 
