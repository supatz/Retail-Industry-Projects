##########################################
## SOURCING FILES AND LOADING LIBRARIES ##
##########################################

set.seed(42)

options(warn = -1)

## Initialising variables
allTestResults <- list()
# toRetain <- ls() # Saving variables that already exist in workspace
failedTestResults <- list()
result <- list()
# 
# ## Initialising functions
# 
# failedindex <- function(d, failedTests)
# {
#   if(!is.null(failedTests[[d]]$Result) && failedTests[[d]]$Result != "Result : Test passed")
#   {
#     return(d)
#   }
# }
# 
# findFailedIndex <- function(failedTests)
# {
#   listIndex <- sapply(1:length(failedTests), FUN = failedindex, failedTests)
#   listIndex[sapply(listIndex, is.null)] <- NULL
#   return(as.numeric(as.character(listIndex)))
# }

packages <- c("ggplot2", "cluster", "fpc", "clustMixType", "flashClust", "dendextend", "reshape", "EMCluster", "kohonen",
              "MASS", "sp", "dplyr", "deldir", "fpc", "TSclust")

loadPackage <- function(pkgName)
{
  if (!do.call(require, list(pkgName)))
  {
    # install.packages(pkgName, dependencies = T, repos = "http://cran.us.r-project.org")
    do.call(library, list(pkgName))
  }
}

#Importing all packages
lapply(packages, FUN = function(p){ loadPackage(p)})

source("ClusteringUtils.R")
loadGlobals()
source("EDAUtils/00.CommonMethods_Individual.R")

library(testthat)
library(futile.logger)

flog.threshold(INFO)
flog.appender(appender.file("./testCases.log"))

primaryColor = "#17E6E6"
secondaryColor = "#756F75"

###################
## LOAD DATASETS ##
###################

hotel <- read.csv("../SampleDatasets/hotel_edited.csv")
hotel <- hotel[,setdiff(colnames(hotel), c("hotel_id", "Class"))]
hotel <- na.omit(hotel)

smiley <- read.csv("../SampleDatasets/smiley.csv")
smiley <- smiley[,-3]

hypercube <- read.csv("../SampleDatasets/hypercube4D.csv")
hypercube <- hypercube[,-5]

# model_smiley <- kmeans(smiley, 4)
# model_hotel <- kproto(hotel, 2)

#########################
## META FILE FUNCTIONS ##
#########################

### Testing metaFileLoad()
testMetaFileLoad <- function(varTypeFile, data, results)
{
  failedTests <- list()
  obj <- metaFileLoad(varTypeFile, data)
  error <- tryCatch(
    {
      test_that("Checking meta file load",
                {
                  expect_equal(class(obj$typeData), results$typeDataType)
                  expect_equal(dim(obj$typeData), results$typeDataDim)
                  expect_equal(as.character(obj$typeData$Column), results$typeDataColumn)
                  expect_equal(unlist(obj$typeData$Column.Type), results$typeDataColumnType)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testMetaFileLoad(NULL, smiley, list(typeDataType = "data.frame", typeDataDim = c(2, 2), 
                                              typeDataColumn = c("V1", "V2"), typeDataColumnType = c("numeric", "numeric")))
result <- append(result, list(testMetaFileLoad(NULL, hotel, list(typeDataType = "data.frame", typeDataDim = c(23, 2), 
                                                 typeDataColumn = c("max_rooms_capacity", "building_type", "location_type", 
                                                                    "Occupancy", "AvgDailyRate", "Compet_Occupancy", 
                                                                    "Compet_AvgDailyRate", "PercentGovtNights", "PercentGroupNights", 
                                                                    "PercentTransientNights", "PercentBusiness", "PercentLeisure", 
                                                                    "hotelcount1mile", "hotelcount5mile", "rooms1mile", "rooms5mile", 
                                                                    "loyalty_pct", "call_center_booking_pct", "travel_agency_booking_pct",
                                                                    "third_party_web_bookings_pct", "hotel_to_hotel_bookings_pct", 
                                                                    "direct_call_booking_pct", "direct_web_booking_pct"), 
                                                 typeDataColumnType = c("numeric", "character", "character", "numeric", "numeric", 
                                                                        "numeric", "numeric", "numeric", "numeric", "numeric", "numeric",
                                                                        "numeric", "numeric", "numeric", "numeric", "numeric", "numeric",
                                                                        "numeric", "numeric", "numeric", "numeric", "numeric", "numeric")))))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nmetaFileLoad() test starts\n", 
                                                                                             x, "metaFileLoad() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nmetaFileLoad() test starts\n", x, "\nmetaFileLoad() test ends\n\n")))
  }
})
### end of metaFileLoad() test

### Testing useMetaFile()
testUseMetaFile <- function(data, typeData, results)
{
  failedTests <- list()
  obj <- useMetaFile(data, typeData)
  error <- tryCatch(
    {
      test_that("Checking meta file evaluation",
                {
                  expect_equal(class(obj$data), results$dataClass)
                  expect_equal(dim(obj$data), results$dataDim)
                  expect_equal(as.character(obj$catCols), results$catCols)
                  # expect_equal(unlist(obj$typeData$Column.Type), results$typeDataColumnType)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
typeData <- metaFileLoad(NULL, hotel)$typeData
result <- testUseMetaFile(hotel, typeData, list(dataClass = "data.frame", dataDim = c(606, 23), catCols = c("building_type", "location_type")))
typeData <- metaFileLoad(NULL, smiley)$typeData
result <- append(result, list(testUseMetaFile(smiley, typeData, list(dataClass = "data.frame", dataDim = c(1000, 2), catCols =  character(0)))))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nuseMetaFile() test starts\n", 
                                                                x, "useMetaFile() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nuseMetaFile() test starts\n", x, "\nmuseMetaFile() test ends\n\n")))
  }
})
### end of useMetaFile() test

### Testing standardizeData()
testStandardizeData <- function(data, catColCount, results)
{
  failedTests <- list()
  obj <- standardizeData(data, catColCount)
  error <- tryCatch(
    {
      test_that("Checking data standardization",
                {
                  expect_equal(class(obj), results$dataClass)
                  expect_equal(dim(obj), results$dataDim)
                  expect_equal(unname(unlist(sapply(obj, is.numeric))), results$str)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testStandardizeData(hotel, ncol(hotel)-2, list(dataClass = "data.frame", dataDim = c(606, 23), 
                                                         str = c(TRUE, FALSE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 
                                                                 TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE)))
result <- append(result, list(testStandardizeData(smiley, ncol(smiley), list(dataClass = "data.frame", dataDim = c(1000, 2), 
                                                                             str =  c(TRUE, TRUE)))))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nstandardizeData() test starts\n", 
                                                                x, "standardizeData() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nstandardizeData() test starts\n", x, "\nstandardizeData() test ends\n\n")))
  }
})
### end of useMetaFile() test

### END OF META FILE FUNCTIONS ###

######################
## COMMON FUNCTIONS ##
######################

### Testing findDependentColumns()
testFindDependentColumns <- function(data, y, results)
{
  failedTests <- list()
  obj <- findDependentColumns(data, y)
  error <- tryCatch(
    {
      test_that("Checking function to find dependent columns",
                {
                  expect_equal(obj, results)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testFindDependentColumns(hotel, colnames(hotel)[6], c("PercentTransientNights", "PercentLeisure", "direct_web_booking_pct"))
result <- append(result, list(testFindDependentColumns(hotel, colnames(hotel)[20], c("PercentTransientNights", "PercentLeisure" ))))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nfindDependentColumns() test starts\n", 
                                                                x, "findDependentColumns() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nfindDependentColumns() test starts\n", x, "\nfindDependentColumns() test ends\n\n")))
  }
})
### end of findDependentColumns() test

### Testing findDependentColumns()
testHandleMissingValues <- function(data, remove, results)
{
  failedTests <- list()
  obj <- handleMissingValues(data, remove)
  error <- tryCatch(
    {
      test_that("Checking function to find dependent columns",
                {
                  expect_equal(class(obj$data), results$dataClass)
                  expect_equal(dim(obj$data), results$dataDim)
                  expect_equal(obj$mssg, results$mssg)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
hotel <- read.csv("../SampleDatasets/hotel_edited.csv")
hotel <- hotel[,setdiff(colnames(hotel), c("hotel_id", "Class"))]
result <- testHandleMissingValues(hotel, F, list(dataClass = "data.frame", dataDim = c(858, 23), 
                                                 mssg = "WARNING: There are 252 row(s) with missing values in the data set. Because of this, there is  a possibility that models may misbehave. Please use the 'Data Wrangling Brick' to create your analytical data set."))
result <- append(result, list(testHandleMissingValues(hotel, T, list(dataClass = "data.frame", dataDim = c(606, 23), 
                                                 mssg = "NOTE: There are 252 row(s) with missing values in the data set, which have been removed."))))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nhandleMissingValues() test starts\n", 
                                                                x, "handleMissingValues() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nhandleMissingValues() test starts\n", x, "\nhandleMissingValues() test ends\n\n")))
  }
})
hotel <- na.omit(hotel)
### end of handleMissingValues() test

### Testing dissDTWARP()
testDissDTWARP <- function(data, results)
{
  failedTests <- list()
  obj <- dissDTWARP(data, nrow(data))
  error <- tryCatch(
    {
      test_that("Checking function to find dependent columns",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(range(obj), results$range)
                  expect_equal(length(which(obj==0)), results$zeros)
                  expect_equal(mean(obj), results$mean)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  remove(obj)
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testDissDTWARP(smiley[1:100,], list(class = "matrix", range = c(0.0000000, 0.5057997),
                                                                dim = c(100, 100), zeros = 5050, mean = 0.09078389))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\ndissDTWARP() test starts\n", 
                                                                x, "dissDTWARP() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\ndissDTWARP() test starts\n", x, "\ndissDTWARP() test ends\n\n")))
  }
})
### end of dissDTWARP() test

### Testing makeNiceDistMatrix()
testMakeNiceDistMatrix <- function(data, dissMeasure, results)
{
  failedTests <- list()
  obj <- makeNiceDistMatrix(data, dissMeasure)
  error <- tryCatch(
    {
      test_that("Checking function to find dependent columns",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(range(obj), results$range)
                  expect_equal(length(which(obj==0)), results$zeros)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  remove(obj)
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testMakeNiceDistMatrix(smiley[1:100,], "DTWARP", list(class = "matrix", range = c(0.0000000, 0.5057997),
                                                                   dim = c(100, 100), zeros = 5050))
result <- append(result, testMakeNiceDistMatrix(smiley[1:100,], "euclidean", list(class = c("dissimilarity", "dist"), 
                                                                                  range = c(0.003042051, 0.505799693),
                                                                                  dim = c(100, 100), zeros = 0)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nmakeNiceDistMatrix() test starts\n", 
                                                                x, "makeNiceDistMatrix() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nmakeNiceDistMatrix() test starts\n", x, "\nmakeNiceDistMatrix() test ends\n\n")))
  }
})
### end of makeNiceDistMatrix() test

# dissPER <- function(data, reqDim)
# dissSAX <- function(data, reqDim)

#############
##         ##
## k-MEANS ##
##         ##
#############
set.seed(42)
model_smiley <- kmeans(smiley, 4)
set.seed(42)
model_hotel <- kproto(hotel, 2)

### Testing kProtoModel()
testKProtoModel <- function(data, k, iter, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- kProtoModel(data, k, iter)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(names(obj), results$names)
                  expect_equal(as.numeric(sort(unname(obj$size))), as.numeric(sort(unname(table(obj$cluster)))))
                  expect_equal(round(obj$withinss, 2), results$withinss)
                  expect_equal(round(obj$tot.withinss, 2), results$tot.withinss)
                  expect_equal(obj$trace$moved, results$moved)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testKProtoModel(hotel, 2, 30, list(class = "kproto", length = 9, 
                                             names = c("cluster", "centers", "lambda", "size", "withinss", 
                                                       "tot.withinss", "dists", "iter", "trace"),
                                             withinss = c(7818083165, 8071122069), tot.withinss = 15889205235,
                                             moved = c(606, 4, 1, 0)))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nkProtoModel() test starts\n", 
                                                                x, "kProtoModel() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nkProtoModel() test starts\n", x, "\nkProtoModel() test ends\n\n")))
  }
})
### end of kProtoModel() test

### Testing kModesModel()
testKModesModel <- function(data, k, iter, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- kModesModel(data, k, iter)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(names(obj), results$names)
                  expect_equal(as.numeric(sort(unname(obj$size))), as.numeric(sort(unname(table(obj$cluster)))))
                  expect_equal(class(obj$modes), results$modeClass)
                  expect_equal(dim(obj$modes), results$modeDim)
                  expect_equal(sort(levels(as.factor(as.matrix(obj$modes)))), results$modeFactors)
                  expect_equal(round(obj$withindiff, 2), results$withindiff)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testKModesModel(hotel[,c("building_type", "location_type")], 2, 30, list(class = "kmodes", length = 6, 
                                             names = c("cluster", "size", "modes", "withindiff", "iterations", "weighted"),
                                             modeClass = "data.frame", modeDim = c(2,2), withindiff = c(511, 63),
                                             modeFactors = c("2 TO 6 STORY INTERIOR CORRIDORS", "7 TO 12 STORY HIGH RISE", "SUBURBAN", "URBAN")))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nkModesModel() test starts\n", 
                                                                x, "kModesModel() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nkModesModel() test starts\n", x, "\nkModesModel() test ends\n\n")))
  }
})
### end of kModesModel() test

### Testing kMedoidsModel()
testKMedoidsModel <- function(data, k, iter, metric, dissMeasure, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- kMedoidsModel(data, k, iter, metric, dissMeasure)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(names(obj), results$names)
                  expect_equal(round(obj$silinfo$avg.width, 2), results$avg.width)
                  expect_equal(round(obj$silinfo$clus.avg.widths, 2), results$clus.avg.widths)
                  expect_equal(round(obj$id.med, 2), results$id.med)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testKMedoidsModel(smiley, 4, 30, "euclidean", NULL, list(class = c("pam", "partition"), length = 9, 
                                                                    names = c("medoids", "id.med", "clustering", "objective", 
                                                                              "isolation", "clusinfo", "silinfo", "diss", "call"),
                                                           avg.width = 0.58, id.med = c(20, 309, 370, 750),
                                                           clus.avg.widths = c(0.81, 0.78, 0.47, 0.47)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nkMedoidsModel() test starts\n", 
                                                                x, "kMedoidsModel() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nkMedoidsModel() test starts\n", x, "\nkMedoidsModel() test ends\n\n")))
  }
})
### end of kMedoidsModel() test

### Testing kMeansModel()
testKMeansModel <- function(data, k, iter, metric, algo, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- kMeansModel(data, k, iter, metric, algo)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(names(obj), results$names)
                  expect_equal(as.numeric(sort(obj$size)), as.numeric(sort(unname(table(obj$cluster)))))
                  expect_equal(round(obj$withinss, 2), results$withinss)
                  expect_equal(round(obj$totss, 2), results$totss)
                  expect_equal(round(obj$tot.withinss, 2), results$tot.withinss)
                  expect_equal(round(obj$betweenss, 2), results$betweenss)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testKMeansModel(smiley, 4, 30, "euclidean", "Lloyd", list(class = "kmeans", length = 9, 
                                                                    names = c("cluster", "centers", "totss", 
                                                                              "withinss", "tot.withinss", "betweenss", 
                                                                              "size", "iter", "ifault"),
                                                                    withinss = c(24.83, 119.16, 3.44, 44.03),
                                                                    totss = 938.30, tot.withinss = 191.45, betweenss = 746.85))
result <- append(result, testKMeansModel(smiley, 4, 50, "manhattan", "Hartigan-Wong", list(class = "kmeans", length = 9, 
                                                                                   names = c("cluster", "centers", "totss", 
                                                                                             "withinss", "tot.withinss", "betweenss", 
                                                                                             "size", "iter", "ifault"),
                                                                                   withinss = c(20.19, 3.65, 125.23, 42.50),
                                                                                   totss = 938.30, tot.withinss = 191.56, betweenss = 746.74)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nkMeansModel() test starts\n", 
                                                                x, "kMeansModel() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nkMeansModel() test starts\n", x, "\nkMeansModel() test ends\n\n")))
  }
})
### end of kMeansModel() test

### Testing kMeansMainClusterCentroids()
testKMeansMainClusterCentroids <- function(type, model, k, results)
{
  failedTests <- list()
  obj <- kMeansMainClusterCentroids(type, model, k)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(colnames(obj), results$colnames)
                  expect_equal(rownames(obj), results$rownames)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testKMeansMainClusterCentroids("kmeans", model_smiley, 4, list(class = "data.frame", dim = c(2,5), 
                                                                         colnames = c("Features", "Cluster1", "Cluster2", "Cluster3", "Cluster4"),
                                                                         rownames = c("V1", "V2")))
result <- append(result, testKMeansMainClusterCentroids("kmeans", model_hotel, 2, list(class = "data.frame", dim = c(23,3), 
                                                                                       colnames = c("Features", "Cluster1", "Cluster2"),
                                                                                       rownames = c("max_rooms_capacity", "building_type", "location_type", "Occupancy", 
                                                                                                    "AvgDailyRate", "Compet_Occupancy", "Compet_AvgDailyRate", 
                                                                                                    "PercentGovtNights", "PercentGroupNights", "PercentTransientNights", 
                                                                                                    "PercentBusiness", "PercentLeisure", "hotelcount1mile", "hotelcount5mile", 
                                                                                                    "rooms1mile", "rooms5mile", "loyalty_pct", "call_center_booking_pct", 
                                                                                                    "travel_agency_booking_pct", "third_party_web_bookings_pct", 
                                                                                                    "hotel_to_hotel_bookings_pct", "direct_call_booking_pct", 
                                                                                                    "direct_web_booking_pct"))))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nkMeansMainClusterCentroids() test starts\n", 
                                                                x, "kMeansMainClusterCentroids() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nkMeansMainClusterCentroids() test starts\n", x, "\nkMeansMainClusterCentroids() test ends\n\n")))
  }
})
### end of kMeansMainClusterCentroids() test

### Testing kMeansDissMatrixCentroids()
testKMeansDissMatrixCentroids <- function(data, clusters, results)
{
  failedTests <- list()
  obj <- kMeansDissMatrixCentroids(data, clusters)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(colnames(obj), results$colnames)
                  expect_equal(rownames(obj), results$rownames)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testKMeansDissMatrixCentroids(smiley, model_smiley$cluster, list(class = "data.frame", dim = c(2,5), 
                                                                           colnames = c("Features", "Cluster1", "Cluster2", "Cluster3", "Cluster4"),
                                                                           rownames = c("V1", "V2")))
result <- append(result, testKMeansDissMatrixCentroids(hotel, model_hotel$cluster, list(class = "data.frame", dim = c(23,3), 
                                                                                        colnames = c("Features", "Cluster1", "Cluster2"),
                                                                                        rownames = c("max_rooms_capacity", "building_type", "location_type", "Occupancy", 
                                                                                                     "AvgDailyRate", "Compet_Occupancy", "Compet_AvgDailyRate", 
                                                                                                     "PercentGovtNights", "PercentGroupNights", "PercentTransientNights", 
                                                                                                     "PercentBusiness", "PercentLeisure", "hotelcount1mile", "hotelcount5mile", 
                                                                                                     "rooms1mile", "rooms5mile", "loyalty_pct", "call_center_booking_pct", 
                                                                                                     "travel_agency_booking_pct", "third_party_web_bookings_pct", 
                                                                                                     "hotel_to_hotel_bookings_pct", "direct_call_booking_pct", 
                                                                                                     "direct_web_booking_pct"))))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nkMeansDissMatrixCentroids() test starts\n", 
                                                                x, "kMeansDissMatrixCentroids() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nkMeansDissMatrixCentroids() test starts\n", x, "\nkMeansDissMatrixCentroids() test ends\n\n")))
  }
})
### end of kMeansDissMatrixCentroids() test

### Testing kMeansKneePlot()
testKMeansKneePlot <- function(type, data, metric, kRange, iter, algo, dissMeasure, maxRows, results)
{
  failedTests <- list()
  obj <- kMeansKneePlot(type, data, metric, kRange, iter, algo, primaryColor, dissMeasure = NULL, maxRows = maxRows)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(length(obj), results$objLength)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  p <- obj$plot
  k <- obj$k
  # Test 2
  error <- tryCatch(
    {
      test_that("Checking if object plot and k value matches",
                {
                  expect_equal(class(p), results$plotClass)
                  expect_equal(!is.null(p), TRUE)
                  expect_equal(class(k), results$kClass)
                  expect_equal(!is.null(k), TRUE)
                  expect_lte(k, kRange[2])
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testKMeansKneePlot("kmeans", smiley, "euclidean", c(2,12), 30, "Lloyd", NULL, maxRows = 500, list(objLength = 2, plotClass = c("gg", "ggplot"), kClass = "numeric"))
result <- append(result, testKMeansKneePlot("kmeans", smiley, "euclidean", c(2,12), 30, "Lloyd", NULL, maxRows = nrow(smiley), list(objLength = 2, plotClass = c("gg", "ggplot"), kClass = "numeric")))
result <- append(result, testKMeansKneePlot("kmedoids", smiley, "manhattan", c(2,12), 50, NULL, NULL, maxRows = 500, list(objLength = 2, plotClass = c("gg", "ggplot"), kClass = "numeric")))
result <- append(result, testKMeansKneePlot("kproto", hotel, "euclidean", c(2,12), 30, NULL, NULL, maxRows = nrow(hotel), list(objLength = 2, plotClass = c("gg", "ggplot"), kClass = "numeric")))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nkMeansKneePlot() test starts\n", 
                                                                x, "kMeansKneePlot() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nkMeansKneePlot() test starts\n", x, "\nkMeansKneePlot() test ends\n\n")))
  }
})
### end of kMeansKneePlot() test

### Testing kMeansClusters()
testkMeansClusters <- function(data, clusters, results)
{
  failedTests <- list()
  obj <- kMeansClusters(data, clusters, data.frame())
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned data frame matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(colnames(obj), results$colnames)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testkMeansClusters(smiley, model_smiley$cluster, list(class = "data.frame", dim = c(1000, 3), colnames = c("V1", "V2", "clusters")))
result <- append(result, testkMeansClusters(hotel, model_hotel$cluster, list(class = "data.frame", dim = c(606, 24), 
                                                                             colnames = c("max_rooms_capacity", "building_type", "location_type", 
                                                                                          "Occupancy", "AvgDailyRate", "Compet_Occupancy", "Compet_AvgDailyRate", 
                                                                                          "PercentGovtNights", "PercentGroupNights", "PercentTransientNights", 
                                                                                          "PercentBusiness", "PercentLeisure", "hotelcount1mile", "hotelcount5mile", 
                                                                                          "rooms1mile", "rooms5mile", "loyalty_pct", "call_center_booking_pct", 
                                                                                          "travel_agency_booking_pct", "third_party_web_bookings_pct", 
                                                                                          "hotel_to_hotel_bookings_pct", "direct_call_booking_pct", 
                                                                                          "direct_web_booking_pct", "clusters"))))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nkMeansClusters() test starts\n", 
                                                                x, "kMeansClusters() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nkMeansClusters() test starts\n", x, "\nkMeansClusters() test ends\n\n")))
  }
})
### end of kMeansClusters() test

### Testing kMeansMainModelCall()
testKMeansMainModelCall <- function(type, data, k, metric, iter, algo, dissMeasure, results)
{
  failedTests <- list()
  obj <- kMeansMainModelCall(type, data, k, metric, iter, algo, dissMeasure)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned data frame matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(!is.null(obj), TRUE)
                  expect_equal(length(obj), results$length)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }

  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testKMeansMainModelCall("kmeans", smiley, 4, "euclidean", 30, "Lloyd", NULL, 
                                  list(class = "kmeans", length = 9))
result <- append(result, testKMeansMainModelCall("kmedoids", smiley, 4, "euclidean", 30, NULL, NULL, 
                                  list(class = c("pam", "partition"), length = 9)))
result <- append(result, testKMeansMainModelCall("kproto", hotel, 4, "euclidean", 30, NULL, NULL, 
                                                 list(class = "kproto", length = 9)))
result <- append(result, testKMeansMainModelCall("kmodes", hotel[,c("building_type", "location_type")], 
                                                 4, "euclidean", 30, NULL, NULL, 
                                                 list(class = "kmodes", length = 6)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nkMeansMainModelCall() test starts\n",
                                                                x, "kMeansMainModelCall() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nkMeansMainModelCall() test starts\n", x, "\nkMeansMainModelCall() test ends\n\n")))
  }
})
### end of kMeansMainModelCall() test

### END OF k-MEANS ###

##################
##              ##
## HIERARCHICAL ##
##              ##
##################
hclust_smiley <- flashClust::flashClust(cluster::daisy(smiley, "euclidean"), "complete")
diana_smiley <- diana(cluster::daisy(smiley, "euclidean"), 4)
hclust_hotel <- flashClust::flashClust(cluster::daisy(hotel, "euclidean"), "complete")
diana_hotel <- diana(cluster::daisy(hotel, "euclidean"), 4)

### Testing hclustModel()
testHClustModel <- function(data, method, metric, results)
{
  failedTests <- list()
  obj <- hclustModel(data, method, metric)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned data frame matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(names(obj), results$names)
                  expect_equal(length(obj), results$length)
                  expect_equal(class(obj$merge), results$mergeClass)
                  expect_equal(dim(obj$merge), results$mergeDim)
                  expect_equal(range(obj$merge), results$mergeRange)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testHClustModel(smiley, "complete", "euclidean", list(class = "hclust", length = 7, mergeRange  = c(-1000, 998),
                                                                names = c("merge", "height", "order", "labels", 
                                                                          "method", "call", "dist.method"),
                                                                mergeClass = "matrix", mergeDim = c(999, 2)))
result <- append(result, testHClustModel(hotel, "complete", "euclidean", list(class = "hclust", length = 7, mergeRange  = c(-606, 604),
                                                                names = c("merge", "height", "order", "labels", 
                                                                          "method", "call", "dist.method"),
                                                                mergeClass = "matrix", mergeDim = c(605, 2))))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nhclustModel() test starts\n",
                                                                x, "hclustModel() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nhclustModel() test starts\n", x, "\nhclustModel() test ends\n\n")))
  }
})
### end of hclustModel() test

### Testing hClustClusters()
testHClustClusters <- function(data, model, k, results)
{
  failedTests <- list()
  obj <- hClustClusters(data, model, k, data.frame())
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned data frame matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(colnames(obj), results$colnames)
                  expect_equal(as.numeric(sort(unname(table(obj$clusters)))), results$freq)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testHClustClusters(smiley, hclust_smiley, 4, list(class = "data.frame", dim = c(1000, 3), 
                                                            colnames  = c("V1", "V2", "clusters"),
                                                            freq = c(122, 167, 294, 417)))
result <- append(result, testHClustClusters(hotel, hclust_hotel, 2, list(class = "data.frame", dim = c(606, 24), 
                                     freq = c(9, 597), 
                                     colnames = c("max_rooms_capacity", "building_type", "location_type", 
                                                  "Occupancy", "AvgDailyRate", "Compet_Occupancy", "Compet_AvgDailyRate", 
                                                  "PercentGovtNights", "PercentGroupNights", "PercentTransientNights", 
                                                  "PercentBusiness", "PercentLeisure", "hotelcount1mile", "hotelcount5mile", 
                                                  "rooms1mile", "rooms5mile", "loyalty_pct", "call_center_booking_pct", 
                                                  "travel_agency_booking_pct", "third_party_web_bookings_pct", 
                                                  "hotel_to_hotel_bookings_pct", "direct_call_booking_pct", 
                                                  "direct_web_booking_pct", "clusters"))))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nhClustClusters() test starts\n",
                                                                x, "hClustClusters() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nhClustClusters() test starts\n", x, "\nhClustClusters() test ends\n\n")))
  }
})
### end of hClustClusters() test

### Testing hclustPlotFn()
testHClustPlotFn <- function(model, kn, results)
{
  failedTests <- list()
  obj <- hclustPlotFn(model, kn)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  plotObj <- ggplot_build(obj)$data[[2]]
  # Test 2
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(round(range(plotObj$x), 2), results$rangeX)
                  expect_equal(round(range(plotObj$y), 2), results$rangeY)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testHClustPlotFn(hclust_smiley, 4, list(class = c("gg", "ggplot"), 
                                                  rangeX = c(1, 1000), 
                                                  rangeY = c(-2.60, 0.000000)))
result <- append(result, testHClustPlotFn(hclust_hotel, 3, list(class = c("gg", "ggplot"), 
                                                  rangeX = c(1, 606), 
                                                  rangeY = c(-0.58, 0.00))))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nhclustPlotFn() test starts\n",
                                                                x, "hclustPlotFn() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nhclustPlotFn() test starts\n", x, "\nhclustPlotFn() test ends\n\n")))
  }
})
### end of hclustPlotFn() test

### Testing dianaModel()
testDianaModel <- function(data, metric, results)
{
  failedTests <- list()
  obj <- dianaModel(data, metric) 
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned data frame matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(names(obj), results$names)
                  expect_equal(length(obj), results$length)
                  expect_equal(round(obj$dc, 2), results$dc)
                  expect_equal(class(obj$merge), results$mergeClass)
                  expect_equal(dim(obj$merge), results$mergeDim)
                  expect_equal(range(obj$merge), results$mergeRange)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testDianaModel(smiley, "euclidean", list(class = c("diana", "twins"), length = 6, mergeRange  = c(-1000, 998),
                                                   names = c("order", "height", "dc", "merge", "diss", "call"),
                                                   mergeClass = "matrix", mergeDim = c(999, 2), dc = 0.99))
result <- append(result, testDianaModel(hotel, "manhattan", list(class = c("diana", "twins"), length = 7, mergeRange  = c(-606, 604),
                                                   names = c("order", "height", "dc", "merge", "diss", "call", "order.lab"),
                                                   mergeClass = "matrix", mergeDim = c(605, 2), dc = 0.87)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\ndianaModel() test starts\n",
                                                                x, "dianaModel() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\ndianaModel() test starts\n", x, "\ndianaModel() test ends\n\n")))
  }
})
### end of dianaModel() test

### Testing dianaClusters()
testDianaClusters <- function(data, model, k, results)
{
  failedTests <- list()
  obj <- dianaClusters(data, model, k, data.frame())
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned data frame matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(colnames(obj), results$colnames)
                  expect_equal(as.numeric(sort(unname(table(obj$clusters)))), results$freq)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testDianaClusters(smiley, diana_smiley, 6, 
                            list(class = "data.frame", dim = c(1000, 3), 
                                 colnames = c("V1", "V2", "clusters"), 
                                 freq = c(23, 161, 167, 167, 232, 250)))
result <- append(result, testDianaClusters(hotel, diana_hotel, 3, 
                                           list(class = "data.frame", dim = c(606, 24), 
                                                colnames = c("max_rooms_capacity", "building_type", "location_type", 
                                                             "Occupancy", "AvgDailyRate", "Compet_Occupancy", "Compet_AvgDailyRate", 
                                                             "PercentGovtNights", "PercentGroupNights", "PercentTransientNights", 
                                                             "PercentBusiness", "PercentLeisure", "hotelcount1mile", "hotelcount5mile", 
                                                             "rooms1mile", "rooms5mile", "loyalty_pct", "call_center_booking_pct", 
                                                             "travel_agency_booking_pct", "third_party_web_bookings_pct", 
                                                             "hotel_to_hotel_bookings_pct", "direct_call_booking_pct", 
                                                             "direct_web_booking_pct", "clusters"), 
                                                freq = c(13, 35, 558))))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\ndianaClusters() test starts\n",
                                                                x, "dianaClusters() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\ndianaClusters() test starts\n", x, "\ndianaClusters() test ends\n\n")))
  }
})
### end of dianaClusters() test

### Testing hierarchicalCentroids()
testHierarchicalCentroids <- function(data, model, k, results)
{
  failedTests <- list()
  obj <- hierarchicalCentroids(data, model, k)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned data frame matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(colnames(obj), results$colnames)
                  expect_equal(rownames(obj), results$rownames)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testHierarchicalCentroids(smiley, hclust_smiley, 4, list(class = "data.frame", dim = c(2, 5), 
                                                                   rownames  = c("V1", "V2"),
                                                                   colnames = c("Features", "Cluster1", "Cluster2", "Cluster3", "Cluster4")))

result <- append(result, testHierarchicalCentroids(hotel, hclust_hotel, 2, list(class = "data.frame", dim = c(23, 3), 
                                                                                colnames = c("Features", "Cluster1", "Cluster2"),
                                                                                rownames = c("max_rooms_capacity", "building_type", "location_type", 
                                                                                             "Occupancy", "AvgDailyRate", "Compet_Occupancy", "Compet_AvgDailyRate", 
                                                                                             "PercentGovtNights", "PercentGroupNights", "PercentTransientNights", 
                                                                                             "PercentBusiness", "PercentLeisure", "hotelcount1mile", "hotelcount5mile", 
                                                                                             "rooms1mile", "rooms5mile", "loyalty_pct", "call_center_booking_pct", 
                                                                                             "travel_agency_booking_pct", "third_party_web_bookings_pct", 
                                                                                             "hotel_to_hotel_bookings_pct", "direct_call_booking_pct", 
                                                                                             "direct_web_booking_pct"))))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nhierarchicalCentroids() test starts\n",
                                                                x, "hierarchicalCentroids() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nhierarchicalCentroids() test starts\n", x, "\nhierarchicalCentroids() test ends\n\n")))
  }
})
### end of hierarchicalCentroids() test

### Testing hierarchicalKneePlotGen()
testHierarchicalKneePlotGen <- function(data, model, metric, method, kRange, results)
{
  failedTests <- list()
  obj <- hierarchicalKneePlotGen(data, model, metric, method, kRange, primaryColor) 
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  # Test 2
  error <- tryCatch(
    {
      test_that("Checking if objects inside the object matches",
                {
                  expect_equal(class(obj$plot), results$plotClass)
                  expect_equal(obj$k, results$k)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testHierarchicalKneePlotGen(smiley, hclust_smiley, "euclidean", "complete", c(2,10), 
                                      list(class = "list", length = 2, plotClass = c("gg", "ggplot"), k = 6))
result <- append(result, testHierarchicalKneePlotGen(hotel, hclust_hotel, "euclidean", "complete", c(2,10), 
                                                     list(class = "list", length = 2, plotClass = c("gg", "ggplot"), k = 2)))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nhierarchicalKneePlotGen() test starts\n",
                                                                x, "hierarchicalKneePlotGen() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nhierarchicalKneePlotGen() test starts\n", x, "\nhierarchicalKneePlotGen() test ends\n\n")))
  }
})
### end of hierarchicalKneePlotGen() test

### Testing truncatedDendrogram()
testTruncatedDendrogram <- function(model, kRange, results)
{
  failedTests <- list()
  obj <- truncatedDendrogram(model, kRange)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  plotObj <- ggplot_build(obj)$data
  # Test 2
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(round(plotObj[[4]]$intercept, 2), results$intercept)
                  expect_equal(round(plotObj[[5]]$y, 2), results$y)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testTruncatedDendrogram(hclust_smiley, c(2,10), 
                                  list(class = c("gg", "ggplot"), intercept = 0.71, y = -0.26))
result <- append(result, testTruncatedDendrogram(hclust_hotel, c(2,10), 
                                                 list(class = c("gg", "ggplot"), intercept = 0.34, y = -0.12)))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\ntruncatedDendrogram() test starts\n",
                                                                x, "truncatedDendrogram() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\ntruncatedDendrogram() test starts\n", x, "\ntruncatedDendrogram() test ends\n\n")))
  }
})
### end of truncatedDendrogram() test

### END OF HIERARCHICAL ###

########
##    ##
## EM ##
##    ##
########

### Testing emKneePlot()
testEmKneePlots <- function(data, metric, method, kRange, iter, maxRows, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- emKneePlot(data, metric, method, kRange, iter, primaryColor, maxRows)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  # Test 2
  error <- tryCatch(
    {
      test_that("Checking if objects inside the object matches",
                {
                  expect_equal(class(obj$silPlot), results$silPlotClass)
                  expect_equal(class(obj$logPlot), results$logPlotClass)
                  expect_equal(obj$k, results$k)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testEmKneePlots(smiley, "euclidean", "em.EM", c(2,10), 20, 500,
                          list(class = "list", length = 3, silPlotClass = c("gg", "ggplot"),
                               logPlotClass = c("gg", "ggplot"), k = 6))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nemKneePlot() test starts\n",
                                                                x, "emKneePlot() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nemKneePlot() test starts\n", x, "\nemKneePlot() test ends\n\n")))
  }
})
### end of emKneePlot() test

### Testing emModel()
testEmModel <- function(data, k, method, iter, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- emModel(data, k, method, iter)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(names(obj), results$names)
                  expect_equal(sort(round(obj$pi, 2)), results$pi)
                  expect_equal(round(range(obj$Mu), 2), results$Mu)
                  expect_equal(round(range(obj$LTSigma), 2), results$LTSigma)
                  expect_equal(round(range(obj$llhdval), 2), results$llhdval)
                  expect_equal(sort(obj$nc), results$nc)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testEmModel(smiley, 6, "Rnd.EM", 10, 
                      list(class = "emret", length = 9, nc = c(117, 148, 151, 167, 167, 250),
                           LTSigma = c(-0.09, 0.13), llhdval = c(-963.85, -963.85),
                           names = c("pi", "Mu", "LTSigma", "llhdval", "n", "p", "nclass", "nc", "class"),
                           pi = c( 0.12, 0.15, 0.15, 0.17, 0.17, 0.25), Mu = c(-1.44, 1.32)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nemModel() test starts\n",
                                                                x, "emModel() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nemModel() test starts\n", x, "\nemModel() test ends\n\n")))
  }
})
### end of emModel() test

### Testing emClusterCentroids()
testEmClusterCentroids <- function(data, model, dummyNames, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- emClusterCentroids(data, model, dummyNames)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(class(obj$centroidTable), results$tableClass)
                  expect_equal(dim(obj$centroidTable), results$tableDim)
                  expect_equal(round(range(obj$centroidTable[,-1]), 2), results$tableRange)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
em_smiley <- emModel(smiley, 4, "Rnd.EM", 20)
result <- testEmClusterCentroids(smiley, em_smiley, NULL, 
                                 list(class = "list", length = 2, tableClass = "data.frame",
                                      tableDim = c(2, 5), tableRange = c(-1.15, 1.32)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nemClusterCentroids() test starts\n",
                                                                x, "emClusterCentroids() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nemClusterCentroids() test starts\n", x, "\nemClusterCentroids() test ends\n\n")))
  }
})
### end of emClusterCentroids() test

### END OF EM ###

#########
##     ##
## SOM ##
##     ##
#########

### Testing somModel()
testSomModel <- function(data, xdim, ydim, rlen, alpha, mode, topography, neighbourhood, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- somModel(data, xdim, ydim, rlen, alpha, mode, topography, neighbourhood)  
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(names(obj), results$names)
                  expect_equal(round(range(obj$grid$pts), 2), results$gridPts)
                  expect_equal(dim(obj$codes[[1]]), results$dimCodes)
                  # expect_equal(round(range(obj$codes[[1]]), 2), results$rangeCodes)
                  expect_equal(round(unname(unlist(obj$radius)), 2), results$radius)
                  expect_equal(round(mean(obj$changes), 3), results$meanChanges)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testSomModel(smiley, 20, 20, 100, c(0.01, 0.2), "pbatch", "hexagonal", "bubble",
                       list(class = "kohonen", length = 13,
                            names = c("data", "unit.classif", "distances", "grid", "codes", 
                                      "changes", "alpha", "radius", "user.weights", "distance.weights", 
                                      "whatmap", "maxNA.fraction", "dist.fcts"), meanChanges =  0.003,
                            gridPts = c(0.87, 20.50), dimCodes = c(400, 2), 
                            rangeCodes = c(-1.08, 1.25), radius = c(11.79, 0.00)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nsomModel() test starts\n",
                                                                x, "somModel() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nsomModel() test starts\n", x, "\nsomModel() test ends\n\n")))
  }
})
### end of somModel() test

### Testing somTrainingGraph()
testSomTrainingGraph <- function(model, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- somTrainingGraph(model, primaryColor) 
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(names(obj), results$names)
                  expect_equal(round(range(obj$data$Y), 4), results$rangeY)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
set.seed(42)
som_smiley <- somModel(smiley, 20, 20, 100, c(0.01, 0.2), "pbatch", "hexagonal", "bubble")
result <- testSomTrainingGraph(som_smiley, list(class = c("gg", "ggplot"), length = 9,
                                                names = c("data", "layers", "scales", "mapping", "theme", 
                                                          "coordinates", "facet", "plot_env", "labels"), 
                                                rangeY = c(0.0004, 0.0203)))
                                                

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nsomTrainingGraph() test starts\n",
                                                                x, "somTrainingGraph() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nsomTrainingGraph() test starts\n", x, "\nsomTrainingGraph() test ends\n\n")))
  }
})
### end of somTrainingGraph() test

### Testing somComponentPlanes()
testSomComponentPlanes <- function(model, data, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- somComponentPlanes(model, data)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  # Test 2
  error <- tryCatch(
    {
      test_that("Checking if returned plot object matches",
                {
                  lapply(obj, function(x){
                    expect_equal(class(x), results$plotClass)
                  })
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testSomComponentPlanes(som_smiley, smiley, list(class = c("list"), length = 2,
                                                          plotClass = "integer"))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nsomComponentPlanes() test starts\n",
                                                                x, "somComponentPlanes() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nsomComponentPlanes() test starts\n", x, "\nsomComponentPlanes() test ends\n\n")))
  }
})
### end of somComponentPlanes() test

### Testing somUMatrix()
testSomUMatrix <- function(model, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- somUMatrix(model)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testSomUMatrix(som_smiley, list(class = c("RecordedPlot", "recordedplot")))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nsomUMatrix() test starts\n",
                                                                x, "somUMatrix() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nsomUMatrix() test starts\n", x, "\nsomUMatrix() test ends\n\n")))
  }
})
### end of somUMatrix() test

### Testing somClustersFunc()
testSomClustersFunc <- function(model, k, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- somClustersFunc(model, k)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(names(obj), results$names)
                  expect_equal(length(table(obj$clusters)), results$clusters)
                  expect_equal(length(table(obj$mapCluster)), results$clusters)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testSomClustersFunc(som_smiley, 4, list(class = "list", length = 2, 
                                                  names = c("clusters", "mapCluster"), clusters = 4))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nsomClustersFunc() test starts\n",
                                                                x, "somClustersFunc() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nsomClustersFunc() test starts\n", x, "\nsomClustersFunc() test ends\n\n")))
  }
})
### end of somClustersFunc() test

### Testing somShowClusters()
testSomShowClusters <- function(model, k, clusters, origPlot, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- somShowClusters(model, k, clusters, origPlot)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
temp <- somClustersFunc(som_smiley, 4)
som_mapClusters <- temp$mapCluster
som_clusters <- temp$cluster
result <- testSomShowClusters(som_smiley, 4, som_mapClusters, somUMatrix(som_smiley),
                              list(class = c("RecordedPlot", "recordedplot")))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nsomShowClusters() test starts\n",
                                                                x, "somShowClusters() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nsomShowClusters() test starts\n", x, "\nsomShowClusters() test ends\n\n")))
  }
})
### end of somShowClusters() test

### Testing somCentroids()
testSomCentroids <- function(model, k, metric, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- somCentroids(model, k, metric)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(colnames(obj), results$colnames)
                  expect_equal(rownames(obj), results$rownames)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testSomCentroids(som_smiley, 4, "euclidean", 
                           list(class = "data.frame", dim = c(2, 5), rownames = c("V1", "V2"),
                                colnames = c("Features", "Cluster1", "Cluster2", "Cluster3", "Cluster4")))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nsomCentroids() test starts\n",
                                                                x, "somCentroids() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nsomCentroids() test starts\n", x, "\nsomCentroids() test ends\n\n")))
  }
})
### end of somCentroids() test

### END OF SOM ###

##########
##      ##
## WONG ##
##      ##
##########
set.seed(42)
wong_kmeans_smiley <- kmeans(smiley, 20)

### Testing wongKmeansCentroids()
testWongKmeansCentroids <- function(type, model, k, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- wongKmeansCentroids(type, model, k)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(round(range(obj), 3), results$range)
                  expect_equal(colnames(obj), results$colnames)
                  expect_equal(rownames(obj), results$rownames)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testWongKmeansCentroids("kmeans", wong_kmeans_smiley, 20,
                                  list(class = "data.frame", dim = c(20, 2), colnames = c("V1", "V2"), 
                                       rownames = unlist(lapply(1:20, function(x)paste0("Cluster", x))),
                                       range = c(-0.974, 1.074)))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nwongKmeansCentroids() test starts\n",
                                                                x, "wongKmeansCentroids() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nwongKmeansCentroids() test starts\n", x, "\nwongKmeansCentroids() test ends\n\n")))
  }
})
### end of wongKmeansCentroids() test

### Testing wongKmeansWss()
testWongKmeansWss <- function(model, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- wongKmeansWss(model)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(round(range(obj[,-1]), 3), results$range)
                  expect_equal(colnames(obj), results$colnames)
                  expect_equal(rownames(obj), results$rownames)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testWongKmeansWss(wong_kmeans_smiley, list(class = "data.frame", dim = c(20, 2), 
                             colnames = c("Cluster IDs", "Within sum of squares of each cluster"), 
                             rownames = unlist(lapply(1:20, function(x)paste0("V", x))),
                             range = c(0.060, 1.197)))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nwongKmeansWss() test starts\n",
                                                                x, "wongKmeansWss() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nwongKmeansWss() test starts\n", x, "\nwongKmeansWss() test ends\n\n")))
  }
})
### end of wongKmeansWss() test

clusterN <- unname(unlist(table(wong_kmeans_smiley$cluster)))
clusterWSS <- wong_kmeans_smiley$withinss #wongKmeansWss(wong_kmeans_smiley)
clusterCentroids <- wongKmeansCentroids("kmeans", wong_kmeans_smiley, 20)

### Testing simpleMatching()
testSimpleMatching <- function(x, y, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- simpleMatching(x, y)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(obj, results)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testSimpleMatching(clusterCentroids[1,], clusterCentroids[5,], 1)
result <- append(result, testSimpleMatching(clusterCentroids[7,], clusterCentroids[20,], 1))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nsimpleMatching() test starts\n",
                                                                x, "simpleMatching() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nsimpleMatching() test starts\n", x, "\nsimpleMatching() test ends\n\n")))
  }
})
### end of simpleMatching() test

### Testing customDist()
testCustomDist <- function(x, y, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- customDist(x, y)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(round(obj, 3), results)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testCustomDist(clusterCentroids[1,], clusterCentroids[5,], 0.972)
result <- append(result, testCustomDist(clusterCentroids[7,], clusterCentroids[20,], 1.519))
result <- append(result, testCustomDist(clusterCentroids[10,], clusterCentroids[10,], 0))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\ncustomDist() test starts\n",
                                                                x, "customDist() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\ncustomDist() test starts\n", x, "\ncustomDist() test ends\n\n")))
  }
})
### end of customDist() test

### Testing wongFMeasure()
testWongFMeasure <- function(n, wss, centroid, i, j, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- wongFMeasure(n, wss, centroid, i, j)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(round(obj, 3), results)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testWongFMeasure(clusterN, clusterWSS, clusterCentroids, 20, 10, 217.238)
result <- append(result, testWongFMeasure(clusterN, clusterWSS, clusterCentroids, 15, 5, 298.791))
result <- append(result, testWongFMeasure(clusterN, clusterWSS, clusterCentroids, 10, 10, 0))
result <- append(result, testWongFMeasure(clusterN, clusterWSS, clusterCentroids, 5, 15, 298.791))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nwongFMeasure() test starts\n",
                                                                x, "wongFMeasure() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nwongFMeasure() test starts\n", x, "\nwongFMeasure() test ends\n\n")))
  }
})
### end of wongFMeasure() test

### Testing wongConstructF()
testWongConstructF <- function(clusterN, clusterWSS, clusterCentroids, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- wongConstructF(clusterN, clusterWSS, clusterCentroids)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(round(range(obj), 3), results$range)
                  expect_equal(round(mean(obj), 3), results$mean)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testWongConstructF(clusterN, clusterWSS, clusterCentroids, 
                             list(class = "matrix", dim = c(20, 20), range = c(0, 8882.803), mean = 713.538))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nwongConstructF() test starts\n",
                                                                x, "wongConstructF() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nwongConstructF() test starts\n", x, "\nwongConstructF() test ends\n\n")))
  }
})
### end of wongConstructF() test

### Testing wongDistanceMatrix()
testWongDistanceMatrix <- function(fMatrix, centroids, nVals, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- wongDistanceMatrix(fMatrix, centroids, nVals)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                  expect_equal(round(range(obj), 3), results$range)
                  expect_equal(round(mean(unlist(sapply(obj, mean))), 5), results$mean)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

fMatrix <- wongConstructF(clusterN, clusterWSS, clusterCentroids)
result <- testWongDistanceMatrix(fMatrix, clusterCentroids, clusterN, 
                                 list(class = "data.frame", dim = c(20, 20), 
                                      range = c(0, 0.021), mean = 0.00431))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nwongDistanceMatrix() test starts\n",
                                                                x, "wongDistanceMatrix() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nwongDistanceMatrix() test starts\n", x, "\nwongDistanceMatrix() test ends\n\n")))
  }
})
### end of wongDistanceMatrix() test

### Testing wongHclust()
testWongHclust <- function(fMatrix, centroids, nVals, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- wongHclust(fMatrix, centroids, distanceMatrix)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(names(obj), results$names)
                  expect_equal(length(obj), results$length)
                  expect_equal(class(obj$merge), results$mergeClass)
                  expect_equal(dim(obj$merge), results$mergeDim)
                  expect_equal(range(obj$merge), results$mergeRange)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

distanceMatrix <- wongDistanceMatrix(fMatrix, clusterCentroids, clusterN)
result <- testWongHclust(fMatrix, clusterCentroids, distanceMatrix, 
                         list(class = "hclust", length = 7, mergeClass = "matrix", mergeDim = c(19, 2),
                              names = c("merge", "height", "order", "labels", "method", "call", "dist.method"),
                              mergeRange = c(-20, 18)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nwongHclust() test starts\n",
                                                                x, "wongHclust() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nwongHclust() test starts\n", x, "\nwongHclust() test ends\n\n")))
  }
})
### end of wongHclust() test

### Testing wongHclustKneePlot()
testWongHclustKneePlot <- function(model, kRange, dMatrix, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- wongHclustKneePlot(model, kRange, dMatrix, primaryColor)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(obj$k, results$k)
                  expect_equal(class(obj$plot), results$plotClass)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

wong_hclust_smiley <- wongHclust(fMatrix, clusterCentroids, distanceMatrix)
result <- testWongHclustKneePlot(wong_hclust_smiley, c(2,20), distanceMatrix,
                                 list(class = "list", length = 2, k = 1,
                                      plotClass = c("gg", "ggplot")))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nwongHclustKneePlot() test starts\n",
                                                                x, "wongHclustKneePlot() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nwongHclustKneePlot() test starts\n", x, "\nwongHclustKneePlot() test ends\n\n")))
  }
})
### end of wongHclustKneePlot() test

### Testing wongAssignClusters()
testWongAssignClusters <- function(clusters, hclustModel, k, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- wongAssignClusters(clusters, hclustModel, k)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(as.numeric(sort(unname(unlist(table(obj))))), results$clus)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testWongAssignClusters(wong_kmeans_smiley$cluster, wong_hclust_smiley, 4,
                                 list(class = "integer", length = 1000, clus = c(167, 167, 250, 416)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nwongAssignClusters() test starts\n",
                                                                x, "wongAssignClusters() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nwongAssignClusters() test starts\n", x, "\nwongAssignClusters() test ends\n\n")))
  }
})
### end of wongAssignClusters() test

### Testing wongFinalCentroids()
testWongFinalCentroids <- function(data, k, clusters, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- wongFinalCentroids(data, k, clusters)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(round(range(obj[,-1]), 3), results$range)
                  expect_equal(rownames(obj), results$rownames)
                  expect_equal(colnames(obj), results$colnames)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

wong_clusters <- wongAssignClusters(wong_kmeans_smiley$cluster, wong_hclust_smiley, 4)
result <- testWongFinalCentroids(smiley, 4, wong_clusters,
                                 list(class = "data.frame", length = 5, range = c(-0.797, 0.994),
                                      rownames = c("V1", "V2"),
                                      colnames = c("Features", "Cluster1", "Cluster2", "Cluster3", "Cluster4")))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nwongFinalCentroids() test starts\n",
                                                                x, "wongFinalCentroids() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nwongFinalCentroids() test starts\n", x, "\nwongFinalCentroids() test ends\n\n")))
  }
})
### end of wongFinalCentroids() test

### Testing wongIsLinked()
testWongIsLinked <- function(centroids, i, j, nVals, results)
{
  failedTests <- list()
  set.seed(42)
  obj <- wongIsLinked(centroids, i, j, nVals)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if returned object matches",
                {
                  expect_equal(class(obj), results$class)
                  expect_equal(obj, results$value)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testWongIsLinked(clusterCentroids, 2, 18, clusterN, list(class = "logical", value = TRUE))
result <- append(result, testWongIsLinked(clusterCentroids, 7, 7, clusterN, list(class = "logical", value = TRUE)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nwongIsLinked() test starts\n",
                                                                x, "wongIsLinked() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nwongIsLinked() test starts\n", x, "\nwongIsLinked() test ends\n\n")))
  }
})
### end of wongIsLinked() test

### END OF WONG ###

########################
## CLUSTERING COMMONS ##
########################

### Testing clusterMetrics()
testClusterMetrics <- function(data, metric, clusters, results)
{
  failedTests <- list()
  obj <- clusterMetrics(data, metric, clusters, primaryColor)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if plot is ggplot object",
                {
                  expect_equal(class(obj), results$plotClass)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  # Test 2
  plotObj <- ggplot_build(obj)$data[[1]]
  error <- tryCatch(
    {
      test_that("Checking if plot has expected values",
                {
                  expect_equal(round(plotObj$xmax, 3), round(results$xmax,3))
                  expect_equal(round(plotObj$ymax, 3), round(results$ymax, 3))
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testClusterMetrics(smiley, "euclidean", model_smiley$cluster, list(plotClass = c("gg", "ggplot"), 
                                                                      xmax = c(1.45, 2.45, 3.45, 4.45), ymax = c(162, 167, 424, 247)))
result <- append(result, list(testClusterMetrics(hotel, "euclidean", model_hotel$cluster, list(plotClass = c("gg", "ggplot"), 
                                                                      xmax = c(1.45, 2.45), ymax = c(571, 35)))))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nclusterMetrics() test starts\n", 
                                                                x, "clusterMetrics() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nclusterMetrics() test starts\n", x, "\nclusterMetrics() test ends\n\n")))
  }
})
### end of clusterMetrics() test

### Testing zScorePlots()
testZScorePlots <- function(data, centers, clusters, results)
{
  failedTests <- list()
  obj <- zScorePlots(data, centers, primaryColor, secondaryColor, clusters)[[1]] #$numerical[[1]]
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if plot is ggplot object",
                {
                  expect_equal(class(obj), results$plotClass)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  # Test 2
  plotObj <- ggplot_build(obj)$data[[1]]
  error <- tryCatch(
    {
      test_that("Checking if plot has expected values",
                {
                  expect_equal(round(plotObj$xmax, 3), round(results$xmax,3))
                  expect_equal(round(plotObj$ymax, 3), round(results$ymax, 3))
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function
result <- testZScorePlots(smiley, model_smiley$centers, model_smiley$clusters, list(plotClass = c("gg", "ggplot"), 
                                                                                    xmax = c(1.45, 2.45, 3.45, 4.45), 
                                                                                    ymax = c(0.0000000, 0.0000000, 0.0000000, 0.0000000)))
result <- append(result, list(testZScorePlots(hotel, model_hotel$centers, model_hotel$clusters, list(plotClass = c("gg", "ggplot"), 
                                                                                               xmax = c(1.45, 2.45), ymax = c(3, 5)))))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nzScorePlots() test starts\n", 
                                                                x, "zScorePlots() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nzScorePlots() test starts\n", x, "\nzScorePlots() test ends\n\n")))
  }
})
### end of zScorePlots() test

### Testing sammonsPlot()
testSammonsPlot <- function(data, numCols, clusters, centroidTable, featureList, results)
{
  failedTests <- list()
  obj <- sammonsPlot(data, numCols, clusters, centroidTable, featureList, primaryColor)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if object is valid",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  # Test 2
  error <- tryCatch(
    {
      test_that("Checking if plot is ggplot object",
                {
                  lapply(obj, function(x){
                     expect_equal(class(x), c("gg", "ggplot"))
                  })
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  # Test 3
  plotObj <- ggplot_build(obj[[1]])$data[[1]]
  error <- tryCatch(
    {
      test_that("Checking if plot has expected values",
                {
                  expect_equal(round(range(plotObj$x), 3), results$rangeX)
                  expect_equal(round(range(plotObj$y), 3), results$rangeY)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }

  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

smiley_centroids <- kMeansMainClusterCentroids("kmeans", model_smiley, 4)
result <- testSammonsPlot(smiley, colnames(smiley), model_smiley$cluster, smiley_centroids, colnames(smiley),
                          list(class = "list", length = 2, rangeX = c(-1.584, 1.729), rangeY = c(-1.260, 1.222)))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nsammonsPlot() test starts\n", 
                                                                x, "sammonsPlot() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nsammonsPlot() test starts\n", x, "\nsammonsPlot() test ends\n\n")))
  }
})
### end of sammonsPlot() test

### Testing computeStatsSampling()
testComputeStatsSampling <- function(data, k, clusters, metrics, distMetric, maxRows, results)
{
  failedTests <- list()
  obj <- computeStatsSampling(data, k, clusters, metrics, distMetric="euclidean", maxRows)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if object is valid",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(round(range(obj), 2), results$range)
                  expect_equal(sort(names(obj)), results$names)
                  expect_equal(round(mean(obj), 2), results$mean)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testComputeStatsSampling(smiley, 4, model_smiley$cluster, comparisonMetrics, "euclidean", nrow(smiley),
                           list(class = "numeric", length = 8, range = c(0.36, 42.4),
                                names = sort(names(comparisonMetrics)), mean = 8.29))
lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\ncomputeStats() test starts\n", 
                                                                x, "computeStats() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\ncomputeStats() test starts\n", x, "\ncomputeStats() test ends\n\n")))
  }
})
### end of computeStats() test

### Testing clusterPlot()
testClusterPlot <- function(data, clusters, f1, f2, clus, results)
{
  failedTests <- list()
  obj <- clusterPlot(data, clusters, f1, f2, clus)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if object is valid",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  # Test 2
  plotObj <- ggplot_build(obj)$data[[1]]
  error <- tryCatch(
    {
      test_that("Checking if values are valid",
                {
                  expect_equal(round(range(plotObj$x), 3), results$rangeX)
                  expect_equal(round(range(plotObj$y), 3), results$rangeY)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testClusterPlot(smiley, model_smiley$cluster, colnames(smiley)[1], colnames(smiley)[2], smiley_centroids,
                          list(class = c("gg", "ggplot"), rangeX = c(-1.072, 1.105), rangeY = c(-1.114, 1.263)))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nclusterPlot() test starts\n", 
                                                                x, "clusterPlot() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nclusterPlot() test starts\n", x, "\nclusterPlot() test ends\n\n")))
  }
})
### end of clusterPlot() test

#############################################
## NEED REACT DATA FOR THE BELOW TEST CASE ##
#############################################

### Testing populateComparisonTable()
# testPopulateComparisonTable <- function(rd, models, metrics, results)
# {
#   failedTests <- list()
#   obj <- populateComparisonTable(rd, models, metrics)
#   # Test 1
#   error <- tryCatch(
#     {
#       test_that("Checking if plot is ggplot object",
#                 {
#                   expect_equal(class(obj), results$plotClass)
#                 })
#     },error = function(e)
#     {
#       return(e)
#     }
#   )
#   if(!isTRUE(error))
#   {
#     failedTests[length(failedTests)+1] <- as.character(error)
#   }
#   
#   if(length(failedTests) == 0)
#     return("Result: Test passed")
#   else
#     return(failedTests)
# }# end of function
# result <- testZScorePlots()
# 
# lapply(result, function(x){
#   if(x != "Result: Test passed")
#   {
#     failedTestResults <<- append(failedTestResults, list(paste0("\n\npopulateComparisonTable() test starts\n", 
#                                                                 x, "populateComparisonTable() test ends\n\n")))
#   }else
#   {
#     allTestResults <<- append(allTestResults, list(paste0("\n\npopulateComparisonTable() test starts\n", x,
#                                                           "\npopulateComparisonTable() test ends\n\n")))
#   }
# })
### end of populateComparisonTable() test

###########################
## TIME SERIES FUNCTIONS ##
###########################

### Testing makeDataUsingWindows()
testMakeDataUsingWindows <- function(data, windowType, windowSize, results)
{
  failedTests <- list()
  obj <- makeDataUsingWindows(data, windowType, windowSize)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if object is valid",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                  expect_equal(dim(obj), results$dim)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testMakeDataUsingWindows(smiley, 'rollWin', 10, list(class = "data.frame", dim = c(200, 10)))
result <- append(result, testMakeDataUsingWindows(smiley, 'movWin', 10, list(class = "data.frame", dim = c(1990, 10))))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nmakeDataUsingWindows() test starts\n", 
                                                                x, "makeDataUsingWindows() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nmakeDataUsingWindows() test starts\n", x, "\nmakeDataUsingWindows() test ends\n\n")))
  }
})
### end of makeDataUsingWindows() test

### Testing factorScree()
testFactorScree <- function(data, results)
{
  failedTests <- list()
  obj <- factorScree(data, primaryColor, secondaryColor)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if object is valid",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  # Test 2
  plotObj <- ggplot_build(obj)$data[[1]]
  error <- tryCatch(
    {
      test_that("Checking if plot value matches",
                {
                  expect_equal(round(range(plotObj$y), 3), results$rangeY)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testFactorScree(smiley, list(class = c("gg", "ggplot"), rangeY = c(0.993, 1.007)))
result <- append(result, testFactorScree(hotel[,setdiff(colnames(hotel), c("building_type", "location_type"))], 
                                         list(class = c("gg", "ggplot"), rangeY = c(0.000, 5.546))))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nfactorScree() test starts\n", 
                                                                x, "factorScree() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nfactorScree() test starts\n", x, "\nfactorScree() test ends\n\n")))
  }
})
### end of factorScree() test

### Testing runSVD()
testRunSVD <- function(data, coverage, results)
{
  failedTests <- list()
  obj <- runSVD(data, coverage)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if object is valid",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  # Test 2
  error <- tryCatch(
    {
      test_that("Checking if object values are valid",
                {
                  expect_equal(class(obj$data), results$dataClass)
                  expect_equal(dim(obj$data), results$dataDim)
                  expect_equal(class(obj$svdObj), results$objClass)
                  expect_equal(names(obj$svdObj), results$objNames)
                  expect_equal(dim(obj$svdObj$u), results$objUDim)
                  expect_equal(round(range(obj$svdObj$u), 2), results$objURange)
                  expect_equal(dim(obj$svdObj$v), results$objVDim)
                  expect_equal(round(range(obj$svdObj$v), 2), results$objVRange)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testRunSVD(smiley, 0.96, list(class = "list", length = 2, dataClass = "data.frame",
                                        dataDim = c(1000, 2), objClass = "list", objNames = c("d", "u", "v"),
                                        objUDim = c(1000, 2), objURange = c(-0.06, 0.06), 
                                        objVDim = c(2, 2), objVRange = c(-1, 0)))
result <- append(result, testRunSVD(smiley, 0.69, list(class = "list", length = 2, dataClass = "data.frame",
                                                       dataDim = c(1000, 2), objClass = "list", objNames = c("d", "u", "v"),
                                                       objUDim = c(1000, 2), objURange = c(-0.06, 0.06), 
                                                       objVDim = c(2, 2), objVRange = c(-1, 0))))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nrunSVD() test starts\n", 
                                                                x, "runSVD() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nrunSVD() test starts\n", x, "\nrunSVD() test ends\n\n")))
  }
})
### end of runSVD() test

### Testing runPCA()
testRunPCA <- function(data, coverage, results)
{
  failedTests <- list()
  obj <- runPCA(data, coverage)
  # Test 1
  error <- tryCatch(
    {
      test_that("Checking if object is valid",
                {
                  expect_equal(is.null(obj), FALSE)
                  expect_equal(class(obj), results$class)
                  expect_equal(length(obj), results$length)
                  expect_equal(names(obj), results$names)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  # Test 2
  error <- tryCatch(
    {
      test_that("Checking if object values are valid",
                {
                  expect_equal(round(obj$pcaOut[[1]], 3), results$stdDev)
                  expect_equal(class(obj$truncatedData), results$dataClass)
                  expect_equal(dim(obj$truncatedData), results$dataDim)
                  expect_equal(round(abs(range(obj$truncatedData)), 2), results$dataRange)
                })
    },error = function(e)
    {
      return(e)
    }
  )
  if(!isTRUE(error))
  {
    failedTests[length(failedTests)+1] <- as.character(error)
  }
  
  if(length(failedTests) == 0)
    return("Result: Test passed")
  else
    return(failedTests)
}# end of function

result <- testRunPCA(smiley, 0.96, list(class = "list", length = 2, names = c("pcaOut", "truncatedData"),
                                        stdDev = c(1.004, 0.996), dataClass = "data.frame", 
                                        dataDim = c(1000, 2), dataRange = c(2.19, 1.56)))

result <- append(result, testRunPCA(smiley, 0.69, list(class = "list", length = 2, names = c("pcaOut", "truncatedData"),
                                                       stdDev = c(1.004, 0.996), dataClass = "data.frame", 
                                                       dataDim = c(1000, 2), dataRange = c(2.19, 1.56))))

lapply(result, function(x){
  if(x != "Result: Test passed")
  {
    failedTestResults <<- append(failedTestResults, list(paste0("\n\nrunPCA() test starts\n", 
                                                                x, "runPCA() test ends\n\n")))
  }else
  {
    allTestResults <<- append(allTestResults, list(paste0("\n\nrunPCA() test starts\n", x, "\nrunPCA() test ends\n\n")))
  }
})
### end of runPCA() test

#####################################################

# print(allTestResults)
# if(length(failedTestResults)==0)
#   print("All tests passed!")

tryCatch({
  if(length(failedTestResults) > 0)
  {
    # flog.info(unlist(failedTestResults))
    stop(unlist(failedTestResults))
  }else
  {
    print("All tests passed")
  }
})
