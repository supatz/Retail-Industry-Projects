usagePeriod <- NULL
expiryMssg <- NULL

defaultDeclarations <- function() 
{
  noOfDays <- 30 # expiry set for 30 days
  daysInMinutes <- noOfDays * 24 * 60
  usagePeriod <<- daysInMinutes * 0.0006919462  # 0.0006919462 = epoch time for a minute
  expiryMssg <<- ""
}


fileInfoAvailable <- function()
{
  if(file.exists("Source/Description.json"))
  {
    tmp <- rjson::fromJSON(file = "Source/Description.json")
    if("version" %in% names(tmp) && "filename" %in% names(tmp))
      return(TRUE)
  }
  return(FALSE)
}


isFirstRun <- function()
{
  targetPath <- base::.libPaths()[1]
  availableList <- base::list.files(targetPath, pattern = ".RDS")
  availableList <- base::unlist(base::lapply(availableList, function(x) base::strsplit(x, ".RDS")[[1]][1]))
  # Checking if Description.json exists
  if(!fileInfoAvailable())
    return("The Description.json file which is a necessary requirement, seems to be missing.")
  # If here, then Description.json exists
  tmp <- rjson::fromJSON(file = "Source/Description.json")
  fileSaved <- base::paste0(tmp$filename, ".RDS")
  # Check if firstRun.RDS exists
  if(base::file.exists("Source/firstRun.RDS"))
  {
    return("TRUE")
  }else 
  {
    # If here, firstRun.RDS doesn't exist
    return("FALSE")
  }
}

checkExpiry <- function()
{
  res <- isFirstRun()
  if(res != "TRUE" && res != "FALSE")
    return(res)
  targetPath <- base::.libPaths()[1]
  availableList <- base::list.files(targetPath, pattern = ".RDS")
  availableList <- base::unlist(base::lapply(availableList, function(x) base::strsplit(x, ".RDS")[[1]][1]))
  tmp <- rjson::fromJSON(file = "Source/Description.json")
  fileSaved <- base::paste0(tmp$filename, ".RDS")
  ts <- base::as.numeric(base::as.POSIXct(base::Sys.time(), tz = "Asia/Kolkata"))
  if(res == "TRUE")
  {
    if(base::file.exists(base::paste0(targetPath, "/", fileSaved)))
    {
      dataToWrite <- base::readRDS(base::paste0(targetPath, "/", fileSaved))
      dataToWrite[[tmp$version]] <- ts
    }else
    {
      dataToWrite <- list(ts)
      names(dataToWrite) <- tmp$version
    }
    base::unlink("Source/firstRun.RDS")
    base::saveRDS(dataToWrite, base::paste0(targetPath, "/", fileSaved))
    return("FIRST")
  }else
  {
    # res == "FALSE"
    if(base::file.exists(base::paste0(targetPath, "/", fileSaved)))
    {
      # check license period
      info <- base::readRDS(paste0(targetPath, "/", fileSaved))
      if(tmp$version %in% names(info))
      {
        tsRecorded <- info[[tmp$version]]
        delta <- base::difftime(base::as.POSIXct(ts, tz = "Asia/Kolkata", origin = "1970-1-1"), 
                                base::as.POSIXct(tsRecorded, tz = "Asia/Kolkata", origin = "1970-1-1"), units = "days")[[1]]
        if(delta > usagePeriod)
        {
          filesToDelete <- base::setdiff(list.files("Source/", pattern = ".RData$", recursive = T), 
                                         c("mainUtils.RData", "PackageInstallationUtils.RData"))
          base::unlink(base::unlist(base::lapply(filesToDelete, function(x) base::paste0("Source/", x))))
          info[[tmp$version]] <- NULL
          base::saveRDS(info, base::paste0(targetPath, "/", fileSaved))
          if(length(info) == 0)
            base::unlink(base::paste0(targetPath, "/", fileSaved))
          rdataToDelete <- base::setdiff(list.files(path = "Source/", pattern = "*.RData$"), c("mainUtils.RData", "PackageInstallationUtils.RData"))
          base::unlink(base::paste0("Source/", rdataToDelete))
          return("You shall not pass! Your license has expired!! Kindly re-download the brick for use.")
        }
        else
          return("PASS")
      }else
      {
        # file tampered
        return("Required files are missing. Kindly re-download the brick for use.")
      }
    }else
    {
      # file tampered
      return("License has been tampered with. Kindly re-download the brick for use.")
    }
  }
}

startup <- function(input, output, mssg)
{
  if(mssg == "FIRST")
  {
    shiny::modalDialog({
      ui <- shiny::bootstrapPage(
        htmltools::tags$p(id="headPopup","License verification step!",style="color:black;"),
        htmltools::tags$hr(), 
        htmltools::tags$p(id="bodyPopup", "Link the zip of the brick from where the files were extracted", 
                          style="color:black;font-size=18px"),
        shinyFiles::shinyFilesButton('file', 'File select', 'Please select a file', FALSE),
        htmltools::tags$br(),
        htmltools::tags$br(),
        shiny::textOutput("zipMssg")
      )
      server <- function(input, output)
      {
        fileInfo <- ""
        output$zipMssg <- shiny::renderText(invisible())
        volumes <- shinyFiles::getVolumes() #c('R Installation'=R.home())
        shinyFiles::shinyFileChoose(input, 'file', roots = volumes, restrictions = base::system.file(package='base'))
        output$zipMssg <- shiny::renderText({
          if(!is.null(input$file))
          {
            fileInfo <<- as.character(shinyFiles::parseFilePaths(volumes, input$file)[['datapath']])
            fileInfo
          }else
          {
            invisible()
          }
        })
        observe({
          print(length(as.character(shinyFiles::parseFilePaths(volumes, input$file)[['datapath']])))
          
          if(length(as.character(shinyFiles::parseFilePaths(volumes, input$file)[['datapath']])) > 0 &&
             file.exists(as.character(shinyFiles::parseFilePaths(volumes, input$file)[['datapath']])))
          {
            unlink(as.character(shinyFiles::parseFilePaths(volumes, input$file)[['datapath']]))
            print(as.character(shinyFiles::parseFilePaths(volumes, input$file)[['datapath']]))
            print(file.exists(as.character(shinyFiles::parseFilePaths(volumes, input$file)[['datapath']])))
            if(!file.exists(as.character(shinyFiles::parseFilePaths(volumes, input$file)[['datapath']])))
              output$zipMssg <- shiny::renderText({"Succesfully verified!"}) else
                output$zipMssg <- shiny::renderText({paste0(as.character(shinyFiles::parseFilePaths(volumes, input$file)[['datapath']]), " not foind!")})
          }else if(length(as.character(shinyFiles::parseFilePaths(volumes, input$file)[['datapath']])) > 0 &&
                   !file.exists(as.character(shinyFiles::parseFilePaths(volumes, input$file)[['datapath']])))
          {
            output$zipMssg <- shiny::renderText({"Verification unsuccessful!!!"})
          }
        })
      }
      shiny::shinyApp(ui = ui, server = server)
    }) # end of modalDialog
  }else if(mssg == "PASS")
  {
    output$popStartup <- shiny::renderUI({})
    output$popStartup_2 <- shiny::renderUI({})
  }else
  {
    output$popStartup_2 <- shiny::renderUI({htmltools::tags$div(class="whiteBox_2","")})
    output$popStartup <- shiny::renderUI({
      shiny::tagList(htmltools::tags$div(class="whiteBox",
                                         htmltools::tags$p(id="headPopup","License expiry alert!",style="color:red;"),
                                         htmltools::tags$hr(),
                                         htmltools::tags$p(id="bodyPopup", mssg, style="color:red;font-size=18px"),
                                         htmltools::tags$hr(),
                                         shiny::actionButton("closePopupExpiry","Close"))
      )
    })
    shiny::observeEvent(input$closePopupExpiry,{
      output$popStartup <- shiny::renderUI({})
      output$popStartup_2 <- shiny::renderUI({})
    })
  }
}

