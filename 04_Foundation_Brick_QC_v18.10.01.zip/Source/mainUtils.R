expired <- FALSE
loadPackageInstall <- function()
{
  if (file.exists("Source/PackageInstallationUtils.R")) {
    source("Source/PackageInstallationUtils.R")
  }
  if (file.exists("Source/PackageInstallationUtils.RData")) {
    load("Source/PackageInstallationUtils.RData", envir = .GlobalEnv)
  }
}

loadFunctions <- function(input, output,session) 
{
  tryCatch({
    Rfiles <- 0
    RDatafiles <- 0
    if (file.exists("Source/utils.R")) {
      source("Source/utils.R")
      Rfiles <- Rfiles + 1
    }
    if (file.exists("Source/utils.RData")) {
      load("Source/utils.RData", envir = .GlobalEnv)
      RDatafiles <- RDatafiles + 1
    }
    loadGlobals()
    if (file.exists("Source/downloadReport.R")) {
      source("Source/downloadReport.R")
      Rfiles <- Rfiles + 1
    }
    if (file.exists("Source/downloadReport.RData")) {
      load("Source/downloadReport.RData", envir = .GlobalEnv)
      RDatafiles <- RDatafiles + 1
    }

    
    #################################################
    ## The code hereafter is common for all bricks ##
    #################################################
    
    if (file.exists("Source/brickUsage.R")) {
      source("Source/brickUsage.R")
      Rfiles <- Rfiles + 1
    }
    if (file.exists("Source/brickUsage.RData")) {
      load("Source/brickUsage.RData", envir = .GlobalEnv)
      RDatafiles <- RDatafiles + 1
    }
    if (file.exists("Source/reportIssue.R")) {
      source("Source/reportIssue.R")
      Rfiles <- Rfiles + 1
    }
    if (file.exists("Source/reportIssue.RData")) {
      load("Source/reportIssue.RData", envir = .GlobalEnv)
      RDatafiles <- RDatafiles + 1
    } 
    if (file.exists("Source/customPrecision.R")) {
      source("Source/customPrecision.R")
      Rfiles <- Rfiles + 1
    }
    if (file.exists("Source/customPrecision.RData")) {
      load("Source/customPrecision.RData", envir = .GlobalEnv)
      RDatafiles <- RDatafiles + 1
    }
    if(file.exists('Source/databaseUI.R'))
      source('Source/databaseUI.R')
    if(file.exists('Source/databaseUI.RData'))
      load('Source/databaseUI.RData', envir = .GlobalEnv)
    databaseUI(input,output,session)
    if (file.exists("Source/oldVersionPopup.R")) {
      source("Source/oldVersionPopup.R")
      Rfiles <- Rfiles + 1
    }
    if (file.exists("Source/oldVersionPopup.RData")) {
      load("Source/oldVersionPopup.RData", envir = .GlobalEnv)
      RDatafiles <- RDatafiles + 1
    }
    
    if (RDatafiles >= Rfiles) {
      if (file.exists("Source/expiry.R")) 
        source("Source/expiry.R")
      if (file.exists("Source/expiry.RData")) 
        load("Source/expiry.RData", envir = .GlobalEnv)
      defaultDeclarations()
      expiryMssg <<- checkExpiry()
      if (expiryMssg == "FIRST" || expiryMssg == "PASS") {
        expired <<- FALSE
      }
      else {
        expired <<- TRUE
      }
    }
    else expired <<- FALSE
  }, error = function(e) {
    expired <<- TRUE
    fireAlert(input, output)
  })
}

fireAlert <- function(input, output)
{
  output$popStartup_2<-renderUI({tags$div(class="whiteBox_2","")})
  output$popStartup<-renderUI({
    tagList(tags$div(class="whiteBox",
                     tags$p(id="headPopup","License expired!",style="color:red;"),
                     tags$hr(),
                     tags$p(id="bodyPopup", "You are using an expired brick. Booooo!", style="color:red;font-size=18px"),
                     tags$hr(),
                     actionButton("closePopup","Close"))
    )
  })
  observeEvent(input$closePopup,{
    output$popStartup<-renderUI({})
    output$popStartup_2<-renderUI({})
  })
}