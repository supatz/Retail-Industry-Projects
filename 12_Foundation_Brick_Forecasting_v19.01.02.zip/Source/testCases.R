source("forecasting_utils.R")
source("forecast-gts.R")


loadGlobals()
loadPackage <- function(pkgName){
  if (!do.call(require, list(pkgName))) {
    # install.packages(pkgName, dependencies = T, repos = "http://cran.us.r-project.org")
    do.call(library, list(pkgName))
  }
}
print("vars" %in% packages)
# stop("Boo")
lapply(packages, FUN = function(p){ loadPackage(p) })

library(testthat)
library(futile.logger)


allTestsResults <- list()
allTestsResultsSummary <- list()
allTestsGetColNamesfromType <- list()


hts_data <- utils::read.csv("../JenkinsTestData/hotel_main_small.csv")
non_hts_data <- utils::read.csv("../JenkinsTestData/hotel_data.csv")
values_to_check_against <- readRDS("../JenkinsTestData/testcase_values.RDS")

# values_to_check_against$hts_arima_model$forecasts$origfcasts <- NULL
# values_to_check_against$hts_mars_model$forecasts$origfcasts <- NULL
# values_to_check_against$hts_prophet_model$forecasts$origfcasts <- NULL
# values_to_check_against$hts_vars_model$forecasts$origfcasts <- NULL
# values_to_check_against$hts_ucm_model$forecasts$origfcasts <- NULL
# values_to_check_against$hts_svr_model$forecasts$origfcasts <- NULL
# values_to_check_against$hts_hw_model$forecasts$origfcasts <- NULL
# values_to_check_against$hts_tbats_model$forecasts$origfcasts <- NULL

set.seed(7)
#  Get Colnames of specific type

testGetColNamesfromType <- function(){
  failedTestsGetColNamesfromType <- list()
  
  # Test Numeric Columns
  error <- tryCatch({
    test_that("Get numeric columns",{
      expect_equal(getNumColNames(non_hts_data),c("RMS_AVAIL_QTY","Occupancy","AvgDailyRate",
                                              "Compet_Occupancy","Compet_AvgDailyRate","PercentGovtNights",
                                              "PercentGroupNights","PercentTransientNights","PercentBusiness",       
                                              "PercentLeisure","hotelcount1mile","hotelcount5mile",       
                                              "rooms1mile","rooms5mile","club_contribution",     
                                              "cro_nts_totsty","gds_nts_totsty","ids_nts_totsty",       
                                              "inn_nts_totsty","slf_nts_totsty" ,"web_nts_totsty"))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsGetColNamesfromType[length(failedTestsGetColNamesfromType)+1] <- as.character(error)
  }
  
  #Test character columns
  error <- tryCatch({
    test_that("Get char columns",{
      expect_equal(getCharColNames(non_hts_data),character(0))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsGetColNamesfromType[length(failedTestsGetColNamesfromType)+1] <- as.character(error)
  }
  
  #Test Factor columns
  error <- tryCatch({
    test_that("Get factor columns",{
      expect_equal(getFactorColNames(non_hts_data),c("Date"))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsGetColNamesfromType[length(failedTestsGetColNamesfromType)+1] <- as.character(error)
  }
  
  if(length(failedTestsGetColNamesfromType) == 0){
    return("GetColNamesfromType Test Passed")
  }
  else{
    return(failedTestsGetColNamesfromType)
  }
  
}

testResultsGetColNamesfromType <- testGetColNamesfromType()

if(testResultsGetColNamesfromType!="GetColNamesfromType Test Passed"){
  allTestsResults['GetColNamesfromType Test'] <- testResultsGetColNamesfromType
}

#Make XTS----------------------------------------------------------------------------

non_hts_df_single <- data.frame(non_hts_data[,c("Occupancy","Date")])


testXTS <- function(){
  failedTestsXTS <- list()
  non_hts_data$Date <- lubridate::parse_date_time(non_hts_data$Date,"ymd")
  non_hts_df_single$Date <- lubridate::parse_date_time(non_hts_df_single$Date,"ymd")
  
  # Call function
  non_hts_data_xts <- make_xts(non_hts_data,"Date")
  non_hts_data_df_single_xts <- make_xts(non_hts_df_single,"Date")
  
  error <- tryCatch({
    test_that("Make XTS for full data frame",{
      expect_equal(class(non_hts_data_xts),c("xts","zoo"))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsXTS[length(failedTestsXTS)+1] <- as.character(error)
  }

  error <- tryCatch({
    test_that("Check colnames for Make XTS full df",{
      expect_equal(colnames(non_hts_data_xts),c("RMS_AVAIL_QTY","Occupancy","AvgDailyRate",
                                                "Compet_Occupancy","Compet_AvgDailyRate","PercentGovtNights",
                                                "PercentGroupNights","PercentTransientNights","PercentBusiness",       
                                                "PercentLeisure","hotelcount1mile","hotelcount5mile",       
                                                "rooms1mile","rooms5mile","club_contribution",     
                                                "cro_nts_totsty","gds_nts_totsty","ids_nts_totsty",       
                                                "inn_nts_totsty","slf_nts_totsty" ,"web_nts_totsty"))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsXTS[length(failedTestsXTS)+1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Make XTS for single column df",{
      expect_equal(class(non_hts_data_df_single_xts),c("xts","zoo"))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsXTS[length(failedTestsXTS)+1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Check colnames for Make XTS single column df",{
      expect_equal(colnames(non_hts_data_df_single_xts),c("Occupancy"))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsXTS[length(failedTestsXTS)+1] <- as.character(error)
  }
  
  if(length(failedTestsXTS) == 0){
    return("Make XTS Test Passed")
  }
  else{
    return(failedTestsXTS)
  }  
}


testResultsMakeXTS <- testXTS()

if(testResultsMakeXTS!="Make XTS Test Passed"){
  allTestsResults['Make XTS Test'] <- testResultsMakeXTS
}

#------------------Find Roll Range----------------------------------------------------



testFindRollRange <- function(){
  failedTestsRollRange <- list()
  DTformat <- "ymd"
  non_hts_data$Date <- lubridate::parse_date_time(non_hts_data$Date,DTformat)

  # Call function
  non_hts_data_xts <- make_xts(non_hts_data,"Date")
  DTformat <- unlist(strsplit(gsub("[[:blank:][:punct:]]","",DTformat),split = ""))
  format_dict <- c(y="years",m="months",d="days",H="hours",M="minutes",S="seconds")
  format_list <- lapply(DTformat,FUN = function(x) format_dict[[x]])
  
  error <- tryCatch({
    test_that("Check roll range for years",{
      expect_equal(find_roll_range(non_hts_data_xts,format_list[[1]]),list(roll_min=1,roll_max=1))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsRollRange[length(failedTestsRollRange)+1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Check roll range for months",{
      expect_equal(find_roll_range(non_hts_data_xts,format_list[[2]]),list(roll_min=1,roll_max=2))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsRollRange[length(failedTestsRollRange)+1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Check roll range for days",{
      expect_equal(find_roll_range(non_hts_data_xts,format_list[[3]]),list(roll_min=1,roll_max=30))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsRollRange[length(failedTestsRollRange)+1] <- as.character(error)
  }

  error <- tryCatch({
    test_that("Check roll range for hours",{
      expect_equal(find_roll_range(non_hts_data_xts,"hours"),list(roll_min=1,roll_max=23))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsRollRange[length(failedTestsRollRange)+1] <- as.character(error)
  }

  error <- tryCatch({
    test_that("Check roll range for minutes",{
      expect_equal(find_roll_range(non_hts_data_xts,"minutes"),list(roll_min=1,roll_max=49))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsRollRange[length(failedTestsRollRange)+1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Check roll range for minutes",{
      expect_equal(find_roll_range(non_hts_data_xts,"seconds"),list(roll_min=1,roll_max=49))
    })
  },error=function(e){return(e)})
  
  if(!isTRUE(error)){
    failedTestsRollRange[length(failedTestsRollRange)+1] <- as.character(error)
  }
  
  if(length(failedTestsRollRange) == 0){
    return("Roll Range Test Passed")
  }
  else{
    return(failedTestsRollRange)
  } 
}

testResultsFindRollRange <- testFindRollRange()
if(testResultsFindRollRange!="Roll Range Test Passed"){
  allTestsResults['Roll Range Test'] <- testResultsFindRollRange
}

# Roll UP Hierarchical and Non-hierarchical data



testRollDatabyTime <- function(){
  failedTestsRollDatabyTime <- list()
  Roll_level <- "month"
  non_hts_TimeVar <- "Date"
  hts_TimeVar <- "Yearmonth"
  non_hts_DTformat <- "ymd"
  hts_DTformat <- "ym"
  AnomalyVar <- "Occupancy"
  TimeZone <- "GMT"
  Roll_Option <- "mean"
  Roll_Period <- 2
  non_hts_HierarchyColumns <- NULL
  hts_HierarchyColumns <- 'UID'
  
  non_hts_data[,non_hts_TimeVar] <- lubridate::parse_date_time(non_hts_data[,non_hts_TimeVar],non_hts_DTformat)
  hts_data[,hts_TimeVar] <- lubridate::parse_date_time(hts_data[,hts_TimeVar],hts_DTformat)
  
  rolled_non_hts_data <- rollupDataByTime(non_hts_data,HierarchyColumns = non_hts_HierarchyColumns,Roll_Level = Roll_level,TimeVar = non_hts_TimeVar,DTformat = non_hts_DTformat,Roll_Option = Roll_Option,Roll_Period = Roll_Period,TimeZone = TimeZone,AnomalyVar = AnomalyVar)
  rolled_hts_data <- rollupDataByTime(hts_data,HierarchyColumns = hts_HierarchyColumns,Roll_Level = Roll_level,TimeVar = hts_TimeVar,DTformat = hts_DTformat,Roll_Option = Roll_Option,Roll_Period = Roll_Period,TimeZone = TimeZone,AnomalyVar = AnomalyVar)
 
  error <- tryCatch({
    test_that("Check roll up by time for non hts",{
      expect_equal(rolled_non_hts_data,values_to_check_against$rolled_non_hts_data)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsRollDatabyTime[length(failedTestsRollDatabyTime) + 1] <- as.character(error)
  } 
  
  error <- tryCatch({
    test_that("Check roll up by time for hts",{
      expect_equal(rolled_hts_data,values_to_check_against$rolled_hts_data)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsRollDatabyTime[length(failedTestsRollDatabyTime) + 1] <- as.character(error)
  }

  if (length(failedTestsRollDatabyTime) == 0) {
    return("Roll Data by Time Test Passed")
  }
  else{
    return(failedTestsRollDatabyTime)
  } 
  
}

testResultsRollDatabyTime <- testRollDatabyTime()
if (testResultsRollDatabyTime != "Roll Data by Time Test Passed") {
  allTestsResults['Roll Data by Time Test'] <- testResultsRollDatabyTime
}

# Build Hierarchical and non-hts auto arima model

testBuildModel <- function(){
  failedTestsBuildModel <- list()
  
  hts_train <- values_to_check_against$hts_train
  hts_xreg <- values_to_check_against$hts_xreg
  hts_newxreg <- values_to_check_against$hts_newxreg
  hts_train_time <- values_to_check_against$hts_train_time

  non_hts_train <- values_to_check_against$non_hts_train
  non_hts_xreg <- values_to_check_against$non_hts_xreg
  non_hts_newxreg <- values_to_check_against$non_hts_newxreg

  ahead <- 5
  seasonal_cond <- TRUE
  stationary_cond <- TRUE
  arima_frequency <- 12
  hts_method <- "tdgsa"
  hts_base_level <- NULL
  
  # MARS params
  nlag <- 1
  
  # Prophet params
  prophet_test_date <- values_to_check_against$prophet_test_date
  yearly_seas <- FALSE
  weekly_seas <- FALSE
  daily_seas <- FALSE
  
  # VARS params
  vars_endo_train_data <- values_to_check_against$vars_endo_train_data
  non_hts_newxreg_vars <- values_to_check_against$non_hts_newxreg_vars
  non_hts_xreg_vars <- values_to_check_against$non_hts_xreg_vars
  vars_hts_endo_train <- values_to_check_against$vars_hts_endo_train
  lag_order <- 1
  regressor_type <- 'const'
  
  # UCM params
  ucm_level <- FALSE
  ucm_slope <- FALSE
  ucm_season <- FALSE
  ucm_cycle <- FALSE
  season_length <- NULL
  cycle_length <- NULL
  
  # SVR params
  svr_kernel <- 'radial'
  
  # HW params
  
  a <- NULL
  b <- FALSE
  g <- FALSE
  s <- NULL
  hw_freq <- NULL
  
  # tbats param
  
  tbats_use_boxcox <- FALSE
  tbats_use_trend <- FALSE
  tbats_use_damped_trend <- FALSE
  tbats_use_arma <- FALSE
  tbats_seasonal_period <- NULL

  hts_arima_model <- fCast(data = hts_train,isHts=TRUE,ahead=ahead,
                   fmethod="auto.arima",
                   params=list(seasonal = seasonal_cond,stationary = stationary_cond,xreg=hts_xreg,freq=arima_frequency)
                   ,htsParams=c(list(method=hts_method), level=hts_base_level,newxreg=list(hts_newxreg)))
  
  non_hts_arima_model <- fCast(data = non_hts_train,isHts=FALSE,htsParams = list(xreg = non_hts_newxreg)
                   ,ahead=ahead,fmethod="auto.arima"
                   ,params=list(seasonal = seasonal_cond,stationary = stationary_cond,xreg = non_hts_xreg,freq=arima_frequency))
  
  hts_mars_model <- fCast(data=hts_train,isHts=TRUE,fmethod='earth_custom',ahead=ahead,params=list(nlag=nlag,xreg = hts_xreg),htsParams = c(list(method=hts_method),level=hts_base_level,newxreg=list(hts_newxreg)))
  
  non_hts_mars_model <- fCast(data = non_hts_train,isHts=FALSE,htsParams = list(xreg = non_hts_newxreg)
                   ,ahead=ahead,fmethod='earth_custom',params=list(xreg = non_hts_xreg,nlag=nlag))
  
  hts_prophet_model <- fCast(data=hts_train,isHts=TRUE,fmethod='prophet',ahead=prophet_test_date,params=list(ds_train=hts_train_time,yearly.seasonality = yearly_seas,weekly.seasonality = weekly_seas,daily.seasonality = daily_seas,xreg=hts_xreg),htsParams = c(list(method=hts_method),level=hts_base_level,newxreg=list(hts_newxreg)))
  
  hts_vars_model <-  fCast(data=hts_train,isHts=TRUE,fmethod='VAR',ahead=ahead,params=list(p=lag_order,type=regressor_type,exogen=hts_xreg,endogen=vars_hts_endo_train),htsParams = c(list(method=hts_method),level=hts_base_level,newxreg=list(hts_newxreg)),yVar= "Occupancy")
  hts_vars_model$forecasts$fitted <- hts_vars_model$forecasts$fitted[1:15,]
  
  non_hts_vars_model <- fCast(data = vars_endo_train_data,isHts=FALSE,
                              htsParams = list(xreg = non_hts_newxreg_vars),
                              ahead=ahead,
                              fmethod='VAR',
                              params=list(p=lag_order,type=regressor_type,exogen=non_hts_xreg_vars),
                              yVar="Occupancy")
  
  hts_ucm_model <- fCast(data=hts_train,isHts=TRUE,fmethod='ucm' ,ahead=ahead ,params=list(level=ucm_level, slope=ucm_slope, season=ucm_season, cycle=ucm_cycle,  xreg = hts_xreg,season.length = season_length, cycle.period = cycle_length) ,htsParams = c(list(method=hts_method), level=hts_base_level, newxreg=list(hts_newxreg)))
  
  non_hts_ucm_model <- fCast(data=non_hts_train,isHts=FALSE,fmethod='ucm' ,ahead=ahead,params=list(level=ucm_level, slope=ucm_slope, season=ucm_season, cycle=ucm_cycle, xreg = non_hts_xreg ,season.length = season_length, cycle.period = cycle_length),htsParams = list(xreg=non_hts_newxreg))
  
  hts_svr_model <-  fCast(data = hts_train, isHts = TRUE, fmethod = 'SVR' , ahead = ahead , params = list(n_lag = nlag, xreg = hts_xreg, kernel=svr_kernel)  , htsParams = c(list(method = hts_method)   ,level = hts_base_level,newxreg = list(hts_newxreg)))
  
  non_hts_svr_model <-fCast(data = non_hts_train , isHts = FALSE, htsParams = list(xreg = non_hts_newxreg), ahead = ahead , fmethod = 'SVR', params = list(n_lag = nlag, xreg = non_hts_xreg, kernel=svr_kernel  ))
  
  hts_hw_model <-  fCast(hts_train,isHts=TRUE,fmethod='HoltWinters',ahead=ahead,params=list(alpha = a,beta = b,gamma = g,seasonal = s),htsParams=c(list(method=hts_method),level=hts_base_level),hw_freq=hw_freq)
  
  non_hts_hw_model <- fCast(data =non_hts_train,isHts=FALSE,ahead=ahead,fmethod='HoltWinters',params=list(alpha=a,beta=b,gamma=g,seasonal=s))

  
  non_hts_tbats_model <- fCast(data = non_hts_train,isHts=FALSE,ahead=ahead,fmethod='tbats',params=list(use.box.cox=tbats_use_boxcox,use.trend=tbats_use_trend,use.damped.trend=tbats_use_damped_trend,seasonal.periods=tbats_seasonal_period,use.arma.errors=tbats_use_arma,use.parallel=TRUE))
  
  hts_tbats_model <- fCast(hts_train,isHts=TRUE,fmethod="tbats",ahead=ahead,params=list(use.box.cox=tbats_use_boxcox,use.trend=tbats_use_trend,use.damped.trend=tbats_use_damped_trend,seasonal.periods=tbats_seasonal_period,use.arma.errors=tbats_use_arma,use.parallel=TRUE),htsParams=c(list(method=hts_method),level=hts_base_level))

  
  error <- tryCatch({
    test_that("Build non hts auto arima model",{
      expect_equal(non_hts_arima_model,values_to_check_against$non_hts_arima_model)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  } 
  
  error <- tryCatch({
    test_that("Build  hts auto arima model",{
      expect_equal(hts_arima_model,values_to_check_against$hts_arima_model)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Build non hts mars model",{

      expect_equal(non_hts_mars_model$forecasts$mean,values_to_check_against$non_hts_mars_model$forecasts$mean,tolerance=1e-6)
    })
  },error = function(e){return(e)})

  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Build  hts mars model",{
      expect_equal(hts_mars_model,values_to_check_against$hts_mars_model)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Build  hts prophet model",{
      expect_equal(hts_prophet_model,values_to_check_against$hts_prophet_model)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Build   hts vars model",{
      expect_equal(data.frame(hts_vars_model$forecasts$fitted[1:15,]), data.frame(values_to_check_against$hts_vars_model$forecasts$fitted))
    })
    test_that("Builds hts vars model",{
      expect_equal(data.frame(hts_vars_model$forecasts$residuals[1:15,]), data.frame(values_to_check_against$hts_vars_model$forecasts$residuals))
    })
  },error = function(e){return(e)})

  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Build  non hts vars model",{
      expect_equal(non_hts_vars_model,values_to_check_against$non_hts_vars_model)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Build  non hts ucm model",{
      expect_equal(non_hts_ucm_model,values_to_check_against$non_hts_ucm_model,tolerance=1e-6)
    })
  },error = function(e){return(e)})

  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }

  error <- tryCatch({
    test_that("Build  hts ucm model",{
      expect_equal(hts_ucm_model,values_to_check_against$hts_ucm_model)
    })
  },error = function(e){return(e)})

  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Build  non hts svr model",{
      expect_equal(non_hts_svr_model,values_to_check_against$non_hts_svr_model,tolerance=1e-6)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Build  hts svr model",{
      expect_equal(hts_svr_model,values_to_check_against$hts_svr_model)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Build  non hts hw model",{
      expect_equal(non_hts_hw_model,values_to_check_against$non_hts_hw_model)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Build  hts hw model",{
      expect_equal(hts_hw_model,values_to_check_against$hts_hw_model)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Build  non hts tbats model",{
      expect_equal(non_hts_tbats_model,values_to_check_against$non_hts_tbats_model)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }

  error <- tryCatch({
    test_that("Build  hts tbats model",{
      expect_equal(hts_tbats_model,values_to_check_against$hts_tbats_model)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsBuildModel[length(failedTestsBuildModel) + 1] <- as.character(error)
  }
  
  
  if (length(failedTestsBuildModel) == 0) {
    return("Build Model Test Passed")
  }
  else{
    return(failedTestsBuildModel)
  } 
}

testResultsBuildModel <- testBuildModel()
if (testResultsBuildModel != "Build Model Test Passed") {
  allTestsResults['Build Model Test'] <- testResultsBuildModel
}

testGetAccuracy <- function(){
  failedTestsGetAccuracy <- list()
  
  hts_train <- values_to_check_against$hts_train
  hts_validation <- values_to_check_against$hts_validation
  hts_arima_model <- values_to_check_against$hts_arima_model
  
  non_hts_train <- values_to_check_against$non_hts_train
  non_hts_validation <- values_to_check_against$non_hts_validation
  non_hts_arima_model <- values_to_check_against$non_hts_arima_model
  
  get_hts_accuracy <- getAccuracy_func(hts_arima_model,hts_train,hts_validation)
  get_non_hts_accuracy <- getAccuracy_func(non_hts_arima_model,non_hts_train,non_hts_validation)
  
  error <- tryCatch({
    test_that("Check HTS Train Accuracy",{
      expect_equal(as.vector(get_hts_accuracy$train_mape),c(0.3395624,4.5287405,4.6145396))
      
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsGetAccuracy[length(failedTestsGetAccuracy) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Check HTS Test Accuracy",{
      expect_equal(as.vector(get_hts_accuracy$test_mape),c(0.4794722,6.528415,7.630938),tolerance=1e-6)
      
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsGetAccuracy[length(failedTestsGetAccuracy) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Check non HTS Train Accuracy",{
      expect_equal(get_non_hts_accuracy$train_mape,20.01843,tolerance=1e-6)
      
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsGetAccuracy[length(failedTestsGetAccuracy) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Check non HTS Test Accuracy",{
      expect_equal(get_non_hts_accuracy$test_mape,24.26878)
      
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsGetAccuracy[length(failedTestsGetAccuracy) + 1] <- as.character(error)
  }
  
  if (length(failedTestsGetAccuracy) == 0) {
    return("Check Accuracy Test Passed")
  }
  else{
    return(failedTestsGetAccuracy)
  }  
}

testResultsGetAccuracy <- testGetAccuracy()
if (testResultsGetAccuracy != "Check Accuracy Test Passed") {
  allTestsResults['Check Accuracy Test'] <- testResultsGetAccuracy
}


testModelSummary <- function(){
  failedTestsModelSummary <- list()
  
  hts_train <- values_to_check_against$hts_train
  models <- values_to_check_against$model_list
  model_name <- 'arima'
  hts_method <- 'tdgsa'
  hts_base_level <- NULL
  hts_node <- 'Total'
    
  selected_model_hts <- get_hts_model_summary(hts_train,models,model_name,hts_method,hts_base_level,hts_node)
  
  error <- tryCatch({
    test_that("Check model summary HTS",{
      expect_equal(selected_model_hts$Total$coef,c('intercept'=1.334607523,'ADR'=-0.009684149,'REVPAR'=0.014505103))
      expect_equal(selected_model_hts$Total$sigma2,4.032181e-05)
      expect_equal(selected_model_hts$Total$aic,-111.8141,tolerance=1e-5)
      expect_equal(selected_model_hts$Total$arma,c(0,0,0,0,12,0,0))
      expect_equal(selected_model_hts$Total$bic,-108.7237,tolerance=1e-5)
      
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsModelSummary[length(failedTestsModelSummary) + 1] <- as.character(error)
  }
  
  if (length(failedTestsModelSummary) == 0) {
    return("Model Summary Test Passed")
  }
  else{
    return(failedTestsModelSummary)
  }  
}

testResultsModelSummary <- testModelSummary()
if (testResultsModelSummary != "Model Summary Test Passed") {
  allTestsResults['Model Summary Test'] <- testResultsModelSummary
}

total_node_residuals <- c(-0.0010953863,0.0001452541 , 0.0137835907, -0.0048135290 ,-0.0049377779,
                          0.0008624332 , 0.0040283454 , 0.0017087184 , 0.0048938813, -0.0062361693,
                          0.0037434591, -0.0090615845 ,-0.0002860020 , 0.0074142017, -0.0051421038,
                          -0.0050073311)
one_node_residuals <- c(-0.016691673 , 0.034847570 ,-0.101446473 ,-0.074382636 , 0.035929685,
                        -0.006046008 , 0.031676332, -0.008285571 , 0.028882262 , 0.050133780,
                        0.038569440 , -0.004009499, -0.012117885 , 0.024968384 ,-0.018928659,
                        -0.005463541)

two_node_residuals <- c( 0.015596287, -0.034702316 , 0.115230063 , 0.069569107, -0.040867463,
                         0.006908441 ,-0.027647986 , 0.009994290 ,-0.023988381, -0.056369949,
                         -0.034825980 ,-0.005052085 , 0.011831883 ,-0.017554183 , 0.013786555,
                         0.000456210)

testNodeResiduals <- function(){
  failedTestsNodeResiduals <- list()
  
  error <- tryCatch({
    test_that("Check node residuals HTS",{
      expect_equal(get_node_residuals(values_to_check_against$hts_arima_model$forecasts,'Total'),total_node_residuals,tolerance=1e-5)
      expect_equal(get_node_residuals(values_to_check_against$hts_arima_model$forecasts,'1'),one_node_residuals,tolerance=1e-5)
      expect_equal(get_node_residuals(values_to_check_against$hts_arima_model$forecasts,'2'),two_node_residuals,tolerance=1e-5)
})
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsNodeResiduals[length(failedTestsNodeResiduals) + 1] <- as.character(error)
  } 
  
  if (length(failedTestsNodeResiduals) == 0) {
    return("Node Residuals Test Passed")
  }
  else{
    return(failedTestsNodeResiduals)
  }  
}

testResultsNodeResiduals <- testNodeResiduals()
if (testResultsNodeResiduals != "Node Residuals Test Passed") {
  allTestsResults['Node Residuals Test'] <- testResultsNodeResiduals
}

testDownloadForecast <- function(){
  failedTestsDownloadForecast <- list()
  
  hts_val_time <- values_to_check_against$hts_val_time
  
  downloaded_forecast <- download_forecast_hts(values_to_check_against$hts_arima_model,"Total","Total",hts_val_time,"Occupancy","Yearmonth")
  
  error <- tryCatch({
    test_that("Check download forecast colnames HTS",{
      expect_equal(colnames(downloaded_forecast),c("Yearmonth","Total","X1","X2"))
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsDownloadForecast[length(failedTestsDownloadForecast) + 1] <- as.character(error)
  } 
  
  error <- tryCatch({
    test_that("Check download forecast class HTS",{
      expect_equal(class(downloaded_forecast),"data.frame")
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsDownloadForecast[length(failedTestsDownloadForecast) + 1] <- as.character(error)
  }
  
  if (length(failedTestsDownloadForecast) == 0) {
    return("Download Forecast Test Passed")
  }
  else{
    return(failedTestsDownloadForecast)
  }
}

testResultsDownloadForecast <- testDownloadForecast()
if (testResultsDownloadForecast != "Download Forecast Test Passed") {
  allTestsResults['Download Forecast Test'] <- testResultsDownloadForecast
}



testHTSPlots <- function(){
  failedResultsHTSPlots <- list()
  
  hts_data <- values_to_check_against$hts_data
  model <- values_to_check_against$hts_arima_model
  hts_level <- 'Total'
  hts_node <- 'Total'
  hts_data_time <- values_to_check_against$hts_data_time
  hts_train_time <- values_to_check_against$hts_train_time
  hts_val_time <- values_to_check_against$hts_val_time
  corporate_forecast_data <- NULL
  yVar <- NULL
  
  plt <- plotHts(hts_data,model,hts_level ,hts_node,hts_data_time,hts_train_time,hts_val_time,corporate_forecast_data=corporate_forecast_data,yVar=yVar)
  
  error <- tryCatch({
    test_that("Check HTS Plot class",{
      expect_is(plt,c("plotly","htmwidget"))
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedResultsHTSPlots[length(failedResultsHTSPlots) + 1] <- as.character(error)
  }
  
  if (length(failedResultsHTSPlots) == 0) {
    return("HTS Plot Test Passed")
  }
  else{
    return(failedResultsHTSPlots)
  }
}

testResultsHTSPlots <- testHTSPlots()
if (testResultsHTSPlots != "HTS Plot Test Passed") {
  allTestsResults['HTS Plot Test'] <- testResultsHTSPlots
}

testRAMSize <- function(){
  failedTestsRAMSize <- list()
  OSType <- Sys.info()['sysname']
  
  error <- tryCatch({
    test_that("Check RAM Size",{
       expect_is(findRAMSize(OSType),"numeric")
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsRAMSize[length(failedTestsRAMSize) + 1] <- as.character(error)
  }
  
  if (length(failedTestsRAMSize) == 0) {
    return("RAM Size Test Passed")
  }
  else{
    return(failedTestsRAMSize)
  }
}

testResultsRAMSize <- testRAMSize()
if (testResultsRAMSize != "RAM Size Test Passed") {
  allTestsResults['RAM Size Test'] <- testResultsRAMSize
}

testGetImpuationMethod <- function(){
  failedTestsGetImputationMethod <- list()
  
  error <- tryCatch({
    test_that("Get Imputation Method",{
      expect_equal(get_imputation_method_name("locf"),"Last Observation carry Forward")
      expect_equal(get_imputation_method_name("nocb"),"Next Observation carry Backward")
      expect_equal(get_imputation_method_name("interpolation"),"Interpolation")
      expect_equal(get_imputation_method_name("mean"),"Mean")   
      expect_equal(get_imputation_method_name("median"),"Median") 
      expect_equal(get_imputation_method_name("mode"),"Mode")
      expect_equal(get_imputation_method_name("kalman"),"Kalman Smoothing and State Space Models")
      expect_equal(get_imputation_method_name("ma"),"Weighted Moving Average")
      expect_equal(get_imputation_method_name("replace"),"Replace with a specific value")
      expect_equal(get_imputation_method_name("seadec"),"Seasonal Decomposition")
      expect_equal(get_imputation_method_name("seasplit"),"Seasonal Split")      
      
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsGetImputationMethod[length(failedTestsGetImputationMethod) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Get Imputation Method if NULL",{
      expect_equal(get_imputation_method_name(NULL),NULL)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsGetImputationMethod[length(failedTestsGetImputationMethod) + 1] <- as.character(error)
  }
  
  if (length(failedTestsGetImputationMethod) == 0) {
    return("Imputation Method Test Passed")
  }
  else{
    return(failedTestsGetImputationMethod)
  }
}

testResultsGetImputationMethod <- testGetImpuationMethod()
if (testResultsGetImputationMethod != "Imputation Method Test Passed") {
  allTestsResults['Imputation Method Test'] <- testResultsGetImputationMethod
}

testReconciliationTable <- function(){
  failedTestsReconciliationTable <- list()
  
  hts_level <- 0
  hts_node <- 'Total'
  tdsga_arima_model <- values_to_check_against$hts_arima_model
  comb_arima_model <- values_to_check_against$hts_arima_model_comb
  HierarchyColumns <- "UID"
  
  tdgsa_recon_table <- get_reconciliation_table(hts_data,hts_level,hts_node,tdsga_arima_model,HierarchyColumns,"tdgsa")
  
  comb_recon_table <- get_reconciliation_table(hts_data,hts_level,hts_node,comb_arima_model,HierarchyColumns,"comb")
  
  error <- tryCatch({
    test_that("Check Reconciliation Table Top Down approach",{
      expect_equal(tdgsa_recon_table,values_to_check_against$recon_table_tdgsa)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsReconciliationTable[length(failedTestsReconciliationTable) + 1] <- as.character(error)
  }
  
  error <- tryCatch({
    test_that("Check Reconciliation Table Optimal Combination aaproach",{
      expect_equal(comb_recon_table,values_to_check_against$recon_table_comb)
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsReconciliationTable[length(failedTestsReconciliationTable) + 1] <- as.character(error)
  }
  
  if (length(failedTestsReconciliationTable) == 0) {
    return("Reconciliation Table Test Passed")
  }
  else{
    return(failedTestsReconciliationTable)
  }
}

testResultsReconciliationTable <- testReconciliationTable()
if (testResultsReconciliationTable != "Reconciliation Table Test Passed") {
  allTestsResults['Reconciliation Test'] <- testResultsReconciliationTable
}



testRoundOffDataFrame <- function(){
  failedTestsRoundOffDataFrame <- list()
  
  test_df <- data.frame(a=c(0.23456,0.12345),b=c(0.12324,0.12633))
  
  error <- tryCatch({
    test_that("Check Round off DF",{
      expect_equal(roundOffDataFrame(test_df,TRUE,2),data.frame(a=c(0.23,0.12),b=c(0.12,0.13)))
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsRoundOffDataFrame[length(failedTestsRoundOffDataFrame) + 1] <- as.character(error)
  }
  
  if (length(failedTestsRoundOffDataFrame) == 0) {
    return("Round Off Test Passed")
  }
  else{
    return(failedTestsRoundOffDataFrame)
  }
}

testResultsRoundOffDataFrame <- testRoundOffDataFrame()
if (testResultsRoundOffDataFrame != "Round Off Test Passed") {
  allTestsResults['Round Off Test'] <- testResultsRoundOffDataFrame
}

testImputeTS <- function(){
  failedTestsImputeTS <- list()
  
  data_level <- "day"
  
  data_missing <- utils::read.csv("../JenkinsTestData/hotel_data_missing.csv")
  data_missing$Date <- parse_date_time(data_missing$Date,"ymd")
  
  
  data_missing_NA <- pad(data_missing,interval = data_level)
  
  input <- list()
  input[['interpolation_option']] <- "linear"
  input[['kalman_model']] <- "auto.arima"
  input[['moving_avg_method']] <- "Simple Moving Average"
  input[['moving_avg_window']] <- 1
  input[['replace_fill']] <- 0.54
  
  error <- tryCatch({
    test_that("Check imputation",{
      expect_equal(impute_ts(data_missing_NA,"locf",input)[10,]['Occupancy'][[1]],0.4017994,tolerance=1e-6)
      expect_equal(impute_ts(data_missing_NA,"nocb",input)[10,]['Occupancy'][[1]],0.4570239,tolerance=1e-6)
      expect_equal(impute_ts(data_missing_NA,"interpolation",input)[10,]['Occupancy'][[1]],0.4294117,tolerance=1e-6)
      expect_equal(impute_ts(data_missing_NA,"kalman",input)[10,]['Occupancy'][[1]],0,tolerance=1e-6)
      expect_equal(impute_ts(data_missing_NA,"mean",input)[10,]['Occupancy'][[1]],0.4501282,tolerance=1e-6)
      expect_equal(impute_ts(data_missing_NA,"median",input)[10,]['Occupancy'][[1]],0.4350396,tolerance=1e-6)
      expect_equal(impute_ts(data_missing_NA,"mode",input)[10,]['Occupancy'][[1]],0.111419,tolerance=1e-6)
      expect_equal(impute_ts(data_missing_NA,"replace",input)[10,]['Occupancy'][[1]],0.54,tolerance=1e-6)
      
      
      
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsImputeTS[length(failedTestsImputeTS) + 1] <- as.character(error)
  }  
  
  if (length(failedTestsImputeTS) == 0) {
    return("Impute TS Test Passed")
  }
  else{
    return(failedTestsImputeTS)
  }
}

testResultsImputeTS <- testImputeTS()
if (testResultsImputeTS != "Impute TS Test Passed") {
  allTestsResults['Impute TS Test'] <- testResultsImputeTS
}

testMissingValues <- function(){
  failedTestsMissingValues <- list()
  
  output <- list()
  
  correct_check <- update_ui_and_text_if_missing_values(5,5,output)
  missing_check <- update_ui_and_text_if_missing_values(6,5,output)
  inequal_check <- update_ui_and_text_if_missing_values(5,6,output)
  
  error <- tryCatch({
    test_that("Check missing value text",{
      expect_equal(correct_check$missing_value_text(),"The data doesn't have missing values")
      expect_equal(missing_check$missing_value_text(),"The data has missing DateTime values")
      expect_equal(inequal_check$missing_value_text(),"The data has duplicate values or inequally spaced time intervals")
      
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsMissingValues[length(failedTestsMissingValues) + 1] <- as.character(error)
  }

  error <- tryCatch({
    test_that("Check missing value ui",{
      expect_equal(correct_check$imputation_ui(),NULL)
      expect_error(missing_check$imputation_ui())
      expect_equal(inequal_check$imputation_ui(),NULL)
      
    })
  },error = function(e){return(e)})
  
  if (!isTRUE(error)) {
    failedTestsMissingValues[length(failedTestsMissingValues) + 1] <- as.character(error)
  }

  if (length(failedTestsMissingValues) == 0) {
    return("Missing Value UI Test Passed")
  }
  else{
    return(failedTestsMissingValues)
  }  
}

testResultsMissingValues <- testMissingValues()
if (testResultsMissingValues != "Missing Value UI Test Passed") {
  allTestsResults['Missing Value UI Test'] <- testResultsMissingValues
}