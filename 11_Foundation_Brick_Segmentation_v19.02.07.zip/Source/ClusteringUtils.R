#############
## LOADING ##
#############

git_url <- NULL
project_issue_url <- NULL
session_url <- NULL
# packages <- NULL
comparisonMetrics <- NULL
modelsAvailable <- NULL
samplingIter <- NULL
projectID <- 130

loadGlobals <- function () {
  git_url <<- "http://mugitlab.mu-sigma.com/api/v3"
  project_issue_url <<- "http://mugitlab.mu-sigma.com/api/v3/projects/95/issues"
  session_url <<- "http://mugitlab.mu-sigma.com/api/v3/session"
  projectID <<- 130
  # packages <<- c ("shinyjs", "pander", "stats", "class", "ggplot2", "cluster", "clustMixType",
  #                "stringr", "ggdendro", "flashClust", "tempR", "kohonen", "factoextra", "fpc",
  #                "stats", "wmtsa", "jmotif", "wavelets", "EMCluster", "dendextend", "reshape",
  #                "data.table", "shiny", "NbClust", "sp", "deldir", "MASS", "dplyr", "nFactors",
  #                "klaR", "R.devices", "svdvisual", "qgraph", "httr", "rjson", "shinyBS", "knitr",
  #                "shiny", "TSclust", "Rtsne", "fastICA", "coloredICA", "httr", "threejs", "pryr", 
  #                "colourpicker", "grDevices", "fifer")
  packages <<- c ("grDevices", "prettydoc", "rmarkdown", "reshape", "fpc", "ggplot2", "MASS", "cluster",
                  "threejs", "data.table", "sp", "deldir", "dplyr", "TSclust", "clustMixType", "klaR",
                  "stats", "dendextend","flashClust", "EMCluster", "kohonen","R.devices","wavelets", "seewave",
                  "nFactors", "Rtsne","fastICA","coloredICA","NbClust", "DT", "qgraph", "pryr", "dummies", "caret","factoextra","svdvisual")
  dbPackages <<- c("rJava","RPostgreSQL","RMySQL","RSQLite","DBI","RJDBC","odbc")
  comparisonMetrics <<- c ("Number of clusters" = "cluster.number",
                          "% of points in largest cluster" = "maxSize",
                          "% of points in smallest cluster" = "minSize",
                          "Avg distance between clusters" = "average.between",
                          "Avg distance within clusters" = "average.within",
                         "Ratio of average distance within to between clusters" = "wb.ratio",
                         "Widest within-cluster gap" = "widestgap",
                         "Avg silhouette width" = "avg.silwidth")
  modelsAvailable <<- c ("kmeans" = "K-Means", "hclust" = "Agglomerative hierarchical",
                        "diana" = "Divisive hierarchical", "som" = "Self-Organizing Maps",
                        "em" = "Expectation Maximization", "wong" = "Wong's Two-Step Method")
  samplingIter <<- 10
  ## For test cases relative paths
  if(file.exists("Source/packageList.csv")){
    packageList <<- read.csv("Source/packageList.csv")
  } else if(file.exists("packageList.csv")){
    packageList <<- read.csv("packageList.csv")
  } else {
    packageList <<- NULL
  }
}

findRAMSize <- function (osType) {
  if (osType  ==  "Windows") {
    maxRAM <- as.numeric(memory.limit()) * 1024 ^ 2
  } else if (osType  ==  "Linux") {
    maxRAM <- floor(as.numeric(system("awk '/MemTotal/ {print $2}' /proc/meminfo", intern = TRUE)) / 1024) * 1024 ^ 2
  } else if (osType  ==  "Darwin") {
    cmdOutput <- system("sysctl hw.memsize", intern = TRUE)
    maxRAM <- substr(cmdOutput, 13, nchar(cmdOutput))
    maxRAM <- (as.numeric(maxRAM) / (1024 * 1024)) * 1024 ^ 2
  } else {
    maxRAM <- 102400 * 1024 ^ 2
  }
  return(maxRAM)
}

# roundOffDataFrame <- function(data, roundOff = FALSE, precision = 4)
# {
#   if(roundOff) {
#     data <- as.data.frame(sapply(data, function (x) {
#                 y <- class(x)
#                 if(y == "numeric") {
#                     return(round(x, precision))
#                 }else if(y == "factor"){
#                   return(as.character(x))
#                 }
#                 return(x)
#             }))
#   }
#   return(data)
# }

avgColor <- function(primaryColor, secondaryColor){
  pc <- grDevices::col2rgb(primaryColor)[,1]
  sc <- grDevices::col2rgb(secondaryColor)[,1]
  meanCol <- round(sqrt((sc ^ 2 + pc ^ 2) / 2))
  return(grDevices::rgb(255-meanCol[1], 255-meanCol[2], 255-meanCol[3], maxColorValue = 255))
}

#####################
## DOWNLOAD REPORT ##
#####################

downloadReport <- function (working_dir, reactData, input, fileName) {
  rmarkdown::render("Source/Report.Rmd",
                    params = list(working_dir = working_dir, reactData = reactData, input = input),
                    switch (input$reportDownloadFormat,
                           PrettyHTML = prettydoc::html_pretty(css = paste0(working_dir, "../Styles/pretty_styles.css")),
                           HTML = rmarkdown::html_document(css = paste0(working_dir, "../Styles/styles.css"), toc =  T, toc_float =  T)
                    ), output_dir = paste0(working_dir, "Downloads/"),
                    output_file = paste(fileName, switch (input$reportDownloadFormat,
                                                         HTML = ".html", PrettyHTML = "_pretty.html"), sep = ""))
}

###############!
## META FILE ##
###############

metaFileLoad <- function (varTypeFile, dataset) {
  alertNoMetaFile <- ""
  typeFileErrorText <- ""
  typeFileErrorTable <- ""
  typeColumnErrorText <- ""
  if (is.null(varTypeFile)) {
    typeData <- data.frame("Column" = colnames(dataset))
    typeData$Column.Type <- unname(lapply(dataset, function (x) {
      CheckColumnType(x, 0)
    }))
    alertNoMetaFile <- "NOTE: For ease of handling integer and discrete numbers, any numeric and integer columns will
be converted into factor if the number of unique values is less than 20. To prevent such conversions, upload a relevant
    meta file mentioning the variable types to be typecasted. The Data Wrangling brick can be used to generate such meta files."
  } else {
    alertNoMetaFile <- ""
    typeData <- read.csv(varTypeFile$datapath, stringsAsFactors = FALSE)
    typeData <- typeData[which(typeData$Column %in% colnames(dataset)), ]
    if (any(!(typeData$Column.Type %in% c("numeric", "factor", "character")))) {
      typeFileErrorText <- "Error : The uploaded file should be of the format"
      typeFileErrorTable <- data.frame("Column" = c("SampleColumnName1", "SampleColumnName1", "SampleColumnName1"),
                                       "Column.Type" = c("numeric", "factor", "character"),
                                       "Reference.Level" = c(NA, "Yes", "Male"))
    }
    if (!all(colnames(dataset) %in% typeData$Column)) {
      typeColumnErrorText <- "Error : The variable type csv does not have entries for all columns of the dataset"
    }
  }#end of if varFileType exists
  return(list(typeData = typeData, colErr = typeColumnErrorText, typeErrorText = typeFileErrorText,
              typeErrorTable = typeFileErrorTable, noMetaAlert = alertNoMetaFile))
}

useMetaFile <- function (dataset, typeData) {
  datasetNumeric <- as.character(typeData$Column[which(typeData$Column.Type  ==  "numeric")])
  datasetNumericCategorical <- as.character(typeData$Column[which(typeData$Column.Type  ==  "factor")])
  datasetStringCategorical <- as.character(typeData$Column[which(typeData$Column.Type  ==  "character")])
  datasetCategorical <- union(datasetNumericCategorical, datasetStringCategorical)
  orderedNames <- colnames(dataset)
  if (length(datasetCategorical) > 0) {
    dataset[, datasetCategorical] <- cbind.data.frame(sapply(dataset[, datasetCategorical, drop = F],
                                                            function (x) {
                                                              as.factor(as.character(x))
                                                            }),
                                                     dataset[, datasetNumeric, drop = F], stringsAsFactors = T)
  }
  if (length(datasetNumeric) > 0) {
    dataset[, datasetNumeric] <- cbind.data.frame(sapply(dataset[, datasetNumeric, drop = F],
                                                        function (x) {
                                                          as.numeric(x)
                                                        }),
                                                 dataset[, datasetCategorical, drop = F], stringsAsFactors = T)
  }
  dataset <- dataset[, orderedNames, drop = F]
  if (is.null(typeData$Reference.Level)) {
    typeData$Reference.Level <- unlist(lapply(colnames(dataset),
                                              function (x) {
                                                if (typeData[which(typeData[, "Column"]  ==  x), "Column.Type"]  ==  "factor" ||
                                                    typeData[which(typeData[, "Column"]  ==  x), "Column.Type"]  ==  "character") {
                                                  names(sort(table(dataset[, x]), decreasing = T)[1])
                                                } else {
                                                  return(NA)
                                                }
                                              })) #end of unlist
  }#end of if typeData$Reference.Level is NULL
  return(list(data = dataset, typeData = typeData, numCols = datasetNumeric, catCols = datasetCategorical))
}

standardizeData <- function (data, catColCount) {
  if (catColCount  ==  0)
    return(reshape::rescaler.data.frame(data, type = "sd"))
  numCols <- unlist(lapply(1:ncol(data), function (x) {
                 if (is.numeric(data[, x]) || is.integer(data[, x]))
                   return(x)
              }))
  data[, numCols] <- reshape::rescaler.data.frame(data[, numCols, drop = F], type = "sd")
  return(data)
}



####Min Max Normalization
##Author:- Sangeet Moy Das
normalize <- function(x){
  normalizeddf <- x 
  for (n in names(x)){
    normalizeddf[,n] <-  (x[,n] - min(x[,n])) /  (max(x[,n]) -  min(x[,n]))
  } 
  return(normalizeddf)
}

minMaxNormalizeData <- function (data, catColCount) {
  if (catColCount  ==  0)
    return(normalize(data))
  numCols <- unlist(lapply(1:ncol(data), function (x) {
    if (is.numeric(data[, x]) || is.integer(data[, x]))
      return(x)
  }))
  data[, numCols] <-normalize(data[, numCols, drop = F])
  return(data)
}
#### Min Max Normalization

#############!
## COMMONS ##
#############

findDependentColumns <- function (data, y) {
  formula <- stats::as.formula(paste0(y, " ~ ."))
  model <- stats::lm(formula, data)
  return(names(which(is.na(model$coefficients)  ==  T)))
}

handleMissingValues <- function (data, remove = T, y = NULL) {
  missN <- nrow(data[rowSums(is.na(data)) > 0, ])
  if (!is.null(missN) && missN > 0) {
    if (!remove) {
      missValueMsg <- paste0("WARNING: There are ", missN, " row(s) with missing values in the data set. Because of this, there is  a possibility that models may misbehave. Please use the 'Data Wrangling Brick' to create your analytical data set.")
    } else {
      missValueMsg <- paste0("NOTE: There are ", missN, " row(s) with missing values in the data set, which have been removed.")
    }
  } else  {
      missValueMsg <- ""
  }
  if (remove && !is.null(missN))
    data <- na.omit(data)
  return(list(data = data, mssg = missValueMsg, missTable = NULL))
}

parseInputs <- function (inputs) {
  entries <- names(inputs)[grep("_", names(inputs))]
  new_inputs <- list()
  lapply(entries, function (n) {
    i <- gregexpr("_", n)[[1]][1]
    op <- substr(n, 1, i - 1)
    s <- substr(n, i + 1, nchar(n))
    if (!(op %in% names(new_inputs))) {
      new_inputs[[op]] <<- list()
    }
    new_inputs[[op]][[paste(c(op, s), collapse = "_")]] <<- inputs[[n]]
  })
  return(new_inputs)
}

clusterMetrics <- function (data, metric, clus, primaryColor = "black") {
  if (metric != "euclidean" && metric != "manhattan")  {
    diss <- makeNiceDistMatrix(data, metric)
    stats <- fpc::cluster.stats(d = diss, clustering = clus)
    clusterTable <- unlist(lapply(1:stats$cluster.number, function (x) {
      return(stats$cluster.size[[x]])
    }))
    clusterTable <- cbind.data.frame(unlist(lapply(1:stats$cluster.number, function (x) paste0("Cluster ", x))), clusterTable)
  }
  else  {
    stats <- table(clus)
    clusterTable <- cbind.data.frame(c(unlist(lapply(1:length(stats), function (x)paste0("Cluster ", x)))), c(unlist(unname(stats))))
  }
  colnames(clusterTable) <- c("Cluster IDs", "Data Points")
  clusterTable[, "Cluster IDs"] <- as.character(clusterTable[, "Cluster IDs"])
  clusFreqPlot <- ggplot2::ggplot(clusterTable, ggplot2::aes(x = clusterTable[, "Cluster IDs"], y = clusterTable[, "Data Points"])) +
    ggplot2::geom_bar(fill = primaryColor, stat = "identity") + ggplot2::ylab("Data Points") + ggplot2::xlab("Cluster IDs") +
    ggplot2::ggtitle("Cluster Distribution") +
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5, size = 12), axis.title = ggplot2::element_text(size = 14),
          axis.text.x = ggplot2::element_text(angle = 45))
  return(clusFreqPlot)
}

findProportions <- function(charVector, colName){
  proportion <- sort(table(charVector), decreasing = T) / length(charVector)
  proportion <- proportion[1:min(10, length(proportion))]
  columnName <- paste(colName, names(proportion), sep = "_")
  proportion <- data.frame(unname(proportion))[, 2, drop=F]
  colnames(proportion) <- "Proportions"
  rownames(proportion) <- columnName
  return(proportion)
}


zScoreCatPlots <- function(data, clusters){
  #
  # The local and global proportions are for a categorical variable is taken as a Binomial distribution
  # The local proportions are standardized based onthe following URL:
  # https://stats.stackexchange.com/questions/113602/test-if-two-binomial-distributions-are-statistically-different-from-each-other
  #
  if(is.null(data) || nrow(data)<1)
    return(NULL)
  nClusters <- length(unique(clusters))
  proportionList <- list()  # the global proportion of each factor of a categorical variable
  invisible(lapply(1:ncol(data), function(x){
       colName <- colnames(data[, x, drop = F])
       proportionList[[colName]] <<- findProportions(data[, x], colName)
    })
  )#end of invisible
  plotData <- data.frame(c(NA))
  lapply(1:nClusters, function(x){
    tempData <- data.frame(c(NA))
    colnames(tempData) <- "Proportions"
    lapply(1:ncol(data), function(y){
      indexes <- which(clusters == x)
      clusData <- data[indexes, , drop = F]
      colName <- colnames(clusData)[y]
      localProportion <- findProportions(clusData[, y], colName)
      numerator <- localProportion - proportionList[[colName]]
      p_hat <- (nrow(clusData) * localProportion + nrow(data) * proportionList[[colName]]) / (nrow(clusData) + nrow(data))
      denominator <- sqrt( (p_hat * (1 - p_hat)) * (1/nrow(data) + 1/nrow(clusData)) )
      zScore <- numerator / denominator
      tempData <<- rbind.data.frame(tempData, zScore)
    })
    plotData <<- cbind.data.frame(plotData, tempData)
  })
  plotData <- plotData[, 2:ncol(plotData), drop = F]   # Dropping the first column with NAs
  plotData <- na.omit(plotData)
  colnames(plotData) <- unlist(paste0("Cluster", 1:nClusters))
  plotData <- cbind.data.frame(rownames(plotData), plotData)
  colnames(plotData)[1] <- "ColumnName"
  # This function returns a data frame of the same structure as kCentreData in zScorePlots
  return(plotData)
}


zScorePlots <- function (data, centers, primaryColor, secondaryColor, clusters) {
  catCols <- unlist(lapply(1:ncol(data), function (x) {
    if (is.factor(data[, x]) || is.character(data[, x]))
      return(x)
  }))
  plotList <- list()
  kCentreData <- centers[setdiff(rownames(centers), catCols), -1, drop = F]
  rows <- rownames(kCentreData)
  if (nrow(kCentreData) > 1)  {
    kCentreData <- data.frame(sapply(kCentreData, as.numeric))
  } else  {
    lapply(1:length(kCentreData), function (x) {
       kCentreData[x] <<- as.numeric(kCentreData[x])
    })
    kCentreData <- data.frame(kCentreData)
  }
  if (length(kCentreData) > 1)  {
    kCentreData <- cbind.data.frame(rows, kCentreData[,, drop = F])
  } else  {
    kCentreData <- cbind.data.frame(rows, t(kCentreData))
  }
  colnames(kCentreData)[1] <- "ColumnName"
  rownames(kCentreData) <- rows
  
  if(!is.null(catCols)){
    kCentreData <- rbind.data.frame(kCentreData, zScoreCatPlots(data[, catCols, drop = F], clusters))
  }
  kCentreData <- na.omit(kCentreData)
  lapply(2:ncol(kCentreData), function (x) {
    categ <- as.factor(ifelse(kCentreData[, x] > 1.96, "1", ifelse(kCentreData[, x] < (-1.96), "2", "3")))
    g <- ggplot2::ggplot(kCentreData, ggplot2::aes(x = rownames(kCentreData), y = kCentreData[, x])) + 
      ggplot2::geom_col(ggplot2::aes(fill = categ)) + ggplot2::xlab("Variables") + 
      ggplot2::ylab("Z-score") + ggplot2::coord_flip() + 
      ggplot2::geom_hline(yintercept = c(1.96, -1.96), color = avgColor(primaryColor, secondaryColor)) + 
      ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5), legend.position = "none") + 
      ggplot2::ggtitle(paste0("Cluster ", x - 1)) +
      ggplot2::scale_fill_manual(values = c("1" = secondaryColor, 
                                            "2" = secondaryColor, 
                                            "3" = primaryColor))
    plotList <<- append(plotList, list(g))
  })
  return(plotList)
}

generateSilPlot <- function (df, x, primaryColor) {
  g <- ggplot2::ggplot(df) + ggplot2::geom_line(ggplot2::aes_string(x = "K", y = "Silhouette"), colour = primaryColor) +
    ggplot2::theme(legend.position = "none") +
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5, size = 12), axis.title = ggplot2::element_text(size = 14)) +
    ggplot2::ggtitle(paste0("Plot of Average Silhouette Width for different K")) + ggplot2::xlab("Number of clusters") +
    ggplot2::ylab("Average Silhouette Width") + ggplot2::scale_x_continuous(breaks = df[, "K"]) +
    ggplot2::geom_vline(ggplot2::aes(xintercept = x), linetype = "dotted")
  return(g)
}

generateQuickPeekSammons <- function (data, primaryColor, secondaryColor) {
    colorGradient <- grDevices::colorRampPalette(c(primaryColor, secondaryColor))(nrow(data))
    points <- as.data.frame(MASS::sammon(cluster::daisy(unique(data), "euclidean"), k = 3)$points)
    colnames(points) <- lapply(1:ncol(points), function (x)paste0("X", x))
    dataX <- points[, 1]
    dataY <- points[, 2]
    dataZ <- points[, 3]
    threejs::scatterplot3js(dataX, dataY, dataZ, color = colorGradient, flip.y = FALSE, size = 0.5)
}

sammonsPlot <- function (data, numCols, clusters, centroidTable, featureList, primaryColor) {
  # dplyr needs to be loaded for the pipe %>% operator to work 
  library(dplyr)
  data <- data[, numCols, drop = F]
  clusterNames <- colnames(centroidTable[, -1, drop = F])
  centroidTable <- centroidTable[numCols,, drop = F]
  centroidTable <- data.table::transpose(centroidTable)
  cols <- centroidTable[1, ]
  centroidTable <- centroidTable[-1,, drop = F]
  centroidTable <- data.frame(sapply(centroidTable, as.numeric))
  colnames(centroidTable) <- cols
  rownames(centroidTable) <- clusterNames
  centroidTable <- reshape::rescaler.data.frame(centroidTable, type = "sd")
  centroidDiss <- cluster::daisy(centroidTable, "euclidean")
  sam <- MASS::sammon(centroidDiss, trace = F)
  polygondata <- data.frame(sam$points)
  polygondata$id <- clusterNames
  vor_pts <- sp::SpatialPointsDataFrame(cbind.data.frame(polygondata$X1, polygondata$X2), polygondata, match.ID = TRUE)
  vor_desc <- tile.list.udf(deldir::deldir(vor_pts@coords[, 1], vor_pts@coords[, 2]))
  vor_polygons <- lapply(1:(length(vor_desc)), function (i) {
      tmp <- cbind( (vor_desc[[i]]$x), vor_desc[[i]]$y)
      tmp <- rbind(tmp, (tmp[1, ]))
    sp::Polygons(list(sp::Polygon(tmp)), ID = i)
  })
  vor_dat <- vor_pts@data
  rownames(vor_dat) <- sapply(slot(sp::SpatialPolygons(vor_polygons), "polygons"), slot, "ID")
  vor <- sp::SpatialPolygonsDataFrame(sp::SpatialPolygons(vor_polygons), data = vor_dat)
  sammonsdata <- na.omit(data)
  plotList <- list()
  lapply(1:length(featureList), function (j) {
      data$newcol <- clusters
      newclusvarname <- featureList[j]
      data$newone <- sammonsdata[, newclusvarname]
      scaleddata_grouped <- data %>% dplyr::group_by(newcol) %>% dplyr::mutate(avg_lf = mean(newone, na.rm = T))
      b <- scaleddata_grouped[, c("newcol", "avg_lf")]
      b <- data.frame(unique(b))
      b <- b[order(+b["newcol"]), ]
      d <- b$avg_lf
      vor_df <- ggplot2::fortify(vor)
      for (k in 1:nrow(vor_df))      {
        vor_df$varname[k] <- d[as.integer(vor_df$id[k])]
      }
      colorfill <- as.integer(as.factor(clusterNames))
      polyplots_title <- paste0("Voronoi representation of cluster centers: ", featureList[j])
      sammon_plot <- ggplot2::ggplot() +
        ggplot2::geom_map(data = vor_df, map = vor_df, ggplot2::aes(x = long, y = lat, map_id = vor_df$id, fill = varname), size = 0.25) +
        ggplot2::geom_path(data = vor_df, ggplot2::aes(x = long, y = lat, map = vor_df$id), lwd = 0.1) +
        ggplot2::geom_point(data = polygondata, ggplot2::aes(X1, X2, colour = clusterNames, size = length(table(clusters))), fill = factor(colorfill), shape = 21) +
        ggplot2::scale_size_continuous(range = c(3, 7), guide = FALSE) + ggplot2::guides(fill = ggplot2::guide_legend(title = "Color scale")) +
        ggplot2::labs(x = "X1", y = "X2") + ggplot2::labs(colour = "clusters") + ggplot2::ggtitle(polyplots_title) + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5)) +
        ggplot2::scale_fill_gradient(low = "white", high = primaryColor) + ggplot2::theme(legend.position = "bottom")
      plotList <<- append(plotList, list(sammon_plot))
  })
  detach(package:dplyr)
  return(plotList)
}

tile.list.udf <- function (object) {
  if (!inherits(object, "deldir"))
    stop("Argument \"object\" is not of class \"deldir\".\n")
  ptp <- object$summary$pt.type
  rw <- object$rw
  x.crnrs <- rw[c(1, 2, 2, 1)]
  y.crnrs <- rw[c(3, 3, 4, 4)]
  ddd <- object$dirsgs
  sss <- object$summary
  npts <- nrow(sss)
  x <- sss[["x"]]
  y <- sss[["y"]]
  z <- sss[["z"]]
  haveZ <- !is.null(z)
  i.crnr <- deldir::get.cnrind(x, y, rw)
  rslt <- list()
  ind.orig <- object$ind.orig
  for (i in 1:npts) {
    m <- as.matrix(rbind(ddd[ddd$ind1  ==  i, 1:4], ddd[ddd$ind2  ==  i, 1:4]))
    bp1 <- c(ddd[ddd$ind1  ==  i, 7], ddd[ddd$ind2  ==  i, 7])
    bp2 <- c(ddd[ddd$ind1  ==  i, 8], ddd[ddd$ind2  ==  i, 8])
    m1 <- cbind(m[, 1:2, drop = FALSE], 0 + bp1)
    m2 <- cbind(m[, 3:4, drop = FALSE], 0 + bp2)
    m <- rbind(m1, m2)
    pt <- unlist(sss[i, c("x", "y")])
    theta <- atan2(m[, 2] - pt[2], m[, 1] - pt[1])
    theta <- ifelse(theta > 0, theta, theta + 2 * pi)
    theta.0 <- sort(unique(theta))
    mm <- m[match(theta.0, theta),, drop = F]
    xx <- mm[, 1]
    yy <- mm[, 2]
    bp <- as.logical(mm[, 3])
    ii <- i.crnr %in% i
    xx <- c(xx, x.crnrs[ii])
    yy <- c(yy, y.crnrs[ii])
    bp <- c(bp, rep(TRUE, sum(ii)))
    tmp <- list(ptNum = ind.orig[i], pt = pt, x = unname(xx),
                y = unname(yy), bp = bp, area = sss[i, "dir.area"])
    if (length(ptp)) {
      tmp <- append(tmp, values = ptp[i], after = 2)
      names(tmp)[3] <- "ptType"
    }
    rslt[[i]] <- deldir::acw(tmp)
    if (haveZ) rslt[[i]]["z"] <- z[i]
  }
  class(rslt) <- "tile.list.udf"
  attr(rslt, "rw") <- object$rw
  rslt
}

makeNiceDistMatrix <- function (data, dissMeasure) {
  if (dissMeasure  ==  "euclidean" || dissMeasure  ==  "manhattan")
    return(cluster::daisy(data, metric = dissMeasure))
  if (dissMeasure  ==  "DWT")
    return(TSclust::diss.DWT(data)) #FOUNDATION BRICK WEEKLY DIGEST
  reqDim <- nrow(data)
  if (dissMeasure  ==  "DTWARP")
    return(dissDTWARP(data, reqDim))
  if (dissMeasure  ==  "PER")
    return(dissPER(data, reqDim))
  if (dissMeasure  ==  "SAX")
    return(dissSAX(data, reqDim))
}

dissDTWARP <- function (data, reqDim) {
  dumMat <- matrix(0, reqDim, reqDim)
  lapply(1:reqDim, function (i) {
    lapply(1:i, function (j, i) {
          dumMat[i, j] <<- TSclust::diss.DTWARP(data[i, ], data[j, ])
    }, i = i)
  })
  return(dumMat)
}

dissPER <- function (data, reqDim) {
  dumMat <- matrix(0, reqDim, reqDim)
  lapply(1:reqDim, function (i) {
    lapply(1:i, function (j, i) {
      dumMat[i, j] <<- TSclust::diss.DTWARP(data[i, ], data[j, ])
    }, i = i)
  })
  return(dumMat)
}

dissSAX <- function (data, reqDim) {
  dumMat <- matrix(0, reqDim, reqDim)
  lapply(1:reqDim, function (i) {
    lapply(1:i, function (j, i) {
      if (length(which( (as.numeric(data[i, ]) - as.numeric(data[j, ]))  ==  0))  ==  0) {
        dumMat[i, j] <<- TSclust::diss.MINDIST.SAX(as.numeric(data[i, ]), as.numeric(data[j, ]), 3, 4)
      }
    }, i = i)
  })
  return(dumMat)
}

#############!
## K-MEANS ##
#############

kMeansMainModelCall <- function (type, data, k, metric = "euclidean", iter = 30, algo = "Lloyd", dissMeasure = NULL) {
  if (type  ==  "kmedoids") {
    return(kMedoidsModel(data, k, iter, metric))
  } else if (type  ==  "kmodes") {
    return(kModesModel(data, k, iter))
  } else if (type  ==  "kproto") {
    return(kProtoModel(data, k, iter))
  } else {
    return(kMeansModel(data, k, iter, metric, algo))
  }
}

kMeansDissMatrixCentroids <- function (data, clusters) {
  k <- length(table(clusters))
  centroids <- matrix(unlist(lapply(1:k, function (x) {
    clusData <- data[which(clusters == x),, drop = F]
    unlist(sapply(clusData, function (y) {
      if (is.factor(y) || is.character(y)) {
        val <- names(sort(table(y), decreasing = T)[1])
      } else {
        n <- ceiling(length(y) / 2)
        y <- sort(y)[n]
        val <- y #round(y, 3)
      }
    }))
  })), ncol = k, byrow = F, dimnames = list(colnames(data), lapply(1:k, function (x)paste0("Cluster", x))))
  centroids <- as.data.frame(centroids)
  centroidToReturn <- cbind.data.frame(Features = rownames(centroids), centroids)
  return(centroidToReturn)
}

kMeansMainClusterCentroids <- function (type, model, k) {
  if (type  ==  "kmedoids") {
    centers <- model$medoids
  } else if (type  ==  "kmodes") {
    centers <- model$modes
  } else{
    centers <- model$centers
  }
  centers <- as.data.frame(centers)
  rows <- colnames(centers)
  centers <- data.table::transpose(centers)
  centers <- cbind.data.frame(rows, centers)
  rownames(centers) <- rows
  colnames(centers) <- c("Features", unlist(lapply(1:k, function (x)paste0("Cluster", x))))
  return(centers)
}

kMeansKneePlot <- function (type, data, metric, kRange, iter, algo, primaryColor, dissMeasure = NULL, maxRows = NULL) {
  if (maxRows < nrow(data))  {
    sets <- samplingIter
  } else  {
    sets <- 1
  }
  tempData <- data
  lower <- kRange[1]
  upper <- kRange[2]
  silMeasure <- rbind.data.frame(c(lower:upper))
  for (i in 1:sets) {
    data <- tempData
    data <- data[sample(1:nrow(data))[1:maxRows],, drop = F]
    if (!is.null(dissMeasure)) {
      diss <- makeNiceDistMatrix(data, dissMeasure)
    } else {
      diss <- cluster::daisy(data, metric = metric)
    }
    df <- matrix(unlist(lapply(lower:upper, function (x) {
      model <- kMeansMainModelCall(type, data, x, metric = metric, iter = iter, algo = algo, dissMeasure = dissMeasure)
      if (type == "kmedoids")      {
        cluster <- model$clustering
      } else   {
        cluster <- model$cluster
      }
      if (var(model$cluster) == 0)
        return(NULL)
      sil <- mean(cluster::silhouette(cluster, diss)[, 3])
      return(c(x, sil)) # round(sil, 3)))
    })), ncol = 2, byrow = T, dimnames = list(NULL, c("K", "Silhouette")))
    silMeasure <- rbind.data.frame(silMeasure, c(df[, 2]))
  }
  silMeasure <- silMeasure[-1, ]
  silMeasure <- apply(silMeasure, 2, mean)
  df <- cbind.data.frame(c(lower:upper), c(silMeasure))
  rownames(df) <- NULL
  colnames(df) <- c("K", "Silhouette")
  df <- as.data.frame(df)
  x <- as.numeric(df[which(df[, "Silhouette"]  ==  max(df[, "Silhouette"]))[[1]], "K"])
  g <- generateSilPlot(df, x, primaryColor)
  return(list(plot = g, k = x))
}

kMeansModel <- function (data, k, iter, metric, algo) {
  model <- stats::kmeans(x = data, centers = as.numeric(k), iter.max = as.numeric(iter), algorithm = algo)
  return(model)
}

kMedoidsModel <- function (data, k, iter, metric, dissMeasure = NULL) {
  if (!is.null(dissMeasure))  {
    diss <- makeNiceDistMatrix(data, dissMeasure)
    model <- cluster::pam(x = diss, k = as.numeric(k), metric = metric, diss = TRUE, keep.data = F)
  } else  {
    model <- cluster::pam(data, k = as.numeric(k), metric = metric, keep.data = F)
  }
  return(model)
}

kProtoModel <- function (data, k, iter) {
  model <- clustMixType::kproto(x = data, k = as.numeric(k), iter.max = as.numeric(iter),
                                keep.data = F, stand = T)
  return(model)
}

kModesModel <- function (data, k, iter) {
  model <- klaR::kmodes(data, modes = as.numeric(k), iter.max = iter)
  return(model)
}

kMeansClusters <- function (data, clusters, ignoredData = data.frame()) {
  if (length(ignoredData) > 0)  {
    dataToDownload <- cbind.data.frame(ignoredData, data, clusters)
    colnames(dataToDownload) <- c(colnames(ignoredData), colnames(data), "clusters")
    return(dataToDownload)
  } else
    return(cbind.data.frame(data, clusters))
}

###################!
## AGGLOMERATIVE ##
###################

hclustPlotFn <- function (model, kn) {
    dend <- stats::as.dendrogram(model)
    dend_c <- dendextend::color_branches(dend, k = kn)
    ggdend <- dendextend::as.ggdend(dend_c)
    plotObj <- ggplot2::ggplot(ggdend, horiz = TRUE, theme = NULL) +
            ggplot2::ylab("Height") +
            ggplot2::xlab("Cluster") +
            ggplot2::ggtitle("Cluster Centroids Dendogram") +
            ggplot2::theme(
              plot.title = ggplot2::element_text(hjust = 0.5),
              axis.text = ggplot2::element_text(size = 14),
              axis.text.x = ggplot2::element_text(vjust = 1, size = 18, hjust = 1)
            )
       return(plotObj)
}

truncatedDendrogram <- function (model, kRange, labels = TRUE) {
  k <- as.numeric(kRange[2])
  tmp <- sort(unique(model$height), decreasing = T)
  h <- mean(c(tmp[k], tmp[k-1]))
  dend <- stats::as.dendrogram(model)
  if (k == 1)  {
    dend <- dendextend::color_branches(dend, k = k, col = "black")
  } else {
    dend <- dendextend::color_branches(dend, k = k)
  }
  ggdend <- dendextend::as.ggdend(dend)
  g <- ggplot2::ggplot(ggdend, horiz = F, theme = NULL, nodes = T, labels = labels) +
    ggplot2::ylab("Height") +
    ggplot2::xlab("Cluster") +
    ggplot2::ggtitle("Cluster Centroids Dendogram") +
    ggplot2::theme(
      plot.title = ggplot2::element_text(hjust = 0.5),
      axis.text = ggplot2::element_text(size = 12),
      axis.text.x = ggplot2::element_text(vjust = 1, size = 12, hjust = 1)
    )
  if (k > 1)
    g <- g + ggplot2::geom_abline(intercept = h, slope = 0, linetype = "dashed")
  plotObj <- ggplot2::ggplot_build(g)$data
  yLim <- max(plotObj[[1]]$y, plotObj[[2]]$y) #* 0.01
  yLim <- ifelse(yLim < 1, yLim * 0.2, yLim * 0.1)
  g <- g + ggplot2::expand_limits(y = -yLim)
  return(g)
}

hclustModel  <- function (data, method, metric) {
  if (metric  ==  "euclidean" || metric  ==  "manhattan")  {
    model <- flashClust::flashClust(cluster::daisy(data, metric = metric), method = method, members = NULL)
  } else{
    model <- flashClust::flashClust(stats::as.dist(makeNiceDistMatrix(data, metric)), method = method, members = NULL)
  }
  return(model)
}

hClustClusters <- function (data, model, k, ignoredData = data.frame()) {
  clusters <- dendextend::cutree(model, k = k)
  if (length(ignoredData) > 0)  {
    dataToDownload <- cbind.data.frame(ignoredData, data, clusters)
    colnames(dataToDownload) <- c(colnames(ignoredData), colnames(data), "clusters")
    return(dataToDownload)
  } else
    return(cbind.data.frame(data, clusters))
}

hierarchicalCentroids <- function (data, model, k) {
  clusters <- dendextend::cutree(stats::as.hclust(model), k)
  centroids <- matrix(unlist(lapply(1:k, function (x) {
                    clusData <- data[which(clusters == x),, drop = F]
                    unlist(sapply(clusData, function (y) {
                       if (is.factor(y) || is.character(y)) {
                         val <- names(sort(table(y), decreasing = T)[1])
                       } else {
                         val <- mean(y) # round(mean(y), 3)
                       }
                    }))
                })), ncol = k, byrow = F, dimnames = list(colnames(data), lapply(1:k, function (x)paste0("Cluster", x))))
  centroids <- as.data.frame(centroids)
  centroidToReturn <- cbind.data.frame(Features = rownames(centroids), centroids)
  return(centroidToReturn)
}

hierarchicalKneePlotGen <- function (data, model, metric, method, kRange, primaryColor) {
  kRange <- as.numeric(kRange)
  lower <- kRange[1]
  upper <- ifelse(nrow(data) <= kRange[2], nrow(data) - 1, kRange[2])
  if (metric  !=  "euclidean" && metric  !=  "manhattan")  {
    diss <- makeNiceDistMatrix(data, metric)
  } else  {
    diss <- cluster::daisy(data, metric = metric)
  }
  df <- matrix(unlist(lapply(lower:upper, function (x) {
    cluster <- dendextend::cutree(stats::as.hclust(model), k = x)
    if (var(cluster) == 0)
      return(c(x, 0))
    sil <- mean(cluster::silhouette(cluster, diss)[, 3])
    return(c(x, sil)) # round(sil, 3)))
  })), ncol = 2, byrow = T, dimnames = list(NULL, c("K", "Silhouette")))
  df <- as.data.frame(df)
  x <- df[which(df[, "Silhouette"]  ==  max(df[, "Silhouette"]))[[1]], "K"]
  g <- generateSilPlot(df, x, primaryColor)
  return(list(plot = g, k = x))
}

##############
## DIVISIVE ##
##############
dianaModel <- function (data, metric) {
  if (metric  !=  "euclidean" && metric  !=  "manhattan") {
    model <- cluster::diana(makeNiceDistMatrix(data, metric), diss = T, keep.data = F)
  } else{
    model <- cluster::diana(cluster::daisy(data, metric = metric), diss = T, keep.data = F)
  }
  return(model)
}

dianaClusters <- function (data, model, k, ignoredData = data.frame()) {
  clusters <- dendextend::cutree(stats::as.hclust(model), k = k)
  if (length(ignoredData) > 0)  {
    dataToDownload <- cbind.data.frame(ignoredData, data, clusters)
    colnames(dataToDownload) <- c(colnames(ignoredData), colnames(data), "clusters")
    return(dataToDownload)
  } else
    return(cbind.data.frame(data, clusters))
}

#################!
## MODEL-BASED ##
#################

emKneePlot <- function (data, metric, method, kRange, iter, primaryColor, maxRows = NULL) {
  if (maxRows < nrow(data))  {
    sets <- samplingIter
  } else  {
    sets <- 1
  }
  tempData <- data
  lower <- kRange[1]
  upper <- kRange[2]
  silMeasure <- rbind.data.frame(c(lower:upper))
  logMeasure <- rbind.data.frame(c(lower:upper))
  for (i in 1:sets)  {
    data <- tempData
    data <- data[sample(1:nrow(data))[1:maxRows],, drop = F]
    diss <- cluster::daisy(data, metric = metric)
    logLikelihood <- c()
    df <- matrix(unlist(lapply(lower:upper, function (x) {
      model <- emModel(data, x, method, iter = iter)
      logLikelihood <<- c(logLikelihood, model$llhdval)
      if (var(model$class) == 0)      {
        return(NULL)
      }
      cluster <- model$class
      sil <- mean(cluster::silhouette(cluster, diss)[, 3])
      return(c(x, sil)) # round(sil, 3)))
    })), ncol = 2, byrow = T, dimnames = list(NULL, c("K", "Silhouette")))
    silMeasure <- rbind.data.frame(silMeasure, c(df[, 2]))
    logMeasure <- rbind.data.frame(logMeasure, c(logLikelihood))
  }
  # Silhouette plot
  silMeasure <- silMeasure[-1, ]
  silMeasure <- apply(silMeasure, 2, mean)
  df <- cbind.data.frame(c(lower:upper), c(silMeasure))
  rownames(df) <- NULL
  colnames(df) <- c("K", "Silhouette")
  df <- as.data.frame(df)
  x <- df[which(df[, "Silhouette"]  ==  max(df[, "Silhouette"]))[[1]], "K"]
  gS <- generateSilPlot(df, x, primaryColor)
  # Loglikelihood plot
  logMeasure <- logMeasure[-1, ]
  logMeasure <- apply(logMeasure, 2, mean)
  df <- cbind.data.frame(c(lower:upper), c(logMeasure))
  rownames(df) <- NULL
  colnames(df) <- c("K", "LogLikelihood")
  df <- as.data.frame(df)
  gL <- ggplot2::ggplot(df) + ggplot2::geom_line(ggplot2::aes_string(x = "K", y = "LogLikelihood"), colour = primaryColor) +
    ggplot2::theme(legend.position = "none") +
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5, size = 12), axis.title = ggplot2::element_text(size = 14)) +
    ggplot2::ggtitle(paste0("Log-Likelihood of data for estimated parameters across different K")) +
    ggplot2::xlab("Number of clusters") + ggplot2::ylab("Total Log-Likelihood") + ggplot2::scale_x_continuous(breaks = df[, "K"])
  return(list(silPlot = gS, logPlot = gL, k = x))
}

emModel <- function (data, k, method, iter = 10) {
  # The package needs to be loaded since the EM function calls have dependencies on the loading of the library
  library(EMCluster)
  data <- reshape::rescaler.data.frame(data, type = "sd")
  emobj <- EMCluster::init.EM(x = as.matrix(data), nclass = as.numeric(k),
                              method = method, min.n.iter = iter)
  model <- EMCluster::emcluster(as.matrix(data), emobj, assign.class = T)
  detach(package:EMCluster)
  return(model)
}

emClusterCentroids <- function (data, model, dummyNames) {
  rows <- setdiff(colnames(data), dummyNames)
  cols <- unlist(lapply(1:model$nclass, function (x)paste0("Cluster", x)))
  colnames(model$Mu) <- colnames(data)
  ###########
  centroidTable <- model$Mu
  centroidTable <- data.table::transpose(data.frame(centroidTable))
  centroidTable <- cbind.data.frame(colnames(data), centroidTable)
  colnames(centroidTable) <- c("Feature", cols)
  rownames(centroidTable) <- centroidTable[, "Feature"]
  ###########
  model$Mu <- data.frame(model$Mu[, setdiff(colnames(data), dummyNames), drop = F])
  model$Mu <- data.table::transpose(model$Mu)
  model$Mu <- cbind.data.frame(rows, model$Mu)
  colnames(model$Mu) <- c("Features", cols)
  rownames(model$Mu) <- rows
  return(list(centroidTable = centroidTable, zScoreTable = model$Mu))
}

#########!
## SOM ##
#########
somModel <- function (data, xdim, ydim, rlen, alpha, mode, topography, neighbourhood)  {
  som_grid <- kohonen::somgrid(xdim = xdim, ydim = ydim, topo = topography, neighbourhood.fct = neighbourhood)
  model <- kohonen::supersom(data = as.matrix(data), grid = som_grid, rlen = as.numeric(rlen), alpha = as.numeric(alpha),
                             mode = mode, keep.data = T)
  return(model)
}

somTrainingGraph <- function (model, primaryColor) {
  df <- cbind.data.frame(c(1:nrow(model$changes)), model$changes)
  colnames(df) <- c("X", "Y")
  g <- ggplot2::ggplot(df, ggplot2::aes(x = X, y = Y)) + ggplot2::geom_line(colour = primaryColor) + ggplot2::xlab("Iterations") + ggplot2::ylab("Mean distance to closest unit") +
    ggplot2::ggtitle("Training progress") + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5, size = 12), axis.title = ggplot2::element_text(size = 14)) +
    ggplot2::theme(legend.position = "none")
  return(g)
}

somComponentPlanes <- function (model, data) {
  lim <- ncol(kohonen::getCodes(model, 1))
  plotList <- c()
  lapply(1:lim, function (x) {
    plotList <<- append(plotList, list(x))
  })
  return(plotList)
}

somClustersFunc <- function (model, k) {
  mapClusters <- dendextend::cutree(stats::hclust(stats::dist(model$codes[[1]])), as.numeric(k))
  codes <- data.frame(model$codes[[1]])
  codes <- cbind.data.frame(codes, mapClusters)
  colnames(codes)[ncol(codes)] <- "Cluster"
  clusters <- codes[model$unit.classif, "Cluster"]
  return(list(clusters = clusters, mapCluster = mapClusters))
}

coolBlueHotRed <- function (n, alpha = 1) {
  grDevices::rainbow(n, end = 4 / 6, alpha = alpha)[n:1]
}

somUMatrix <- function (model) {
  p <- R.devices::capturePlot(plot(model, type = "dist.neighbours", heatkey = T, codeRendering = "stars",
                                   keepMargins = T, shape = "straight", palette.name = coolBlueHotRed, heatkeywidth = 0.4))
  return(p)
}

somShowClusters <- function (model, k, clusters, origPlot) {
  plot.new()
  p <- R.devices::capturePlot({
    grDevices::replayPlot(origPlot)
    kohonen::add.cluster.boundaries(model, clusters)
  })
  return(p)
}

somCentroids <- function (model, k, metric) {
  diss <- cluster::daisy(data.frame(model$codes[[1]]), metric)
  clusters <- dendextend::cutree(stats::hclust(diss), k)
  data <- data.frame(sapply(data.frame(model$codes[[1]]), function (x) as.numeric(x))) # round(as.numeric(x), 3)))
  centroids <- matrix(unlist(lapply(1:k, function (x) {
    clusData <- data[which(clusters == x),, drop = F]
    unlist(sapply(clusData, function (y) {
      if (is.factor(y) || is.character(y)) {
        val <- names(sort(table(y), decreasing = T)[1])
      } else {
        val <- mean(y) # round(mean(y), 3)
      }
    }))
  })), ncol = k, byrow = F, dimnames = list(colnames(data), unlist(lapply(1:k, function (x)paste0("Cluster", x)))))
  centroids <- as.data.frame(centroids)
  centroidToReturn <- cbind.data.frame(Features = rownames(centroids), centroids)
  return(centroidToReturn)
}

############!
## WONG'S ##
############

wongKmeansCentroids <- function (type, model, k) {
  centroids <- kMeansMainClusterCentroids(type, model, k)
  rows <- colnames(centroids[, -1])
  cols <- rownames(centroids)
  centroids <- data.table::transpose(centroids[, -1, drop = F])
  centroids <- data.frame(centroids)
  colnames(centroids) <- cols
  rownames(centroids) <- rows
  return(centroids)
}

wongFinalCentroids <- function (data, k, clusters) {
  centroids <- matrix(unlist(lapply(1:k, function (x) {
    clusData <- data[which(clusters == x),, drop = F]
    unlist(sapply(clusData, function (y) {
      if (is.factor(y) || is.character(y)) {
        val <- names(sort(table(y), decreasing = T)[1])
      } else {
        val <- mean(y) # round(mean(y), 3)
      }
    }))
  })), ncol = k, byrow = F, dimnames = list(colnames(data), lapply(1:k, function (x)paste0("Cluster", x))))
  centroids <- as.data.frame(centroids)
  centroidToReturn <- cbind.data.frame(Features = rownames(centroids), centroids)
  return(centroidToReturn)
}

simpleMatching <- function (x, y) {
  denominator <- length(x)
  numerator <- sum(unlist(lapply(1:denominator, function (i) {
        if (x[, i]  !=  y[, i])
           return(1)
        return(0)
  })))
  return(numerator / denominator)
}

customDist <- function (x, y) {
  catCols <- colnames(x)[!unname(sapply(data.frame(x), is.numeric))]
  if (length(catCols) == 0)
    return(sum( (x - y) ^ 2))
  numCols <- setdiff(colnames(x), catCols)
  numDist <- 0
  catDist <- 0
  if (length(numCols)  !=  0)
    numDist <- sum( (x[, numCols] - y[, numCols]) ^ 2)
  catDist <- simpleMatching(x[, catCols], y[, catCols])
  return(numDist + catDist)
}

wongIsLinked <- function (centroids, i, j, nVals) {
  midPoint <- lapply(1:length(centroids[i,, drop = F]), function (x) {
                  if (is.numeric(centroids[i, x, drop = F])) {
                    return(as.numeric(mean(centroids[i, x, drop = F], centroids[j, x, drop = F])))
                  } else {
                    if (nVals[i] > nVals[j])
                      return(centroids[i, x, drop = F])
                    return(centroids[j, x, drop = F])
                  }
              })
  midPoint <- data.frame(midPoint)
  dMid <- customDist(centroids[i,, drop = F], midPoint)
  iterator <- setdiff(1:nrow(centroids), c(i, j))
  lapply(iterator, function (k) {
       if (customDist(centroids[k,, drop = F], midPoint) < dMid)
         return(FALSE)
  })
  return(TRUE)
}

wongFMeasure <- function (n, wss, centroid, i, j) {
  if (i  ==  j)
    return(0)
  p <- ncol(centroid)
  numerator <- (n[[i]] + n[[j]])  ^  (1 + (p / 2))
  term <- (n[[i]] + n[[j]]) * customDist(centroid[i,, drop = F], centroid[j,, drop = F]) / 4
  denominator <- (wss[[i]] + wss[[j]] + term)  ^  (p / 2)
  return(numerator / denominator)
}

wongConstructF <- function (clusterN, clusterWSS, clusterCentroids) {
  k <- length(clusterN)
  m <- matrix(rep(0, k * k), nrow = k, ncol = k)
  lapply(1:k, function (i) {
     lapply(1:i, function (j) {
        m[i, j] <<- m[j, i] <<- wongFMeasure(clusterN, clusterWSS, clusterCentroids, i, j)
     })
  })
  return(m)
}

wongKmeansWss <- function (model) {
  wss <- data.frame(model$withinss)
  wss <- data.table::transpose(wss)
  wss <- sapply(data.frame(wss), function (x) x) #round(x, 3))
  names <- unlist(lapply(1:length(model$withinss), function (x)paste0("Cluster ", x)))
  wss <- cbind.data.frame(names, wss)
  colnames(wss) <- c("Cluster IDs", "Within sum of squares of each cluster")
  return(wss)
}

wongDistanceMatrix <- function (fMatrix, centroids, nVals) {
  k <- nrow(fMatrix)
  D <- matrix(rep(NA, k * k), nrow = k, ncol = k)
  lapply(1:k, function (i) {
    lapply(1:i, function (j) {
      if (i == j) {
        D[i, j] <<- D[j, i] <<- 0
      } else if (wongIsLinked(centroids, i, j, nVals)) {
        D[i, j] <<- D[j, i] <<- 1 / fMatrix[i, j]
      } else
        D[i, j] <<- D[j, i] <<- .Machine$double.xmax
    })
  })
  D <- data.frame(D)
  return(D)
}

wongHclust <- function (fMatrix, centroids, distanceMatrix) {
  model <- stats::hclust(stats::as.dist(distanceMatrix), method = "single")
  return(model)
}

wongHclustKneePlot <- function (model, kRange, dMatrix, primaryColor) {
  kRange <- as.numeric(kRange) - 1
  diss <- dMatrix
  df <- matrix(unlist(lapply(1:kRange, function (x) {
    cluster <- dendextend::cutree(stats::as.hclust(model), k = x)
    if (var(cluster) == 0)
      return(c(x, 0))
    sil <- mean(cluster::silhouette(cluster, diss)[, 3])
    return(c(x, sil)) # round(sil, 3)))
  })), ncol = 2, byrow = T, dimnames = list(NULL, c("K", "Silhouette")))
  df <- as.data.frame(df)
  x <- df[which(df[, "Silhouette"]  ==  max(df[, "Silhouette"]))[[1]], "K"]
  g <- generateSilPlot(df, x, primaryColor)
  return(list(plot = g, k = x))
}

wongAssignClusters <- function (clusters, hclustModel, k) {
  newClusts <- dendextend::cutree(hclustModel, k)
  return(unname(newClusts[clusters]))
}

############

fft0 <- function (z, inverse ) {
  n <- length(z)
  if (n  ==  0) return(z)
  k <- 0:(n - 1)
  ff <- (if (inverse) 1 else -1) * 2 * pi * 1i * k / n
  return(vapply(1:n, function (h) sum(z * exp(ff * (h - 1))), complex(1)))
}

runFourierTransform <- function (x, inverseFlag, totalTime) {
  acq.freq <- length(x) / totalTime      # data acquisition frequency (Hz)
  ts  <- seq(0, (totalTime - 1 / acq.freq), 1 / acq.freq) # vector of sampling time-points (s)
  if (inverseFlag  ==  T) {
    X.k <- fft0(as.matrix(x), inverse = TRUE)
    x.n <- get.trajectory(X.k, ts, acq.freq = acq.freq) / acq.freq
    freqPlotData <- plot.frequency.spectrum(X.k)
    max.y <- ceiling(1.5 * max(Mod(x.n)))
    min.y <- ceiling(-1.5 * max(Mod(x.n)))

    return(list(freqPlotData, X.k, ts, x.n, max.y, min.y))
  } else{
     X.k <- fft0(as.matrix(x), inverse = FALSE)
    x.n <- get.trajectory(X.k, ts, acq.freq = acq.freq) / acq.freq
    freqPlotData <- plot.frequency.spectrum(X.k)
    max.y <- ceiling(1.5 * max(Mod(x.n)))
    min.y <- ceiling(-1.5 * max(Mod(x.n)))

    return(list( freqPlotData, X.k, ts, x.n, max.y, min.y))
  }
}

simpleDFT <- function (x, inverseFlag) {
  transformedData <- apply(x, 1, function (x)fft0(x, inverseFlag))
  return(data.frame(t(transformedData)))
}


runFFTonVector <- function (dataPoint, coverage) {
  specData <- stats::spectrum(fft(dataPoint), plot = FALSE)
  sortedSpecDensity <- sort(specData$spec, decreasing = TRUE)
  for (index in 1:length(specData$spec)) {

    if (sum(sortedSpecDensity[1:index]) / sum(sortedSpecDensity) >= coverage) {
      chosenIndex <- index
      break
    } else {
      chosenIndex <- length(specData$spec)
    }
  }
  threshold <- sortedSpecDensity[chosenIndex]
  indexList <- which(specData$spec >=  threshold)
  freqList <- numeric(length(sortedSpecDensity))
  # freqList[indexList] <- round(specData$freq[indexList], 3)
  return(t(freqList))
}


simpleFFT <- function (dataFrame, coverage = 0.95) {
  z <- data.frame(t(apply(dataFrame, 1, function (x)runFFTonVector(x, coverage))))
  return(z)
}

fftCompressed <- function (x, inverseFlag) {
  finalDim <- as.integer( (dim(x)[2]) / 2)
  transformedData <- apply(x, 1, function (x)(Re(fft(x, inverseFlag) * Im(fft(x, inverseFlag)))[1:finalDim]))
  return(data.frame(t(transformedData)))
}

runFastFourierTransform <- function (x, inverseFlag, totalTime) {
  acq.freq <- length(x) / totalTime      # data acquisition frequency (Hz)
  ts  <- seq(0, (totalTime - 1 / acq.freq), 1 / acq.freq) # vector of sampling time-points (s)
  if (inverseFlag  ==  T) {
    X.k <- fft(as.matrix(x), inverse = TRUE)
    x.n <- get.trajectory(X.k, ts, acq.freq = acq.freq) / acq.freq
    freqPlotData <- plot.frequency.spectrum(X.k)
    max.y <- ceiling(1.5 * max(Mod(x.n)))
    min.y <- ceiling(-1.5 * max(Mod(x.n)))
    return(list(freqPlotData, X.k, ts, x.n, max.y, min.y))
  } else{
     X.k <- fft(as.matrix(x), inverse = FALSE)
    x.n <- get.trajectory(X.k, ts, acq.freq = acq.freq) / acq.freq
    freqPlotData <- plot.frequency.spectrum(X.k)
    max.y <- ceiling(1.5 * max(Mod(x.n)))
    min.y <- ceiling(-1.5 * max(Mod(x.n)))
    return(list(freqPlotData, X.k, ts, x.n, max.y, min.y))
  }
}


runDWT <- function (x) {
  namBcp <- rownames(x)
  wtData <- NULL
  for (i in 1:nrow(x)) {
    a <- t(x[i, ])
    wt <- wavelets::dwt(a, filter = "haar", boundary = "periodic")
    wtData <- rbind(wtData, unlist(c(wt@W, wt@V[[wt@level]])))
  }
  wtData <- as.data.frame(wtData)
  rownames(wtData) <- namBcp
  return(wtData)
}

runPCA <- function (dataFrameForPCA, coverage) {
  nameBcp <- rownames(dataFrameForPCA)
  data <- as.matrix(dataFrameForPCA)
  pcaOut <- stats::prcomp(data, center = TRUE, scale = TRUE)
  for (j in 1:length(pcaOut$sdev)) {
    covered <- sum(pcaOut$sdev[1:j]) / sum(pcaOut$sdev)
    if (covered >=  coverage) {
      pc.use <- j
      break
    }
  }
  truncatedData  <- pcaOut$x[, 1:pc.use]
  truncatedData <- data.frame(truncatedData)
  # truncatedData <- round(data.frame(truncatedData), 2)
  rownames(truncatedData) <- nameBcp
  return(list("pcaOut" = pcaOut, "truncatedData" = truncatedData))
}

runSVD <- function (x, coverage) {
  nameBcp <- rownames(x)
  s <- svd(x)
  U <- s$u
  V <- s$v
  D <- diag(s$d) ##turn it into a matrix
  for (j in 1:length(s$d)) {
    covered <- sum(s$d[1:j]) / sum(s$d)
    if (covered >=  coverage) {
      k <- j
      break
    }
  }
  sol.U <- U[, 1:k] %*% D[1:k, 1:k] %*% t(V[, 1:k])
  datNames <- c()
  for (i in 1:dim(sol.U)[2]) {
    datNames <- c(datNames, paste0("V", as.character(i)))
  }
  res <- data.frame(sol.U) #round(data.frame(sol.U), 2)
  names(res) <- c(datNames)
  rownames(res) <- nameBcp
  return(list(data = res, svdObj = s))
}

runSAX <- function (x, alphabetSize, numOutDim, brkPtStyle) {
  returnObj <- apply(x, 1, function (b)as.numeric(as.factor(seewave::SAX(b, alphabet = alphabetSize, PAA = numOutDim, breakpoints = brkPtStyle))))
  return(data.frame(t(returnObj)))
}

# returns the x.n time series for a given time sequence (ts) and
# a vector with the amount of frequencies k in the signal (X.k)
get.trajectory <- function (X.k, ts, acq.freq) {
  N <- length(ts)
  i <- complex(real = 0, imaginary = 1)
  x.n <- rep(0, N)           # create vector to keep the trajectory
  ks  <- 0:(length(X.k) - 1)
  for (n in 0:(N - 1)) {
    x.n[n + 1] <- sum(X.k * exp(i * 2 * pi * ks * n / N)) / N
  }
  x.n * acq.freq
}

plot.frequency.spectrum <- function (X.k, xlimits = c(0, length(X.k))) {
  plot.data  <- cbind(0:(length(X.k) - 1), Mod(X.k))
  # TODO: why this scaling is necessary?
  plot.data[2:length(X.k), 2] <- 2 * plot.data[2:length(X.k), 2]
  return(plot.data)
}

# Plot the i-th harmonic
# Xk: the frequencies computed by the FFt
#  i: which harmonic
# ts: the sampling time points
# acq.freq: the acquisition rate
plot.harmonic <- function (Xk, i, ts, acq.freq, color = "red") {
  Xk.h <- rep(0, length(Xk))
  Xk.h[i + 1] <- Xk[i + 1] # i-th harmonic
  harmonic.trajectory <- get.trajectory(Xk.h, ts, acq.freq = acq.freq)
  points(ts, harmonic.trajectory, type = "l", col = color)
}

makeDataUsingWindows <- function (data, windowType, windowSize) {
  # data is expected to be a vector
  # windowType = movWin or rollWin
  # windowSize is an integer
  data <- as.vector(as.matrix(data))
  if (windowType  ==  "movWin") {
    newData <-  lapply(1 : (length(data) - windowSize), function (x) data[x : (x + windowSize - 1)])
  } else if (windowType  ==  "rollWin") {
    newData <-  lapply(seq(1, length(data), windowSize), function (x) data[x:(x + (windowSize - 1))])
  }
  return(na.omit(data.table::transpose(data.frame(newData))))
}

#####################
## FACTOR ANALYSIS ##
#####################

factorScree <- function (data, primaryColor, secondaryColor) {
  fac_data <- na.omit(reshape::rescaler.data.frame(data, type = "sd"))
  ev <- eigen(stats::cor(fac_data, use = "pairwise.complete.obs"))
  ev.values <- ev$values
  ev.values <- as.data.frame(ev.values)
  aparallel <- as.data.frame(nFactors::parallel(subject = nrow(fac_data), var = ncol(fac_data), rep = 100, cent = .05)$eigen$qevpea)
  return(ggplot2::ggplot(ggplot2::aes(x = 1:nrow(cbind(ev.values, aparallel)),
                    y = ev.values, color =  "Eigen-Values"),
                data = cbind(ev.values, aparallel)) +  ggplot2::geom_point(color = primaryColor) + ggplot2::geom_line(size = 1, color = primaryColor) +
           ggplot2::labs(title = "Scree Plot") + ggplot2::xlab("Component") + ggplot2::ylab("Eigen Values") +
           ggplot2::geom_hline(yintercept = 1, linetype = "dashed", color = secondaryColor) + ggplot2::theme(legend.position = "none") +
           ggplot2::scale_y_continuous(breaks = round(seq(0, 10, by = 1), 1)) + ggplot2::scale_x_continuous(breaks = 1:nrow(cbind(ev.values, aparallel))))
}

makeFactors <- function (data, numFactors, lowerUniqueness) {
  fac_data <- na.omit(reshape::rescaler.data.frame(data, type = "sd"))
  k <- as.numeric(numFactors)
  p <- ncol(fac_data)
  if (!( ( (p - k) ** 2 > (p + k)) && k <=  p))  {
    return(list(result = NULL, message = "Invalid number of factors. Select a lower number and submit again.", columnKey = NULL, graphObj = NULL))
  } else  {
    a <- tryCatch({
            factor_model <- stats::factanal(fac_data, as.numeric(k), rotation = "varimax", lower = lowerUniqueness)
            columnKey <- data.frame("ID" = c(1:ncol(fac_data)), "ColumnName" = colnames(fac_data))
            return(list(result = (as.matrix(fac_data) %*% loadings(factor_model)), message = NULL, columnKey = columnKey, graphObj = factor_model))
          }, error = function (e) {
            return(list(result = NULL, message = "Cannot converge to a solution for current set of hyperparameters", columnKey = NULL, graphObj = NULL))
          })
  }
}

runTSNE <- function (data, desiredDims, perp, itercnt) {
  tryCatch({
    return(list(data = Rtsne::Rtsne(data, dims = desiredDims, perplexity = perp, verbose = FALSE, max_iter = itercnt), errorMsg = NULL))
  }, error = function (e) {
    if (grepl("Perplexity is too large", as.character(e))) {
      msg <- "Perplexity is too large"
    }
    else{
      msg <- as.character(e)
    }
    return(list(data = NULL, errorMsg = msg))
  })
}

runICA <- function (data, numComps, iterCnt) {
  tryCatch({
    return(list(result = data.frame(fastICA::fastICA(data, n.comp = numComps, maxit = iterCnt, verbose = FALSE)$S), errorMsg = NULL))
  }, error = function (e) {
    return(list(result = NULL, errorMsg = as.character(e)))
  })
}

runColoredICA <- function (data, nComp, iterCnt) {
  rownames(data) <- 1:nrow(data)
  data <- t(t(t(data)))
  tryCatch({
    return(list(data = t(data.frame( (coloredICA::cICA(data, M = nComp, tol = 0.0001, maxit = iterCnt, nmaxit = 5)$S))), errorMsg = NULL))
  }, error = function (e) {
    return(list(data = NULL, errorMsg = as.character(e)))
  })
}

################!
## COMPARISON ##
################

computeStats <- function (data, k, clusters, metrics, distMetric = "euclidean") {
  if (distMetric != "euclidean" && distMetric != "manhattan") {
    diss <- makeNiceDistMatrix(data, distMetric)
  } else {
    diss <- cluster::daisy(data, distMetric)
  }
  stats <- fpc::cluster.stats(d = diss, clustering = clusters, silhouette = T, wgap = T)
  metricVal <- c()
  if ("ccc" %in% metrics) {
    x <- NbClust::NbClust(data = data, index = "ccc", method = "average")
    metricVal[["Cubic Clustering Criterion"]] <- x$All.index[[as.character(k)]]
  }
  if ("maxSize" %in% metrics)
    metricVal[["% of points in largest cluster"]] <- max(stats$cluster.size) * 100 / sum(stats$cluster.size)
  if ("minSize" %in% metrics)
    metricVal[["% of points in smallest cluster"]] <- min(stats$cluster.size) * 100 / sum(stats$cluster.size)
  metricList <- setdiff(metrics, c("maxSize", "minSize", "ccc"))
  metricList <- names(metrics)[which( unname(metrics) %in% metricList)]
  vals <- unlist(lapply(metricList, function (x) {
    return(stats[[metrics[[x]]]])
  }))
  names(vals) <- metricList
  metricVal <- c(metricVal, vals)
  return(metricVal)
}

customStratifiedSampling <- function(data, maxRows) {
  # This function assumes that the data.frame contains a column names "clusters"
  # This function creates a sample that may not have uniform distribution but ensures that all clusters
  #  are represented in the sample
 
  data$clusters <- factor(as.character(data$clusters))
  freqTable <- table(data$clusters)
  sampledData <- data.frame()
  lapply(1:length(freqTable), function(x){
    sampLen <- min(freqTable[[x]], maxRows/nrow(data))
    sampledData <<- rbind.data.frame(sampledData, sample_n(data[which(data$clusters == names(freqTable[x])),,drop=F], sampLen))
  })
  return(sampledData)
}

computeStatsSampling <- function (data, k, clusters, metrics, distMetric = "euclidean", maxRows = NULL) {
  if (!is.null(maxRows) && maxRows < nrow(data))  {
    metricTable <- data.frame(metrics)
    # data <- cbind.data.frame(clusters, data)
    # colnames(data)[1] <- "clusters"
    
    samplingIndex <- caret::createDataPartition(clusters, samplingIter, maxRows/nrow(data))
    lapply(samplingIndex, function(x){
       sampData <- data[x,,drop=F]
       metricTable <<- cbind.data.frame(metricTable, unname(computeStats( data[x,,drop=F], k, clusters[x], metrics, distMetric)[names(metrics)]))
    })
    
    # data <- data[, -1]
    metricTable <- apply(metricTable[, -1], 1, mean)
    return(metricTable)
  } else
    return(computeStats(data, k, clusters, metrics, distMetric))
}

populateComparisonTable <- function (rd, models, metrics, maxRows) {
  cols <- names(models)
  models <- unname(models)
  colVals <- unlist(lapply(models, function (x) {
    rd[[x]]$metricTable <<- computeStatsSampling(rd$dataset, as.numeric(rd[[x]]$k), rd[[x]]$clusters,
                                                 metrics, rd[[x]]$metric, maxRows)
  }))
  metricTable <- data.frame(unname(rd[[models[[1]]]]$metricTable[names(metrics)]))
  if (length(models) > 1)
    lapply(2:length(models), function (x)({
      metricTable <<- cbind.data.frame(metricTable, unname(rd[[models[[x]]]]$metricTable[names(metrics)]))
    }))
  # metricTable <- sapply(metricTable, round, 3)
  metricTable <- cbind.data.frame(names(metrics), metricTable)
  colnames(metricTable) <- c("Metrics", cols)
  return(metricTable)
}

comparisonMetricTable <- function (rd, models, metrics) {
  cols <- names(models)
  metricTable <- cbind.data.frame(unname( (rd[[models[[1]]]]$metricTable[, 2])))
  if (length(models) > 1)
    lapply(2:length(models), function (x)({
        metricTable <<- cbind.data.frame(metricTable, unname( (rd[[models[[x]]]]$metricTable[, 2])))
    }))
  # metricTable <- data.frame(sapply(metricTable, round, 3))
  metricTable <- cbind.data.frame(as.character(rd[[models[[1]]]]$metricTable[, 1]), metricTable)
  colnames(metricTable) <- c("Metrics", cols)
  rownames(metricTable) <- as.character(metricTable[, 1])
  metricTable <- metricTable[names(metrics),, drop = F]
  return(metricTable)
}

clusterPlot <- function (data, clusters, f1, f2, clus) {
  rows <- clus[, 1]
  clus <- data.frame(data.table::transpose(clus))
  colnames(clus) <- rows
  clus <- clus[-1, c(f1, f2), drop = F]
  clus <- sapply(clus, as.numeric)
  rows <- rownames(data)
  data <- cbind.data.frame(rows, data[, c(f1, f2), drop = F], clusters)
  colnames(data) <- c("Names", f1, f2, "ClusterID")
  data[, "ClusterID"] <- as.factor(data[, "ClusterID"])
  data[, "Names"] <- as.factor(data[, "Names"])
  
  
  g <- ggplot2::ggplot(data, ggplot2::aes_string(x = f1, y = f2, colour = "ClusterID")) + ggplot2::geom_point() +
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5, size = 12), axis.title = ggplot2::element_text(size = 14)) +
    ggplot2::ggtitle("Plot of clusters as represented by two features") + ggplot2::xlab(f1) + ggplot2::ylab(f2) + 
    ggplot2::theme(legend.position = "none") 
    # annotate("text", x = clus[, f1] +  ( (max(clus[, f1]) - min(clus[, f1])) * 0.07 / 2),
    #          y = clus[, f2] + ( (max(clus[, f2]) - min(clus[, f2])) * 0.1 / 2),
    #          label = unlist(lapply(1:nrow(clus), function (x)paste0("bold(ClusterID: ", as.character(x), ")"))), parse = T) +
    # annotate("point", x = clus[, f1], y = clus[, f2])
  
  tmp <- cbind.data.frame(paste0("Cluster", c(1:nrow(clus))), clus[,f1], clus[,f2], c(1:nrow(clus)))
  colnames(tmp) <- colnames(data)
  data <- rbind.data.frame(data, tmp)
  data <- cbind.data.frame(data, c(rep(1, nrow(data) - nrow(clus)), rep(5, nrow(clus))))
  colnames(data)[ncol(data)] <- "Size"
  
  g <- g + ggplot2::geom_point(data = data[(nrow(data)-nrow(clus)+1):nrow(data),,drop=F], 
                      ggplot2::aes_string(x = f1, y = f2, colour = "ClusterID"), size = 3) + 
    ggplot2::geom_point(data = data[(nrow(data)-nrow(clus)+1):nrow(data),,drop=F], 
                  ggplot2::aes_string(x = f1, y = f2), size = 3, shape = 1, colour = "black", stroke = 1)
  
  return(g)
}
