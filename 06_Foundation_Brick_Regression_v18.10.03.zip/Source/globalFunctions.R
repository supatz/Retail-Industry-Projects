
#-- Transforming the input parameters based on the input type selected : CSV/ DB
# Converts parameters to make them compatible with the platform on which it is running: R/ SQL Database
paraTransform <- function(connType,filters,groupby,funcSel,operationSel,argValue){
  filters <- trimws(filters)
  groupby <- trimws(groupby)
  funcSel <- trimws(funcSel)
  operationSel <- trimws(operationSel)
  argValue <- trimws(argValue)
  
  if(is.null(connType)){
    operationSel <- ifelse(operationSel=='=','==',operationSel)
    operationSel <- ifelse(operationSel=='in','%in%',operationSel)
    funcSel <- ifelse(funcSel=='avg','mean',funcSel)
    filters <- gsub(' = ','==',filters)
    filters <- gsub(' in ',' %in% ',filters)
    if(funcSel=='column'){ #-- Column Comparison - transforming parameters
      filters <- paste(if(filters!='') paste(filters,' & '),'!',colSel,operationSel,argValue)
      funcSel <- 'length'
      operationSel <- '=='
      argValue <- 0
    }
    
  } else {
    operationSel <- ifelse(operationSel=='==','=',operationSel)
    operationSel <- ifelse(operationSel=='%in%','in',operationSel)
    funcSel <- ifelse(funcSel=='mean','avg',funcSel)
    filters <- gsub('==','=',filters)
    filters <- gsub(' %in% ',' in ',filters)
  }
  return(c(filters,groupby,funcSel,operationSel,argValue))
}


#-- Treating inputs based on comparison type : Multiple File QC or Single File QC
#-- Inputs from Rule creation section are captured differently for Single Dataset and Multiple Dataset comparison cases.
#-- This function treats for the inconsitencies
inputTreatment <- function(connType,filters,groupby,colSel,funcSel,operationSel,argValue,comparison){
  
  if(comparison==1){  #-- If query involves comparison, the paramters are split on ';' to correspond to LHS and RHS  datasets
    filters <- trimws(unlist(strsplit(filters,";")))
    groupby <- trimws(unlist(strsplit(groupby,";")))
    operationSel <- trimws(unlist(strsplit(operationSel,";")))
  } else { #-- If query does not involve comparison, the values for second table will be ''
    filters <- c(filters,'')
    groupby <- c(groupby,'')
    operationSel <- c('',operationSel)   
  }
  
  colSel <- trimws(unlist(strsplit(colSel,";"))) 
  loc <- gregexpr('\\.',colSel[2])[[1]][[1]]  # Get alias of secondary dataset
  table2Alias <- substring(colSel[2],1,loc-1)
  colSel[2] <- substring(colSel[2],loc+1,nchar(colSel[2]))
  
  funcSel <- trimws(unlist(strsplit(funcSel,";")))
  funcSel <- ifelse(trimws(funcSel==''),'none',funcSel)
  
  if(length(funcSel)==1) funcSel <- trimws(c(funcSel,''))
  
  # Transform input parameters according to data connection type: CSV or DB
  paraTransform1 <- paraTransform(connType,filters[1],groupby[1],funcSel[1],operationSel[1],argValue)
  paraTransform2 <- paraTransform(connType,filters[2],groupby[2],funcSel[2],operationSel[2],argValue)
  filters <- c(paraTransform1[1],paraTransform2[1])
  groupby <- c(paraTransform1[2],paraTransform2[2])
  funcSel <- c(paraTransform1[3],paraTransform2[3])
  operationSel <- c(paraTransform1[4],paraTransform2[4])
  argValue <- argValue
  
  return(list(filters,groupby,colSel,funcSel,operationSel,argValue,table2Alias))
}


evalQuery1 <- function(data,filters,groupby,colSel,funcSel,operationSel,argValue,comparison){
  print('Evaluating Query 1')
  
  inputTreatment <- inputTreatment(data$con,filters,groupby,colSel,funcSel,operationSel,argValue,comparison)
  
  filters <- inputTreatment[[1]]
  groupby <- inputTreatment[[2]]
  colSel <- inputTreatment[[3]]
  funcSel <- inputTreatment[[4]]
  operationSel <- inputTreatment[[5]]
  argValue <- inputTreatment[[6]]
  
  operationSel <- operationSel[2]
  arithmeticSel <- operationSel[1] # unused
  
  
  if(is.null(data$con)){ # FOR CSV ---------------------
    lhs <- evaluateQuery(data,filters[1],groupby[1],colSel[1],funcSel[1],operationSel,0)
    #print(lhs)
    if(comparison=='1'){# FOR CSV - Multi Dataset Comparison ---------------------
      table2Alias <- inputTreatment[[7]]
      table2Index <- which(names(inTables$tableNames)==table2Alias)
      rhs <- evaluateQuery(list(con=NULL,table=inTables$tables[[table2Index]]$data),filters[2],groupby[2],colSel[2],funcSel[2],operationSel,0)
    } else {
      rhs <- list('',argValue,'')
    }
    
    nlhs <- nrow(lhs[[2]])
    nrhs <- nrow(data.frame(rhs[[2]]))
    
    # Multi-Multi row comparison not supported
    if(nlhs>1 & nrhs>1 & nlhs!=nrhs){
      return(list(FALSE,'LHS and RHS rows do not match',''))
    }
    
    dat <- data.frame(lhs[[2]])
    bin <- compare(funcSel,dat,colnames(dat),operationSel,unlist(rhs[[2]])) # Compare lHS and RHS
    val <- bin[[2]]
    val <- ifelse(nrow(val)>1,'Mult. Rows',ifelse(nrow(val)==0,'No Rows returned in one of the queries',round(val,3)))
    bin <- list(bin[[1]],val,'')
    return(bin)
    
  } else {# FOR DB ---------------------
    if(comparison==0){
      bin <- evaluateQuery_db(data,filters[1],groupby[1],colSel[1],funcSel[1],operationSel,argValue)
      return(bin)
    } else { # FOR DB - Multi Table Comparison ---------------------
      
      table2Alias <- inputTreatment[[7]]
      table2Index <- which(names(inTables$tableNames)==table2Alias)
      table2Name <- inTables$tableNames[table2Index]
      
      # Direct column comparison case within primary dataset.
      # Can be handled by evaluateQuery_db function instead of considering both sides separately
      if(table2Alias == 'A' & funcSel[1]=='none' & funcSel[2]=='none' ){ 
        argValue <- colSel[2]
        bin <- evaluateQuery_db(data,filters[1],groupby[1],colSel[1],funcSel[1],operationSel,argValue)
        return(bin)
      }
      
      
      lhs <- createQuery1(data,filters[1],groupby[1],colSel[1],funcSel[1],operationSel,0,'qclhstable')
      rhs <- createQuery1(list(con=data$con,table=table2Name),filters[2],groupby[2],colSel[2],funcSel[2],operationSel,0,'qcrhstable')
      
      nlhs <- dbGetQuery(data$con,'select count(*) from qclhstable;')
      nrhs <- dbGetQuery(data$con,'select count(*) from qcrhstable;')
      lhsval <- 'Mult. Rows'
      rhsval <- 'Mult. Rows'
      
      # Read values only if nrow == 1
      if(nlhs==1){ lhsval <- round(unlist(dbGetQuery(data$con,'select * from qclhstable;')),3)
      }
      if(nrhs==1){ rhsval <- round(unlist(dbGetQuery(data$con,'select * from qcrhstable;')),3)
      }
      
      if(nlhs>1 & nrhs>1 & nlhs!=nrhs){
        return(list(FALSE,'LHS and RHS rows do not match',''))
      }
      
      # Multi- Multi rows comparison not supported
      if(!((nlhs==1 | nrhs==1) | operationSel %in% c('in','not in')))
        return(list(FALSE,'Multiple row comparison on both sides not supported',''))
      
      
      # Query for LHStable and RHStable comparison
      if(operationSel %in% c('in','not in')){
        query <- paste0('select count(*) from (select distinct col from qclhstable) a join (select distinct col from qcrhstable) b on a.col = b.col ')
        query1 <- paste0('select count(distinct col) from qcrhstable')
        cnt <- dbGetQuery(data$con,query)
        cnt1 <- dbGetQuery(data$con,query1)
        res <- ifelse(operationSel=='in' & cnt==cnt1,TRUE,ifelse(operationSel=='not in' & cnt==0,TRUE,FALSE))
        
      } else {
        query <- paste0('select count(*) from (select col from qclhstable) a join (select col from qcrhstable) b on not a.col ',operationSel,' b.col')  
        res <- dbGetQuery(data$con,query)
        res <- ifelse(res>0,FALSE,TRUE)
      }
      
      dbExecute(data$con,'DROP TABLE IF EXISTS qclhstable')
      dbExecute(data$con,'DROP TABLE IF EXISTS qcrhstable')
      #print(list(res,paste0(lhsval," ; ",rhsval),''))
      return(list(res,paste0(lhsval," ; ",rhsval),''))
    }
  }
}

# Test case
# data <- list(con=con2,table='hotel3')
# table2Name <- 'hotel3'
# colSel <- c('RMS_AVAIL_QTY','RMS_AVAIL_QTY')
# funcSel <- c('sum','sum')
# groupby <- c('','')
# filters <- c('','')
# operationSel <- '='

evaluateQuery <- function(conList,filters,groupby,colSel,funcSel,operationSel,argValue){
  print('Evaluating Query')
  
  if(is.null(conList$con)){ # Local CSV ---------
    val <- evaluateQuery_local(data,filters,groupby,colSel,funcSel,operationSel,argValue)
    return(val)
  }
  else { # Database -----------
    bin <- evaluateQuery_db(data,filters,groupby,colSel,funcSel,operationSel,argValue)
    return(bin)
  }
}


# Function that evaluate all database check on single primary dataset
evaluateQuery_db <- function(data,filters,groupby,colSel,funcSel,operationSel,argValue){ 
  
  switch(funcSel
         ,'data type'={
           val <- dataType(inDataType(),colSel)
           argValue <- ifelse(argValue=='logical','bool',argValue)
           res <- ifelse(operationSel!='none',val==argValue,'')
           list(res,val,'')}
         ,{
           createQuery(data,filters,groupby,colSel,funcSel,operationSel,argValue)
         }
  )
}


# Function that evaluates either sides of the multiple datset comparison
# Function that creates the SQL query for either sides of multiple dataset QC checks
createQuery1 <- function(conList,filters,groupby,colSel,funcSel,operationSel,argValue,tbName){
  print('Evaluating query on db')
  
  tableName <- conList$table
  filter <- gsub('&','AND',gsub('\\|','OR',filters))
  groupbycols <- groupby
  
  opExpr <- operationExpr1(operationSel,argValue)
  
  #select <- paste0('select (',colExpr(colSel,funcSel),') ',opExpr,' as col')
  from <- paste('from', tableName)
  where <- filterExpr(colSel,funcSel,filter)
  groupby <- groupbycolsexpr(groupbycols,funcSel)
  
  select2 <- 'select col, count(*) as cnt '
  where2 <- ''
  
  query <- ''
  res <- ''
  val <- ''
  
  select <- paste('select (',colExpr(colSel,funcSel),') as col')
  dbExecute(conList$con,paste0('DROP TABLE IF EXISTS ',tbName))
 
  query1 <- paste('create temporary table ',tbName,' as ', select,from,where,groupby)
  val0 <- dbExecute(conList$con,query1)

  return(list('',tbName,''))
  
}


# Function that creates the SQL query for single dataset QC checks
createQuery <- function(conList,filters,groupby,colSel,funcSel,operationSel,argValue){
  print('Evaluating query on db')
  
  #creating query that returns results similar t  o fplyr function in previous code
  
  tableName <- conList$table
  filter <- gsub('&','AND',gsub('\\|','OR',filters))
  groupbycols <- groupby
  
  opExpr <- operationExpr(funcSel,colSel,operationSel,argValue)
  
  from <- paste('from', tableName)
  where <- filterExpr(colSel,funcSel,filter)
  groupby <- groupbycolsexpr(groupbycols,funcSel)
  
  select2 <- 'select col, count(*) as cnt '
  where2 <- ''
  
  # final total query
  query <- ''
  res <- ''
  val <- ''
  
  if(opExpr!='' | funcSel=='has.unique') 
  {
    select <- paste('select case when ',colExpr(colSel,funcSel),' ',opExpr,' then 1 else 0 end as col')
    query <- paste(select2,'from (',select,from,where,groupby,') sub where col = 0 group by col')
    
    res <- execSqlQuery(conList,query)
    if(nrow(res)==0) res<-data.frame()    ## No rows returned implies no FALSE conditions found.
    res <- res[res$col==0,2]
    res <- ifelse(is.null(res),TRUE,FALSE)
  }
  
  select <- paste('select (',colExpr(colSel,funcSel),') as col')
  query1 <- paste('select col ','from (',select,from,where,groupby,') sub')
  val0 <- execSqlQuery(conList,query1)
  val <- ifelse(nrow(val0)>1,'Mult. Rows',ifelse(nrow(val0)==0,'',val0[1,1]))
  
  if(val=='' & res==T){
    val <- 0
    if(!(argValue=='0' & (operationSel=='=' | operationSel=='<=' | operationSel=='>='))){
      res <- F
    }
  }
  
  # If inter select query returns no rows, then count(*) does not give 0 to check for 0/FALSE cases.
  # Since, there are no rows returned , it means that the filters are all false and any aggregation sums to 0. 
  innerQuery <- paste(select,from,where,groupby)
  return(list(res,val,innerQuery))
}

# Wrapper function 
execSqlQuery <- function(conList,query){
  table <- dbSendQuery(conList$con,query)
  res <- dbFetch(table)
  if(!class(conList$con)=="SQLiteConnection") clearResults(conList$con)
  return(res)
}

# Creates arguemtns in SELECT statement
colExpr <- function(colSel,funcSel){
  #print('colexpr')
  switch(funcSel
         ,'min'=,'max'=,'avg'=,'sum'=,'count'= paste0(funcSel,'(',colSel,')')
         ,'length'=paste0('count','(',colSel,')')
         ,'count na'=paste0('count(*)')
         ,'count distinct'=paste('count( distinct',colSel,')')
         ,'count blanks'=,'count na'=paste('count(',colSel,')')
         ,'has.unique'=paste('count( distinct',colSel,')=count(*)')
         ,'none'=,'column'= colSel
  )
}

# Creates arguments in FILTER statement
filterExpr <- function(colSel,funcSel,filter){
  minor <- switch(funcSel
                  ,'count blanks'=paste(colSel," = '' ")
                  ,'count na'= paste(colSel,'is null'),'')
  complete <- paste(if(filter!='' | minor!= '') 'where ',filter,if(minor!='' & filter!='') 'and',minor)
  #complete <- ''
  return(complete)
}


# creates comparison arguments in SELECT statement for Multiple Dataset  QC
operationExpr1 <- function(operationSel,argValue,where=0){
  expr <- switch(operationSel
                 ,'>'=,'>='=,'<'=,'<='=,'='=,'!='= paste(operationSel,argValue)
                 ,'in'=paste('in (',argValue,')')
                 ,'not in'=paste('not in (',argValue,')')
                 ,'between'={
                   vec <- as.numeric(gsub('\\(|\\)','',strsplit(argValue,',')[[1]]))
                   paste('between',vec[1],'and',vec[2]) 
                 }
                 ,'is'=,'is not'=paste(operationSel,argValue))
  return(paste0(ifelse(where,'where col',''),expr))
}

# creates arguments in FILTER statement
operationExpr <- function(funcSel,colSel,operationSel,argValue,where=0){
  if(funcSel=='has.unique') return('')
  expr <- switch(operationSel
                 ,'>'=,'>='=,'<'=,'<='=,'='=,'!='= paste(operationSel,argValue)
                 ,'in'=paste('in (',argValue,')')
                 ,'not in'=paste('not in (',argValue,')')
                 ,'between'={
                   vec <- as.numeric(gsub('\\(|\\)','',strsplit(argValue,',')[[1]]))
                   paste('between',vec[1],'and',vec[2]) 
                 }
                 ,'is'=,'is not'=paste(operationSel,argValue))
  return(paste0(ifelse(where,'where col',''),expr))
}

# creates arguments in GROUP BY statement
groupbycolsexpr <- function(groupbycols,funcSel){
  switch(funcSel
         ,'none'=''
         ,if(groupbycols!='') paste('group by',groupbycols) else '')
}



## Wrapper function for evaluating the inputs
evaluateQuery_local <- function(data,filters,groupby,colSel,funcSel,operationSel,argValue){
  
  data <- data$table
  print('Evaluating query on local')
  cmdString <- 'data'
  
  #-- Filter data if any input data filter has been provided
  if(trimws(filters)!=''){
    cmdString <- paste(cmdString,'%>% filter(',filters,')')
    data <- eval(parse(text=paste('data %>% filter(',filters,')')))
  }
  
  #-- Group by data based on the group_by columns provided
  if(trimws(groupby)!=''){ 
    cmdString <- paste(cmdString,'%>% group_by(',groupby,')')
    data <- eval(parse(text=paste('data %>% group_by(',groupby,')')))
  }
  
  #groupbyCols <- trimws(unlist(strsplit(groupby,",")))
  aggColName <- paste0(gsub(" ","_",funcSel),"_",colSel) ## This name is provided as the column name to the new aggregated columns created.
  
  #print('Computing val')
  valList <- switch(funcSel,
                    'min'=,
                    'max'=,
                    'mean'=,
                    'sum'=,
                    'median'=,
                    'length'=,
                    'count distinct'=,
                    'count na'=,
                    'count blanks'= fplyr(data,colSel,funcSel),
                    'has.unique'=hasUnique(data,colSel,funcSel),
                    'data type'=dataType(inDataType(),colSel),
                    'date format'=compare(funcSel,data[,colSel],colSel,operationSel='==',argValue),
                    'none'={
                      cmdStr <- paste('data %>% select(',colSel,')')
                      val <- eval(parse(text=cmdStr))
                      list('',val,cmdStr)  # All values must be returned in this format list(res,val,cmdString)
                    })  
  
  
  #**MAINTAIN THE ORDER OF IF CONDITIONS BELOW
  if(funcSel=='has.unique'){
    cmdString1 <- valList[[3]]
    cmdString1 <- gsub('data %>%','',cmdString1)
    valList[[3]] <- paste(cmdString,'%>%',cmdString1)
    return(valList)
  }
  
  #val <- valList
  cmdString1 <- valList[[3]]
  cmdString1 <- gsub('data %>%','',cmdString1)
  cmdString <- paste(cmdString,'%>%',cmdString1)
  valList[[3]] <- cmdString
  
  if(operationSel=='none'){
    val <- unlist(collect(valList[[2]]))
    val <- ifelse(length(val)>1,0,val)
    return(list('',val,cmdString))
  }
  
  if('tbl' %in% class(valList[[2]])){
    if(funcSel!='none')
      valList[[2]] <- valList[[2]] %>% select_(aggColName)
    else
      valList[[2]] <- valList[[2]] %>% select_(colSel)
  }
  
  #print('Comparing with arguments provided')
  #bin <- compare(funcSel,val,colSel,operationSel,argValue)
  #return(list(bin[[1]],bin[[2]],cmdString))
  #print(valList)
  return(valList)
}

# Checks for No Duplicates in a column: CSV / Data.frames
hasUnique <- function(data,colSel,funcSel){
  cmdString0 <- paste0('data %>% dplyr::select(',colSel,') %>% dplyr::summarize(n_dist=n_distinct(',colSel,'),n=n()) %>% dplyr::mutate(l=n-n_dist) %>% dplyr::ungroup() %>% dplyr::summarize(sum(l)) %>% dplyr::collect(n=Inf) %>% unlist')
  cmdString <- paste0('data %>% select(',colSel,') %>% summarize(n_dist=n_distinct(',colSel,'),n=n()) %>% mutate(l=n-n_dist) %>% ungroup() %>% summarize(sum(l)) %>% collect(n=Inf) %>% unlist')
  val <- eval(parse(text=cmdString0))
  res <- ifelse(val==0,TRUE,FALSE)
  list(res,val,cmdString)
}

#-- Evaluates the aggregation function in the QC checks for Local CSV datasets
#-- Aggregations are handled by this function. Also provides the commnand string being executed for these aggregations.
fplyr <- function(data,colSel,funcSel){
  print('Executing Summarize functions')
  
  aggColName <- paste0(gsub(" ","_",funcSel),"_",colSel)
  
  cmdString <- switch(funcSel,
                      'min'=,'max'=,'mean'=,'sum'={
                        paste0('data',' %>% summarize(',aggColName,"="
                               ,funcSel,'(as.numeric(',colSel,')',ifelse(funcSel=='length','))',',na.rm=T)) '))
                      },
                      'median'={
                        paste0('data %>% select(',colSel,') %>% filter(ntile(',colSel,', 2) == 1) %>% summarize(',aggColName,"=",'max(',colSel,'))')
                      },
                      'length'={
                        paste0('data %>% select(',colSel,') %>% summarize(',aggColName,"=",'n())')
                      },
                      'count distinct'=,'has.unique'={
                        paste0('data %>% summarize(',aggColName,"=",'n_distinct(',colSel,'))')
                      },
                      'count na'={
                        paste0('data %>% select(',colSel,') %>% filter(is.na(',colSel,')) %>% summarize(',aggColName,"=",'n())')
                      },
                      'count blanks'={
                        paste0("data %>% select(",colSel,") %>% filter(",colSel,"== '') %>% summarize(",aggColName,"=","n()) ")
                      })
  
  
  val <- eval(parse(text=cmdString))
  val <- val %>% ungroup()
  return(list('',val,cmdString))
}


#-- Evaluates the comparison in QC checks on local CSV datasets
compare <- function(funcSel,val,colSel,operationSel,argValue){
  print('Comparing with the arguments')
  
  ## **** The 'val' variable is handled such that dplyr's database results are supported. The 'collect' function works both for databases and data.frames. For databases, it queries the whole table. *** DPLYR queries below have been enforced for the same purpose so as to support databases.
  ## **** This function does not handle database queries as of now.
  vlen <- val %>%  collect() %>% nrow()
  if(vlen==1) val<-data.frame(val)   ##vlen will capture number of rows in the data. This values will be compared against no. of true /false.
  valcolsel <- colnames(val)
  
  #****DPLYR for Databases: HANDLE THE VAL variable PROPERLY. TYPES FOR VAL ARE DIFFERENT WITH AND WITHOUT SUMMARY FUNCIONS*****
  
  if(funcSel=='data type'){
    res <- (argValue==val)
    return(list(res,val))
  }
  
  if(operationSel=='%in%'){
    #if(length(unlist(strsplit(argValue,",")))==1) argValue <- paste(argValue,argValue,sep=",")
    res <- eval(parse(text=paste0("val %>% filter(",valcolsel," %in% ","argValue",") %>% summarize(n()) %>% collect %>% unlist")))
    res <- ifelse(vlen>0,res==vlen,FALSE)
    #if(nrow(val)>1) val <- 'Mult. Rows' else if(nrow(val)==0) val <- 0 else val <- round(val,3)
    return(list(res,val))
  }
  else if(operationSel=='not in'){
    #if(length(unlist(strsplit(argValue,",")))==1) argValue <- paste(argValue,argValue,sep=",")
    res <- eval(parse(text=paste0("val %>% filter(!",valcolsel," %in% ","argValue",") %>% summarize(n()) %>% collect %>% unlist")))
    res <- ifelse(vlen>0,res==vlen,FALSE)
    #if(nrow(val)>1) val <- 'Mult. Rows' else if(nrow(val)==0) val <- 0 else val <- round(val,3)
    return(list(res,val))
  }
  else if(operationSel=='between'){
    vec <- as.numeric(gsub('\\(|\\)','',strsplit(argValue,',')[[1]])) #Parse range argument as vector  grepl('\\(',argValue)
    res <- eval(parse(text=(paste('val %>% filter(',valcolsel,'>=',vec[1],' &',valcolsel,'<=',vec[2],
                                  ') %>% collect(n=Inf) %>% unlist %>% length')))) 
    res <- ifelse(vlen>0,res==vlen,FALSE)
    #if(nrow(val)>1) val <- 'Mult. Rows' else if(nrow(val)==0) val <- 0 else val <- round(val,3)
    return( list(res,val))
  }
  else
  { cString <- (paste('val %>% filter(',valcolsel,operationSel,'argValue',') %>% collect(n=Inf) %>% unlist %>% length'))
  res <- eval(parse(text= cString
  ))
  res <- ifelse(vlen>0,res==vlen,FALSE)
  return(list(res,val))
  }
  
}



dataType <- function(data,col){
  val <- data[col,2,drop=F]
  return(list('',val,''))}


dateFormat <- function(data,col){ val <- as.Date(data[,col])}


evalStr <- function(str){ eval(parse(text=str)) }


getNumCols <- function(dat){
  log <- unlist(lapply(dat,is.numeric))
  colnames(dat)[log]
}

getCharCols<- function(dat){
  log <- unlist(lapply(dat,is.character))
  colnames(dat)[log]
}







