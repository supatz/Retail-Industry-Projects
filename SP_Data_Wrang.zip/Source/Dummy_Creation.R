# #================================================================================================================================
# #	Delivery Engine: Code Repository ( R )
# #================================================================================================================================
# #	  Section - 4        :      Transformation
# #   Sub Section - 1    :      Creation of Dummy Variables
# #================================================================================================================================
# #	  Main Functions     :      DummyVarCreation
# #   Sub Functions      :      DummyVarCreationParamCheck
# #                       
# #================================================================================================================================
# #	  Details: 		              The function creates dummy variables for (n - 1)levels of the categorical variables.
# #					         	          Levels can either be user-defined or the one having least frequency. 
# #					
# #--------------------------------------------------------------------------------------------------------------------------------
# #' DummyVarCreationParamCheck()                     
# #'-------------------------------------------------------------------------------------------------------------------------------
# #'   DESCRIPTION:             Checks the validity of the input parameters for the function DummyVarCreation
# #'-------------------------------------------------------------------------------------------------------------------------------
# #'  
# #'   @param data              Dataframe containing categorical variables for which dummy variables ought to be created.
# #'   @param cutoffValue       Maximum number of categorical variables in a column
# #'	 @param outPath			      The location to which the outPut log file is to be saved
# #'	 @param fileName		      The name of the logFile created 
# #'
# #'-------------------------------------------------------------------------------------------------------------------------------
# #'   @return                  Checks the validity of each parameter and stops the function in case parameters do not match  
# #'                            pre-defined conditions.
# #'-------------------------------------------------------------------------------------------------------------------------------

# DummyVarCreationParamCheck <- function(data, outPath, fileName, cutoffValue, referenceLevel) {
  
#   #checking the existance of the dataframe and data in it
#   # if (! (is.data.frame(data) || class(data) == "data.frame"))
#   #   stop ("The class of data should be a dataframe.")
#   # if (is.null(data))
#   #   stop ("Dummy Variables cannot be created with null or zero records")
  
#   #Check if the file path mentioned is valid
#   if (length(outPath) != 1)
#     stop ("only one outpath can be specified")
#   if (class(outPath) != "character")
#     stop ("Outpath should be charecter")
#   if (!(file.exists(outPath))) 
#     stop ("Invalid location / directory path. Breaking out.")
  
#   #Check if the file name mentioned already exists / is valid
#   if (length(fileName) != 1)
#     stop ("Only a single file name can be given")
#   if (class(fileName) != "character")
#     stop ("file name should be a string")
  
#   #Checking for class and length of vector: cutoffValue 
#   if (!(class(cutoffValue) == "numeric" || class(cutoffValue) == "integer") || is.null(cutoffValue))
#     stop ("cutoffValue should be a numeric vector")
#   if (!(length(cutoffValue) == 1))
#     stop ("Sinlge integer value expected: cutoffValue")
#   if (cutoffValue < 0)
#     stop ("cutoffValue should be an positive value")
# }


# #'-------------------------------------------------------------------------------------------------------------------------------
# #' DummyVarCreation()                     
# #'-------------------------------------------------------------------------------------------------------------------------------
# #'  @description              Function to create dummy variable values for categorical columns in a data set using one-hot 
# #'                            encoding, and also drops the dummy level as per user input, or the level having least frequency
# #'-------------------------------------------------------------------------------------------------------------------------------
# #'   PARAMETERS
# #'   @param data              Dataframe containing categorical variables for which dummy variables ought to be created. 
# #'   @param cutoffValue       Maximum number of unique levels in a column, above which the column is considered numeric continuous
# #'                            (default : 20)
# #'	 @param outPath	  	   	  Location to which the outPut log file is to be saved (default : getwd())
# #'	 @param fileName	    	  Name of the logFile created (default : DummyVariableLogData)
# #'	                          
# #'-------------------------------------------------------------------------------------------------------------------------------
# #'   @return                  The dataset including the dummy variables created for the choosen columns
# #'-------------------------------------------------------------------------------------------------------------------------------

# DummyVarCreation <- function(data, outPath = getwd(), fileName = paste("DummyVariableLog_", deparse(substitute(data)), sep = ""), 
#                               referenceLevel, cutoffValue = 200) {
  
  
#   # Step - 1: Check if required packages are installed
#   #------------------------------------------------------------------------------------------------------------------------------
#   ##print ("Checking for relevant packages")
#   if (is.element("dummies", installed.packages()[, 1]) == TRUE) { 
#     library(dummies) 
#   } else {  
#     install.packages("dummies", dependencies = T, repos = "http://cran.us.r-project.org")
#     library(dummies)
#   }
  
#   DummyVarCreationParamCheck(data = data, outPath = outPath, fileName = fileName, referenceLevel = referenceLevel, cutoffValue = cutoffValue)
  

  
#   # Step - 3:  Checking data Quality
#   #------------------------------------------------------------------------------------------------------------------------------     
#   ##print ("Checking data quality")
  
#   #create empty vector
#   numVar <- c()
#   strCat <- c()
#   levelDropVec <- c()
#   rmcol <- c()
  
#   #Extracting categorical variables and converting them to factors 
#   # for (i in 1:length(data)) {
#   #   if (sum(is.na(data[,i])) == nrow(data)) {
#   #     rmcol <- c(rmcol, i)
#   #   } else {
#   #   colType <- CheckColumnType(data[[i]] , cutoffValue)
#   #   if (colType == "Numeric Continuous") {
#   #     numVar <- c(numVar, i) 
#   #   } else if (colType == "String Categorical"){
#   #     if (length(unique(data[[i]])) > cutoffValue){
#   #     strCat <- c(strCat, i)
#   #     }
#   #   }else { (!(is.factor(data[,i]))) 
#   #     data[, i] <- as.factor(data[[i]])
#   #   } 
#   #   }
#   # }
#   # 
#   # 
  
#   #log the removal of continuous numeric variable
#   # if (length(numVar) > 0 || length(strCat) > 0 || length(rmcol) > 0) {
#   #   colNamesVector <- colnames(data)
#   #   colToRem <- c(numVar, strCat, rmcol)
#   #   subData <- subset(data, select = colnames(data)[colToRem])
#   #   colNamesVector<- colNamesVector[-colToRem]
#   #   data <- as.data.frame(data[, -colToRem])
#   #   colnames(data) <- colNamesVector
#   #   }

#  if (length(data) > 0){
#    #Creating dummy columns to remove
#    dummyColsToRemove <- c()
#     for (i in 1:length(data)){ 
#       #freqDf <- data.frame(table(data[[i]]))
#       # minFreqVal <- freqDf[which.min(freqDf[, 2]), 1 ]
#       # minFreqVal <- as.character(minFreqVal)
#       data[,1] <- as.character(data[,1])
#       dummyColsToRemove <- c(dummyColsToRemove, referenceLevel)
#       levelDropVec <- c(levelDropVec, paste(colnames(data)[i], sep = "_", referenceLevel))
#     }

  

#  #creation of dummy variables 
#   dummys <- dummy.data.frame(data, sep = "_")
 
#   #Removal of columns
#   dummys <- dummys[, !colnames(dummys) %in% levelDropVec]
#   if (length(numVar) != 0 || length(strCat) != 0 || length(rmcol) !=0) {  
#     file <- as.data.frame(cbind(subData, dummys))
#   } else { 
#     file <-  dummys 
#   }
#  } else { file <- subData}

 
# #    write.csv(file,"DummyVariableCreationOutPut.csv")
#   return(file)
# }



#================================================================================================================================
# Delivery Engine: Code Repository ( R )
#================================================================================================================================
#   Section - 4        :      Transformation
#   Sub Section - 1    :      Creation of Dummy Variables
#================================================================================================================================
#   Main Functions     :      DummyVarCreation
#   Sub Functions      :      DummyVarCreationParamCheck
#                       
#================================================================================================================================
#   Details:                  The function creates dummy variables for (n - 1)levels of the categorical variables.
#                             Levels can either be user-defined or the one having least frequency. 
#         
#--------------------------------------------------------------------------------------------------------------------------------
#' DummyVarCreationParamCheck()                     
#'-------------------------------------------------------------------------------------------------------------------------------
#'   DESCRIPTION:             Checks the validity of the input parameters for the function DummyVarCreation
#'-------------------------------------------------------------------------------------------------------------------------------
#'  
#'   @param data              Dataframe containing categorical variables for which dummy variables ought to be created.
#'   @param cutoffValue       Maximum number of categorical variables in a column
#'   @param outPath           The location to which the outPut log file is to be saved
#'   @param fileName          The name of the logFile created 
#'
#'-------------------------------------------------------------------------------------------------------------------------------
#'   @return                  Checks the validity of each parameter and stops the function in case parameters do not match  
#'                            pre-defined conditions.
#'-------------------------------------------------------------------------------------------------------------------------------

DummyVarCreationParamCheck <- function(data, outPath, fileName, cutoffValue, referenceLevel) {
  
  #checking the existance of the dataframe and data in it
  # if (! (is.data.frame(data) || class(data) == "data.frame"))
  #   stop ("The class of data should be a dataframe.")
  # if (is.null(data))
  #   stop ("Dummy Variables cannot be created with null or zero records")
  
  #Check if the file path mentioned is valid
  if (length(outPath) != 1)
    stop ("only one outpath can be specified")
  if (class(outPath) != "character")
    stop ("Outpath should be charecter")
  if (!(file.exists(outPath))) 
    stop ("Invalid location / directory path. Breaking out.")
  
  #Check if the file name mentioned already exists / is valid
  if (length(fileName) != 1)
    stop ("Only a single file name can be given")
  if (class(fileName) != "character")
    stop ("file name should be a string")
  
  #Checking for class and length of vector: cutoffValue 
  if (!(class(cutoffValue) == "numeric" || class(cutoffValue) == "integer") || is.null(cutoffValue))
    stop ("cutoffValue should be a numeric vector")
  if (!(length(cutoffValue) == 1))
    stop ("Sinlge integer value expected: cutoffValue")
  if (cutoffValue < 0)
    stop ("cutoffValue should be an positive value")
}


#'-------------------------------------------------------------------------------------------------------------------------------
#' DummyVarCreation()                     
#'-------------------------------------------------------------------------------------------------------------------------------
#'  @description              Function to create dummy variable values for categorical columns in a data set using one-hot 
#'                            encoding, and also drops the dummy level as per user input, or the level having least frequency
#'-------------------------------------------------------------------------------------------------------------------------------
#'   PARAMETERS
#'   @param data              Dataframe containing categorical variables for which dummy variables ought to be created. 
#'   @param cutoffValue       Maximum number of unique levels in a column, above which the column is considered numeric continuous
#'                            (default : 20)
#'   @param outPath           Location to which the outPut log file is to be saved (default : getwd())
#'   @param fileName          Name of the logFile created (default : DummyVariableLogData)
#'                            
#'-------------------------------------------------------------------------------------------------------------------------------
#'   @return                  The dataset including the dummy variables created for the choosen columns
#'-------------------------------------------------------------------------------------------------------------------------------

DummyVarCreation <- function(columnToConvert, outPath = getwd(), fileName = paste("DummyVariableLog_", deparse(substitute(columnToConvert)), sep = ""), 
                             referenceLevel = NA, cutoffValue = 20) {
  
  
  # Step - 1: Check if required packages are installed
  #------------------------------------------------------------------------------------------------------------------------------
  ##print ("Checking for relevant packages")
  # if (is.element("dummies", installed.packages()[, 1]) == TRUE) { 
  #   library(dummies) 
  # } else {  
  #   install.packages("dummies", dependencies = T, repos = "http://cran.us.r-project.org")
  #   library(dummies)
  # }
  
  # DummyVarCreationParamCheck(data = columnToConvert, outPath = outPath, fileName = fileName, referenceLevel = referenceLevel, cutoffValue = cutoffValue)
  
  
  
  # Step - 3:  Checking data Quality
  #------------------------------------------------------------------------------------------------------------------------------     
  ##print ("Checking data quality")
  
  #create empty vector
  numVar <- c()
  strCat <- c()
  levelDropVec <- c()
  rmcol <- c()
  
  if (length(columnToConvert) > 0){
    #Creating dummy columns to remove
    dummyColsToRemove <- c()
    
    if(is.na(referenceLevel) || is.null(referenceLevel) || referenceLevel == ""){
      freqDf <- data.frame(table(columnToConvert))
      minFreqVal <- freqDf[which.min(freqDf[, 2]), 1 ]
      minFreqVal <- as.character(minFreqVal)
      referenceLevel <- minFreqVal
    }
    columnName <- names(columnToConvert)
    columnToConvert[[1]] <- as.character(columnToConvert[[1]])
    names(columnToConvert) <- columnName
    dummyColsToRemove <- c(dummyColsToRemove, referenceLevel)
    levelDropVec <- c(levelDropVec, paste(colnames(columnToConvert), sep = "_", referenceLevel))
    
    #creation of dummy variables 
    if(length(unique(columnToConvert[[1]]))>2){
      dummys <- dummies::dummy.data.frame(columnToConvert, names = colnames(columnToConvert), sep = "_")
      #Removal of columns
      dummys <- dummys[, !colnames(dummys) %in% levelDropVec]
    }else{
      # If its a binary column
      dummys <- as.data.frame(as.numeric(columnToConvert != referenceLevel))
      colnames(dummys) <- paste(colnames(columnToConvert),
                                unique(columnToConvert)[unique(columnToConvert) != referenceLevel],sep='_')
    }
    
  }
  return(dummys)
}

